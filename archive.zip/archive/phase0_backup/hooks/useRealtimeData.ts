"use client";

import { useState, useEffect, useRef, useCallback } from 'react';
import type { RealtimeConfig, RealtimeState, ErrorState } from '../lib/types/ui';

interface UseRealtimeDataOptions<T> extends Partial<RealtimeConfig> {
  fetchFn: () => Promise<T>;
  enabled?: boolean;
  onSuccess?: (data: T) => void;
  onError?: (error: ErrorState) => void;
  transform?: (data: any) => T;
}

export function useRealtimeData<T>(options: UseRealtimeDataOptions<T>) {
  const {
    fetchFn,
    interval = 30000, // 30 seconds default
    maxRetries = 3,
    retryDelay = 1000,
    pauseOnBlur = true,
    resumeOnFocus = true,
    enabled = true,
    onSuccess,
    onError,
    transform,
    dependencies = []
  } = options;

  const [state, setState] = useState<RealtimeState<T>>({
    data: null,
    isConnected: false,
    isLoading: false,
    lastUpdate: '',
    error: null,
    retryCount: 0
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const isMountedRef = useRef(true);
  const isDocumentVisible = useRef(true);
  const lastFetchTime = useRef(0);

  // Cleanup function
  const cleanup = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = null;
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
  }, []);

  // Fetch data function
  const fetchData = useCallback(async (isRetry = false) => {
    if (!enabled || !isMountedRef.current) return;

    // Prevent too frequent requests
    const now = Date.now();
    if (now - lastFetchTime.current < 1000 && !isRetry) return;
    lastFetchTime.current = now;

    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();

    try {
      setState(prev => ({ 
        ...prev, 
        isLoading: true, 
        error: isRetry ? prev.error : null 
      }));

      const rawData = await fetchFn();
      const data = transform ? transform(rawData) : rawData;

      if (!abortControllerRef.current?.signal.aborted && isMountedRef.current) {
        setState(prev => ({
          ...prev,
          data,
          isConnected: true,
          isLoading: false,
          lastUpdate: new Date().toISOString(),
          error: null,
          retryCount: 0
        }));

        onSuccess?.(data);
      }
    } catch (error: any) {
      if (error.name === 'AbortError' || !isMountedRef.current) return;

      const errorState: ErrorState = {
        message: error.message || 'Failed to fetch data',
        code: error.code || 'FETCH_ERROR',
        details: error.details || error.stack,
        timestamp: new Date().toISOString(),
        retryable: true
      };

      setState(prev => ({
        ...prev,
        isConnected: false,
        isLoading: false,
        error: errorState,
        retryCount: prev.retryCount + 1
      }));

      onError?.(errorState);

      // Auto retry logic
      if (state.retryCount < maxRetries) {
        const delay = retryDelay * Math.pow(2, state.retryCount); // Exponential backoff
        retryTimeoutRef.current = setTimeout(() => {
          if (isMountedRef.current) {
            fetchData(true);
          }
        }, delay);
      }
    }
  }, [fetchFn, enabled, transform, onSuccess, onError, state.retryCount, maxRetries, retryDelay]);

  // Start polling
  const startPolling = useCallback(() => {
    if (!enabled || intervalRef.current) return;

    // Immediate fetch
    fetchData();

    // Set up interval
    intervalRef.current = setInterval(() => {
      if (isDocumentVisible.current || !pauseOnBlur) {
        fetchData();
      }
    }, interval);

    setState(prev => ({ ...prev, isConnected: true }));
  }, [enabled, interval, pauseOnBlur, fetchData]);

  // Stop polling
  const stopPolling = useCallback(() => {
    cleanup();
    setState(prev => ({ ...prev, isConnected: false }));
  }, [cleanup]);

  // Manual refresh
  const refresh = useCallback(() => {
    setState(prev => ({ ...prev, retryCount: 0 }));
    fetchData();
  }, [fetchData]);

  // Handle visibility change
  useEffect(() => {
    if (!pauseOnBlur && !resumeOnFocus) return;

    const handleVisibilityChange = () => {
      isDocumentVisible.current = !document.hidden;

      if (document.hidden && pauseOnBlur) {
        // Pause polling when document is hidden
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      } else if (!document.hidden && resumeOnFocus) {
        // Resume polling when document becomes visible
        if (enabled && !intervalRef.current) {
          startPolling();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [pauseOnBlur, resumeOnFocus, enabled, startPolling]);

  // Handle dependencies change
  useEffect(() => {
    if (enabled) {
      refresh();
    }
  }, dependencies);

  // Start/stop polling based on enabled state
  useEffect(() => {
    if (enabled) {
      startPolling();
    } else {
      stopPolling();
    }

    return () => {
      isMountedRef.current = false;
      cleanup();
    };
  }, [enabled, startPolling, stopPolling, cleanup]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      cleanup();
    };
  }, [cleanup]);

  return {
    ...state,
    refresh,
    startPolling,
    stopPolling
  };
}

// Hook for realtime notifications
export function useRealtimeNotifications() {
  return useRealtimeData({
    fetchFn: async () => {
      const response = await fetch('/api/notifications/unread', {
        cache: 'no-store'
      });
      if (!response.ok) throw new Error('Failed to fetch notifications');
      return response.json();
    },
    interval: 15000, // 15 seconds for notifications
    maxRetries: 5,
    pauseOnBlur: true,
    resumeOnFocus: true
  });
}

// Hook for realtime dashboard data
export function useRealtimeDashboard() {
  return useRealtimeData({
    fetchFn: async () => {
      const response = await fetch('/api/dashboard/stats', {
        cache: 'no-store'
      });
      if (!response.ok) throw new Error('Failed to fetch dashboard data');
      return response.json();
    },
    interval: 60000, // 1 minute for dashboard
    maxRetries: 3,
    pauseOnBlur: false, // Keep updating dashboard in background
    resumeOnFocus: true
  });
}

// Hook for realtime work orders
export function useRealtimeWorkOrders(filters?: Record<string, any>) {
  return useRealtimeData({
    fetchFn: async () => {
      const params = new URLSearchParams(filters);
      const response = await fetch(`/api/work-orders?${params}`, {
        cache: 'no-store'
      });
      if (!response.ok) throw new Error('Failed to fetch work orders');
      return response.json();
    },
    interval: 30000, // 30 seconds for work orders
    dependencies: [JSON.stringify(filters)],
    pauseOnBlur: true,
    resumeOnFocus: true
  });
}

export default useRealtimeData;