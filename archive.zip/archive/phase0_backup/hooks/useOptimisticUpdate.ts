"use client";

import { useState, useRef, useCallback } from 'react';
import type { OptimisticUpdateConfig, OptimisticUpdateState } from '../lib/types/performance';

export function useOptimisticUpdate<T>(config: OptimisticUpdateConfig<T>) {
  const {
    entity,
    updateFn,
    revertFn,
    serverUpdateFn,
    onSuccess,
    onError,
    timeout = 10000
  } = config;

  const [state, setState] = useState<OptimisticUpdateState<T>>({
    data: entity,
    isOptimistic: false,
    isPending: false,
    error: null,
    retryCount: 0,
    lastUpdate: new Date().toISOString()
  });

  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const cleanup = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
  }, []);

  const performOptimisticUpdate = useCallback(async (): Promise<boolean> => {
    cleanup();

    // Start optimistic update
    const optimisticData = updateFn(state.data);
    setState(prev => ({
      ...prev,
      data: optimisticData,
      isOptimistic: true,
      isPending: true,
      error: null,
      lastUpdate: new Date().toISOString()
    }));

    // Set up abort controller for this request
    abortControllerRef.current = new AbortController();
    const originalData = state.data;

    try {
      // Set up timeout
      const timeoutPromise = new Promise((_, reject) => {
        timeoutRef.current = setTimeout(() => {
          reject(new Error('Update timeout'));
        }, timeout);
      });

      // Race between server update and timeout
      const serverData = await Promise.race([
        serverUpdateFn(optimisticData),
        timeoutPromise
      ]) as T;

      // Clear timeout if successful
      cleanup();

      // Check if request was aborted
      if (abortControllerRef.current?.signal.aborted) {
        return false;
      }

      // Update with server data
      setState(prev => ({
        ...prev,
        data: serverData,
        isOptimistic: false,
        isPending: false,
        error: null,
        retryCount: 0,
        lastUpdate: new Date().toISOString()
      }));

      onSuccess?.(serverData);
      return true;

    } catch (error: any) {
      // Don't revert if request was aborted
      if (error.name === 'AbortError' || abortControllerRef.current?.signal.aborted) {
        return false;
      }

      // Revert optimistic update on error
      const revertedData = revertFn(originalData);
      
      setState(prev => ({
        ...prev,
        data: revertedData,
        isOptimistic: false,
        isPending: false,
        error,
        retryCount: prev.retryCount + 1,
        lastUpdate: new Date().toISOString()
      }));

      onError?.(error, originalData);
      cleanup();
      return false;
    }
  }, [state.data, updateFn, revertFn, serverUpdateFn, onSuccess, onError, timeout, cleanup]);

  const retry = useCallback(() => {
    if (state.isPending) return;
    return performOptimisticUpdate();
  }, [state.isPending, performOptimisticUpdate]);

  const cancel = useCallback(() => {
    cleanup();
    
    // Revert to original data if optimistic
    if (state.isOptimistic) {
      setState(prev => ({
        ...prev,
        data: entity,
        isOptimistic: false,
        isPending: false,
        error: null,
        lastUpdate: new Date().toISOString()
      }));
    }
  }, [entity, state.isOptimistic, cleanup]);

  const reset = useCallback(() => {
    cleanup();
    setState({
      data: entity,
      isOptimistic: false,
      isPending: false,
      error: null,
      retryCount: 0,
      lastUpdate: new Date().toISOString()
    });
  }, [entity, cleanup]);

  return {
    ...state,
    update: performOptimisticUpdate,
    retry,
    cancel,
    reset
  };
}

// Hook for optimistic list updates
export function useOptimisticList<T extends { id: string }>(
  initialItems: T[],
  serverUpdateFn: (action: string, item: T, items: T[]) => Promise<T[]>
) {
  const [state, setState] = useState({
    items: initialItems,
    optimisticOperations: new Set<string>(),
    errors: new Map<string, Error>()
  });

  const addOptimistic = useCallback(async (item: T): Promise<boolean> => {
    const operationId = `add_${item.id}_${Date.now()}`;
    
    // Optimistic add
    setState(prev => ({
      ...prev,
      items: [...prev.items, item],
      optimisticOperations: new Set([...prev.optimisticOperations, operationId])
    }));

    try {
      const updatedItems = await serverUpdateFn('add', item, state.items);
      
      setState(prev => ({
        ...prev,
        items: updatedItems,
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors].filter(([key]) => key !== operationId))
      }));

      return true;
    } catch (error: any) {
      // Revert add
      setState(prev => ({
        ...prev,
        items: prev.items.filter(i => i.id !== item.id),
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors, [operationId, error]])
      }));

      return false;
    }
  }, [state.items, serverUpdateFn]);

  const updateOptimistic = useCallback(async (item: T): Promise<boolean> => {
    const operationId = `update_${item.id}_${Date.now()}`;
    const originalItem = state.items.find(i => i.id === item.id);
    
    if (!originalItem) return false;

    // Optimistic update
    setState(prev => ({
      ...prev,
      items: prev.items.map(i => i.id === item.id ? item : i),
      optimisticOperations: new Set([...prev.optimisticOperations, operationId])
    }));

    try {
      const updatedItems = await serverUpdateFn('update', item, state.items);
      
      setState(prev => ({
        ...prev,
        items: updatedItems,
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors].filter(([key]) => key !== operationId))
      }));

      return true;
    } catch (error: any) {
      // Revert update
      setState(prev => ({
        ...prev,
        items: prev.items.map(i => i.id === item.id ? originalItem : i),
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors, [operationId, error]])
      }));

      return false;
    }
  }, [state.items, serverUpdateFn]);

  const removeOptimistic = useCallback(async (itemId: string): Promise<boolean> => {
    const operationId = `remove_${itemId}_${Date.now()}`;
    const originalItem = state.items.find(i => i.id === itemId);
    
    if (!originalItem) return false;

    // Optimistic remove
    setState(prev => ({
      ...prev,
      items: prev.items.filter(i => i.id !== itemId),
      optimisticOperations: new Set([...prev.optimisticOperations, operationId])
    }));

    try {
      const updatedItems = await serverUpdateFn('remove', originalItem, state.items);
      
      setState(prev => ({
        ...prev,
        items: updatedItems,
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors].filter(([key]) => key !== operationId))
      }));

      return true;
    } catch (error: any) {
      // Revert remove
      setState(prev => ({
        ...prev,
        items: [...prev.items, originalItem],
        optimisticOperations: new Set([...prev.optimisticOperations].filter(id => id !== operationId)),
        errors: new Map([...prev.errors, [operationId, error]])
      }));

      return false;
    }
  }, [state.items, serverUpdateFn]);

  const isOptimistic = (itemId: string) => {
    return Array.from(state.optimisticOperations).some(op => op.includes(itemId));
  };

  const getError = (itemId: string) => {
    const errorEntry = Array.from(state.errors.entries()).find(([key]) => key.includes(itemId));
    return errorEntry?.[1] || null;
  };

  return {
    items: state.items,
    addOptimistic,
    updateOptimistic,
    removeOptimistic,
    isOptimistic,
    getError,
    hasOptimisticOperations: state.optimisticOperations.size > 0,
    hasErrors: state.errors.size > 0
  };
}

export default useOptimisticUpdate;