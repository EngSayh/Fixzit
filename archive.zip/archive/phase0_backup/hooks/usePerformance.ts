"use client";

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useDebounce } from './useDebounce';
import type { VirtualScrollConfig, VirtualScrollState, VirtualItem, PerformanceMetrics } from '../lib/types/performance';

// Performance monitoring hook
export function usePerformanceMonitor() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    renderTime: 0,
    firstContentfulPaint: 0,
    largestContentfulPaint: 0,
    cumulativeLayoutShift: 0,
    firstInputDelay: 0,
    timeToInteractive: 0
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      
      entries.forEach((entry) => {
        switch (entry.entryType) {
          case 'paint':
            if (entry.name === 'first-contentful-paint') {
              setMetrics(prev => ({ ...prev, firstContentfulPaint: entry.startTime }));
            }
            break;
          case 'largest-contentful-paint':
            setMetrics(prev => ({ ...prev, largestContentfulPaint: entry.startTime }));
            break;
          case 'layout-shift':
            if (!(entry as any).hadRecentInput) {
              setMetrics(prev => ({ 
                ...prev, 
                cumulativeLayoutShift: prev.cumulativeLayoutShift + (entry as any).value 
              }));
            }
            break;
          case 'first-input':
            setMetrics(prev => ({ ...prev, firstInputDelay: (entry as any).processingStart - entry.startTime }));
            break;
        }
      });
    });

    try {
      observer.observe({ entryTypes: ['paint', 'largest-contentful-paint', 'layout-shift', 'first-input'] });
    } catch (error) {
      console.warn('Performance Observer not supported:', error);
    }

    return () => observer.disconnect();
  }, []);

  return metrics;
}

// Debounced search hook
export function useDebouncedSearch<T>(
  searchFn: (query: string) => Promise<T[]>,
  delay: number = 300,
  minLength: number = 2
) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<T[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const debouncedQuery = useDebounce(query, delay);
  const abortControllerRef = useRef<AbortController | null>(null);

  const search = useCallback(async (searchQuery: string) => {
    if (searchQuery.length < minLength) {
      setResults([]);
      setIsLoading(false);
      return;
    }

    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();
    setIsLoading(true);
    setError(null);

    try {
      const data = await searchFn(searchQuery);
      
      if (!abortControllerRef.current.signal.aborted) {
        setResults(data);
        setIsLoading(false);
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'Search failed');
        setResults([]);
        setIsLoading(false);
      }
    }
  }, [searchFn, minLength]);

  useEffect(() => {
    search(debouncedQuery);
  }, [debouncedQuery, search]);

  const clearSearch = useCallback(() => {
    setQuery('');
    setResults([]);
    setError(null);
    setIsLoading(false);
  }, []);

  return {
    query,
    setQuery,
    results,
    isLoading,
    error,
    clearSearch
  };
}

// Virtual scrolling hook for large lists
export function useVirtualScroll<T>(
  items: T[],
  config: VirtualScrollConfig
) {
  const [state, setState] = useState<VirtualScrollState>({
    visibleStartIndex: 0,
    visibleEndIndex: 0,
    totalHeight: 0,
    scrollTop: 0,
    isScrolling: false,
    scrollDirection: 'down'
  });

  const scrollElementRef = useRef<HTMLDivElement>(null);
  const isScrollingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const itemHeight = typeof config.itemHeight === 'number' 
    ? config.itemHeight 
    : config.estimatedItemSize || 50;

  const totalHeight = useMemo(() => {
    if (typeof config.itemHeight === 'number') {
      return items.length * config.itemHeight;
    }
    return items.length * itemHeight;
  }, [items.length, config.itemHeight, itemHeight]);

  const visibleItems = useMemo(() => {
    const overscan = config.overscan || 5;
    const startIndex = Math.max(0, state.visibleStartIndex - overscan);
    const endIndex = Math.min(items.length - 1, state.visibleEndIndex + overscan);
    
    const visible: VirtualItem[] = [];
    
    for (let i = startIndex; i <= endIndex; i++) {
      const size = typeof config.itemHeight === 'function' 
        ? config.itemHeight(i)
        : itemHeight;
      
      const start = typeof config.itemHeight === 'function'
        ? items.slice(0, i).reduce((acc, _, idx) => acc + config.itemHeight!(idx), 0)
        : i * itemHeight;
      
      visible.push({
        index: i,
        start,
        end: start + size,
        size
      });
    }
    
    return visible;
  }, [state.visibleStartIndex, state.visibleEndIndex, items, config.itemHeight, itemHeight, config.overscan]);

  const handleScroll = useCallback((event: React.UIEvent<HTMLDivElement>) => {
    const scrollTop = event.currentTarget.scrollTop;
    const containerHeight = config.containerHeight;
    
    const visibleStartIndex = Math.floor(scrollTop / itemHeight);
    const visibleEndIndex = Math.min(
      items.length - 1,
      Math.ceil((scrollTop + containerHeight) / itemHeight)
    );

    setState(prev => ({
      ...prev,
      scrollTop,
      visibleStartIndex,
      visibleEndIndex,
      totalHeight,
      isScrolling: true,
      scrollDirection: scrollTop > prev.scrollTop ? 'down' : 'up'
    }));

    // Reset scrolling state after delay
    if (isScrollingTimeoutRef.current) {
      clearTimeout(isScrollingTimeoutRef.current);
    }
    
    isScrollingTimeoutRef.current = setTimeout(() => {
      setState(prev => ({ ...prev, isScrolling: false }));
    }, 150);
  }, [itemHeight, items.length, totalHeight, config.containerHeight]);

  const scrollToIndex = useCallback((index: number) => {
    if (!scrollElementRef.current) return;
    
    const scrollTop = index * itemHeight;
    scrollElementRef.current.scrollTop = scrollTop;
  }, [itemHeight]);

  useEffect(() => {
    // Initial calculation
    const containerHeight = config.containerHeight;
    const initialVisibleCount = Math.ceil(containerHeight / itemHeight);
    
    setState(prev => ({
      ...prev,
      visibleEndIndex: Math.min(initialVisibleCount, items.length - 1),
      totalHeight
    }));
  }, [items.length, itemHeight, totalHeight, config.containerHeight]);

  // Scroll to index effect
  useEffect(() => {
    if (config.scrollToIndex !== undefined) {
      scrollToIndex(config.scrollToIndex);
    }
  }, [config.scrollToIndex, scrollToIndex]);

  return {
    scrollElementRef,
    state,
    visibleItems,
    totalHeight,
    handleScroll,
    scrollToIndex
  };
}

// Memoization hook for expensive computations
export function useExpensiveMemo<T>(
  factory: () => T,
  deps: React.DependencyList,
  shouldUpdate?: (prev: T, next: T) => boolean
): T {
  const prevDepsRef = useRef<React.DependencyList>();
  const prevValueRef = useRef<T>();

  const hasChanged = useMemo(() => {
    if (!prevDepsRef.current) return true;
    
    return deps.some((dep, index) => 
      !Object.is(dep, prevDepsRef.current![index])
    );
  }, deps);

  const value = useMemo(() => {
    if (!hasChanged && prevValueRef.current !== undefined) {
      return prevValueRef.current;
    }
    
    const newValue = factory();
    
    if (shouldUpdate && prevValueRef.current !== undefined) {
      if (!shouldUpdate(prevValueRef.current, newValue)) {
        return prevValueRef.current;
      }
    }
    
    prevDepsRef.current = deps;
    prevValueRef.current = newValue;
    return newValue;
  }, [hasChanged, factory, shouldUpdate, deps]);

  return value;
}

// Component render tracking for performance debugging
export function useRenderTracking(componentName: string) {
  const renderCountRef = useRef(0);
  const lastRenderTimeRef = useRef(Date.now());
  
  useEffect(() => {
    renderCountRef.current += 1;
    const currentTime = Date.now();
    const timeSinceLastRender = currentTime - lastRenderTimeRef.current;
    lastRenderTimeRef.current = currentTime;
    
    if (process.env.NODE_ENV === 'development') {
      console.log(`[${componentName}] Render #${renderCountRef.current}, Time since last: ${timeSinceLastRender}ms`);
    }
  });

  return {
    renderCount: renderCountRef.current,
    getStats: () => ({
      renderCount: renderCountRef.current,
      componentName
    })
  };
}

// Intersection Observer hook for lazy loading
export function useIntersectionObserver(
  options: IntersectionObserverInit = {}
) {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [entry, setEntry] = useState<IntersectionObserverEntry | null>(null);
  const elementRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting);
      setEntry(entry);
    }, options);

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [options]);

  return {
    elementRef,
    isIntersecting,
    entry
  };
}

// Memory usage monitoring hook
export function useMemoryMonitor() {
  const [memoryInfo, setMemoryInfo] = useState<{
    used: number;
    total: number;
    limit: number;
  } | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !(performance as any).memory) {
      return;
    }

    const updateMemoryInfo = () => {
      const memory = (performance as any).memory;
      setMemoryInfo({
        used: memory.usedJSHeapSize,
        total: memory.totalJSHeapSize,
        limit: memory.jsHeapSizeLimit
      });
    };

    updateMemoryInfo();
    const interval = setInterval(updateMemoryInfo, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, []);

  return memoryInfo;
}

export default {
  usePerformanceMonitor,
  useDebouncedSearch,
  useVirtualScroll,
  useExpensiveMemo,
  useRenderTracking,
  useIntersectionObserver,
  useMemoryMonitor
};