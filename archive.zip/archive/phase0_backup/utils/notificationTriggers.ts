// Notification trigger utilities for FIXZIT SOUQ Enterprise modules

interface NotificationTrigger {
  type: string;
  subtype: string;
  title: string;
  message: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  recipientId: string;
  actionUrl?: string;
  actionText?: string;
  requiresAction?: boolean;
  data?: any;
  workOrderId?: string;
  propertyId?: string;
  unitId?: string;
  tenantId?: string;
  invoiceId?: string;
  paymentId?: string;
  employeeId?: string;
  vendorId?: string;
  rfqId?: string;
  orderId?: string;
  leadId?: string;
  contactId?: string;
  dealId?: string;
}

// Generic notification sending function
export const sendNotification = async (notification: NotificationTrigger): Promise<boolean> => {
  try {
    const response = await fetch('/api/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(notification),
    });

    return response.ok;
  } catch (error) {
    console.error('Failed to send notification:', error);
    return false;
  }
};

// Work Order Notification Triggers
export const WorkOrderNotifications = {
  // New work order assigned
  newAssignment: async (workOrderId: string, assigneeId: string, workOrderNumber: string, description: string, propertyId?: string) => {
    return sendNotification({
      type: 'work_order',
      subtype: 'new_assignment',
      title: 'New Work Order Assigned',
      message: `Work Order #${workOrderNumber} has been assigned to you: ${description}`,
      priority: 'high',
      recipientId: assigneeId,
      workOrderId,
      propertyId,
      actionUrl: `/work-orders/${workOrderId}`,
      actionText: 'View Work Order',
      requiresAction: true,
      data: { workOrderNumber, description }
    });
  },

  // Status change notification
  statusChange: async (workOrderId: string, recipientId: string, workOrderNumber: string, oldStatus: string, newStatus: string, updatedBy: string) => {
    const priority = newStatus === 'completed' ? 'medium' : newStatus === 'urgent' ? 'high' : 'medium';
    return sendNotification({
      type: 'work_order',
      subtype: 'status_change',
      title: 'Work Order Status Updated',
      message: `Work Order #${workOrderNumber} status changed from ${oldStatus} to ${newStatus} by ${updatedBy}`,
      priority,
      recipientId,
      workOrderId,
      actionUrl: `/work-orders/${workOrderId}`,
      actionText: 'View Work Order',
      requiresAction: newStatus === 'review_required',
      data: { workOrderNumber, oldStatus, newStatus, updatedBy }
    });
  },

  // Work order completion
  completion: async (workOrderId: string, requesterId: string, workOrderNumber: string, completedBy: string, propertyId?: string) => {
    return sendNotification({
      type: 'work_order',
      subtype: 'completion',
      title: 'Work Order Completed',
      message: `Work Order #${workOrderNumber} has been completed by ${completedBy}`,
      priority: 'medium',
      recipientId: requesterId,
      workOrderId,
      propertyId,
      actionUrl: `/work-orders/${workOrderId}`,
      actionText: 'View Details',
      requiresAction: false,
      data: { workOrderNumber, completedBy }
    });
  },

  // Overdue work order
  overdue: async (workOrderId: string, assigneeId: string, workOrderNumber: string, daysOverdue: number, propertyId?: string) => {
    return sendNotification({
      type: 'work_order',
      subtype: 'overdue',
      title: 'Work Order Overdue',
      message: `Work Order #${workOrderNumber} is ${daysOverdue} days overdue and requires immediate attention`,
      priority: 'critical',
      recipientId: assigneeId,
      workOrderId,
      propertyId,
      actionUrl: `/work-orders/${workOrderId}`,
      actionText: 'Update Status',
      requiresAction: true,
      data: { workOrderNumber, daysOverdue }
    });
  }
};

// Finance/Payment Notification Triggers
export const FinanceNotifications = {
  // Payment due reminder
  paymentDue: async (tenantId: string, invoiceId: string, invoiceNumber: string, amount: number, dueDate: string, daysUntilDue: number) => {
    const priority = daysUntilDue <= 3 ? 'high' : daysUntilDue <= 7 ? 'medium' : 'low';
    return sendNotification({
      type: 'payment',
      subtype: 'payment_due',
      title: 'Payment Due Reminder',
      message: `Invoice #${invoiceNumber} for SAR ${amount.toLocaleString()} is due ${daysUntilDue > 0 ? `in ${daysUntilDue} days` : 'today'}`,
      priority,
      recipientId: tenantId,
      invoiceId,
      tenantId,
      actionUrl: `/finance/invoices/${invoiceId}`,
      actionText: 'Pay Now',
      requiresAction: true,
      data: { invoiceNumber, amount, dueDate, daysUntilDue }
    });
  },

  // Payment received
  paymentReceived: async (landlordId: string, paymentId: string, invoiceId: string, tenantName: string, amount: number, paymentMethod: string) => {
    return sendNotification({
      type: 'payment',
      subtype: 'payment_received',
      title: 'Payment Received',
      message: `Payment of SAR ${amount.toLocaleString()} received from ${tenantName} via ${paymentMethod}`,
      priority: 'medium',
      recipientId: landlordId,
      paymentId,
      invoiceId,
      actionUrl: `/finance/payments/${paymentId}`,
      actionText: 'View Payment',
      requiresAction: false,
      data: { tenantName, amount, paymentMethod }
    });
  },

  // Overdue payment
  overduePayment: async (tenantId: string, invoiceId: string, invoiceNumber: string, amount: number, daysOverdue: number) => {
    return sendNotification({
      type: 'payment',
      subtype: 'payment_overdue',
      title: 'Payment Overdue',
      message: `Invoice #${invoiceNumber} for SAR ${amount.toLocaleString()} is ${daysOverdue} days overdue`,
      priority: 'critical',
      recipientId: tenantId,
      invoiceId,
      tenantId,
      actionUrl: `/finance/invoices/${invoiceId}`,
      actionText: 'Pay Now',
      requiresAction: true,
      data: { invoiceNumber, amount, daysOverdue }
    });
  },

  // Invoice generated
  invoiceGenerated: async (tenantId: string, invoiceId: string, invoiceNumber: string, amount: number, dueDate: string) => {
    return sendNotification({
      type: 'payment',
      subtype: 'invoice_generated',
      title: 'New Invoice Generated',
      message: `Invoice #${invoiceNumber} for SAR ${amount.toLocaleString()} has been generated. Due date: ${dueDate}`,
      priority: 'medium',
      recipientId: tenantId,
      invoiceId,
      tenantId,
      actionUrl: `/finance/invoices/${invoiceId}`,
      actionText: 'View Invoice',
      requiresAction: false,
      data: { invoiceNumber, amount, dueDate }
    });
  }
};

// Property Management Notification Triggers
export const PropertyNotifications = {
  // Maintenance request
  maintenanceRequest: async (managerId: string, propertyId: string, unitId: string, tenantId: string, tenantName: string, requestType: string, description: string) => {
    return sendNotification({
      type: 'property',
      subtype: 'maintenance_request',
      title: 'New Maintenance Request',
      message: `${tenantName} submitted a maintenance request: ${requestType} - ${description}`,
      priority: 'medium',
      recipientId: managerId,
      propertyId,
      unitId,
      tenantId,
      actionUrl: `/properties/${propertyId}/units/${unitId}`,
      actionText: 'Create Work Order',
      requiresAction: true,
      data: { tenantName, requestType, description }
    });
  },

  // Lease renewal reminder
  leaseRenewal: async (landlordId: string, tenantId: string, propertyId: string, unitId: string, tenantName: string, leaseEndDate: string, daysUntilExpiry: number) => {
    const priority = daysUntilExpiry <= 30 ? 'high' : daysUntilExpiry <= 60 ? 'medium' : 'low';
    return sendNotification({
      type: 'property',
      subtype: 'lease_renewal',
      title: 'Lease Renewal Reminder',
      message: `Lease for ${tenantName} expires in ${daysUntilExpiry} days (${leaseEndDate}). Consider renewal process.`,
      priority,
      recipientId: landlordId,
      propertyId,
      unitId,
      tenantId,
      actionUrl: `/properties/${propertyId}/units/${unitId}`,
      actionText: 'Start Renewal',
      requiresAction: daysUntilExpiry <= 60,
      data: { tenantName, leaseEndDate, daysUntilExpiry }
    });
  },

  // Tenant check-in
  tenantCheckIn: async (managerId: string, tenantId: string, propertyId: string, unitId: string, tenantName: string, checkInDate: string) => {
    return sendNotification({
      type: 'property',
      subtype: 'tenant_checkin',
      title: 'New Tenant Check-in',
      message: `${tenantName} has checked into the property. Check-in date: ${checkInDate}`,
      priority: 'medium',
      recipientId: managerId,
      propertyId,
      unitId,
      tenantId,
      actionUrl: `/properties/${propertyId}/units/${unitId}`,
      actionText: 'View Details',
      requiresAction: false,
      data: { tenantName, checkInDate }
    });
  }
};

// HR Notification Triggers
export const HRNotifications = {
  // Leave request
  leaveRequest: async (hrManagerId: string, employeeId: string, employeeName: string, leaveType: string, startDate: string, endDate: string, reason: string) => {
    return sendNotification({
      type: 'hr',
      subtype: 'leave_request',
      title: 'Leave Request Pending Approval',
      message: `${employeeName} has submitted a ${leaveType} request from ${startDate} to ${endDate}`,
      priority: 'medium',
      recipientId: hrManagerId,
      employeeId,
      actionUrl: `/hr/leave-requests`,
      actionText: 'Review Request',
      requiresAction: true,
      data: { employeeName, leaveType, startDate, endDate, reason }
    });
  },

  // Payroll processed
  payrollProcessed: async (employeeId: string, employeeName: string, salary: number, payPeriod: string) => {
    return sendNotification({
      type: 'hr',
      subtype: 'payroll_processed',
      title: 'Payroll Processed',
      message: `Your salary of SAR ${salary.toLocaleString()} for ${payPeriod} has been processed`,
      priority: 'low',
      recipientId: employeeId,
      employeeId,
      actionUrl: `/hr/payroll`,
      actionText: 'View Payslip',
      requiresAction: false,
      data: { employeeName, salary, payPeriod }
    });
  },

  // New employee onboarding
  newEmployee: async (hrManagerId: string, employeeId: string, employeeName: string, position: string, startDate: string) => {
    return sendNotification({
      type: 'hr',
      subtype: 'new_employee',
      title: 'New Employee Onboarding',
      message: `${employeeName} is starting as ${position} on ${startDate}. Complete onboarding checklist.`,
      priority: 'medium',
      recipientId: hrManagerId,
      employeeId,
      actionUrl: `/hr/employees/${employeeId}`,
      actionText: 'Start Onboarding',
      requiresAction: true,
      data: { employeeName, position, startDate }
    });
  }
};

// Marketplace Notification Triggers
export const MarketplaceNotifications = {
  // New RFQ received
  newRFQ: async (vendorId: string, rfqId: string, rfqNumber: string, category: string, description: string, dueDate: string) => {
    return sendNotification({
      type: 'marketplace',
      subtype: 'rfq_new',
      title: 'New RFQ Available',
      message: `RFQ #${rfqNumber} for ${category} - ${description}. Submission due: ${dueDate}`,
      priority: 'medium',
      recipientId: vendorId,
      vendorId,
      rfqId,
      actionUrl: `/marketplace/rfqs/${rfqId}`,
      actionText: 'Submit Bid',
      requiresAction: true,
      data: { rfqNumber, category, description, dueDate }
    });
  },

  // Bid received
  bidReceived: async (buyerId: string, rfqId: string, vendorName: string, rfqNumber: string, bidAmount: number) => {
    return sendNotification({
      type: 'marketplace',
      subtype: 'bid_received',
      title: 'New Bid Received',
      message: `${vendorName} submitted a bid of SAR ${bidAmount.toLocaleString()} for RFQ #${rfqNumber}`,
      priority: 'medium',
      recipientId: buyerId,
      rfqId,
      actionUrl: `/marketplace/rfqs/${rfqId}/bids`,
      actionText: 'Review Bids',
      requiresAction: false,
      data: { vendorName, rfqNumber, bidAmount }
    });
  },

  // Order confirmed
  orderConfirmed: async (vendorId: string, orderId: string, orderNumber: string, customerName: string, totalAmount: number) => {
    return sendNotification({
      type: 'marketplace',
      subtype: 'order_confirmed',
      title: 'Order Confirmed',
      message: `Order #${orderNumber} from ${customerName} confirmed for SAR ${totalAmount.toLocaleString()}`,
      priority: 'high',
      recipientId: vendorId,
      vendorId,
      orderId,
      actionUrl: `/marketplace/orders/${orderId}`,
      actionText: 'Process Order',
      requiresAction: true,
      data: { orderNumber, customerName, totalAmount }
    });
  }
};

// CRM Notification Triggers
export const CRMNotifications = {
  // New lead assigned
  newLead: async (salesRepId: string, leadId: string, leadName: string, company: string, source: string, value: number) => {
    return sendNotification({
      type: 'crm',
      subtype: 'new_lead',
      title: 'New Lead Assigned',
      message: `New lead ${leadName} from ${company} assigned to you. Potential value: SAR ${value.toLocaleString()}`,
      priority: 'high',
      recipientId: salesRepId,
      leadId,
      actionUrl: `/crm/leads/${leadId}`,
      actionText: 'Contact Lead',
      requiresAction: true,
      data: { leadName, company, source, value }
    });
  },

  // Deal stage change
  dealStageChange: async (salesRepId: string, dealId: string, dealName: string, oldStage: string, newStage: string, value: number) => {
    const priority = newStage === 'closed_won' ? 'high' : newStage === 'closed_lost' ? 'medium' : 'medium';
    return sendNotification({
      type: 'crm',
      subtype: 'deal_stage_change',
      title: 'Deal Stage Updated',
      message: `Deal "${dealName}" moved from ${oldStage} to ${newStage}. Value: SAR ${value.toLocaleString()}`,
      priority,
      recipientId: salesRepId,
      dealId,
      actionUrl: `/crm/deals/${dealId}`,
      actionText: 'View Deal',
      requiresAction: newStage === 'proposal_sent',
      data: { dealName, oldStage, newStage, value }
    });
  },

  // Follow-up reminder
  followUpReminder: async (salesRepId: string, contactId: string, contactName: string, company: string, lastContact: string, daysOverdue: number) => {
    const priority = daysOverdue > 7 ? 'high' : 'medium';
    return sendNotification({
      type: 'crm',
      subtype: 'followup_reminder',
      title: 'Follow-up Reminder',
      message: `Follow-up with ${contactName} from ${company} is ${daysOverdue} days overdue. Last contact: ${lastContact}`,
      priority,
      recipientId: salesRepId,
      contactId,
      actionUrl: `/crm/contacts/${contactId}`,
      actionText: 'Contact Now',
      requiresAction: true,
      data: { contactName, company, lastContact, daysOverdue }
    });
  }
};

// System Notification Triggers
export const SystemNotifications = {
  // System maintenance
  systemMaintenance: async (userId: string, maintenanceDate: string, duration: string, affectedServices: string[]) => {
    return sendNotification({
      type: 'system',
      subtype: 'maintenance_scheduled',
      title: 'Scheduled System Maintenance',
      message: `System maintenance scheduled for ${maintenanceDate} (${duration}). Affected services: ${affectedServices.join(', ')}`,
      priority: 'low',
      recipientId: userId,
      actionUrl: `/system/maintenance`,
      actionText: 'View Details',
      requiresAction: false,
      data: { maintenanceDate, duration, affectedServices }
    });
  },

  // Security alert
  securityAlert: async (userId: string, alertType: string, description: string, severity: 'critical' | 'high' | 'medium' | 'low') => {
    return sendNotification({
      type: 'system',
      subtype: 'security_alert',
      title: 'Security Alert',
      message: `${alertType}: ${description}`,
      priority: severity,
      recipientId: userId,
      actionUrl: `/system/security`,
      actionText: 'Review Alert',
      requiresAction: severity === 'critical' || severity === 'high',
      data: { alertType, description, severity }
    });
  }
};

// Utility function to send bulk notifications
export const sendBulkNotifications = async (notifications: NotificationTrigger[]): Promise<boolean[]> => {
  try {
    const promises = notifications.map(notification => sendNotification(notification));
    return await Promise.all(promises);
  } catch (error) {
    console.error('Failed to send bulk notifications:', error);
    return notifications.map(() => false);
  }
};