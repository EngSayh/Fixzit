// Notification helper utilities for FIXZIT SOUQ Enterprise
import { useState, useEffect } from 'react';

// Enhanced real-time notification polling hook with background pause
export const useNotificationPolling = (intervalMs: number = 30000) => {
  const [lastCheck, setLastCheck] = useState<Date>(new Date());
  
  useEffect(() => {
    const ctrl = new AbortController();
    
    const updateLastCheck = () => {
      if (!ctrl.signal.aborted) {
        setLastCheck(new Date());
      }
    };

    let interval: number | undefined;
    const startPolling = () => {
      updateLastCheck();
      interval = window.setInterval(updateLastCheck, intervalMs);
    };
    const stopPolling = () => {
      if (interval) {
        window.clearInterval(interval);
        interval = undefined;
      }
    };
    const handleVisibilityChange = () => {
      document.hidden ? stopPolling() : startPolling();
    };
    
    startPolling();
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      stopPolling();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      ctrl.abort();
    };
  }, [intervalMs]);
  
  return lastCheck;
};

// Notification permission management
export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!('Notification' in window)) {
    console.warn('This browser does not support notifications');
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission === 'denied') {
    return false;
  }

  const permission = await Notification.requestPermission();
  return permission === 'granted';
};

// Browser notification display
export const showBrowserNotification = (title: string, message: string, options?: NotificationOptions) => {
  if (Notification.permission !== 'granted') {
    return null;
  }

  const notification = new Notification(title, {
    body: message,
    icon: '/icons/notification-icon.png',
    badge: '/icons/notification-badge.png',
    ...options
  });

  // Auto-close after 5 seconds
  setTimeout(() => {
    notification.close();
  }, 5000);

  return notification;
};

// Priority to color mapping
export const getPriorityColor = (priority: string): { bg: string; text: string; border: string } => {
  switch (priority) {
    case 'critical':
      return { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' };
    case 'high':
      return { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' };
    case 'medium':
      return { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' };
    case 'low':
      return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' };
    default:
      return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' };
  }
};

// Notification type to icon mapping
export const getNotificationIcon = (type: string): string => {
  switch (type) {
    case 'work_order':
      return '🔧';
    case 'payment':
      return '💰';
    case 'property':
      return '🏢';
    case 'hr':
      return '👥';
    case 'marketplace':
      return '🛒';
    case 'crm':
      return '🤝';
    case 'system':
      return '⚙️';
    default:
      return '📋';
  }
};

// Format notification time
export const formatNotificationTime = (createdAt: string): string => {
  const now = new Date();
  const notificationTime = new Date(createdAt);
  const diffMs = now.getTime() - notificationTime.getTime();
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMinutes < 1) {
    return 'Just now';
  } else if (diffMinutes < 60) {
    return `${diffMinutes}m ago`;
  } else if (diffHours < 24) {
    return `${diffHours}h ago`;
  } else if (diffDays < 7) {
    return `${diffDays}d ago`;
  } else {
    return notificationTime.toLocaleDateString('ar-SA', {
      month: 'short',
      day: 'numeric',
      year: notificationTime.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  }
};

// Notification category grouping
export const groupNotificationsByCategory = (notifications: any[]) => {
  return notifications.reduce((groups, notification) => {
    const category = notification.type;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(notification);
    return groups;
  }, {} as Record<string, any[]>);
};

// Smart notification batching for performance
export const batchNotificationUpdates = (updates: any[], batchSize: number = 10): any[][] => {
  const batches = [];
  for (let i = 0; i < updates.length; i += batchSize) {
    batches.push(updates.slice(i, i + batchSize));
  }
  return batches;
};

// Notification sound management
export const playNotificationSound = (priority: string = 'medium') => {
  const soundMap = {
    critical: '/sounds/critical-alert.wav',
    high: '/sounds/high-priority.wav',
    medium: '/sounds/notification.wav',
    low: '/sounds/subtle-ding.wav'
  };

  const audio = new Audio(soundMap[priority as keyof typeof soundMap] || soundMap.medium);
  audio.volume = 0.5;
  audio.play().catch(console.warn);
};

// Do Not Disturb check
export const isDuringDoNotDisturb = (
  doNotDisturb: boolean,
  startTime: string,
  endTime: string
): boolean => {
  if (!doNotDisturb) return false;

  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes(); // minutes since midnight

  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startMinutesTotal = startHours * 60 + startMinutes;
  const endMinutesTotal = endHours * 60 + endMinutes;

  // Handle overnight periods (e.g., 22:00 to 08:00)
  if (startMinutesTotal > endMinutesTotal) {
    return currentTime >= startMinutesTotal || currentTime <= endMinutesTotal;
  }
  
  return currentTime >= startMinutesTotal && currentTime <= endMinutesTotal;
};

// Weekend check
export const isWeekend = (): boolean => {
  const day = new Date().getDay();
  return day === 0 || day === 6; // Sunday or Saturday
};

// Check if notification should be delivered based on user preferences
export const shouldDeliverNotification = (
  notification: any,
  userPreferences: any
): { inApp: boolean; email: boolean; sms: boolean } => {
  const { type, priority } = notification;
  
  // Critical notifications always delivered if criticalAlways is true
  if (priority === 'critical' && userPreferences.criticalAlways) {
    return { inApp: true, email: true, sms: true };
  }

  // Check Do Not Disturb
  if (isDuringDoNotDisturb(
    userPreferences.doNotDisturb,
    userPreferences.doNotDisturbStart,
    userPreferences.doNotDisturbEnd
  )) {
    return { inApp: false, email: false, sms: false };
  }

  // Check weekend preferences
  if (isWeekend() && !userPreferences.weekendNotifications) {
    return { inApp: false, email: false, sms: false };
  }

  // Check type-specific preferences
  const typeKey = type.replace('_', '');
  return {
    inApp: userPreferences[`${typeKey}InApp`] ?? true,
    email: userPreferences[`${typeKey}Email`] ?? true,
    sms: userPreferences[`${typeKey}Sms`] ?? false
  };
};

// Export common notification actions
export const notificationActions = {
  markAsRead: async (notificationId: string) => {
    const response = await fetch(`/api/notifications/${notificationId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isRead: true })
    });
    return response.ok;
  },

  markAsUnread: async (notificationId: string) => {
    const response = await fetch(`/api/notifications/${notificationId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isRead: false })
    });
    return response.ok;
  },

  archive: async (notificationId: string) => {
    const response = await fetch(`/api/notifications/${notificationId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isArchived: true })
    });
    return response.ok;
  },

  delete: async (notificationId: string) => {
    const response = await fetch(`/api/notifications/${notificationId}`, {
      method: 'DELETE'
    });
    return response.ok;
  },

  bulkMarkAsRead: async (notificationIds: string[]) => {
    const response = await fetch('/api/notifications/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'mark_read',
        notificationIds
      })
    });
    return response.ok;
  },

  bulkArchive: async (notificationIds: string[]) => {
    const response = await fetch('/api/notifications/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'archive',
        notificationIds
      })
    });
    return response.ok;
  },

  bulkDelete: async (notificationIds: string[]) => {
    const response = await fetch('/api/notifications/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'delete',
        notificationIds
      })
    });
    return response.ok;
  }
};