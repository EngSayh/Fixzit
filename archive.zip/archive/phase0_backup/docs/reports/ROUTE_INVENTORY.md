# FIXZIT SOUQ - Route Inventory and Reorganization Plan

## Current Route Structure Analysis

### Route Groups Overview

#### (app) - Authenticated Application Routes
Main application routes for logged-in users

#### (auth) - Authentication Routes  
Authentication flow pages

#### (public) - Public Routes
Publicly accessible pages

---

## PAGE ROUTES INVENTORY

### (app) Route Group - `/app/(app)/*`

| Route | File | Domain | Status |
|-------|------|--------|--------|
| `/admin` | admin/page.tsx | Admin | Active |
| `/compliance` | compliance/page.tsx | Compliance | Active |
| `/crm` | crm/page.tsx | CRM | Active |
| `/crm/analytics` | crm/analytics/page.tsx | CRM | Active |
| `/crm/contacts` | crm/contacts/page.tsx | CRM | Active |
| `/crm/contacts/[id]` | crm/contacts/[id]/page.tsx | CRM | Active |
| `/crm/contacts/[id]/edit` | crm/contacts/[id]/edit/page.tsx | CRM | Active |
| `/crm/contacts/new` | crm/contacts/new/page.tsx | CRM | Active |
| `/crm/deals` | crm/deals/page.tsx | CRM | Active |
| `/crm/deals/[id]` | crm/deals/[id]/page.tsx | CRM | Active |
| `/crm/deals/new` | crm/deals/new/page.tsx | CRM | Active |
| `/crm/interactions` | crm/interactions/page.tsx | CRM | Active |
| `/crm/leads` | crm/leads/page.tsx | CRM | Active |
| `/crm/leads/[id]` | crm/leads/[id]/page.tsx | CRM | Active |
| `/crm/leads/[id]/convert` | crm/leads/[id]/convert/page.tsx | CRM | Active |
| `/crm/leads/new` | crm/leads/new/page.tsx | CRM | Active |
| `/crm/tasks` | crm/tasks/page.tsx | CRM | Active |
| `/dashboard` | dashboard/page.tsx | Dashboard | Active |
| `/finance` | finance/page.tsx | Finance | Active |
| `/finance/expenses` | finance/expenses/page.tsx | Finance | Active |
| `/finance/invoices` | finance/invoices/page.tsx | Finance | Active |
| `/finance/payments` | finance/payments/page.tsx | Finance | Active |
| `/finance/reports` | finance/reports/page.tsx | Finance | Active |
| `/fm/approvals` | fm/approvals/page.tsx | Facility Management | Active |
| `/fm/properties` | fm/properties/page.tsx | Facility Management | Active |
| `/hr` | hr/page.tsx | HR | Active |
| `/marketplace` | marketplace/page.tsx | Marketplace | Active |
| `/marketplace/orders` | marketplace/orders/page.tsx | Marketplace | Active |
| `/marketplace/products` | marketplace/products/page.tsx | Marketplace | Active |
| `/marketplace/rfqs` | marketplace/rfqs/page.tsx | Marketplace | Active |
| `/marketplace/rfqs/create` | marketplace/rfqs/create/page.tsx | Marketplace | Active |
| `/marketplace/vendors` | marketplace/vendors/page.tsx | Marketplace | Active |
| `/marketplace/vendors/dashboard` | marketplace/vendors/dashboard/page.tsx | Marketplace | Active |
| `/marketplace/vendors/register` | marketplace/vendors/register/page.tsx | Marketplace | Active |
| `/preventive-maintenance` | preventive-maintenance/page.tsx | Maintenance | Active |
| `/profile` | profile/page.tsx | User | Active |
| `/properties` | properties/page.tsx | Properties | Active |
| `/properties/[id]` | properties/[id]/page.tsx | Properties | Active |
| `/reports` | reports/page.tsx | Reports | Active |
| `/settings` | settings/page.tsx | Settings | Active |
| `/support` | support/page.tsx | Support | Active |
| `/system` | system/page.tsx | System | Active |
| `/work-orders` | work-orders/page.tsx | Work Orders | Active |
| `/work-orders/[id]` | work-orders/[id]/page.tsx | Work Orders | Active |

### (auth) Route Group - `/app/(auth)/*`

| Route | File | Domain | Status |
|-------|------|--------|--------|
| `/login` | login/page.tsx | Auth | Active |
| `/reset-password` | reset-password/ | Auth | Incomplete |
| `/signup` | signup/ | Auth | Incomplete |

### (public) Route Group - `/app/(public)/*`

| Route | File | Domain | Status |
|-------|------|--------|--------|
| `/` | page.tsx | Public | Active |
| `/about` | about/ | Public | Incomplete |
| `/contact` | contact/ | Public | Incomplete |
| `/pricing` | pricing/ | Public | Incomplete |

---

## API ROUTES INVENTORY

### Admin Domain (`/api/admin/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/admin/approval-requests` | GET/POST | approval-requests/route.ts | Manage approval requests |
| `/api/admin/asset-categories` | GET/POST | asset-categories/route.ts | Asset category management |
| `/api/admin/asset-maintenance` | GET/POST | asset-maintenance/route.ts | Asset maintenance tracking |
| `/api/admin/assets` | GET/POST | assets/route.ts | Asset management |
| `/api/admin/authority-matrix` | GET/POST | authority-matrix/route.ts | Authority matrix config |
| `/api/admin/dashboard/stats` | GET | dashboard/stats/route.ts | Admin dashboard statistics |
| `/api/admin/fuel-records` | GET/POST | fuel-records/route.ts | Vehicle fuel records |
| `/api/admin/policies` | GET/POST | policies/route.ts | Policy management |
| `/api/admin/policy-acknowledgments` | GET/POST | policy-acknowledgments/route.ts | Policy acknowledgment tracking |
| `/api/admin/trip-records` | GET/POST | trip-records/route.ts | Vehicle trip records |
| `/api/admin/vehicle-inspections` | GET/POST | vehicle-inspections/route.ts | Vehicle inspection logs |
| `/api/admin/vehicles` | GET/POST | vehicles/route.ts | Vehicle fleet management |
| `/api/admin/vendor-contracts` | GET/POST | vendor-contracts/route.ts | Vendor contract management |
| `/api/admin/vendor-performance` | GET/POST | vendor-performance/route.ts | Vendor performance metrics |
| `/api/admin/vendors` | GET/POST | vendors/route.ts | Vendor management |

### Authentication Domain (`/api/auth/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/auth/login` | POST | login/route.ts | User login |
| `/api/auth/logout` | POST | logout/route.ts | User logout |
| `/api/auth/session` | GET | session/route.ts | Session management |

### Compliance Domain (`/api/compliance/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/compliance/permits` | GET/POST | permits/route.ts | Permit management |
| `/api/compliance/stats` | GET | stats/route.ts | Compliance statistics |

### CRM Domain (`/api/crm/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/crm/contacts` | GET/POST | contacts/route.ts | Contact management |
| `/api/crm/contacts/[id]` | GET/PUT/DELETE | contacts/[id]/route.ts | Individual contact operations |
| `/api/crm/deals` | GET/POST | deals/route.ts | Deal management |
| `/api/crm/deals/[id]` | GET/PUT/DELETE | deals/[id]/route.ts | Individual deal operations |
| `/api/crm/interactions` | GET/POST | interactions/route.ts | Customer interactions |
| `/api/crm/leads` | GET/POST | leads/route.ts | Lead management |
| `/api/crm/leads/[id]` | GET/PUT/DELETE | leads/[id]/route.ts | Individual lead operations |
| `/api/crm/leads/[id]/convert` | POST | leads/[id]/convert/route.ts | Convert lead to contact |
| `/api/crm/stats` | GET | stats/route.ts | CRM statistics |
| `/api/crm/tasks` | GET/POST | tasks/route.ts | CRM task management |

### Dashboard Domain (`/api/dashboard/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/dashboard/charts` | GET | charts/route.ts | Dashboard chart data |
| `/api/dashboard/stats` | GET | stats/route.ts | Dashboard statistics |

### Finance Domain (`/api/finances/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/finances/analytics` | GET | analytics/route.ts | Financial analytics |
| `/api/finances/dashboard` | GET | dashboard/route.ts | Finance dashboard data |
| `/api/finances/expense-stats` | GET | expense-stats/route.ts | Expense statistics |
| `/api/finances/expenses` | GET/POST | expenses/route.ts | Expense management |
| `/api/finances/expenses/[id]` | GET/PUT/DELETE | expenses/[id]/route.ts | Individual expense operations |
| `/api/finances/expenses/stats` | GET | expenses/stats/route.ts | Expense statistics |
| `/api/finances/invoices` | GET/POST | invoices/route.ts | Invoice management |
| `/api/finances/invoices/[id]` | GET/PUT/DELETE | invoices/[id]/route.ts | Individual invoice operations |
| `/api/finances/invoices/[id]/send` | POST | invoices/[id]/send/route.ts | Send invoice to tenant |
| `/api/finances/payment-stats` | GET | payment-stats/route.ts | Payment statistics |
| `/api/finances/payments` | GET/POST | payments/route.ts | Payment management |
| `/api/finances/payments/[id]` | GET/PUT/DELETE | payments/[id]/route.ts | Individual payment operations |
| `/api/finances/payments/stats` | GET | payments/stats/route.ts | Payment statistics |
| `/api/finances/reports` | GET | reports/route.ts | Financial reports |
| `/api/finances/stats` | GET | stats/route.ts | Overall finance statistics |

### HR Domain (`/api/hr/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/hr/attendance` | GET/POST | attendance/route.ts | Attendance tracking |
| `/api/hr/departments` | GET/POST | departments/route.ts | Department management |
| `/api/hr/employees` | GET/POST | employees/route.ts | Employee management |
| `/api/hr/employees/[id]` | GET/PUT/DELETE | employees/[id]/route.ts | Individual employee operations |
| `/api/hr/leave-requests` | GET/POST | leave-requests/route.ts | Leave request management |
| `/api/hr/payroll` | GET/POST | payroll/route.ts | Payroll management |
| `/api/hr/seed` | POST | seed/route.ts | HR data seeding |
| `/api/hr/services` | GET/POST | services/route.ts | HR services |
| `/api/hr/services/seed` | POST | services/seed/route.ts | HR services seeding |

### Marketplace Domain (`/api/marketplace/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/marketplace/activity` | GET | activity/route.ts | Marketplace activity feed |
| `/api/marketplace/categories` | GET | categories/route.ts | Product categories |
| `/api/marketplace/orders` | GET/POST | orders/route.ts | Order management |
| `/api/marketplace/products` | GET/POST | products/route.ts | Product management |
| `/api/marketplace/rfqs` | GET/POST | rfqs/route.ts | RFQ management |
| `/api/marketplace/stats` | GET | stats/route.ts | Marketplace statistics |
| `/api/marketplace/vendors` | GET/POST | vendors/route.ts | Vendor management |
| `/api/marketplace/vendors/dashboard` | GET | vendors/dashboard/route.ts | Vendor dashboard data |

### Notifications Domain (`/api/notifications/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/notifications` | GET | route.ts | Get notifications |
| `/api/notifications/[id]` | PUT/DELETE | [id]/route.ts | Individual notification operations |
| `/api/notifications/bulk` | PUT | bulk/route.ts | Bulk notification operations |
| `/api/notifications/preferences` | GET/PUT | preferences/route.ts | Notification preferences |
| `/api/notifications/stats` | GET | stats/route.ts | Notification statistics |

### Preventive Maintenance Domain (`/api/preventive-maintenance/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/preventive-maintenance/stats` | GET | stats/route.ts | Maintenance statistics |
| `/api/preventive-maintenance/tasks` | GET/POST | tasks/route.ts | Maintenance task management |

### Properties Domain (`/api/properties/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/properties` | GET/POST | route.ts | Property management |
| `/api/properties/[id]` | GET/PUT/DELETE | [id]/route.ts | Individual property operations |
| `/api/properties/stats` | GET | stats/route.ts | Property statistics |

### Support Domain (`/api/support/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/support/stats` | GET | stats/route.ts | Support statistics |
| `/api/support/tickets` | GET/POST | tickets/route.ts | Support ticket management |

### System Domain (`/api/system/*`)
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/system/analyze` | GET | analyze/route.ts | System analysis |
| `/api/system/export` | GET | export/route.ts | Data export |

### Other API Routes
| Route | Method | File | Description |
|-------|--------|------|-------------|
| `/api/tenants` | GET/POST | tenants/route.ts | Tenant management |
| `/api/units` | GET/POST | units/route.ts | Unit management |
| `/api/work-orders` | GET/POST | work-orders/route.ts | Work order management |
| `/api/work-orders/[id]` | GET/PUT/DELETE | work-orders/[id]/route.ts | Individual work order operations |
| `/api/work-orders/stats` | GET | work-orders/stats/route.ts | Work order statistics |

---

## DOMAIN OWNERSHIP & DUPLICATIONS

### Identified Issues:

1. **Finance Domain Duplication**
   - `/finance/*` pages (UI routes)  
   - `/api/finances/*` API routes
   - Canonical owner: Finance Module

2. **Properties Domain Overlap**
   - `/properties/*` pages
   - `/fm/properties` page  
   - `/api/properties/*` API routes
   - Canonical owner: Properties Module

3. **Mixed Admin Concerns**
   - `/api/admin/*` contains multiple domains (assets, vendors, vehicles, policies)
   - Should be split into respective domain modules

4. **CRM Domain Scatter**
   - Clear boundaries but complex nested structure
   - Canonical owner: CRM Module

---

## NEW MODULAR STRUCTURE PLAN

### Phase 1: Finance Module (PILOT)
```
src/modules/finance/
├── ui/
│   ├── components/
│   │   ├── InvoiceList.tsx
│   │   ├── InvoiceForm.tsx
│   │   ├── PaymentForm.tsx
│   │   ├── ExpenseForm.tsx
│   │   └── FinanceDashboard.tsx
│   └── pages/
│       ├── InvoicesPage.tsx
│       ├── PaymentsPage.tsx
│       ├── ExpensesPage.tsx
│       └── ReportsPage.tsx
├── services/
│   ├── invoice.service.ts
│   ├── payment.service.ts
│   ├── expense.service.ts
│   └── reports.service.ts
├── repos/
│   ├── invoice.repo.ts
│   ├── payment.repo.ts
│   └── expense.repo.ts
├── schemas/
│   ├── invoice.schema.ts
│   ├── payment.schema.ts
│   └── expense.schema.ts
└── types/
    └── finance.types.ts
```

### Route File Transformation Example:
**Before:** Full business logic in route file
**After:** Thin route file calling service layer

```typescript
// app/api/finances/invoices/route.ts (AFTER)
import { invoiceService } from '@modules/finance/services/invoice.service';

export async function GET(request: NextRequest) {
  return invoiceService.getInvoices(request);
}

export async function POST(request: NextRequest) {
  return invoiceService.createInvoice(request);
}
```

---

## MIGRATION TRACKING

### Completed Migrations:
- [x] Finance Module - ✅ Migrated to src/modules/finance
- [x] Properties Module - ✅ Migrated to src/modules/properties  
- [x] Work Orders Module - ✅ Migrated to src/modules/work-orders
- [ ] CRM Module
- [x] HR Module - ✅ Migrated to src/modules/hr (employees completed, other sub-modules pending)
- [ ] Marketplace Module
- [ ] Admin Module
- [ ] Support Module
- [ ] Compliance Module
- [ ] Preventive Maintenance Module

### Next Steps:
1. Create src/ directory structure
2. Add TypeScript path aliases
3. Extract Finance module as pilot
4. Test and validate
5. Proceed with other modules

---

## NOTES

- All route files remain in current locations
- Only business logic is extracted to modules
- UI components are organized by domain
- Shared components remain in src/components
- Database access centralized in repos
- Validation schemas using Zod
- Type definitions per module