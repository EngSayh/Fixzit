import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3000';

test.describe('Fixzit Platform - Smoke Tests', () => {
  let page: Page;
  
  // Test credentials - these should be valid test accounts in your system
  const testCredentials = {
    email: process.env.TEST_EMAIL || 'test@fixzit.com',
    password: process.env.TEST_PASSWORD || 'TestPassword123'
  };

  test.beforeEach(async ({ browser }) => {
    page = await browser.newPage();
    // Set viewport to desktop size
    await page.setViewportSize({ width: 1920, height: 1080 });
  });

  test.afterEach(async () => {
    await page.close();
  });

  test('Landing Page - Load and Display KPIs', async () => {
    // Navigate to landing page
    await page.goto(BASE_URL);
    
    // Wait for aurora background to load
    await expect(page.locator('.bg-aurora')).toBeVisible();
    
    // Check main heading is visible
    await expect(page.locator('h1')).toContainText('Integrated');
    await expect(page.locator('h1')).toContainText('Property & Facility');
    
    // Verify glass navbar elements are present
    await expect(page.locator('nav')).toHaveClass(/glass/);
    await expect(page.locator('[placeholder*="Search properties"]')).toBeVisible();
    
    // Check language toggle works
    const rtlBtn = page.locator('#rtlBtn');
    await expect(rtlBtn).toBeVisible();
    await rtlBtn.click();
    
    // Verify RTL is applied
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
    
    // Toggle back to LTR
    await rtlBtn.click();
    await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
    
    // Check dark mode toggle
    const darkBtn = page.locator('#darkBtn');
    await expect(darkBtn).toBeVisible();
    await darkBtn.click();
    
    // Verify dark mode is applied
    await expect(page.locator('html')).toHaveClass(/dark/);
    
    // Toggle back to light mode
    await darkBtn.click();
    await expect(page.locator('html')).not.toHaveClass(/dark/);
    
    // Wait for KPI components to load (they should show live data)
    await page.waitForTimeout(2000);
    
    // Check that KPI cards are present and contain data
    const kpiCards = page.locator('.glass:has-text("Open WOs")');
    await expect(kpiCards).toBeVisible();
    
    // Check quick access dock
    await expect(page.locator('#dock')).toBeVisible();
    await expect(page.locator('a[href="/fm/work-orders"]')).toBeVisible();
    await expect(page.locator('a[href="/fm/properties"]')).toBeVisible();
    await expect(page.locator('a[href="/fm/finance"]')).toBeVisible();
    await expect(page.locator('a[href="/souq/rfq"]')).toBeVisible();
  });

  test('Authentication Flow - Login and Dashboard Access', async () => {
    // Start from landing page
    await page.goto(BASE_URL);
    
    // Navigate to login
    await page.click('a[href="/login"]');
    await page.waitForURL('**/login');
    
    // Check login page elements
    await expect(page.locator('h1, h2')).toContainText(/Login|Sign In/i);
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('input[type="password"]')).toBeVisible();
    
    // Fill in credentials
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    
    // Submit login form
    await page.click('button[type="submit"]');
    
    // Wait for redirect to dashboard (role-based)
    await page.waitForURL('**/dashboard', { timeout: 10000 });
    
    // Verify authenticated layout is loaded
    await expect(page.locator('aside')).toBeVisible(); // Sidebar
    await expect(page.locator('header')).toBeVisible(); // Top bar
    
    // Check that user profile menu is present
    const profileButton = page.locator('img[alt=""], button:has(img)').last();
    await expect(profileButton).toBeVisible();
    
    // Check sidebar navigation items
    await expect(page.locator('nav a[href="/dashboard"]')).toBeVisible();
    await expect(page.locator('nav a[href="/work-orders"]')).toBeVisible();
    await expect(page.locator('nav a[href="/properties"]')).toBeVisible();
    
    // Verify dashboard content loads
    await expect(page.locator('h1')).toContainText(/Dashboard|Overview/i);
  });

  test('Work Orders - Create New with Photos', async () => {
    // Login first
    await page.goto(`${BASE_URL}/login`);
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');
    
    // Navigate to work orders page
    await page.click('nav a[href="/work-orders"]');
    await page.waitForURL('**/work-orders');
    
    // Check work orders page loads
    await expect(page.locator('h1')).toContainText(/Work Orders/i);
    
    // Click create work order button
    const createBtn = page.locator('button:has-text("New Work Order"), button:has-text("Create")').first();
    await createBtn.click();
    
    // Fill out work order form (assuming modal opens)
    await expect(page.locator('input[placeholder*="Title"], input[placeholder*="عنوان"]')).toBeVisible();
    
    await page.fill('input[placeholder*="Title"], input[placeholder*="عنوان"]', 'Test Work Order - Automated');
    await page.fill('textarea[placeholder*="Description"], textarea[placeholder*="وصف"]', 'This is an automated test work order created by Playwright');
    await page.fill('input[placeholder*="Property"], input[placeholder*="عقار"]', 'TEST-PROPERTY-001');
    
    // Set priority if dropdown is available
    const prioritySelect = page.locator('select').first();
    if (await prioritySelect.isVisible()) {
      await prioritySelect.selectOption('HIGH');
    }
    
    // Submit the form
    const submitBtn = page.locator('button:has-text("Create"), button:has-text("إنشاء")').last();
    await submitBtn.click();
    
    // Wait for success/redirect
    await page.waitForTimeout(3000);
    
    // Verify work order was created (check for success message or redirect)
    const successIndicator = page.locator('.text-green-600, .bg-emerald-50, [class*="success"]');
    if (await successIndicator.isVisible()) {
      await expect(successIndicator).toBeVisible();
    } else {
      // Or check that we're back to the list with our new item
      await expect(page.locator('text=Test Work Order - Automated')).toBeVisible();
    }
  });

  test('Properties Management - View and Create', async () => {
    // Login and navigate to properties
    await page.goto(`${BASE_URL}/login`);
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');
    
    // Navigate to properties
    await page.click('nav a[href="/properties"]');
    await page.waitForURL('**/properties');
    
    // Check properties page loads
    await expect(page.locator('h1')).toContainText(/Properties/i);
    
    // Click add property button
    const addBtn = page.locator('button:has-text("Add Property"), button:has-text("إضافة عقار")').first();
    await addBtn.click();
    
    // Fill property form
    await expect(page.locator('input[placeholder*="Property Name"], input[placeholder*="اسم العقار"]')).toBeVisible();
    
    await page.fill('input[placeholder*="Property Name"], input[placeholder*="اسم العقار"]', 'Test Property - Automated');
    await page.fill('input[placeholder*="Address"], input[placeholder*="العنوان"]', '123 Test Street, Test District');
    await page.fill('input[placeholder*="City"], input[placeholder*="المدينة"]', 'Riyadh');
    await page.fill('input[placeholder*="State"], input[placeholder*="المنطقة"]', 'Riyadh Region');
    
    // Submit property form
    const createPropertyBtn = page.locator('button:has-text("Create Property"), button:has-text("إضافة العقار")').last();
    await createPropertyBtn.click();
    
    // Wait for creation and verify
    await page.waitForTimeout(2000);
    await expect(page.locator('text=Test Property - Automated')).toBeVisible();
  });

  test('Approvals Flow - View Pending', async () => {
    // Login and navigate to approvals
    await page.goto(`${BASE_URL}/login`);
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');
    
    // Navigate to approvals
    await page.goto(`${BASE_URL}/fm/approvals`);
    await page.waitForTimeout(2000);
    
    // Check approvals page loads
    await expect(page.locator('h1')).toContainText(/Approvals|Pending/i);
    
    // Check for approval items or empty state
    const approvalsContainer = page.locator('main');
    await expect(approvalsContainer).toBeVisible();
    
    // If there are pending approvals, test approve/reject buttons
    const approveBtn = page.locator('button:has-text("Approve"), button:has-text("موافقة")').first();
    if (await approveBtn.isVisible()) {
      await expect(approveBtn).toBeVisible();
      await expect(page.locator('button:has-text("Reject"), button:has-text("رفض")')).toBeVisible();
      
      // Don't actually click them in the test to avoid affecting real data
      // Just verify they're present and clickable
      await expect(approveBtn).toBeEnabled();
    } else {
      // Verify empty state is shown properly
      await expect(page.locator('text=No approvals pending, text=لا توجد موافقات')).toBeVisible();
    }
  });

  test('Real-time Updates and Socket Connection', async () => {
    // Login
    await page.goto(`${BASE_URL}/login`);
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');
    
    // Go to dashboard where real-time updates should be active
    await page.goto(`${BASE_URL}/dashboard`);
    
    // Wait for initial load
    await page.waitForTimeout(2000);
    
    // Check that dashboard KPIs are loaded
    const kpiCards = page.locator('.glass');
    await expect(kpiCards.first()).toBeVisible();
    
    // Capture initial KPI values if any
    const initialWorkOrders = await page.locator('text=Open WOs').locator('..').locator('p[class*="font-extrabold"]').textContent();
    
    // Navigate to work orders and back to test real-time updates
    await page.click('nav a[href="/work-orders"]');
    await page.waitForTimeout(1000);
    await page.click('nav a[href="/dashboard"]');
    await page.waitForTimeout(2000);
    
    // Verify dashboard still shows data (connection maintained)
    await expect(page.locator('text=Open WOs')).toBeVisible();
  });

  test('Mobile Responsiveness', async () => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Test landing page on mobile
    await page.goto(BASE_URL);
    
    // Check that elements adapt to mobile
    await expect(page.locator('.bg-aurora')).toBeVisible();
    await expect(page.locator('h1')).toBeVisible();
    
    // Check that navigation is mobile-friendly
    const nav = page.locator('nav');
    await expect(nav).toBeVisible();
    
    // Login on mobile
    await page.click('a[href="/login"]');
    await page.fill('input[type="email"]', testCredentials.email);
    await page.fill('input[type="password"]', testCredentials.password);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');
    
    // Verify mobile layout works
    await expect(page.locator('aside')).toBeVisible(); // Sidebar should be present
    await expect(page.locator('header')).toBeVisible(); // Header should be present
    
    // Test sidebar collapse/expand on mobile
    const sidebarToggle = page.locator('button[aria-label*="toggle"], button[aria-label*="menu"]');
    if (await sidebarToggle.isVisible()) {
      await sidebarToggle.click();
      await page.waitForTimeout(500);
    }
  });

  test('Accessibility and WCAG Compliance', async () => {
    await page.goto(BASE_URL);
    
    // Check for basic accessibility features
    
    // 1. Check for alt attributes on images
    const images = page.locator('img');
    const imageCount = await images.count();
    if (imageCount > 0) {
      for (let i = 0; i < imageCount; i++) {
        const img = images.nth(i);
        // Skip if it's a decorative image (empty alt is OK)
        const alt = await img.getAttribute('alt');
        const role = await img.getAttribute('role');
        if (role !== 'presentation' && !alt && alt !== '') {
          console.warn(`Image missing alt attribute: ${await img.getAttribute('src')}`);
        }
      }
    }
    
    // 2. Check for form labels
    const inputs = page.locator('input[type="email"], input[type="password"], input[type="text"], textarea, select');
    const inputCount = await inputs.count();
    for (let i = 0; i < inputCount; i++) {
      const input = inputs.nth(i);
      const id = await input.getAttribute('id');
      const ariaLabel = await input.getAttribute('aria-label');
      const placeholder = await input.getAttribute('placeholder');
      
      // Inputs should have either id+label, aria-label, or at minimum a placeholder
      if (!id && !ariaLabel && !placeholder) {
        console.warn('Input missing label or aria-label');
      }
    }
    
    // 3. Check for keyboard navigation
    await page.keyboard.press('Tab');
    await page.keyboard.press('Tab');
    
    // 4. Check color contrast (basic check - would need more sophisticated testing for full WCAG)
    const computedStyle = await page.evaluate(() => {
      const element = document.querySelector('h1');
      if (element) {
        const style = window.getComputedStyle(element);
        return {
          color: style.color,
          backgroundColor: style.backgroundColor
        };
      }
      return null;
    });
    
    expect(computedStyle).toBeTruthy();
  });

  test('Error Handling and Edge Cases', async () => {
    // Test invalid login
    await page.goto(`${BASE_URL}/login`);
    await page.fill('input[type="email"]', 'invalid@example.com');
    await page.fill('input[type="password"]', 'wrongpassword');
    await page.click('button[type="submit"]');
    
    // Should show error message
    await expect(page.locator('.text-rose-600, .text-red-600, [class*="error"]')).toBeVisible();
    
    // Test API error handling by navigating to authenticated pages without login
    await page.goto(`${BASE_URL}/dashboard`);
    
    // Should redirect to login
    await page.waitForURL('**/login');
    
    // Test network error simulation (if possible)
    await page.route('**/api/**', route => route.abort());
    await page.goto(BASE_URL);
    
    // Should handle gracefully - check for error states or loading indicators
    await page.waitForTimeout(2000);
    
    // Reset network
    await page.unroute('**/api/**');
  });
});

// Helper function to wait for animations
async function waitForAnimations(page: Page) {
  await page.waitForTimeout(1000);
}