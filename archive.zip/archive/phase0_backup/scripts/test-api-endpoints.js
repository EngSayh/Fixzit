// Test script for API endpoints
const baseUrl = 'http://localhost:3000/api';

// Test data
const testCredentials = {
  email: 'admin@fixzit.com',
  password: 'Fixzit@123'
};

// Helper function to make requests
async function testEndpoint(name, url, method = 'GET', body = null, token = null) {
  console.log(`\n🧪 Testing ${name}...`);
  
  try {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    if (token) {
      options.headers['Authorization'] = `Bearer ${token}`;
    }
    
    if (body) {
      options.body = JSON.stringify(body);
    }
    
    const response = await fetch(url, options);
    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ ${name} - Success (${response.status})`);
      console.log('Response preview:', JSON.stringify(data).substring(0, 200));
      return { success: true, data };
    } else {
      console.log(`❌ ${name} - Failed (${response.status})`);
      console.log('Error:', data);
      return { success: false, error: data };
    }
  } catch (error) {
    console.log(`❌ ${name} - Error: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// Main test function
async function runTests() {
  console.log('🚀 Starting API endpoint tests...\n');
  
  // Test 1: Login endpoint
  const loginResult = await testEndpoint(
    'Login',
    `${baseUrl}/auth/login`,
    'POST',
    testCredentials
  );
  
  if (!loginResult.success) {
    console.log('\n⚠️  Login failed, creating test user...');
    // If login fails, we might need to create a test user first
    // For now, we'll skip authenticated endpoints
  }
  
  const token = loginResult.data?.token;
  
  // Test 2: Session endpoint
  if (token) {
    await testEndpoint(
      'Session',
      `${baseUrl}/auth/session`,
      'GET',
      null,
      token
    );
  }
  
  // Test 3: Dashboard stats
  if (token) {
    await testEndpoint(
      'Dashboard Stats',
      `${baseUrl}/dashboard/stats`,
      'GET',
      null,
      token
    );
  }
  
  // Test 4: Work orders list
  if (token) {
    await testEndpoint(
      'Work Orders List',
      `${baseUrl}/work-orders`,
      'GET',
      null,
      token
    );
  }
  
  // Test 5: Properties list
  if (token) {
    await testEndpoint(
      'Properties List',
      `${baseUrl}/properties`,
      'GET',
      null,
      token
    );
  }
  
  // Test 6: HR Employees list
  if (token) {
    await testEndpoint(
      'HR Employees',
      `${baseUrl}/hr/employees`,
      'GET',
      null,
      token
    );
  }
  
  // Test 7: Finance Invoices list
  if (token) {
    await testEndpoint(
      'Finance Invoices',
      `${baseUrl}/finance/invoices`,
      'GET',
      null,
      token
    );
  }
  
  // Test 8: CRM Contacts list
  if (token) {
    await testEndpoint(
      'CRM Contacts',
      `${baseUrl}/crm/contacts`,
      'GET',
      null,
      token
    );
  }
  
  // Test 9: Logout
  if (token) {
    await testEndpoint(
      'Logout',
      `${baseUrl}/auth/logout`,
      'POST',
      null,
      token
    );
  }
  
  console.log('\n✨ API endpoint tests completed!\n');
}

// Run tests
console.log('Waiting 3 seconds for server to be ready...');
setTimeout(() => {
  runTests().catch(console.error);
}, 3000);