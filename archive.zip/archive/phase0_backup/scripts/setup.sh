#!/bin/bash

# Frontend Dependencies Setup Script
echo "Setting up FIXZIT SOUQ Frontend Dependencies..."

# Navigate to frontend directory
cd "$(dirname "$0")"

# Create a temporary package.json if needed
if [ ! -f "package.json" ]; then
    echo "package.json not found in frontend directory!"
    exit 1
fi

# Install dependencies with legacy peer deps flag to bypass conflicts
echo "Installing dependencies with legacy peer deps..."
npm install --legacy-peer-deps

# Check if installation was successful
if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully!"
    echo ""
    echo "You can now start the application with:"
    echo "npm run dev"
else
    echo "❌ Installation failed. Trying with force flag..."
    npm install --force
    
    if [ $? -eq 0 ]; then
        echo "✅ Dependencies installed with force flag!"
    else
        echo "❌ Installation failed. Please check the error messages above."
        exit 1
    fi
fi