#!/bin/bash

echo "Updating imports to use src/components..."

# Update imports in app files
find app -name "*.tsx" -o -name "*.ts" | while read file; do
  # Replace ../components/ with ../src/components/
  sed -i 's|from \.\./components/|from ../src/components/|g' "$file"
  
  # Replace ../../components/ with ../../src/components/
  sed -i 's|from \.\./\.\./components/|from ../../src/components/|g' "$file"
  
  # Replace ../../../components/ with ../../../src/components/
  sed -i 's|from \.\./\.\./\.\./components/|from ../../../src/components/|g' "$file"
  
  # Replace ../../../../components/ with ../../../../src/components/
  sed -i 's|from \.\./\.\./\.\./\.\./components/|from ../../../../src/components/|g' "$file"
done

echo "Import updates completed!"

# Count updated files
updated_count=$(grep -r "from.*src/components" app --include="*.tsx" --include="*.ts" | wc -l)
echo "Total imports updated: $updated_count"