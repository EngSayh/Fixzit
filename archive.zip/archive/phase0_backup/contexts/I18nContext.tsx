'use client';

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { i18n, Locale, I18nContextType } from '../lib/i18n';

// Create the context
const I18nContext = createContext<I18nContextType | undefined>(undefined);

// Provider component
export const I18nProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [locale, setLocale] = useState<Locale>('en');
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize i18n system
  useEffect(() => {
    i18n.init();
    setLocale(i18n.getLocale());
    setIsInitialized(true);
  }, []);

  // Switch language function
  const switchLanguage = (newLocale: Locale) => {
    i18n.setLocale(newLocale);
    setLocale(newLocale);
    
    // Trigger rerender by updating state
    if (typeof window !== 'undefined') {
      // Force a small delay to ensure DOM updates
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('languageChanged', { detail: { locale: newLocale } }));
      }, 100);
    }
  };

  // Translation function
  const t = (key: string, params?: Record<string, string | number>): string => {
    return i18n.t(key, params);
  };

  const contextValue: I18nContextType = {
    locale,
    translations: i18n['translations'][locale],
    t,
    switchLanguage,
    isRTL: i18n.isRTL(),
  };

  // Don't render until i18n is initialized to prevent flash
  if (!isInitialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0061A8]"></div>
      </div>
    );
  }

  return (
    <I18nContext.Provider value={contextValue}>
      <div 
        dir={i18n.getDirection()} 
        lang={locale}
        className={`font-sans ${locale === 'ar' ? 'arabic-font' : ''}`}
      >
        {children}
      </div>
    </I18nContext.Provider>
  );
};

// Custom hook to use the i18n context
export const useTranslation = () => {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within an I18nProvider');
  }
  return context;
};

// HOC for components that need translation
export const withTranslation = <P extends object>(
  Component: React.ComponentType<P>
) => {
  const WrappedComponent: React.FC<P> = (props) => {
    const translation = useTranslation();
    return <Component {...props} {...translation} />;
  };
  
  WrappedComponent.displayName = `withTranslation(${Component.displayName || Component.name})`;
  return WrappedComponent;
};

export default I18nContext;