// Reports & Analytics Types
export interface Report {
  id: string;
  name: string;
  description: string;
  type: 'financial' | 'operational' | 'compliance' | 'performance' | 'tenant' | 'maintenance';
  category: string;
  dataSource: string[];
  filters: ReportFilter[];
  schedule?: ReportSchedule;
  format: 'pdf' | 'excel' | 'csv' | 'dashboard';
  createdBy: string;
  createdDate: string;
  lastRun?: string;
  nextRun?: string;
  isActive: boolean;
  parameters: Record<string, any>;
}

export interface ReportFilter {
  field: string;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'between' | 'in';
  value: any;
  label: string;
}

export interface ReportSchedule {
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  time: string;
  dayOfWeek?: number;
  dayOfMonth?: number;
  recipients: string[];
  isActive: boolean;
}

export interface DashboardWidget {
  id: string;
  type: 'kpi' | 'chart' | 'table' | 'map' | 'gauge';
  title: string;
  position: { x: number; y: number; w: number; h: number };
  dataSource: string;
  configuration: Record<string, any>;
  refreshInterval: number;
  isVisible: boolean;
}

export interface Analytics {
  propertyPerformance: PropertyAnalytics[];
  financialTrends: FinancialTrend[];
  maintenanceMetrics: MaintenanceMetrics;
  tenantAnalytics: TenantAnalytics;
  marketplaceTrends: MarketplaceTrends;
  complianceMetrics: ComplianceMetrics;
}

export interface PropertyAnalytics {
  propertyId: string;
  propertyName: string;
  occupancyRate: number;
  avgRent: number;
  totalRevenue: number;
  maintenanceCost: number;
  profitMargin: number;
  tenantSatisfaction: number;
  workOrderCount: number;
  trend: 'up' | 'down' | 'stable';
}

export interface FinancialTrend {
  period: string;
  revenue: number;
  expenses: number;
  profit: number;
  occupancyRate: number;
  avgRentPerSqft: number;
}

export interface MaintenanceMetrics {
  totalWorkOrders: number;
  avgCompletionTime: number;
  costPerWorkOrder: number;
  preventiveVsReactive: { preventive: number; reactive: number };
  topCategories: Array<{ category: string; count: number; cost: number }>;
  technicianPerformance: Array<{ name: string; completed: number; avgTime: number; rating: number }>;
}

export interface TenantAnalytics {
  totalTenants: number;
  avgLeaseLength: number;
  turnoverRate: number;
  satisfactionScore: number;
  renewalRate: number;
  latePaymentRate: number;
  topComplaints: Array<{ category: string; count: number }>;
}

export interface MarketplaceTrends {
  totalOrders: number;
  avgOrderValue: number;
  topVendors: Array<{ name: string; orders: number; value: number }>;
  categoryTrends: Array<{ category: string; growth: number }>;
  paymentTrends: Array<{ month: string; value: number }>;
}

export interface ComplianceMetrics {
  complianceRate: number;
  expiringSoon: number;
  overdue: number;
  inspectionsPassed: number;
  averageScore: number;
}