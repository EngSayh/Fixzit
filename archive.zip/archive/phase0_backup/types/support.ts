// Support Center Types
export interface SupportTicket {
  id: string;
  ticketNumber: string;
  subject: string;
  description: string;
  type: 'technical' | 'billing' | 'general' | 'complaint' | 'feature' | 'bug';
  priority: 'urgent' | 'high' | 'medium' | 'low';
  status: 'open' | 'in_progress' | 'resolved' | 'closed' | 'escalated';
  submittedBy: string;
  assignedTo?: string;
  submittedDate: string;
  lastUpdate: string;
  resolvedDate?: string;
  resolution?: string;
  attachments?: string[];
  tags?: string[];
  customerSatisfaction?: number;
  comments?: TicketComment[];
}

export interface TicketComment {
  id: string;
  ticketId: string;
  userId: string;
  userName: string;
  userRole: string;
  content: string;
  timestamp: string;
  isInternal: boolean;
  attachments?: string[];
}

export interface KnowledgeBaseArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  author: string;
  createdDate: string;
  updatedDate: string;
  viewCount: number;
  helpfulVotes: number;
  isPublished: boolean;
  relatedArticles?: string[];
}

export interface SupportStats {
  totalTickets: number;
  openTickets: number;
  resolvedTickets: number;
  avgResolutionTime: number;
  customerSatisfactionScore: number;
  ticketsByType: Record<string, number>;
  ticketsByPriority: Record<string, number>;
  monthlyTrend: Array<{ month: string; tickets: number; resolved: number }>;
}

export interface SupportFilters {
  status?: string[];
  type?: string[];
  priority?: string[];
  assignedTo?: string[];
  dateRange?: [string, string];
  search?: string;
}