// Preventive Maintenance Types
export interface PreventiveMaintenanceTask {
  id: string;
  title: string;
  description: string;
  category: 'hvac' | 'electrical' | 'plumbing' | 'fire_safety' | 'elevator' | 'cleaning' | 'landscaping' | 'security';
  priority: 'critical' | 'high' | 'medium' | 'low';
  frequency: MaintenanceFrequency;
  duration: number; // in minutes
  assignedTo?: string;
  propertyId?: string;
  unitId?: string;
  assetId?: string;
  checklist: MaintenanceChecklist[];
  requiredTools: string[];
  requiredMaterials: MaintenanceMaterial[];
  instructions: string;
  safetyNotes?: string;
  estimatedCost: number;
  isActive: boolean;
  createdDate: string;
  lastCompleted?: string;
  nextDue: string;
}

export interface MaintenanceFrequency {
  type: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'semi_annual' | 'annual' | 'custom';
  interval?: number;
  daysOfWeek?: number[];
  dayOfMonth?: number;
  customSchedule?: string;
}

export interface MaintenanceChecklist {
  id: string;
  item: string;
  description?: string;
  isRequired: boolean;
  expectedValue?: string;
  unit?: string;
}

export interface MaintenanceMaterial {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  cost: number;
  supplier?: string;
}

export interface MaintenanceSchedule {
  id: string;
  taskId: string;
  propertyId?: string;
  assignedTo: string;
  scheduledDate: string;
  scheduledTime: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'rescheduled';
  actualStartTime?: string;
  actualEndTime?: string;
  completionNotes?: string;
  checklistResults?: ChecklistResult[];
  issuesFound?: MaintenanceIssue[];
  materials_used?: MaintenanceMaterial[];
  totalCost?: number;
  photos?: string[];
  signature?: string;
}

export interface ChecklistResult {
  checklistItemId: string;
  status: 'pass' | 'fail' | 'na';
  value?: string;
  notes?: string;
}

export interface MaintenanceIssue {
  id: string;
  description: string;
  severity: 'critical' | 'major' | 'minor';
  actionRequired: string;
  workOrderCreated?: string;
  photos?: string[];
}

export interface MaintenanceAsset {
  id: string;
  name: string;
  type: string;
  location: string;
  propertyId: string;
  unitId?: string;
  serialNumber?: string;
  manufacturer?: string;
  model?: string;
  installDate?: string;
  warrantyExpiry?: string;
  specifications: Record<string, any>;
  maintenanceTasks: string[];
  currentCondition: 'excellent' | 'good' | 'fair' | 'poor' | 'critical';
  lastInspection?: string;
  nextInspection?: string;
}

export interface MaintenanceStats {
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  upcomingTasks: number;
  avgCompletionTime: number;
  costSavings: number;
  preventiveRatio: number; // preventive vs reactive maintenance
  assetUptime: number;
  tasksByCategory: Record<string, number>;
  completionTrend: Array<{ month: string; completed: number; scheduled: number }>;
  costTrend: Array<{ month: string; preventive: number; reactive: number }>;
}

export interface MaintenanceFilters {
  category?: string[];
  status?: string[];
  priority?: string[];
  propertyId?: string;
  assignedTo?: string[];
  dateRange?: [string, string];
  search?: string;
}