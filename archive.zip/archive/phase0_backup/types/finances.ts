// Financial Management Types for FIXZIT SOUQ Enterprise

// Core Financial Entities
export type PaymentStatus = 'pending' | 'received' | 'overdue' | 'partial' | 'cancelled' | 'refunded';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'check' | 'card' | 'digital_wallet' | 'online';
export type InvoiceStatus = 'draft' | 'sent' | 'viewed' | 'paid' | 'overdue' | 'cancelled' | 'refunded';
export type InvoiceType = 'rent' | 'utilities' | 'service_charge' | 'maintenance' | 'deposit' | 'penalty' | 'other';
export type ExpenseCategory = 'maintenance' | 'utilities' | 'management' | 'marketing' | 'insurance' | 'taxes' | 'legal' | 'supplies' | 'property_improvement' | 'other';
export type TransactionType = 'income' | 'expense' | 'transfer';
export type ReportPeriod = 'monthly' | 'quarterly' | 'yearly' | 'custom';
export type ReportType = 'profit_loss' | 'cash_flow' | 'rental_income' | 'expense_analysis' | 'property_performance' | 'tax_summary';

// Payment Management
export interface Payment {
  id: string;
  invoiceId?: string;
  tenantId?: string;
  propertyId?: string;
  unitId?: string;
  amount: number;
  currency: string;
  paymentDate: string;
  dueDate: string;
  status: PaymentStatus;
  method: PaymentMethod;
  reference?: string;
  description: string;
  notes?: string;
  lateFee?: number;
  discount?: number;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  invoice?: Invoice;
  tenant?: Tenant;
  property?: Property;
  unit?: Unit;
  
  // Calculated fields
  remainingAmount?: number;
  daysPastDue?: number;
  isOverdue?: boolean;
}

// Invoice Management
export interface Invoice {
  id: string;
  invoiceNumber: string;
  tenantId?: string;
  propertyId?: string;
  unitId?: string;
  type: InvoiceType;
  status: InvoiceStatus;
  issueDate: string;
  dueDate: string;
  amount: number;
  currency: string;
  description: string;
  lineItems: InvoiceLineItem[];
  taxAmount?: number;
  discountAmount?: number;
  totalAmount: number;
  paidAmount: number;
  notes?: string;
  terms?: string;
  recurringPattern?: RecurringPattern;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  tenant?: Tenant;
  property?: Property;
  unit?: Unit;
  payments?: Payment[];
  
  // Calculated fields
  remainingAmount?: number;
  daysPastDue?: number;
  isOverdue?: boolean;
  nextDueDate?: string;
}

export interface InvoiceLineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  taxRate?: number;
  taxAmount?: number;
}

export interface RecurringPattern {
  frequency: 'monthly' | 'quarterly' | 'yearly';
  interval: number;
  endDate?: string;
  maxOccurrences?: number;
  isActive: boolean;
}

// Expense Management
export interface Expense {
  id: string;
  propertyId?: string;
  unitId?: string;
  workOrderId?: string;
  category: ExpenseCategory;
  subcategory?: string;
  description: string;
  amount: number;
  currency: string;
  expenseDate: string;
  paymentMethod?: PaymentMethod;
  vendor?: string;
  receipt?: string;
  receiptUrl?: string;
  isRecurring: boolean;
  recurringPattern?: RecurringPattern;
  taxDeductible: boolean;
  approvedBy?: string;
  approvedAt?: string;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  property?: Property;
  unit?: Unit;
  workOrder?: WorkOrder;
  approver?: User;
  
  // Calculated fields
  monthlyAverage?: number;
  yearlyTotal?: number;
}

// Financial Transactions
export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  currency: string;
  date: string;
  description: string;
  category: string;
  propertyId?: string;
  unitId?: string;
  tenantId?: string;
  paymentId?: string;
  expenseId?: string;
  invoiceId?: string;
  reference?: string;
  orgId: string;
  createdBy: string;
  createdAt: string;
  
  // Relations
  property?: Property;
  tenant?: Tenant;
  payment?: Payment;
  expense?: Expense;
  invoice?: Invoice;
}

// Budget Management
export interface Budget {
  id: string;
  name: string;
  propertyId?: string;
  category: ExpenseCategory;
  budgetedAmount: number;
  currency: string;
  period: ReportPeriod;
  startDate: string;
  endDate: string;
  actualSpent: number;
  isActive: boolean;
  alertThreshold: number; // percentage
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  property?: Property;
  expenses?: Expense[];
  
  // Calculated fields
  remainingAmount?: number;
  spentPercentage?: number;
  isOverBudget?: boolean;
  projectedSpend?: number;
}

// Financial Reports
export interface FinancialReport {
  id: string;
  name: string;
  type: ReportType;
  period: ReportPeriod;
  startDate: string;
  endDate: string;
  propertyIds?: string[];
  data: any; // Dynamic based on report type
  generatedBy: string;
  generatedAt: string;
  orgId: string;
  
  // Calculated totals
  totalIncome?: number;
  totalExpenses?: number;
  netIncome?: number;
  profitMargin?: number;
}

// Enhanced interfaces for related entities
export interface Tenant {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  nationalId?: string;
  moveInDate?: string;
  status: 'active' | 'inactive' | 'terminated';
  orgId: string;
  
  // Financial fields
  currentBalance?: number;
  totalPaid?: number;
  outstandingAmount?: number;
  lastPaymentDate?: string;
  paymentHistory?: Payment[];
}

export interface Property {
  id: string;
  name: string;
  address: string;
  type: 'residential' | 'commercial' | 'mixed';
  totalUnits: number;
  orgId: string;
  
  // Financial fields
  monthlyRevenue?: number;
  yearlyRevenue?: number;
  totalExpenses?: number;
  netIncome?: number;
  occupancyRate?: number;
  profitMargin?: number;
}

export interface Unit {
  id: string;
  propertyId: string;
  unitNumber: string;
  type: string;
  rentAmount: number;
  status: 'vacant' | 'occupied' | 'maintenance';
  orgId: string;
  
  // Financial fields
  monthlyRent?: number;
  lastPaymentDate?: string;
  outstandingBalance?: number;
  totalRevenue?: number;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  orgId?: string;
}

export interface WorkOrder {
  id: string;
  woNumber: string;
  title: string;
  actualCost?: number;
  propertyId?: string;
  unitId?: string;
}

// Form Data Interfaces
export interface PaymentFormData {
  invoiceId?: string;
  tenantId?: string;
  propertyId?: string;
  unitId?: string;
  amount: number;
  paymentDate: string;
  method: PaymentMethod;
  reference?: string;
  description: string;
  notes?: string;
}

export interface InvoiceFormData {
  tenantId?: string;
  propertyId?: string;
  unitId?: string;
  type: InvoiceType;
  issueDate: string;
  dueDate: string;
  description: string;
  lineItems: InvoiceLineItem[];
  taxAmount?: number;
  discountAmount?: number;
  notes?: string;
  terms?: string;
  isRecurring?: boolean;
  recurringPattern?: RecurringPattern;
}

export interface ExpenseFormData {
  propertyId?: string;
  unitId?: string;
  workOrderId?: string;
  category: ExpenseCategory;
  subcategory?: string;
  description: string;
  amount: number;
  expenseDate: string;
  paymentMethod?: PaymentMethod;
  vendor?: string;
  receipt?: File;
  isRecurring: boolean;
  recurringPattern?: RecurringPattern;
  taxDeductible: boolean;
}

// Filter Interfaces
export interface PaymentFilters {
  status?: PaymentStatus[];
  method?: PaymentMethod[];
  propertyId?: string;
  tenantId?: string;
  dateFrom?: string;
  dateTo?: string;
  amountRange?: [number, number];
  search?: string;
}

export interface InvoiceFilters {
  status?: InvoiceStatus[];
  type?: InvoiceType[];
  propertyId?: string;
  tenantId?: string;
  dateFrom?: string;
  dateTo?: string;
  amountRange?: [number, number];
  search?: string;
}

export interface ExpenseFilters {
  category?: ExpenseCategory[];
  propertyId?: string;
  unitId?: string;
  dateFrom?: string;
  dateTo?: string;
  amountRange?: [number, number];
  vendor?: string;
  taxDeductible?: boolean;
  search?: string;
}

// Statistics and Analytics
export interface FinancialStats {
  totalRevenue: number;
  totalExpenses: number;
  netIncome: number;
  profitMargin: number;
  outstandingPayments: number;
  overdueAmount: number;
  averageRent: number;
  occupancyRevenue: number;
  monthlyGrowth: number;
  expenseRatio: number;
}

export interface PaymentStats {
  totalReceived: number;
  totalPending: number;
  totalOverdue: number;
  onTimePaymentRate: number;
  averagePaymentDelay: number;
  lateFeeCollected: number;
}

export interface ExpenseStats {
  totalExpenses: number;
  monthlyAverage: number;
  topCategory: string;
  budgetUtilization: number;
  yearOverYearGrowth: number;
  costPerUnit: number;
}

// Analytics and Dashboard Data
export interface FinancialDashboardData {
  stats: FinancialStats;
  revenueChart: Array<{ month: string; revenue: number; expenses: number; netIncome: number }>;
  paymentStatusChart: Array<{ status: string; amount: number; count: number; color: string }>;
  expenseBreakdown: Array<{ category: string; amount: number; percentage: number; color: string }>;
  propertyPerformance: Array<{ property: string; revenue: number; expenses: number; netIncome: number; margin: number }>;
  cashFlowProjection: Array<{ month: string; inflow: number; outflow: number; netFlow: number }>;
  recentTransactions: Transaction[];
  overduePayments: Payment[];
  upcomingInvoices: Invoice[];
}

export interface FinancialAnalytics {
  revenueTrend: Array<{ period: string; amount: number; growth: number }>;
  expenseTrend: Array<{ period: string; amount: number; growth: number }>;
  profitabilityTrend: Array<{ period: string; margin: number; netIncome: number }>;
  paymentPatterns: Array<{ method: string; amount: number; count: number; avgDelay: number }>;
  seasonalTrends: Array<{ month: string; revenue: number; expenses: number; seasonalIndex: number }>;
  benchmarkData: {
    industryAvgMargin: number;
    industryAvgOccupancy: number;
    industryAvgRent: number;
    performanceRank: number;
  };
}

// Configuration and Constants
export const PAYMENT_STATUS_CONFIG: Record<PaymentStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  pending: { label: 'Pending', color: 'text-yellow-800', bgColor: 'bg-yellow-100', icon: '⏳' },
  received: { label: 'Received', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  overdue: { label: 'Overdue', color: 'text-red-800', bgColor: 'bg-red-100', icon: '⚠️' },
  partial: { label: 'Partial', color: 'text-orange-800', bgColor: 'bg-orange-100', icon: '◐' },
  cancelled: { label: 'Cancelled', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '❌' },
  refunded: { label: 'Refunded', color: 'text-purple-800', bgColor: 'bg-purple-100', icon: '↩️' }
};

export const PAYMENT_METHOD_CONFIG: Record<PaymentMethod, { label: string; icon: string; color: string }> = {
  cash: { label: 'Cash', icon: '💵', color: 'bg-green-100 text-green-800' },
  bank_transfer: { label: 'Bank Transfer', icon: '🏦', color: 'bg-blue-100 text-blue-800' },
  check: { label: 'Check', icon: '📝', color: 'bg-gray-100 text-gray-800' },
  card: { label: 'Card', icon: '💳', color: 'bg-purple-100 text-purple-800' },
  digital_wallet: { label: 'Digital Wallet', icon: '📱', color: 'bg-indigo-100 text-indigo-800' },
  online: { label: 'Online Payment', icon: '🌐', color: 'bg-cyan-100 text-cyan-800' }
};

export const INVOICE_STATUS_CONFIG: Record<InvoiceStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  draft: { label: 'Draft', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '📝' },
  sent: { label: 'Sent', color: 'text-blue-800', bgColor: 'bg-blue-100', icon: '📤' },
  viewed: { label: 'Viewed', color: 'text-indigo-800', bgColor: 'bg-indigo-100', icon: '👁️' },
  paid: { label: 'Paid', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  overdue: { label: 'Overdue', color: 'text-red-800', bgColor: 'bg-red-100', icon: '⚠️' },
  cancelled: { label: 'Cancelled', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '❌' },
  refunded: { label: 'Refunded', color: 'text-purple-800', bgColor: 'bg-purple-100', icon: '↩️' }
};

export const EXPENSE_CATEGORY_CONFIG: Record<ExpenseCategory, { label: string; icon: string; color: string }> = {
  maintenance: { label: 'Maintenance', icon: '🔧', color: 'bg-orange-100 text-orange-800' },
  utilities: { label: 'Utilities', icon: '⚡', color: 'bg-yellow-100 text-yellow-800' },
  management: { label: 'Management', icon: '👥', color: 'bg-blue-100 text-blue-800' },
  marketing: { label: 'Marketing', icon: '📢', color: 'bg-pink-100 text-pink-800' },
  insurance: { label: 'Insurance', icon: '🛡️', color: 'bg-indigo-100 text-indigo-800' },
  taxes: { label: 'Taxes', icon: '🏛️', color: 'bg-red-100 text-red-800' },
  legal: { label: 'Legal', icon: '⚖️', color: 'bg-purple-100 text-purple-800' },
  supplies: { label: 'Supplies', icon: '📦', color: 'bg-gray-100 text-gray-800' },
  property_improvement: { label: 'Property Improvement', icon: '🏗️', color: 'bg-green-100 text-green-800' },
  other: { label: 'Other', icon: '📋', color: 'bg-gray-100 text-gray-800' }
};

export const REPORT_TYPE_CONFIG: Record<ReportType, { label: string; description: string; icon: string }> = {
  profit_loss: { label: 'Profit & Loss', description: 'Income and expense summary', icon: '📊' },
  cash_flow: { label: 'Cash Flow', description: 'Money in and out analysis', icon: '💹' },
  rental_income: { label: 'Rental Income', description: 'Rent collection report', icon: '🏠' },
  expense_analysis: { label: 'Expense Analysis', description: 'Detailed expense breakdown', icon: '📉' },
  property_performance: { label: 'Property Performance', description: 'Property-wise financial metrics', icon: '🏢' },
  tax_summary: { label: 'Tax Summary', description: 'Tax-related transactions', icon: '🧾' }
};

// Sorting options
export const PAYMENT_SORT_OPTIONS = [
  { value: 'date_desc', label: 'Date (Newest)' },
  { value: 'date_asc', label: 'Date (Oldest)' },
  { value: 'amount_desc', label: 'Amount (High to Low)' },
  { value: 'amount_asc', label: 'Amount (Low to High)' },
  { value: 'due_date_asc', label: 'Due Date (Earliest)' },
  { value: 'status', label: 'Status' },
  { value: 'tenant', label: 'Tenant Name' }
];

export const INVOICE_SORT_OPTIONS = [
  { value: 'date_desc', label: 'Date (Newest)' },
  { value: 'date_asc', label: 'Date (Oldest)' },
  { value: 'due_date_asc', label: 'Due Date (Earliest)' },
  { value: 'amount_desc', label: 'Amount (High to Low)' },
  { value: 'amount_asc', label: 'Amount (Low to High)' },
  { value: 'status', label: 'Status' },
  { value: 'tenant', label: 'Tenant Name' }
];

export const EXPENSE_SORT_OPTIONS = [
  { value: 'date_desc', label: 'Date (Newest)' },
  { value: 'date_asc', label: 'Date (Oldest)' },
  { value: 'amount_desc', label: 'Amount (High to Low)' },
  { value: 'amount_asc', label: 'Amount (Low to High)' },
  { value: 'category', label: 'Category' },
  { value: 'vendor', label: 'Vendor' }
];

// Currency and formatting
export const SUPPORTED_CURRENCIES = ['SAR', 'USD', 'EUR', 'GBP', 'AED'];
export const DEFAULT_CURRENCY = 'SAR';

// Pagination defaults
export const DEFAULT_PAGE_SIZE = 20;
export const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];

// Date ranges for reports
export const REPORT_DATE_RANGES = [
  { label: 'Last 30 Days', value: 'last_30_days' },
  { label: 'Last Quarter', value: 'last_quarter' },
  { label: 'Last 6 Months', value: 'last_6_months' },
  { label: 'Last Year', value: 'last_year' },
  { label: 'Year to Date', value: 'year_to_date' },
  { label: 'Custom Range', value: 'custom' }
];

// Export types
export const EXPORT_FORMATS = ['pdf', 'excel', 'csv'] as const;
export type ExportFormat = typeof EXPORT_FORMATS[number];

// Bulk operations
export interface BulkPaymentAction {
  action: 'mark_received' | 'send_reminder' | 'apply_late_fee' | 'mark_overdue' | 'delete';
  paymentIds: string[];
  data?: any;
}

export interface BulkInvoiceAction {
  action: 'send' | 'mark_paid' | 'apply_discount' | 'mark_overdue' | 'cancel' | 'duplicate' | 'delete';
  invoiceIds: string[];
  data?: any;
}

// Validation rules
export const VALIDATION_RULES = {
  amount: {
    min: 0.01,
    max: 10000000,
    precision: 2
  },
  lateFeePercentage: {
    min: 0,
    max: 50
  },
  discountPercentage: {
    min: 0,
    max: 100
  },
  taxRate: {
    min: 0,
    max: 30
  }
};