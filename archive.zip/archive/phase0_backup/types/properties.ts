// Property Management Types for FIXZIT SOUQ Enterprise

export type PropertyType = 'residential' | 'commercial' | 'mixed' | 'industrial' | 'retail';
export type UnitStatus = 'vacant' | 'occupied' | 'maintenance' | 'reserved' | 'unavailable';
export type TenantStatus = 'active' | 'inactive' | 'terminated' | 'pending';
export type LeaseStatus = 'active' | 'expired' | 'terminated' | 'pending' | 'draft';
export type LeaseType = 'fixed' | 'month_to_month' | 'yearly' | 'commercial';
export type DocumentCategory = 'lease' | 'inspection' | 'maintenance' | 'photo' | 'floorplan' | 'certificate' | 'insurance' | 'other';

// Enhanced Property Interface
export interface Property {
  id: string;
  name: string;
  address: string;
  type: PropertyType;
  totalUnits: number;
  description?: string;
  amenities?: string[];
  yearBuilt?: number;
  squareFootage?: number;
  parkingSpaces?: number;
  latitude?: number;
  longitude?: number;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  units?: Unit[];
  documents?: PropertyDocument[];
  workOrders?: any[];
  
  // Calculated fields
  occupiedUnits?: number;
  vacantUnits?: number;
  occupancyRate?: number;
  monthlyRevenue?: number;
  totalRevenue?: number;
  maintenanceCosts?: number;
  activeLeases?: number;
  expiringLeases?: number;
}

// Enhanced Unit Interface
export interface Unit {
  id: string;
  propertyId: string;
  unitNumber: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  areaSqm: number;
  rentAmount: number;
  status: UnitStatus;
  floor?: number;
  balcony?: boolean;
  furnished?: boolean;
  parkingIncluded?: boolean;
  description?: string;
  amenities?: string[];
  orgId: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  property?: Property;
  currentLease?: Lease;
  leases?: Lease[];
  documents?: PropertyDocument[];
  workOrders?: any[];
  
  // Calculated fields
  currentTenant?: Tenant;
  leaseExpiryDate?: string;
  daysUntilExpiry?: number;
  isLeaseExpiring?: boolean;
  totalRevenue?: number;
  lastMaintenanceDate?: string;
}

// Tenant Interface
export interface Tenant {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  nationalId?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  moveInDate?: string;
  moveOutDate?: string;
  status: TenantStatus;
  notes?: string;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  leases?: Lease[];
  documents?: PropertyDocument[];
  
  // Calculated fields
  currentUnit?: Unit;
  currentProperty?: Property;
  leaseHistory?: Lease[];
  totalPayments?: number;
  outstandingBalance?: number;
  avgRating?: number;
}

// Lease Interface
export interface Lease {
  id: string;
  tenantId: string;
  unitId: string;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  securityDeposit: number;
  status: LeaseStatus;
  leaseType: LeaseType;
  renewalTerms?: string;
  specialTerms?: string;
  signedDate?: string;
  terminationDate?: string;
  terminationReason?: string;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  tenant?: Tenant;
  unit?: Unit;
  
  // Calculated fields
  daysRemaining?: number;
  isExpiring?: boolean;
  isOverdue?: boolean;
  totalValue?: number;
  renewalEligible?: boolean;
}

// Property Document Interface
export interface PropertyDocument {
  id: string;
  propertyId?: string;
  unitId?: string;
  tenantId?: string;
  filename: string;
  originalName: string;
  url: string;
  size: number;
  mimeType: string;
  category: DocumentCategory;
  description?: string;
  isPublic: boolean;
  uploadedBy: string;
  orgId: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  property?: Property;
  unit?: Unit;
  tenant?: Tenant;
  uploader?: any;
}

// Filter and Search Interfaces
export interface PropertyFilters {
  type?: PropertyType[];
  status?: UnitStatus[];
  occupancyRange?: [number, number];
  revenueRange?: [number, number];
  location?: string;
  amenities?: string[];
  search?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface UnitFilters {
  propertyId?: string;
  status?: UnitStatus[];
  type?: string[];
  bedroomRange?: [number, number];
  bathroomRange?: [number, number];
  rentRange?: [number, number];
  floor?: number[];
  amenities?: string[];
  search?: string;
  leaseExpiring?: boolean;
}

export interface TenantFilters {
  status?: TenantStatus[];
  propertyId?: string;
  unitId?: string;
  leaseExpiring?: boolean;
  moveInDateFrom?: string;
  moveInDateTo?: string;
  search?: string;
}

// Form Data Interfaces
export interface PropertyFormData {
  name: string;
  address: string;
  type: PropertyType;
  totalUnits: number;
  description?: string;
  amenities?: string[];
  yearBuilt?: number;
  squareFootage?: number;
  parkingSpaces?: number;
  latitude?: number;
  longitude?: number;
}

export interface UnitFormData {
  propertyId: string;
  unitNumber: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  areaSqm: number;
  rentAmount: number;
  floor?: number;
  balcony?: boolean;
  furnished?: boolean;
  parkingIncluded?: boolean;
  description?: string;
  amenities?: string[];
}

export interface TenantFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  nationalId?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  notes?: string;
}

export interface LeaseFormData {
  tenantId: string;
  unitId: string;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  securityDeposit: number;
  leaseType: LeaseType;
  renewalTerms?: string;
  specialTerms?: string;
  signedDate?: string;
}

// Statistics and Analytics Interfaces
export interface PropertyStats {
  totalProperties: number;
  totalUnits: number;
  occupiedUnits: number;
  vacantUnits: number;
  maintenanceUnits: number;
  overallOccupancyRate: number;
  totalMonthlyRevenue: number;
  averageRentPerUnit: number;
  maintenanceCosts: number;
  netIncome: number;
}

export interface UnitStats {
  total: number;
  occupied: number;
  vacant: number;
  maintenance: number;
  reserved: number;
  averageRent: number;
  totalRevenue: number;
  occupancyTrend: number;
}

export interface TenantStats {
  total: number;
  active: number;
  inactive: number;
  newThisMonth: number;
  leavingThisMonth: number;
  averageTenancy: number;
  satisfactionRating: number;
}

export interface LeaseStats {
  total: number;
  active: number;
  expiring30Days: number;
  expiring90Days: number;
  expired: number;
  averageLeaseLength: number;
  renewalRate: number;
}

// Dashboard and Analytics
export interface PropertyAnalytics {
  occupancyTrend: { month: string; rate: number }[];
  revenueTrend: { month: string; revenue: number }[];
  maintenanceCosts: { month: string; cost: number }[];
  topPerformingProperties: Property[];
  underperformingProperties: Property[];
  leaseExpirations: { month: string; count: number }[];
  tenantSatisfaction: { property: string; rating: number }[];
}

export interface OccupancyDashboard {
  overallRate: number;
  trend: 'up' | 'down' | 'stable';
  vacantUnits: Unit[];
  expiringLeases: Lease[];
  newMoveIns: number;
  scheduledMoveOuts: number;
  maintenanceUnits: Unit[];
}

// Bulk Operations
export interface BulkPropertyAction {
  action: 'update_status' | 'assign_manager' | 'update_type' | 'add_amenity' | 'delete';
  propertyIds: string[];
  data?: any;
}

export interface BulkUnitAction {
  action: 'update_status' | 'update_rent' | 'assign_property' | 'add_amenity' | 'delete';
  unitIds: string[];
  data?: any;
}

// Configuration and Constants
export const PROPERTY_TYPE_CONFIG: Record<PropertyType, { label: string; icon: string; color: string }> = {
  residential: { label: 'Residential', icon: '🏠', color: 'bg-blue-100 text-blue-800' },
  commercial: { label: 'Commercial', icon: '🏢', color: 'bg-purple-100 text-purple-800' },
  mixed: { label: 'Mixed Use', icon: '🏬', color: 'bg-orange-100 text-orange-800' },
  industrial: { label: 'Industrial', icon: '🏭', color: 'bg-gray-100 text-gray-800' },
  retail: { label: 'Retail', icon: '🏪', color: 'bg-green-100 text-green-800' }
};

export const UNIT_STATUS_CONFIG: Record<UnitStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  vacant: { label: 'Vacant', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '⚪' },
  occupied: { label: 'Occupied', color: 'text-green-800', bgColor: 'bg-green-100', icon: '🟢' },
  maintenance: { label: 'Maintenance', color: 'text-orange-800', bgColor: 'bg-orange-100', icon: '🔧' },
  reserved: { label: 'Reserved', color: 'text-blue-800', bgColor: 'bg-blue-100', icon: '🔵' },
  unavailable: { label: 'Unavailable', color: 'text-red-800', bgColor: 'bg-red-100', icon: '🔴' }
};

export const TENANT_STATUS_CONFIG: Record<TenantStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  active: { label: 'Active', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  inactive: { label: 'Inactive', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '⚪' },
  terminated: { label: 'Terminated', color: 'text-red-800', bgColor: 'bg-red-100', icon: '❌' },
  pending: { label: 'Pending', color: 'text-yellow-800', bgColor: 'bg-yellow-100', icon: '⏳' }
};

export const LEASE_STATUS_CONFIG: Record<LeaseStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  active: { label: 'Active', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  expired: { label: 'Expired', color: 'text-red-800', bgColor: 'bg-red-100', icon: '⏰' },
  terminated: { label: 'Terminated', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '❌' },
  pending: { label: 'Pending', color: 'text-yellow-800', bgColor: 'bg-yellow-100', icon: '⏳' },
  draft: { label: 'Draft', color: 'text-blue-800', bgColor: 'bg-blue-100', icon: '📝' }
};

export const DOCUMENT_CATEGORY_CONFIG: Record<DocumentCategory, { label: string; icon: string; color: string }> = {
  lease: { label: 'Lease Agreement', icon: '📄', color: 'bg-blue-100 text-blue-800' },
  inspection: { label: 'Inspection Report', icon: '🔍', color: 'bg-purple-100 text-purple-800' },
  maintenance: { label: 'Maintenance Record', icon: '🔧', color: 'bg-orange-100 text-orange-800' },
  photo: { label: 'Photo', icon: '📸', color: 'bg-green-100 text-green-800' },
  floorplan: { label: 'Floor Plan', icon: '📐', color: 'bg-yellow-100 text-yellow-800' },
  certificate: { label: 'Certificate', icon: '🏅', color: 'bg-red-100 text-red-800' },
  insurance: { label: 'Insurance', icon: '🛡️', color: 'bg-indigo-100 text-indigo-800' },
  other: { label: 'Other', icon: '📁', color: 'bg-gray-100 text-gray-800' }
};

// Sorting and View Options
export const PROPERTY_SORT_OPTIONS = [
  { value: 'name_asc', label: 'Name (A-Z)' },
  { value: 'name_desc', label: 'Name (Z-A)' },
  { value: 'created_desc', label: 'Newest First' },
  { value: 'created_asc', label: 'Oldest First' },
  { value: 'occupancy_desc', label: 'Occupancy (High to Low)' },
  { value: 'occupancy_asc', label: 'Occupancy (Low to High)' },
  { value: 'revenue_desc', label: 'Revenue (High to Low)' },
  { value: 'revenue_asc', label: 'Revenue (Low to High)' },
  { value: 'units_desc', label: 'Most Units' },
  { value: 'units_asc', label: 'Least Units' }
];

export const UNIT_SORT_OPTIONS = [
  { value: 'unit_number_asc', label: 'Unit Number (A-Z)' },
  { value: 'unit_number_desc', label: 'Unit Number (Z-A)' },
  { value: 'rent_desc', label: 'Rent (High to Low)' },
  { value: 'rent_asc', label: 'Rent (Low to High)' },
  { value: 'status', label: 'Status' },
  { value: 'bedrooms_desc', label: 'Bedrooms (Most)' },
  { value: 'bedrooms_asc', label: 'Bedrooms (Least)' },
  { value: 'area_desc', label: 'Area (Largest)' },
  { value: 'area_asc', label: 'Area (Smallest)' }
];

export const VIEW_MODES = ['grid', 'table', 'map'] as const;
export type ViewMode = typeof VIEW_MODES[number];

// Utility Types
export interface PropertySearchResult {
  properties: Property[];
  total: number;
  page: number;
  limit: number;
  filters: PropertyFilters;
}

export interface UnitSearchResult {
  units: Unit[];
  total: number;
  page: number;
  limit: number;
  filters: UnitFilters;
}

export interface TenantSearchResult {
  tenants: Tenant[];
  total: number;
  page: number;
  limit: number;
  filters: TenantFilters;
}