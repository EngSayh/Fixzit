// System Management Types
export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department?: string;
  isActive: boolean;
  lastLogin?: string;
  createdDate: string;
  updatedDate: string;
  permissions: string[];
  avatar?: string;
  phone?: string;
  preferences?: UserPreferences;
}

export interface UserPreferences {
  language: 'en' | 'ar';
  timezone: string;
  dateFormat: string;
  notifications: NotificationPreferences;
  theme: 'light' | 'dark';
}

export interface NotificationPreferences {
  email: boolean;
  sms: boolean;
  push: boolean;
  workOrders: boolean;
  payments: boolean;
  system: boolean;
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  isActive: boolean;
  createdDate: string;
  updatedDate: string;
  userCount: number;
}

export interface Permission {
  id: string;
  name: string;
  resource: string;
  action: string;
  description: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  resource: string;
  resourceId?: string;
  details: string;
  timestamp: string;
  ipAddress: string;
  userAgent: string;
  status: 'success' | 'failed';
}

export interface Integration {
  id: string;
  name: string;
  type: 'payment' | 'communication' | 'storage' | 'analytics' | 'other';
  status: 'active' | 'inactive' | 'error';
  description: string;
  apiKey?: string;
  webhookUrl?: string;
  lastSync?: string;
  settings: Record<string, any>;
}

export interface Tenant {
  id: string;
  name: string;
  domain: string;
  status: 'active' | 'inactive' | 'suspended';
  subscriptionPlan: string;
  billingCycle: 'monthly' | 'yearly';
  userCount: number;
  storageUsed: number;
  storageLimit: number;
  createdDate: string;
  expiryDate: string;
  adminContact: string;
}

export interface SystemStats {
  totalUsers: number;
  activeUsers: number;
  totalRoles: number;
  totalPermissions: number;
  systemUptime: string;
  lastBackup: string;
  storageUsed: number;
  storageLimit: number;
  apiCalls24h: number;
  errorRate: number;
}

// System Monitoring Types
export interface SystemModule {
  id: string;
  name: string;
  status: 'operational' | 'degraded' | 'error' | 'warning';
  health: number;
  responseTime: number;
  endpoints: any[];
  errors: any[];
  metrics: {
    cpu: number;
    memory: number;
    diskUsage: number;
    networkIO: {
      in: number;
      out: number;
    };
    requestCount: number;
    errorCount: number;
    avgProcessingTime: number;
  };
  dependencies: string[];
  lastChecked: Date;
}

export interface SystemReport {
  timestamp: Date;
  overall: {
    health: number;
    status: string;
    uptime: number;
    activeUsers: number;
  };
  modules: SystemModule[];
  database: any;
  infrastructure: any;
  integrations: any[];
  kpis: any;
  errors: any[];
  recommendations: any[];
  performanceMetrics: any;
}