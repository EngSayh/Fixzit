// Work Order Management Types for FIXZIT SOUQ Enterprise

export type WorkOrderCategory = 'hvac' | 'plumbing' | 'electrical' | 'general' | 'cleaning' | 'maintenance';
export type WorkOrderPriority = 'emergency' | 'high' | 'medium' | 'low';
export type WorkOrderStatus = 'draft' | 'open' | 'assigned' | 'in_progress' | 'on_hold' | 'completed' | 'closed' | 'cancelled';

export interface WorkOrder {
  id: string;
  woNumber: string;
  title: string;
  description: string;
  category: WorkOrderCategory;
  priority: WorkOrderPriority;
  status: WorkOrderStatus;
  propertyId?: string;
  unitId?: string;
  assignedTo?: string;
  createdBy: string;
  orgId: string;
  dueDate?: string;
  completedAt?: string;
  estimatedHours?: number;
  actualHours?: number;
  estimatedCost?: number;
  actualCost?: number;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  property?: Property;
  unit?: Unit;
  assignee?: User;
  creator?: User;
  photos?: WorkOrderPhoto[];
  comments?: WorkOrderComment[];
  timeline?: WorkOrderTimeline[];
}

export interface Property {
  id: string;
  name: string;
  address: string;
  type: 'residential' | 'commercial' | 'mixed';
  totalUnits: number;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Unit {
  id: string;
  propertyId: string;
  unitNumber: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  areaSqm: number;
  rentAmount: number;
  status: 'vacant' | 'occupied' | 'maintenance' | 'reserved';
  orgId: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  phone?: string;
  avatar?: string;
  isActive: boolean;
  orgId?: string;
}

export interface WorkOrderPhoto {
  id: string;
  workOrderId: string;
  url: string;
  filename: string;
  type: 'before' | 'during' | 'after' | 'general';
  description?: string;
  uploadedBy: string;
  createdAt: string;
}

export interface WorkOrderComment {
  id: string;
  workOrderId: string;
  comment: string;
  type: 'comment' | 'status_update' | 'assignment' | 'system';
  createdBy: string;
  createdAt: string;
  user?: User;
}

export interface WorkOrderTimeline {
  id: string;
  workOrderId: string;
  action: string;
  description?: string;
  performedBy: string;
  performedAt: string;
  user?: User;
}

export interface WorkOrderFilters {
  status?: WorkOrderStatus[];
  priority?: WorkOrderPriority[];
  category?: WorkOrderCategory[];
  propertyId?: string;
  assignedTo?: string;
  createdBy?: string;
  dateFrom?: string;
  dateTo?: string;
  search?: string;
}

export interface WorkOrderFormData {
  title: string;
  description: string;
  category: WorkOrderCategory;
  priority: WorkOrderPriority;
  propertyId?: string;
  unitId?: string;
  dueDate?: string;
  estimatedHours?: number;
  estimatedCost?: number;
  photos?: File[];
}

export interface WorkOrderStats {
  total: number;
  open: number;
  inProgress: number;
  completed: number;
  overdue: number;
  emergency: number;
  averageCompletionTime?: number;
  averageResponseTime?: number;
  satisfactionRating?: number;
  totalCost?: number;
}

// Enhanced types for comprehensive system
export interface TechnicianSkill {
  id: string;
  name: string;
  category: WorkOrderCategory;
  level: 'beginner' | 'intermediate' | 'expert';
}

export interface Technician extends User {
  skills: TechnicianSkill[];
  availability: 'available' | 'busy' | 'offline';
  currentWorkOrders: number;
  maxWorkOrders: number;
  avgRating?: number;
  totalCompleted?: number;
  location?: {
    lat: number;
    lng: number;
    lastUpdated: string;
  };
}

export interface WorkOrderAssignment {
  id: string;
  workOrderId: string;
  technicianId: string;
  assignedBy: string;
  assignedAt: string;
  estimatedArrival?: string;
  actualArrival?: string;
  startedAt?: string;
  completedAt?: string;
  rating?: number;
  feedback?: string;
  technician?: Technician;
}

export interface SLATracking {
  id: string;
  workOrderId: string;
  responseTimeTarget: number; // minutes
  completionTimeTarget: number; // hours
  actualResponseTime?: number;
  actualCompletionTime?: number;
  status: 'on_track' | 'at_risk' | 'breached';
  breachReason?: string;
}

export interface WorkOrderTemplate {
  id: string;
  name: string;
  category: WorkOrderCategory;
  description: string;
  estimatedHours: number;
  estimatedCost: number;
  checklistItems: string[];
  requiredSkills: string[];
  isActive: boolean;
}

export interface WorkOrderNotification {
  id: string;
  workOrderId: string;
  userId: string;
  type: 'assignment' | 'status_change' | 'overdue' | 'completion' | 'comment';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface WorkOrderAttachment {
  id: string;
  workOrderId: string;
  filename: string;
  originalName: string;
  url: string;
  size: number;
  mimeType: string;
  uploadedBy: string;
  createdAt: string;
}

export interface BulkAction {
  action: 'assign' | 'update_status' | 'update_priority' | 'add_comment' | 'delete';
  workOrderIds: string[];
  data?: any;
}

// UI Configuration
export const CATEGORY_CONFIG: Record<WorkOrderCategory, { label: string; icon: string; color: string }> = {
  hvac: { label: 'HVAC', icon: '❄️', color: 'bg-blue-100 text-blue-800' },
  plumbing: { label: 'Plumbing', icon: '🚿', color: 'bg-cyan-100 text-cyan-800' },
  electrical: { label: 'Electrical', icon: '⚡', color: 'bg-yellow-100 text-yellow-800' },
  general: { label: 'General', icon: '🔧', color: 'bg-gray-100 text-gray-800' },
  cleaning: { label: 'Cleaning', icon: '🧹', color: 'bg-green-100 text-green-800' },
  maintenance: { label: 'Maintenance', icon: '⚙️', color: 'bg-purple-100 text-purple-800' }
};

export const PRIORITY_CONFIG: Record<WorkOrderPriority, { label: string; color: string; bgColor: string }> = {
  emergency: { label: 'Emergency', color: 'text-red-800', bgColor: 'bg-red-100' },
  high: { label: 'High', color: 'text-orange-800', bgColor: 'bg-orange-100' },
  medium: { label: 'Medium', color: 'text-yellow-800', bgColor: 'bg-yellow-100' },
  low: { label: 'Low', color: 'text-gray-800', bgColor: 'bg-gray-100' }
};

export const STATUS_CONFIG: Record<WorkOrderStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  draft: { label: 'Draft', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '📝' },
  open: { label: 'Open', color: 'text-blue-800', bgColor: 'bg-blue-100', icon: '🔓' },
  assigned: { label: 'Assigned', color: 'text-purple-800', bgColor: 'bg-purple-100', icon: '👤' },
  in_progress: { label: 'In Progress', color: 'text-orange-800', bgColor: 'bg-orange-100', icon: '⚡' },
  on_hold: { label: 'On Hold', color: 'text-yellow-800', bgColor: 'bg-yellow-100', icon: '⏸️' },
  completed: { label: 'Completed', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  closed: { label: 'Closed', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '🔒' },
  cancelled: { label: 'Cancelled', color: 'text-red-800', bgColor: 'bg-red-100', icon: '❌' }
};

// Additional configuration constants
export const SKILL_LEVEL_CONFIG = {
  beginner: { label: 'Beginner', color: 'text-green-800', bgColor: 'bg-green-100' },
  intermediate: { label: 'Intermediate', color: 'text-yellow-800', bgColor: 'bg-yellow-100' },
  expert: { label: 'Expert', color: 'text-red-800', bgColor: 'bg-red-100' }
};

export const SLA_STATUS_CONFIG = {
  on_track: { label: 'On Track', color: 'text-green-800', bgColor: 'bg-green-100', icon: '✅' },
  at_risk: { label: 'At Risk', color: 'text-yellow-800', bgColor: 'bg-yellow-100', icon: '⚠️' },
  breached: { label: 'Breached', color: 'text-red-800', bgColor: 'bg-red-100', icon: '🚨' }
};

export const AVAILABILITY_CONFIG = {
  available: { label: 'Available', color: 'text-green-800', bgColor: 'bg-green-100', icon: '🟢' },
  busy: { label: 'Busy', color: 'text-orange-800', bgColor: 'bg-orange-100', icon: '🟡' },
  offline: { label: 'Offline', color: 'text-gray-800', bgColor: 'bg-gray-100', icon: '⚫' }
};

// Sorting options
export const SORT_OPTIONS = [
  { value: 'created_desc', label: 'Newest First' },
  { value: 'created_asc', label: 'Oldest First' },
  { value: 'due_date_asc', label: 'Due Date (Earliest)' },
  { value: 'due_date_desc', label: 'Due Date (Latest)' },
  { value: 'priority_desc', label: 'Priority (High to Low)' },
  { value: 'priority_asc', label: 'Priority (Low to High)' },
  { value: 'status', label: 'Status' },
  { value: 'category', label: 'Category' }
];

// View modes
export const VIEW_MODES = ['grid', 'table', 'kanban'] as const;
export type ViewMode = typeof VIEW_MODES[number];