// Compliance & Legal Types
export interface ComplianceItem {
  id: string;
  title: string;
  type: 'permit' | 'license' | 'certificate' | 'inspection' | 'legal' | 'insurance';
  status: 'active' | 'expired' | 'pending' | 'expired_soon';
  description: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  renewalDate?: string;
  documentUrl?: string;
  cost?: number;
  propertyId?: string;
  assignedTo?: string;
  notes?: string;
  reminders: ComplianceReminder[];
}

export interface ComplianceReminder {
  id: string;
  complianceItemId: string;
  type: 'renewal' | 'inspection' | 'filing';
  scheduledDate: string;
  message: string;
  sent: boolean;
  sentDate?: string;
}

export interface LegalDocument {
  id: string;
  title: string;
  type: 'contract' | 'agreement' | 'policy' | 'procedure' | 'template';
  category: string;
  version: string;
  status: 'draft' | 'active' | 'archived';
  description: string;
  content?: string;
  documentUrl: string;
  createdBy: string;
  approvedBy?: string;
  createdDate: string;
  approvedDate?: string;
  lastReviewDate?: string;
  nextReviewDate?: string;
  tags: string[];
}

export interface Inspection {
  id: string;
  title: string;
  type: 'safety' | 'fire' | 'health' | 'environmental' | 'building' | 'electrical';
  propertyId: string;
  inspectorName: string;
  inspectorLicense: string;
  scheduledDate: string;
  completedDate?: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'failed';
  findings: InspectionFinding[];
  overallScore?: number;
  certificateUrl?: string;
  nextInspectionDate?: string;
  cost: number;
}

export interface InspectionFinding {
  id: string;
  category: string;
  description: string;
  severity: 'critical' | 'major' | 'minor';
  status: 'open' | 'resolved';
  actionRequired: string;
  deadline?: string;
  assignedTo?: string;
  resolvedDate?: string;
  photos?: string[];
}

export interface ComplianceStats {
  totalItems: number;
  activeItems: number;
  expiringSoon: number;
  expiredItems: number;
  totalInspections: number;
  passedInspections: number;
  avgInspectionScore: number;
  complianceRate: number;
  costYTD: number;
  itemsByType: Record<string, number>;
  expiryTrend: Array<{ month: string; expiring: number }>;
}

export interface ComplianceFilters {
  type?: string[];
  status?: string[];
  propertyId?: string;
  dateRange?: [string, string];
  search?: string;
}