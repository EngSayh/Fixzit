"""
Feature Flags Usage Examples
Demonstrates how to use feature flags throughout the application
"""

import streamlit as st
from services.feature_flags import (
    flag_enabled,
    with_flag,
    require_flag,
    feature_flags_service,
)
from services.remote_config import get_config, get_bool_config, get_int_config


def main():
    st.title("🚩 Feature Flags Usage Examples")

    st.markdown(
        """
    This page demonstrates various ways to use feature flags and remote configuration 
    in your Fixzit application.
    """
    )

    # Example 1: Simple flag check
    st.markdown("### Example 1: Simple Flag Check")

    if flag_enabled("dashboard_charts_v2"):
        st.success("✅ New dashboard charts are enabled!")
        show_new_charts()
    else:
        st.info("📊 Using classic dashboard charts")
        show_classic_charts()

    # Example 2: Conditional content with fallback
    st.markdown("### Example 2: Conditional Content")

    with_flag(
        "secure_sharing_v2",
        enabled_content=lambda: st.button("🔐 Secure Share (New)", type="primary"),
        disabled_content=lambda: st.button("📤 Regular Share", type="secondary"),
    )

    # Example 3: Using decorator
    st.markdown("### Example 3: Advanced Analytics (Decorator Protected)")
    show_advanced_analytics()

    # Example 4: Remote configuration
    st.markdown("### Example 4: Remote Configuration")
    show_config_examples()

    # Example 5: Rollout testing
    st.markdown("### Example 5: Test Your Flag Status")
    test_user_flags()


def show_new_charts():
    """New version of dashboard charts"""
    st.plotly_chart(
        {
            "data": [
                {
                    "type": "scatter",
                    "x": [1, 2, 3, 4],
                    "y": [10, 11, 12, 13],
                    "name": "New Chart Style",
                }
            ],
            "layout": {"title": "🎨 Enhanced Chart (V2)", "showlegend": True},
        },
        use_container_width=True,
    )


def show_classic_charts():
    """Classic version of dashboard charts"""
    st.bar_chart({"data": [1, 2, 3, 4]})
    st.caption("Classic chart style")


@require_flag(
    "advanced_analytics", "🔒 Advanced analytics not available for your account"
)
def show_advanced_analytics():
    """Protected feature requiring flag"""
    st.success("🎯 Advanced Analytics Enabled!")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Conversion Rate", "12.5%", "2.3%")
    with col2:
        st.metric("User Engagement", "89%", "5.1%")
    with col3:
        st.metric("Revenue Impact", "$15,240", "18.7%")


def show_config_examples():
    """Demonstrate remote configuration usage"""
    st.markdown("#### 📡 Live Configuration Values")

    # Get various config types
    max_file_size = get_int_config("max_file_size_mb", 25)
    company_name = get_config("company_name", "Fixzit")
    maintenance_mode = get_bool_config("maintenance_mode", False)

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Max File Size", f"{max_file_size} MB")
        st.caption("🔧 Configurable without deployment")

    with col2:
        st.metric("Company Name", company_name)
        st.caption("🏢 Brand configuration")

    with col3:
        status = "🔴 MAINTENANCE" if maintenance_mode else "🟢 OPERATIONAL"
        st.metric("System Status", status)
        st.caption("⚡ Live status control")

    # Show maintenance mode effect
    if maintenance_mode:
        st.warning(
            "🚧 System is in maintenance mode. Some features may be unavailable."
        )


def test_user_flags():
    """Test flag evaluation for current user"""
    st.markdown("#### 🧪 Test Your Flag Access")

    # Get current user context
    user_role = st.session_state.get("user_role", "individual")
    user_plan = st.session_state.get("user_plan", "free")
    user_id = st.session_state.get("user_id", "demo_user")

    st.info(f"**Your Context:** Role: {user_role} | Plan: {user_plan} | ID: {user_id}")

    # Test common flags
    test_flags = [
        "dashboard_charts_v2",
        "secure_sharing_v2",
        "advanced_analytics",
        "beta_features",
        "premium_support",
    ]

    st.markdown("**Flag Status for Your Account:**")

    for flag_name in test_flags:
        is_enabled = feature_flags_service.is_flag_enabled(flag_name)
        status_icon = "🟢" if is_enabled else "🔴"
        status_text = "ENABLED" if is_enabled else "DISABLED"

        col1, col2 = st.columns([3, 1])
        with col1:
            st.write(f"`{flag_name}`")
        with col2:
            st.write(f"{status_icon} {status_text}")


def create_sample_flags():
    """Create some sample flags for demonstration"""
    if st.button("🎬 Create Sample Flags & Config"):
        # Create sample feature flags
        sample_flags = [
            {
                "name": "dashboard_charts_v2",
                "enabled": True,
                "rollout_percentage": 50,
                "note": "New interactive dashboard charts",
            },
            {
                "name": "secure_sharing_v2",
                "enabled": True,
                "rollout_percentage": 100,
                "target_plans": ["pro", "enterprise"],
                "note": "Enhanced secure sharing for premium users",
            },
            {
                "name": "advanced_analytics",
                "enabled": True,
                "rollout_percentage": 25,
                "target_roles": ["admin", "manager"],
                "note": "Advanced analytics dashboard for managers",
            },
        ]

        for flag_data in sample_flags:
            from services.feature_flags import FlagRule

            flag = FlagRule(
                name=flag_data["name"],
                enabled=flag_data["enabled"],
                rollout_percentage=flag_data["rollout_percentage"],
                target_plans=flag_data.get("target_plans"),
                target_roles=flag_data.get("target_roles"),
                note=flag_data["note"],
                created_by="demo",
            )
            feature_flags_service.create_flag(flag)

        # Create sample remote config
        from services.remote_config import remote_config_service

        sample_configs = {
            "max_file_size_mb": 25,
            "company_name": "Fixzit Demo",
            "maintenance_mode": False,
            "max_users_per_tenant": 100,
            "session_timeout_minutes": 30,
        }

        for key, value in sample_configs.items():
            remote_config_service.set_config(key, value, note=f"Demo config for {key}")

        st.success("✅ Sample flags and configuration created!")
        st.rerun()


if __name__ == "__main__":
    # Add demo setup section
    with st.sidebar:
        st.markdown("### 🎬 Demo Setup")
        create_sample_flags()

        st.markdown("### 📝 Quick Links")
        if st.button("🚩 Manage Flags"):
            st.switch_page("pages/998_FeatureFlags.py")
        if st.button("⚙️ Manage Config"):
            st.switch_page("pages/997_RemoteConfig.py")

    main()
