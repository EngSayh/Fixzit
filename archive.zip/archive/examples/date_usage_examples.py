"""
Examples of how to use the new date management system in Fixzit forms
"""

import streamlit as st
from datetime import datetime, date
from utils.date_manager import (
    date_manager,
    format_date,
    create_date_picker,
    create_datetime_picker,
)


# Example 1: Basic date display
def show_date_display_example():
    """Example of how to display dates with user preferences"""

    # Get some sample dates
    today = datetime.now().date()
    contract_date = date(2025, 3, 15)
    payment_due = date(2025, 2, 28)

    st.markdown("### 📅 Date Display Examples")

    # Display dates with user preferences
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Today", format_date(today))

    with col2:
        st.metric("Contract Date", format_date(contract_date))

    with col3:
        st.metric("Payment Due", format_date(payment_due))


# Example 2: Date picker in forms
def contract_form_example():
    """Example contract form with new date pickers"""

    st.markdown("### 📋 Contract Form Example")

    with st.form("contract_example"):
        col1, col2 = st.columns(2)

        with col1:
            # Contract start date
            start_date = create_date_picker(
                "Contract Start Date",
                "contract_start",
                help_text="Select the contract start date",
            )

            # Contract value
            contract_value = st.number_input(
                "Contract Value (SAR)", min_value=0.0, step=100.0
            )

        with col2:
            # Contract end date
            end_date = create_date_picker(
                "Contract End Date",
                "contract_end",
                help_text="Select the contract end date",
            )

            # Payment frequency
            st.selectbox(
                "Payment Frequency", ["Monthly", "Quarterly", "Semi-Annual", "Annual"]
            )

        # Signature date and time
        signature_datetime = create_datetime_picker(
            "Signature Date & Time", "signature_datetime"
        )

        # Submit button
        if st.form_submit_button("Create Contract"):
            if start_date and end_date and signature_datetime:
                st.success(
                    f"""
                Contract created successfully!
                - Start: {format_date(start_date)}
                - End: {format_date(end_date)}
                - Value: {contract_value:,.2f} SAR
                - Signed: {format_date(signature_datetime.date())} at {signature_datetime.time()}
                """
                )


# Example 3: Payment form with due dates
def payment_form_example():
    """Example payment form with date management"""

    st.markdown("### 💰 Payment Form Example")

    with st.form("payment_example"):
        col1, col2 = st.columns(2)

        with col1:
            # Invoice date
            invoice_date = create_date_picker(
                "Invoice Date", "invoice_date", default_value=datetime.now().date()
            )

            # Amount
            amount = st.number_input("Amount (SAR)", min_value=0.0, step=10.0)

        with col2:
            # Due date
            due_date = create_date_picker(
                "Due Date", "payment_due", help_text="Payment due date"
            )

            # Payment method
            st.selectbox(
                "Payment Method", ["Bank Transfer", "Credit Card", "Cash", "Check"]
            )

        # Notes
        st.text_area("Notes", placeholder="Additional payment notes...")

        if st.form_submit_button("Record Payment"):
            if invoice_date and due_date and amount > 0:
                # Calculate days until due
                days_until_due = (due_date - datetime.now().date()).days

                status = (
                    "⚠️ Overdue"
                    if days_until_due < 0
                    else f"✅ {days_until_due} days remaining"
                )

                st.success(
                    f"""
                Payment recorded successfully!
                - Invoice: {format_date(invoice_date)}
                - Due: {format_date(due_date)}
                - Amount: {amount:,.2f} SAR
                - Status: {status}
                """
                )


# Example 4: Report date range
def report_form_example():
    """Example report form with date ranges"""

    st.markdown("### 📊 Report Generation Example")

    with st.form("report_example"):
        # Date range picker
        start_date, end_date = date_manager.create_date_range_picker(
            "Report Start Date", "Report End Date", "report_range"
        )

        # Report type
        report_type = st.selectbox(
            "Report Type",
            [
                "Financial Summary",
                "Contract Activity",
                "Payment Status",
                "Maintenance Log",
            ],
        )

        # Additional filters
        col1, col2 = st.columns(2)

        with col1:
            st.checkbox("Include Pending Items", value=True)

        with col2:
            export_format = st.selectbox("Export Format", ["PDF", "Excel", "CSV"])

        if st.form_submit_button("Generate Report"):
            if start_date and end_date:
                st.success(
                    f"""
                Report generation started!
                - Period: {format_date(start_date)} to {format_date(end_date)}
                - Type: {report_type}
                - Format: {export_format}
                """
                )


# Example 5: Maintenance scheduling
def maintenance_form_example():
    """Example maintenance scheduling with dates"""

    st.markdown("### 🔧 Maintenance Scheduling Example")

    with st.form("maintenance_example"):
        col1, col2 = st.columns(2)

        with col1:
            # Request date (auto-filled)
            request_date = create_date_picker(
                "Request Date",
                "maintenance_request",
                default_value=datetime.now().date(),
                disabled=True,
            )

            # Priority
            priority = st.selectbox("Priority", ["Low", "Medium", "High", "Emergency"])

        with col2:
            # Scheduled date
            scheduled_date = create_datetime_picker(
                "Scheduled Date & Time", "maintenance_scheduled"
            )

            # Estimated duration
            duration = st.number_input(
                "Estimated Duration (hours)", min_value=0.5, max_value=24.0, step=0.5
            )

        # Description
        description = st.text_area(
            "Maintenance Description", placeholder="Describe the maintenance work..."
        )

        if st.form_submit_button("Schedule Maintenance"):
            if scheduled_date and description:
                st.success(
                    f"""
                Maintenance scheduled successfully!
                - Requested: {format_date(request_date)}
                - Scheduled: {format_date(scheduled_date.date())} at {scheduled_date.time()}
                - Priority: {priority}
                - Duration: {duration} hours
                """
                )


# Example 6: Event management
def event_form_example():
    """Example event management with multiple dates"""

    st.markdown("### 🎉 Event Management Example")

    with st.form("event_example"):
        # Event details
        event_name = st.text_input("Event Name", placeholder="Enter event name")

        col1, col2 = st.columns(2)

        with col1:
            # Event start
            event_start = create_datetime_picker("Event Start", "event_start")

            # Registration deadline
            registration_deadline = create_date_picker(
                "Registration Deadline", "registration_deadline"
            )

        with col2:
            # Event end
            event_end = create_datetime_picker("Event End", "event_end")

            # Maximum attendees
            st.number_input("Maximum Attendees", min_value=1, step=1)

        # Event description
        st.text_area("Event Description", placeholder="Describe the event...")

        if st.form_submit_button("Create Event"):
            if event_name and event_start and event_end:
                duration = event_end - event_start

                st.success(
                    f"""
                Event created successfully!
                - Name: {event_name}
                - Start: {format_date(event_start.date())} at {event_start.time()}
                - End: {format_date(event_end.date())} at {event_end.time()}
                - Duration: {duration}
                - Registration by: {format_date(registration_deadline) if registration_deadline else 'No deadline'}
                """
                )


def main():
    """Main function to demonstrate all examples"""
    st.title("📅 Date Management System Examples")
    st.markdown("*Examples of using the new intelligent date system in Fixzit*")

    # Show current user preferences
    prefs = date_manager.get_user_date_preferences()

    with st.expander("Current Date Preferences", expanded=False):
        st.json(prefs)

    # Show all examples
    show_date_display_example()
    st.markdown("---")

    contract_form_example()
    st.markdown("---")

    payment_form_example()
    st.markdown("---")

    report_form_example()
    st.markdown("---")

    maintenance_form_example()
    st.markdown("---")

    event_form_example()


if __name__ == "__main__":
    main()
