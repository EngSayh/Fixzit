"""
Example of enhanced form with navigation buttons, change tracking, and audit logging
"""

import streamlit as st
from datetime import date
from utils.rtl_support import apply_page_rtl

# Legacy navigation imports removed - using new navigation system
from utils.form_tracking import create_tracked_form
from utils.audit_logger import log_action

# Check authentication
if not st.session_state.get("authenticated", False):
    st.error("Please login to access this page")
    st.stop()

st.set_page_config(
    page_title="Enhanced Contract Form Example", page_icon="📋", layout="wide"
)

# Apply RTL support
apply_page_rtl()

# Navigation handled by main navigation system


def main():
    """Enhanced form example with complete navigation and tracking"""
    # t = lambda key: get_translation(key, st.session_state.language)  # Reserved for future use
    language = st.session_state.get("language", "en")

    # Sample initial data (in real app, this would come from database)
    initial_contract_data = {
        "contract_number": "CT-2025-001",
        "tenant_name": "Ahmed Mohammed",
        "property_name": "Luxury Apartment Complex",
        "unit_number": "A-101",
        "monthly_rent": 5000.0,
        "security_deposit": 5000.0,
        "contract_type": "Residential",
        "lease_duration": 12,
        "start_date": date(2025, 1, 1),
        "end_date": date(2025, 12, 31),
        "include_utilities": True,
        "allow_pets": False,
        "special_terms": "No smoking allowed in the premises.",
        "payment_method": "Bank Transfer",
    }

    # Create form tracker
    form_tracker = create_tracked_form("enhanced_contract_form", initial_contract_data)

    # Custom save callback
    def save_contract_data():
        """Custom save function for contract data"""
        try:
            changes = form_tracker.get_changes()

            if not changes:
                return True, "No changes to save"

            # Log the save attempt
            log_action(
                action_type="contract_save_attempt",
                table_name="contracts",
                additional_data={
                    "form_id": "enhanced_contract_form",
                    "changes_count": len(changes),
                },
            )

            # Simulate database save (replace with actual save logic)
            # conn = get_db_connection()
            # cur = conn.cursor()
            # ... your save logic here ...

            # For demo purposes, we'll just simulate success
            st.success(f"Contract saved successfully! ({len(changes)} changes)")

            # Save the changes using form tracker
            success, message = form_tracker.save_changes(table_name="contracts")

            return success, message

        except Exception as e:
            log_action(
                action_type="contract_save_error", additional_data={"error": str(e)}
            )
            return False, f"Error saving contract: {str(e)}"

    # Navigation bar functionality replaced with standard buttons
    st.title(
        "📋 Enhanced Contract Management"
        if language == "en"
        else "📋 إدارة العقود المحسنة"
    )

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        if st.button("💾 Save", use_container_width=True):
            save_contract_data()
    with col2:
        if st.button(
            "👁️ Preview Contract" if language == "en" else "👁️ معاينة العقد",
            use_container_width=True,
        ):
            st.info("Contract preview would open here")
    with col3:
        if st.button(
            "🖨️ Print Contract" if language == "en" else "🖨️ طباعة العقد",
            use_container_width=True,
        ):
            st.info("Contract would be sent to printer")
    with col4:
        if st.button("🏠 Home", use_container_width=True):
            st.switch_page("pages/01_Dashboard_WorkOS.py")

    # Show change indicator
    form_tracker.create_change_indicator()

    # Main form
    st.markdown("### Contract Details" if language == "en" else "### تفاصيل العقد")

    with st.form("enhanced_contract_form", clear_on_submit=False):

        # Contract Information Section
        st.markdown(
            "#### Basic Information" if language == "en" else "#### المعلومات الأساسية"
        )

        col1, col2 = st.columns(2)

        with col1:
            contract_number = form_tracker.track_text_input(
                "Contract Number" if language == "en" else "رقم العقد",
                "contract_number",
                disabled=True,  # Usually auto-generated
                help="Auto-generated contract number",
            )

            form_tracker.track_text_input(
                "Tenant Name" if language == "en" else "اسم المستأجر",
                "tenant_name",
                placeholder="Enter tenant full name",
            )

            form_tracker.track_text_input(
                "Property Name" if language == "en" else "اسم العقار",
                "property_name",
                placeholder="Enter property name",
            )

        with col2:
            form_tracker.track_text_input(
                "Unit Number" if language == "en" else "رقم الوحدة",
                "unit_number",
                placeholder="A-101, B-205, etc.",
            )

            form_tracker.track_selectbox(
                "Contract Type" if language == "en" else "نوع العقد",
                ["Residential", "Commercial", "Industrial", "Mixed Use"],
                "contract_type",
            )

            form_tracker.track_selectbox(
                "Payment Method" if language == "en" else "طريقة الدفع",
                ["Bank Transfer", "Cash", "Check", "Credit Card"],
                "payment_method",
            )

        # Financial Information
        st.markdown(
            "#### Financial Terms" if language == "en" else "#### الشروط المالية"
        )

        col3, col4, col5 = st.columns(3)

        with col3:
            form_tracker.track_number_input(
                "Monthly Rent (SAR)" if language == "en" else "الإيجار الشهري (ريال)",
                "monthly_rent",
                min_value=0.0,
                step=100.0,
                format="%.2f",
            )

        with col4:
            form_tracker.track_number_input(
                "Security Deposit (SAR)" if language == "en" else "الضمان (ريال)",
                "security_deposit",
                min_value=0.0,
                step=100.0,
                format="%.2f",
            )

        with col5:
            form_tracker.track_number_input(
                "Lease Duration (months)" if language == "en" else "مدة الإيجار (شهر)",
                "lease_duration",
                min_value=1,
                max_value=60,
                step=1,
            )

        # Date Information
        st.markdown("#### Lease Period" if language == "en" else "#### فترة الإيجار")

        col6, col7 = st.columns(2)

        with col6:
            form_tracker.track_date_input(
                "Start Date" if language == "en" else "تاريخ البداية",
                "start_date",
                help_text="Contract start date",
            )

        with col7:
            form_tracker.track_date_input(
                "End Date" if language == "en" else "تاريخ النهاية",
                "end_date",
                help_text="Contract end date",
            )

        # Additional Options
        st.markdown("#### Additional Terms" if language == "en" else "#### شروط إضافية")

        col8, col9 = st.columns(2)

        with col8:
            form_tracker.track_checkbox(
                "Include Utilities" if language == "en" else "شامل المرافق",
                "include_utilities",
            )

        with col9:
            form_tracker.track_checkbox(
                "Allow Pets" if language == "en" else "السماح بالحيوانات الأليفة",
                "allow_pets",
            )

        # Special Terms
        form_tracker.track_text_area(
            (
                "Special Terms & Conditions"
                if language == "en"
                else "الشروط والأحكام الخاصة"
            ),
            "special_terms",
            placeholder="Enter any special terms or conditions...",
            height=100,
        )

        # Form submission (handled by navigation bar)
        submitted = st.form_submit_button(
            "💾 Save Contract" if language == "en" else "💾 حفظ العقد",
            type="primary",
            use_container_width=True,
        )

        if submitted:
            success, message = save_contract_data()
            if success:
                st.success(message)
                # Force rerun to clear changes
                st.rerun()
            else:
                st.error(message)

    # Show pending changes summary
    if form_tracker.has_changes():
        st.markdown("---")
        with st.expander("📝 View Pending Changes", expanded=False):
            form_tracker.show_changes_summary()

    # Additional actions section
    st.markdown("---")
    st.markdown("### Quick Actions" if language == "en" else "### إجراءات سريعة")

    col_actions1, col_actions2, col_actions3, col_actions4 = st.columns(4)

    with col_actions1:
        if st.button("📄 Generate PDF", use_container_width=True):
            st.info("PDF generation would be implemented here")
            log_action(
                "contract_pdf_generated",
                additional_data={"contract_number": contract_number},
            )

    with col_actions2:
        if st.button("📧 Email Contract", use_container_width=True):
            st.info("Email functionality would be implemented here")
            log_action(
                "contract_emailed", additional_data={"contract_number": contract_number}
            )

    with col_actions3:
        if st.button("📱 Send SMS", use_container_width=True):
            st.info("SMS functionality would be implemented here")
            log_action(
                "contract_sms_sent",
                additional_data={"contract_number": contract_number},
            )

    with col_actions4:
        if st.button("🗑️ Delete Draft", use_container_width=True):
            if form_tracker.has_changes():
                st.warning("Please save or discard changes before deleting")
            else:
                st.info("Delete functionality would be implemented here")
                log_action(
                    "contract_deleted",
                    additional_data={"contract_number": contract_number},
                )


if __name__ == "__main__":
    main()
