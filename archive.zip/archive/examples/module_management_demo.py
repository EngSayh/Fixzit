"""
Module Management System Demo
Demonstrates the page organization and system optimization capabilities
"""

import streamlit as st
from services.module_management import module_management_service
from services.feature_flags import flag_enabled
from services.remote_config import get_config


def main():
    st.title("📋 Module Management System Demo")

    st.markdown(
        """
    This demo showcases the new **Module & Page Management** system that allows 
    super admins to organize pages into logical modules and optimize system performance.
    """
    )

    # Feature availability check
    if flag_enabled("module_management_demo"):
        st.success("✅ Module Management demo is enabled!")
    else:
        st.info(
            "🔧 Module Management demo - enable via Feature Flags for enhanced experience"
        )

    # Demo sections
    tab1, tab2, tab3, tab4 = st.tabs(
        [
            "🏗️ System Overview",
            "📋 Page Organization",
            "🚀 Optimization Features",
            "📊 Analytics Demo",
        ]
    )

    with tab1:
        system_overview()

    with tab2:
        page_organization_demo()

    with tab3:
        optimization_features_demo()

    with tab4:
        analytics_demo()


def system_overview():
    """Show system overview and capabilities"""
    st.markdown("### 🎯 What the Module Management System Does")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown(
            """
        #### 📋 Page Organization
        - **Automatic Page Discovery** - Scans and registers all pages
        - **Module Categorization** - Groups related pages together
        - **Priority Management** - Controls page ordering within modules
        - **Access Level Detection** - Automatically detects admin/user pages
        - **Drag & Drop Interface** - Easy page reassignment
        """
        )

        st.markdown(
            """
        #### 🚀 System Optimization
        - **Performance Analysis** - Identifies bottlenecks and improvements
        - **Navigation Optimization** - Reorders based on usage patterns  
        - **Permission Optimization** - Groups by access levels for efficiency
        - **Caching Enhancement** - Smart caching for popular modules
        - **Automatic Backup** - Safe optimization with rollback capability
        """
        )

    with col2:
        # Live system stats
        modules = module_management_service.get_all_modules()
        pages = module_management_service.get_all_pages()

        st.markdown("#### 📊 Current System Stats")

        col_a, col_b = st.columns(2)
        with col_a:
            st.metric("Total Pages", len(pages))
            st.metric("Active Modules", len(modules))

        with col_b:
            organized_pages = len([p for p in pages if p.module_id != "unorganized"])
            organization_rate = (organized_pages / len(pages) * 100) if pages else 0

            st.metric("Organized Pages", organized_pages)
            st.metric("Organization Rate", f"{organization_rate:.1f}%")

        # Module breakdown
        st.markdown("#### 🏗️ Module Breakdown")

        module_counts = {}
        for page in pages:
            module_id = page.module_id
            module_counts[module_id] = module_counts.get(module_id, 0) + 1

        for module in modules[:5]:  # Show top 5 modules
            count = module_counts.get(module.module_id, 0)
            if count > 0:
                st.markdown(f"**{module.icon} {module.module_name}:** {count} pages")


def page_organization_demo():
    """Demonstrate page organization capabilities"""
    st.markdown("### 📋 Page Organization Features")

    # Show current organization
    st.markdown("#### 🗂️ Current Page Organization")

    modules = module_management_service.get_all_modules()
    pages = module_management_service.get_all_pages()

    # Group pages by module for display
    pages_by_module = {}
    for page in pages[:10]:  # Show first 10 pages as demo
        module_id = page.module_id
        if module_id not in pages_by_module:
            pages_by_module[module_id] = []
        pages_by_module[module_id].append(page)

    for module_id, module_pages in pages_by_module.items():
        # Get module info
        module_info = next((m for m in modules if m.module_id == module_id), None)
        module_name = module_info.module_name if module_info else "Unknown"
        module_icon = module_info.icon if module_info else "📄"

        with st.expander(f"{module_icon} {module_name} ({len(module_pages)} pages)"):
            for page in module_pages:
                access_badge = {"user": "👤", "admin": "⚙️", "super_admin": "🔐"}.get(
                    page.access_level, "❓"
                )

                st.markdown(f"**{page.display_name}** {access_badge}")
                st.caption(
                    f"Priority: {page.priority} | {page.description or 'No description'}"
                )

    # Show organization capabilities
    st.markdown("---")
    st.markdown("#### ⚙️ Organization Capabilities")

    capabilities = [
        "🔄 **Move Pages Between Modules** - Drag and drop or dropdown selection",
        "📊 **Set Page Priorities** - Control ordering within modules",
        "🏷️ **Automatic Categorization** - Smart detection of page types",
        "🔍 **Search & Filter** - Find pages by module, access level, or name",
        "📱 **Responsive Management** - Works on all device sizes",
        "💾 **Change Tracking** - All modifications are logged and backed up",
    ]

    for capability in capabilities:
        st.markdown(capability)


def optimization_features_demo():
    """Demonstrate optimization features"""
    st.markdown("### 🚀 System Optimization Features")

    # Optimization types
    st.markdown("#### 🎯 Available Optimizations")

    optimizations = [
        {
            "name": "🧭 Navigation Optimization",
            "description": "Reorders pages based on usage analytics for faster access",
            "benefits": [
                "Reduced clicks to reach popular pages",
                "Improved user experience",
                "Faster workflow completion",
            ],
        },
        {
            "name": "🔐 Permission Optimization",
            "description": "Groups pages by access levels to reduce authorization overhead",
            "benefits": [
                "Faster permission checking",
                "Reduced database queries",
                "Better security grouping",
            ],
        },
        {
            "name": "⚡ Caching Optimization",
            "description": "Enables smart caching for frequently accessed modules",
            "benefits": [
                "Faster page loading",
                "Reduced server load",
                "Better scalability",
            ],
        },
        {
            "name": "🔧 Full System Optimization",
            "description": "Combines all optimizations for maximum performance improvement",
            "benefits": [
                "Complete system enhancement",
                "Maximum performance gains",
                "Automated best practices",
            ],
        },
    ]

    for opt in optimizations:
        with st.expander(opt["name"]):
            st.markdown(f"**Description:** {opt['description']}")
            st.markdown("**Benefits:**")
            for benefit in opt["benefits"]:
                st.markdown(f"- {benefit}")

    # Safety features
    st.markdown("---")
    st.markdown("#### 🛡️ Safety & Backup Features")

    safety_features = [
        "💾 **Automatic Backup** - Full system backup before any optimization",
        "🔄 **Rollback Capability** - Instant rollback if issues occur",
        "📊 **Preview Mode** - See changes before applying them",
        "📝 **Change Logging** - Complete audit trail of all modifications",
        "⚠️ **Impact Analysis** - Understand performance implications before optimization",
        "🎯 **Selective Optimization** - Choose specific areas to optimize",
    ]

    for feature in safety_features:
        st.markdown(feature)


def analytics_demo():
    """Demonstrate analytics capabilities"""
    st.markdown("### 📊 Analytics & Insights Demo")

    # Get sample analytics
    analytics = module_management_service.get_page_analytics(30)

    if analytics.get("top_pages"):
        st.markdown("#### 🔥 Most Popular Pages (Last 30 Days)")

        for i, page in enumerate(analytics["top_pages"][:5], 1):
            col1, col2, col3 = st.columns([1, 4, 1])

            with col1:
                st.markdown(f"**#{i}**")
            with col2:
                st.markdown(f"**{page['name']}**")
                st.caption(f"Module: {page['module']}")
            with col3:
                st.metric("Views", page["count"])

    if analytics.get("module_usage"):
        st.markdown("#### 📈 Module Performance")

        for module in analytics["module_usage"][:5]:
            usage_level = (
                "🔥 High"
                if module["count"] > 100
                else "📊 Medium" if module["count"] > 50 else "📉 Low"
            )

            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"**{module['module_name']}** {usage_level}")
            with col2:
                st.metric("Accesses", module["count"])

    else:
        st.info("📊 Analytics will be available once page access data is collected.")

    # Optimization recommendations
    st.markdown("---")
    st.markdown("#### 💡 Optimization Recommendations")

    pages = module_management_service.get_all_pages()
    modules = module_management_service.get_all_modules()

    recommendations = []

    # Check organization rate
    organized_pages = len([p for p in pages if p.module_id != "unorganized"])
    organization_rate = (organized_pages / len(pages) * 100) if pages else 0

    if organization_rate < 80:
        recommendations.append(
            {
                "icon": "📋",
                "title": "Improve Page Organization",
                "description": f"Only {organization_rate:.1f}% of pages are organized. Consider categorizing unorganized pages.",
                "action": "Visit Module Manager → Page Organization",
            }
        )

    if len(modules) < 5:
        recommendations.append(
            {
                "icon": "🏗️",
                "title": "Create More Modules",
                "description": "Consider creating specialized modules for better organization.",
                "action": "Visit Module Manager → Module Management",
            }
        )

    # Check for admin page distribution
    admin_pages = len([p for p in pages if p.access_level in ["admin", "super_admin"]])
    if admin_pages > len(pages) * 0.3:
        recommendations.append(
            {
                "icon": "⚙️",
                "title": "Optimize Admin Access",
                "description": f"{admin_pages} admin pages detected. Consider permission optimization.",
                "action": "Run Permission Optimization",
            }
        )

    if recommendations:
        for rec in recommendations:
            st.markdown(
                f"""
            **{rec['icon']} {rec['title']}**  
            {rec['description']}  
            *Recommended action: {rec['action']}*
            """
            )
    else:
        st.success(
            "✅ System is well-organized! Consider running performance optimization for additional improvements."
        )


if __name__ == "__main__":
    # Add quick navigation
    with st.sidebar:
        st.markdown("### 🚀 Quick Actions")

        if st.button("📋 Open Module Manager"):
            st.switch_page("pages/996_ModuleManager.py")

        if st.button("🚩 Feature Flags"):
            st.switch_page("pages/998_FeatureFlags.py")

        if st.button("⚙️ Remote Config"):
            st.switch_page("pages/997_RemoteConfig.py")

        st.markdown("---")
        st.markdown("### 📊 Live Stats")

        # Show live configuration
        max_modules = get_config("max_modules_per_user", 10)
        st.metric("Max Modules Limit", max_modules)

        optimization_enabled = get_config("auto_optimization", True)
        st.metric(
            "Auto Optimization", "✅ Enabled" if optimization_enabled else "❌ Disabled"
        )

    main()
