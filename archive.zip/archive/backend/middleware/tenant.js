module.exports = (req, res, next) => {
  if (!req.tenantId) {
    return res.status(400).json({ error: 'Tenant ID required' });
  }
  
  // Add tenantId to all queries
  if (req.method === 'GET') {
    req.query.tenantId = req.tenantId;
  }
  
  next();
};