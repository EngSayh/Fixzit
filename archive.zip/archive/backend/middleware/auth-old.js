const jwt = require('jsonwebtoken');
const User = require('../models/User');

// CRITICAL: JWT secret must be from environment
if (!process.env.JWT_SECRET) {
    console.error('🚨 CRITICAL: JWT_SECRET must be set in .env and be at least 32 characters long');
    process.exit(1);
}

const JWT_SECRET = process.env.JWT_SECRET;

// Enhanced authentication with database verification
const authenticate = async (req, res, next) => {
    try {
        let token = null;
        
        // Only accept tokens from Authorization header (no query params)
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.substring(7);
        }
        
        if (!token) {
            return res.status(401).json({ 
                success: false, 
                message: 'No authentication token provided' 
            });
        }

        // Verify token securely
        const decoded = jwt.verify(token, JWT_SECRET, {
            algorithms: ['HS256'], // Explicitly specify algorithm
            clockTolerance: 30 // Allow 30 seconds clock skew
        });

        // CRITICAL: Wait for MongoDB connection before database operations
        const mongoose = require('mongoose');
        if (mongoose.connection.readyState !== 1) {
            return res.status(503).json({ 
                success: false, 
                message: 'Database connection not ready. Please try again in a moment.' 
            });
        }

        // CRITICAL: Always verify user exists in database
        const user = await User.findById(decoded.userId)
            .select('-password')
            .lean();

        if (!user) {
            return res.status(401).json({ 
                success: false, 
                message: 'User not found or has been deactivated' 
            });
        }

        // Check if user is active
        if (user.status === 'inactive' || user.isDeleted) {
            return res.status(401).json({ 
                success: false, 
                message: 'Account has been deactivated' 
            });
        }

        // Attach full user object to request
        req.user = {
            id: user._id.toString(),
            userId: user._id.toString(), // Backward compatibility
            email: user.email,
            role: user.role,
            userRole: user.role, // Backward compatibility
            tenantId: user.tenantId || user.organization,
            organization: user.organization,
            organizationId: user.organization,
            permissions: user.permissions || [],
            lastActivity: new Date()
        };

        // Add backward compatibility at request level
        req.userId = req.user.id;
        req.userRole = req.user.role;
        req.tenantId = req.user.tenantId;
        req.organizationId = req.user.organization;

        // Update last activity
        User.findByIdAndUpdate(user._id, { 
            lastActivity: new Date() 
        }).exec().catch(console.error);

        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ 
                success: false, 
                message: 'Token has expired' 
            });
        }
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid token' 
            });
        }
        console.error('Authentication error:', error);
        return res.status(500).json({ 
            success: false, 
            message: 'Authentication failed' 
        });
    }
};

// Enhanced tenant isolation
const ensureTenantIsolation = async (req, res, next) => {
    try {
        if (!req.user || !req.user.tenantId) {
            return res.status(403).json({ 
                success: false, 
                message: 'Tenant context required' 
            });
        }

        // Add tenant filter to all queries
        req.tenantFilter = { tenantId: req.user.tenantId };
        
        // Override query methods to enforce tenant isolation
        const originalQuery = req.query;
        req.query = new Proxy(originalQuery, {
            get(target, prop) {
                if (prop === 'tenantId') {
                    return req.user.tenantId; // Always return user's tenant
                }
                return target[prop];
            },
            set(target, prop, value) {
                if (prop === 'tenantId') {
                    console.warn(`Override of tenantId blocked for user ${req.user.id}`);
                    return true; // Silently ignore
                }
                target[prop] = value;
                return true;
            }
        });

        next();
    } catch (error) {
        console.error('Tenant isolation error:', error);
        return res.status(500).json({ 
            success: false, 
            message: 'Tenant isolation failed' 
        });
    }
};

// Role-based access control
const authorize = (...allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ 
                success: false, 
                message: 'Authentication required' 
            });
        }

        // Allow super_admin to bypass role restrictions
        if (req.user.role === 'super_admin') {
            return next();
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                success: false, 
                message: `Access denied. Required roles: ${allowedRoles.join(', ')}` 
            });
        }

        next();
    };
};

// Rate limiting per user
const userRateLimiter = new Map();

const rateLimit = (maxRequests = 100, windowMs = 60000) => {
    return (req, res, next) => {
        if (!req.user) return next();

        const key = `${req.user.id}-${req.path}`;
        const now = Date.now();
        
        if (!userRateLimiter.has(key)) {
            userRateLimiter.set(key, { count: 1, resetTime: now + windowMs });
            return next();
        }

        const limit = userRateLimiter.get(key);
        
        if (now > limit.resetTime) {
            limit.count = 1;
            limit.resetTime = now + windowMs;
            return next();
        }

        if (limit.count >= maxRequests) {
            return res.status(429).json({ 
                success: false, 
                message: 'Too many requests. Please try again later.' 
            });
        }

        limit.count++;
        next();
    };
};

// Export both named and default
module.exports = {
    authenticate,
    authMiddleware: authenticate, // Backwards compatibility
    ensureTenantIsolation,
    authorize,
    rateLimit,
    JWT_SECRET
};

module.exports.default = authenticate;