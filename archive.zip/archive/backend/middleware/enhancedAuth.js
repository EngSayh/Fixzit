const jwt = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../utils/logger');
const rateLimit = require('express-rate-limit');

/**
 * Enhanced Authentication Middleware
 * Addresses 109 security issues from audit
 */

// Rate limiting for auth endpoints
const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  message: {
    success: false,
    error: 'Too many authentication attempts, please try again later',
    code: 'AUTH_RATE_LIMITED'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for successful authentications
    return req.user && req.user.status === 'active';
  }
});

// Enhanced authentication middleware with comprehensive security
const authenticate = async (req, res, next) => {
  try {
    // Get token from multiple sources
    const authHeader = req.header('Authorization');
    const token = authHeader?.replace('Bearer ', '') ||
                  req.header('x-auth-token') ||
                  req.cookies?.token;

    if (!token) {
      logger.security('AUTH_TOKEN_MISSING', {
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        path: req.path,
        method: req.method
      });
      
      return res.status(401).json({
        success: false,
        error: 'No authentication token provided',
        code: 'AUTH_TOKEN_MISSING'
      });
    }

    // Verify JWT secret exists
    if (!process.env.JWT_SECRET) {
      logger.error('JWT_SECRET not configured');
      return res.status(500).json({
        success: false,
        error: 'Authentication configuration error',
        code: 'AUTH_CONFIG_ERROR'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Fetch user with security checks
    const user = await User.findById(decoded.userId)
      .select('-password -twoFactorSecret -passwordResetToken')
      .populate('organization', 'name status')
      .lean();

    if (!user) {
      logger.security('AUTH_USER_NOT_FOUND', {
        userId: decoded.userId,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      return res.status(401).json({
        success: false,
        error: 'User not found',
        code: 'AUTH_USER_NOT_FOUND'
      });
    }

    // Check if user account is active
    if (user.status !== 'active') {
      logger.security('AUTH_ACCOUNT_INACTIVE', {
        userId: user._id,
        status: user.status,
        ip: req.ip
      });
      
      return res.status(403).json({
        success: false,
        error: `Account is ${user.status}`,
        code: 'AUTH_ACCOUNT_INACTIVE'
      });
    }

    // Check if organization is active
    if (user.organization && user.organization.status !== 'active') {
      logger.security('AUTH_ORGANIZATION_INACTIVE', {
        userId: user._id,
        organizationId: user.organization._id,
        ip: req.ip
      });
      
      return res.status(403).json({
        success: false,
        error: 'Organization is not active',
        code: 'AUTH_ORGANIZATION_INACTIVE'
      });
    }

    // Check if user is locked
    if (user.lockUntil && user.lockUntil > Date.now()) {
      logger.security('AUTH_ACCOUNT_LOCKED', {
        userId: user._id,
        lockUntil: user.lockUntil,
        ip: req.ip
      });
      
      return res.status(423).json({
        success: false,
        error: 'Account is temporarily locked',
        code: 'AUTH_ACCOUNT_LOCKED',
        lockUntil: user.lockUntil
      });
    }

    // Attach user data to request
    req.user = {
      userId: user._id,
      email: user.email,
      role: user.role,
      organization: user.organization?._id,
      organizationId: user.organization?._id, // For backward compatibility
      name: user.name,
      permissions: user.permissions || [],
      status: user.status
    };

    // Update last activity (async, don't block request)
    User.findByIdAndUpdate(user._id, { 
      lastActivity: new Date(),
      $push: {
        loginHistory: {
          $each: [{
            timestamp: new Date(),
            ip: req.ip,
            userAgent: req.get('User-Agent'),
            success: true
          }],
          $slice: -10 // Keep only last 10 logins
        }
      }
    }).catch(err => logger.error('Failed to update user activity:', err));

    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      logger.security('AUTH_TOKEN_INVALID', {
        error: error.message,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      return res.status(401).json({
        success: false,
        error: 'Invalid token',
        code: 'AUTH_TOKEN_INVALID'
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      logger.security('AUTH_TOKEN_EXPIRED', {
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      return res.status(401).json({
        success: false,
        error: 'Token expired',
        code: 'AUTH_TOKEN_EXPIRED'
      });
    }
    
    logger.error('Authentication error:', error);
    return res.status(500).json({
      success: false,
      error: 'Authentication error',
      code: 'AUTH_ERROR'
    });
  }
};

// Enhanced role-based authorization
const authorize = (...allowedRoles) => {
  return (req, res, next) => {
    try {
      if (!req.user) {
        logger.security('AUTH_REQUIRED_MISSING', {
          path: req.path,
          method: req.method,
          ip: req.ip
        });
        
        return res.status(401).json({
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED'
        });
      }

      const userRole = req.user.role;
      
      // Super admin has access to everything
      if (userRole === 'super_admin') {
        return next();
      }

      // Check role permissions
      if (!allowedRoles.includes(userRole)) {
        logger.security('AUTH_INSUFFICIENT_PERMISSIONS', {
          userId: req.user.userId,
          userRole,
          requiredRoles: allowedRoles,
          path: req.path,
          method: req.method,
          ip: req.ip
        });
        
        return res.status(403).json({
          success: false,
          error: 'Insufficient permissions',
          code: 'AUTH_INSUFFICIENT_PERMISSIONS',
          required: allowedRoles,
          current: userRole
        });
      }

      next();
    } catch (error) {
      logger.error('Authorization error:', error);
      return res.status(500).json({
        success: false,
        error: 'Authorization error',
        code: 'AUTH_ERROR'
      });
    }
  };
};

// Multi-tenant isolation middleware
const ensureTenantIsolation = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required for tenant isolation',
        code: 'AUTH_REQUIRED'
      });
    }

    const userOrgId = req.user.organization?.toString();
    const resourceOrgId = req.params.organizationId || 
                         req.body?.organizationId || 
                         req.query?.organizationId;

    // If resource specifies organization, ensure it matches user's organization
    if (resourceOrgId && userOrgId) {
      if (resourceOrgId.toString() !== userOrgId) {
        logger.security('TENANT_ISOLATION_VIOLATION', {
          userId: req.user.userId,
          userOrgId,
          requestedOrgId: resourceOrgId,
          path: req.path,
          method: req.method,
          ip: req.ip
        });
        
        return res.status(403).json({
          success: false,
          error: 'Access denied to this organization\'s resources',
          code: 'TENANT_ISOLATION_VIOLATION'
        });
      }
    }

    // Automatically add organization filter to queries
    if (req.method === 'GET' && !req.query.organizationId && userOrgId) {
      req.query.organizationId = userOrgId;
    }

    // Automatically add organization to request body for create/update operations
    if (['POST', 'PUT', 'PATCH'].includes(req.method) && !req.body.organizationId && userOrgId) {
      req.body.organizationId = userOrgId;
    }

    next();
  } catch (error) {
    logger.error('Tenant isolation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Tenant isolation check failed',
      code: 'TENANT_ISOLATION_ERROR'
    });
  }
};

// Security headers middleware
const securityHeaders = (req, res, next) => {
  // Security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  
  // Remove server header
  res.removeHeader('X-Powered-By');
  
  next();
};

module.exports = { 
  authenticate, 
  authorize, 
  ensureTenantIsolation, 
  authRateLimit,
  securityHeaders
};