const mongoose = require('mongoose');
const User = require('../models/User');

/**
 * Multi-tenant middleware to ensure data isolation
 * CRITICAL: This prevents data leakage between tenants
 */
const multiTenantMiddleware = async (req, res, next) => {
  try {
    // Skip for public routes
    const publicRoutes = ['/api/auth/login', '/api/auth/register', '/api/health'];
    if (publicRoutes.includes(req.path)) {
      return next();
    }
    
    // Check if user is authenticated
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }
    
    // Super admin can access everything
    if (req.user.role === 'super_admin') {
      req.tenantFilter = {}; // No filter for super admin
      return next();
    }
    
    // Set tenant context for all other users
    if (!req.user.organization) {
      return res.status(403).json({
        success: false,
        message: 'User not associated with any organization'
      });
    }
    
    // Create tenant filter for database queries
    req.tenantFilter = {
      organization: req.user.organization
    };
    
    // Add tenant context to request
    req.tenant = {
      id: req.user.organization,
      userId: req.user.userId,
      role: req.user.role
    };
    
    // Verify user still exists and is active
    const user = await User.findById(req.user.userId).select('isActive organization');
    if (!user || !user.isActive) {
      return res.status(403).json({
        success: false,
        message: 'User account is inactive or not found'
      });
    }
    
    // Verify organization match (critical security check)
    if (user.organization.toString() !== req.user.organization.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Organization mismatch - potential security violation',
        code: 'TENANT_MISMATCH'
      });
    }
    
    next();
  } catch (error) {
    console.error('Multi-tenant middleware error:', error);
    res.status(500).json({
      success: false,
      message: 'Tenant verification failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

/**
 * Apply tenant filter to mongoose queries automatically
 */
const applyTenantFilter = (schema) => {
  // Add organization field to all schemas
  schema.add({
    organization: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Organization',
      required: true,
      index: true
    }
  });
  
  // Pre hooks for find operations
  const findHooks = [
    'find',
    'findOne',
    'findOneAndUpdate',
    'findOneAndDelete',
    'findOneAndRemove',
    'count',
    'countDocuments',
    'distinct'
  ];
  
  findHooks.forEach(method => {
    schema.pre(method, function() {
      // Apply tenant filter if it exists in the context
      if (this.options.tenantFilter) {
        this.where(this.options.tenantFilter);
      }
    });
  });
  
  // Pre hook for save - ensure organization is set
  schema.pre('save', function(next) {
    if (!this.organization && this.constructor.modelName !== 'Organization') {
      return next(new Error('Organization is required'));
    }
    next();
  });
  
  // Pre hook for insertMany
  schema.pre('insertMany', function(next, docs) {
    docs.forEach(doc => {
      if (!doc.organization) {
        throw new Error('Organization is required for all documents');
      }
    });
    next();
  });
};

/**
 * Role-based access control
 */
const checkRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }
    
    // Super admin always has access
    if (req.user.role === 'super_admin') {
      return next();
    }
    
    // Check if user's role is in allowed roles
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
        required: allowedRoles,
        current: req.user.role
      });
    }
    
    next();
  };
};

/**
 * Verify data ownership
 */
const verifyOwnership = (model, idParam = 'id') => {
  return async (req, res, next) => {
    try {
      const id = req.params[idParam];
      if (!id) {
        return res.status(400).json({
          success: false,
          message: 'Resource ID required'
        });
      }
      
      const resource = await model.findById(id);
      if (!resource) {
        return res.status(404).json({
          success: false,
          message: 'Resource not found'
        });
      }
      
      // Super admin can access everything
      if (req.user.role === 'super_admin') {
        req.resource = resource;
        return next();
      }
      
      // Verify organization match
      if (resource.organization.toString() !== req.user.organization.toString()) {
        return res.status(403).json({
          success: false,
          message: 'Access denied - resource belongs to different organization'
        });
      }
      
      req.resource = resource;
      next();
    } catch (error) {
      console.error('Ownership verification error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to verify ownership'
      });
    }
  };
};

module.exports = {
  multiTenantMiddleware,
  applyTenantFilter,
  checkRole,
  verifyOwnership
};