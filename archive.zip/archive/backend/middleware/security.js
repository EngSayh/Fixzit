const validator = require('validator');
const xss = require('xss');
const rateLimiter = require('express-rate-limit');

const validateInput = (schema) => {
  return (req, res, next) => {
    const errors = [];
    
    if (schema.body) {
      for (const [field, rules] of Object.entries(schema.body)) {
        const value = req.body[field];
        
        if (rules.required && !value) {
          errors.push(`${field} is required`);
          continue;
        }
        
        if (value) {
          if (rules.type === 'email' && !validator.isEmail(value)) {
            errors.push(`${field} must be a valid email`);
          }
          
          if (rules.minLength && value.length < rules.minLength) {
            errors.push(`${field} must be at least ${rules.minLength} characters`);
          }
          
          if (typeof value === 'string') {
            req.body[field] = xss(value.trim());
          }
        }
      }
    }
    
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }
    
    next();
  };
};

const createRateLimiter = (options = {}) => {
  return rateLimiter({
    windowMs: options.windowMs || 15 * 60 * 1000,
    max: options.max || 100,
    message: 'Too many requests from this IP, please try again later',
    standardHeaders: true,
    legacyHeaders: false
  });
};

const securityHeaders = (req, res, next) => {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  if (req.secure) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  
  next();
};

module.exports = { validateInput, createRateLimiter, securityHeaders };