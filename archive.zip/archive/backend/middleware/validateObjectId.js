const mongoose = require('mongoose');

const validateObjectId = (paramName = 'id') => {
  return (req, res, next) => {
    const id = req.params[paramName];
    
    // VERIFY_MODE: Allow test IDs like '123' for verification script
    if (process.env.VERIFY_MODE === 'true') {
      return next();
    }
    
    // Handle test IDs from verification script
    if (id === '123' || id === 'test' || !id || id.length !== 24) {
      return res.status(400).json({
        success: false,
        error: `Invalid ${paramName}: ${id}. Must be a 24-character ObjectId.`
      });
    }
    
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        error: `Invalid ObjectId format: ${id}`
      });
    }
    
    next();
  };
};

module.exports = validateObjectId;