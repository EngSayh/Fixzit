// FIXZIT SOUQ - ENHANCED AUTHENTICATION MIDDLEWARE
// Implements all 14 roles, multi-tenant isolation, audit logging, and production features

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const redis = require('redis');
const rateLimit = require('express-rate-limit');
const { User } = require('../models');
const { AuditLog, Session } = require('../models');

// Initialize Redis client for token management
const redisClient = redis.createClient({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
  db: process.env.REDIS_DB || 0
});

redisClient.on('error', (err) => {
  console.error('Redis Client Error:', err);
});

// Validate required environment variables - graceful fallback for development
const requiredEnvVars = ['JWT_SECRET'];
const optionalEnvVars = ['JWT_REFRESH_SECRET', 'JWT_API_SECRET'];

requiredEnvVars.forEach(varName => {
  if (!process.env[varName]) {
    console.error(`🚨 CRITICAL: ${varName} environment variable is required but not set`);
    process.exit(1);
  }
});

// Set fallback values for optional vars in development
optionalEnvVars.forEach(varName => {
  if (!process.env[varName]) {
    console.warn(`⚠️ Warning: ${varName} not set, using fallback`);
    process.env[varName] = process.env.JWT_SECRET; // Use JWT_SECRET as fallback
  }
});

// FIXZIT SOUQ Role Definitions (14 roles as per spec)
const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  PROPERTY_MANAGER: 'property_manager',
  MAINTENANCE_SUPERVISOR: 'maintenance_supervisor',
  TECHNICIAN: 'technician',
  FINANCE_MANAGER: 'finance_manager',
  ACCOUNTANT: 'accountant',
  HR_MANAGER: 'hr_manager',
  TENANT: 'tenant',
  OWNER: 'owner',
  VENDOR: 'vendor',
  CORPORATE_MANAGER: 'corporate_manager',
  INSPECTOR: 'inspector',
  GUEST: 'guest'
};

// Role hierarchy for permission inheritance
const ROLE_HIERARCHY = {
  [ROLES.SUPER_ADMIN]: [ROLES.ADMIN, ROLES.PROPERTY_MANAGER, ROLES.FINANCE_MANAGER, ROLES.HR_MANAGER],
  [ROLES.ADMIN]: [ROLES.PROPERTY_MANAGER, ROLES.MAINTENANCE_SUPERVISOR],
  [ROLES.PROPERTY_MANAGER]: [ROLES.MAINTENANCE_SUPERVISOR],
  [ROLES.FINANCE_MANAGER]: [ROLES.ACCOUNTANT],
  [ROLES.HR_MANAGER]: [],
  [ROLES.MAINTENANCE_SUPERVISOR]: [ROLES.TECHNICIAN],
  [ROLES.CORPORATE_MANAGER]: [ROLES.PROPERTY_MANAGER],
  // Terminal roles
  [ROLES.TECHNICIAN]: [],
  [ROLES.ACCOUNTANT]: [],
  [ROLES.TENANT]: [],
  [ROLES.OWNER]: [],
  [ROLES.VENDOR]: [],
  [ROLES.INSPECTOR]: [],
  [ROLES.GUEST]: []
};

// Rate limiting configurations per role
const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: 'Too many authentication attempts, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
  handler: async (req, res) => {
    await logAuditEvent(req, 'AUTH_RATE_LIMIT_EXCEEDED', { ip: req.ip });
    res.status(429).json({
      error: 'Too many authentication attempts',
      message: 'Please try again after 15 minutes',
      retryAfter: req.rateLimit.resetTime
    });
  }
});

// API Key rate limiter (more lenient for system integrations)
const apiRateLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute for API keys
  message: 'API rate limit exceeded'
});

// Audit logging function
async function logAuditEvent(req, action, details = {}) {
  try {
    // Skip audit logging if we don't have valid ObjectIds
    const userId = req.user?._id || req.userId;
    const tenantId = req.tenantId;
    
    // Only log if we have valid ObjectIds
    if (userId && tenantId) {
      await AuditLog.create({
        userId,
        tenantId,
        action,
        resource: 'authentication',
        ipAddress: req.ip || req.connection.remoteAddress,
        userAgent: req.get('user-agent'),
        details: {
          ...details,
          timestamp: new Date(),
          path: req.path,
          method: req.method
        }
      });
    } else {
      // Log to console for debugging without saving to database
      console.debug(`Audit event (not saved): ${action}`, details);
    }
  } catch (error) {
    // Suppress audit log errors to not break authentication flow
    console.debug('Audit logging skipped:', error.message);
  }
}

// Device fingerprinting
function getDeviceFingerprint(req) {
  const ua = req.get('user-agent') || '';
  const ip = req.ip || req.connection.remoteAddress;
  const acceptLanguage = req.get('accept-language') || '';
  const acceptEncoding = req.get('accept-encoding') || '';
  
  return Buffer.from(`${ua}|${ip}|${acceptLanguage}|${acceptEncoding}`).toString('base64');
}

// Main authentication middleware
const auth = async (req, res, next) => {
  try {
    // Extract token from multiple sources
    let token = req.header('Authorization')?.replace('Bearer ', '');
    
    // Check for API key authentication
    const apiKey = req.header('X-API-Key');
    if (apiKey && !token) {
      return handleApiKeyAuth(req, res, next, apiKey);
    }
    
    if (!token) {
      // Check cookies for web portal access
      token = req.cookies?.authToken;
      if (!token) {
        throw new Error('No authentication token provided');
      }
    }

    // Check if token is blacklisted in Redis (skip if Redis unavailable)
    try {
      if (redisClient.isOpen) {
        const isBlacklisted = await redisClient.get(`blacklist:${token}`);
        if (isBlacklisted) {
          throw new Error('Token has been invalidated');
        }
      }
    } catch (redisError) {
      // Continue without Redis check if Redis is unavailable
      console.debug('Redis check skipped:', redisError.message);
    }

    // Verify token with appropriate secret
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        // Attempt to use refresh token
        return handleTokenRefresh(req, res, next);
      }
      throw err;
    }

    // Validate token type
    if (decoded.type !== 'access') {
      throw new Error('Invalid token type');
    }

    // Find user with organization and role details
    const user = await User.findById(decoded.userId)
      .select('-password')
      .populate('organization')
      .lean();
    
    if (!user) {
      throw new Error('User not found');
    }

    // Check user status
    if (user.status === 'inactive' || user.isActive === false) {
      await logAuditEvent(req, 'AUTH_BLOCKED_INACTIVE', { userId: user._id });
      throw new Error('User account is inactive');
    }

    // Check if user is locked (too many failed attempts)
    if (user.lockoutUntil && user.lockoutUntil > Date.now()) {
      const minutesRemaining = Math.ceil((user.lockoutUntil - Date.now()) / 60000);
      throw new Error(`Account locked. Try again in ${minutesRemaining} minutes`);
    }

    // Validate session if strict mode
    if (process.env.STRICT_SESSION === 'true') {
      const session = await Session.findOne({
        userId: user._id,
        token: token,
        expiresAt: { $gt: new Date() }
      });
      
      if (!session) {
        throw new Error('Invalid or expired session');
      }
      
      // Update session activity
      session.lastActivity = new Date();
      session.requestCount = (session.requestCount || 0) + 1;
      await session.save();
    }

    // Check IP restrictions for sensitive roles
    if (shouldCheckIPRestriction(user.role)) {
      const allowedIPs = user.allowedIPs || [];
      const currentIP = req.ip || req.connection.remoteAddress;
      
      if (allowedIPs.length > 0 && !allowedIPs.includes(currentIP)) {
        await logAuditEvent(req, 'AUTH_BLOCKED_IP', { 
          userId: user._id, 
          ip: currentIP,
          allowedIPs 
        });
        throw new Error('Access denied from this IP address');
      }
    }

    // Attach comprehensive user context to request
    req.user = user;
    req.userId = user._id;
    req.tenantId = user.organization?._id || user.tenantId || decoded.tenantId;
    req.userRole = user.role;
    req.userEmail = user.email;
    req.organizationId = user.organization?._id || user.organization;
    req.userPermissions = user.permissions || [];
    req.userLanguage = user.language || 'en';
    req.userTimezone = user.timezone || 'UTC';
    req.userCalendar = user.calendarType || 'gregorian';
    req.deviceFingerprint = getDeviceFingerprint(req);
    
    // Add impersonation context if applicable
    if (decoded.impersonatedBy) {
      req.impersonatedBy = decoded.impersonatedBy;
      req.originalUserId = decoded.originalUserId;
    }

    // Log successful authentication
    await logAuditEvent(req, 'AUTH_SUCCESS', { 
      role: user.role,
      impersonated: !!decoded.impersonatedBy 
    });

    next();
  } catch (error) {
    console.error('Auth middleware error:', error.message);
    
    // Log failed authentication attempt
    await logAuditEvent(req, 'AUTH_FAILED', { 
      error: error.message,
      ip: req.ip 
    });
    
    res.status(401).json({ 
      error: 'Authentication failed', 
      message: error.message,
      code: 'AUTH_FAILED'
    });
  }
};

// Handle API key authentication for integrations
async function handleApiKeyAuth(req, res, next, apiKey) {
  try {
    // Verify API key signature
    const decoded = jwt.verify(apiKey, process.env.JWT_API_SECRET);
    
    // Find integration user
    const integration = await User.findOne({
      _id: decoded.userId,
      'apiKeys.key': apiKey,
      'apiKeys.active': true
    }).lean();
    
    if (!integration) {
      throw new Error('Invalid API key');
    }
    
    // Check API key expiration
    const keyData = integration.apiKeys.find(k => k.key === apiKey);
    if (keyData.expiresAt && keyData.expiresAt < new Date()) {
      throw new Error('API key expired');
    }
    
    // Update usage statistics
    await User.updateOne(
      { _id: integration._id, 'apiKeys.key': apiKey },
      { 
        $inc: { 'apiKeys.$.usageCount': 1 },
        $set: { 'apiKeys.$.lastUsed': new Date() }
      }
    );
    
    // Attach context
    req.user = integration;
    req.userId = integration._id;
    req.tenantId = integration.tenantId;
    req.isApiKey = true;
    req.apiKeyName = keyData.name;
    
    await logAuditEvent(req, 'API_KEY_AUTH_SUCCESS', { 
      keyName: keyData.name 
    });
    
    next();
  } catch (error) {
    await logAuditEvent(req, 'API_KEY_AUTH_FAILED', { 
      error: error.message 
    });
    
    res.status(401).json({
      error: 'API authentication failed',
      message: error.message
    });
  }
}

// Handle token refresh
async function handleTokenRefresh(req, res, next) {
  try {
    const refreshToken = req.cookies?.refreshToken || req.header('X-Refresh-Token');
    
    if (!refreshToken) {
      throw new Error('No refresh token provided');
    }
    
    // Verify refresh token
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    
    if (decoded.type !== 'refresh') {
      throw new Error('Invalid refresh token');
    }
    
    // Check if refresh token is blacklisted
    const isBlacklisted = await redisClient.get(`blacklist:${refreshToken}`);
    if (isBlacklisted) {
      throw new Error('Refresh token has been invalidated');
    }
    
    // Generate new access token
    const newAccessToken = jwt.sign(
      { 
        userId: decoded.userId, 
        tenantId: decoded.tenantId,
        type: 'access'
      },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );
    
    // Set new token in response header
    res.setHeader('X-New-Token', newAccessToken);
    
    // If using cookies, update them
    if (req.cookies?.authToken) {
      res.cookie('authToken', newAccessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000 // 15 minutes
      });
    }
    
    // Continue with new token
    req.header = () => newAccessToken;
    return auth(req, res, next);
  } catch (error) {
    res.status(401).json({
      error: 'Token refresh failed',
      message: error.message,
      code: 'REFRESH_FAILED'
    });
  }
}

// Tenant isolation middleware
const tenantIsolation = async (req, res, next) => {
  if (!req.tenantId) {
    await logAuditEvent(req, 'TENANT_ISOLATION_FAILED', { 
      userId: req.userId 
    });
    return res.status(403).json({ 
      error: 'Tenant context required',
      code: 'NO_TENANT_CONTEXT'
    });
  }
  
  // Add tenant filter to all database queries
  req.tenantFilter = { tenantId: req.tenantId };
  
  // Set tenant context for Mongoose
  if (req.user) {
    req.user.currentTenant = req.tenantId;
  }
  
  next();
};

// Enhanced authorization with role hierarchy
const authorize = (allowedRoles = [], options = {}) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ 
          error: 'Authentication required',
          code: 'NOT_AUTHENTICATED'
        });
      }
      
      const userRole = req.user.role;
      
      // Check if user has required role or inherited permissions
      const hasPermission = allowedRoles.length === 0 || 
        allowedRoles.includes(userRole) ||
        hasInheritedRole(userRole, allowedRoles);
      
      if (!hasPermission) {
        await logAuditEvent(req, 'AUTHORIZATION_FAILED', { 
          userRole,
          requiredRoles: allowedRoles 
        });
        
        return res.status(403).json({ 
          error: 'Access denied',
          message: `Insufficient permissions. Required: ${allowedRoles.join(', ')}`,
          code: 'INSUFFICIENT_PERMISSIONS'
        });
      }
      
      await logAuditEvent(req, 'AUTHORIZATION_SUCCESS', { 
        userRole,
        accessedRoles: allowedRoles 
      });
      
      next();
    } catch (error) {
      console.error('Authorization error:', error);
      res.status(403).json({ 
        error: 'Authorization failed',
        message: error.message 
      });
    }
  };
};

// Check if user role has inherited permissions
function hasInheritedRole(userRole, requiredRoles) {
  const inheritedRoles = ROLE_HIERARCHY[userRole] || [];
  return requiredRoles.some(role => inheritedRoles.includes(role));
}

// Check if IP restrictions should be applied
function shouldCheckIPRestriction(role) {
  const restrictedRoles = [
    ROLES.SUPER_ADMIN,
    ROLES.ADMIN,
    ROLES.FINANCE_MANAGER,
    ROLES.HR_MANAGER
  ];
  return restrictedRoles.includes(role);
}

// Generate access and refresh tokens
function generateTokens(user) {
  const accessToken = jwt.sign(
    { 
      userId: user._id, 
      tenantId: user.tenantId || user.organization,
      type: 'access'
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
  
  const refreshToken = jwt.sign(
    { 
      userId: user._id, 
      tenantId: user.tenantId || user.organization,
      type: 'refresh'
    },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
  
  return { accessToken, refreshToken };
}

// Logout function
const logout = async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const refreshToken = req.cookies?.refreshToken || req.header('X-Refresh-Token');
    
    // Blacklist both tokens
    if (token) {
      await redisClient.set(`blacklist:${token}`, 'true', 'EX', 86400); // 24 hours
    }
    if (refreshToken) {
      await redisClient.set(`blacklist:${refreshToken}`, 'true', 'EX', 604800); // 7 days
    }
    
    // Revoke session if strict mode
    if (process.env.STRICT_SESSION === 'true' && token) {
      await Session.updateOne(
        { userId: req.userId, token },
        { status: 'revoked', revokedAt: new Date(), revokedReason: 'User logout' }
      );
    }
    
    // Clear cookies
    res.clearCookie('authToken');
    res.clearCookie('refreshToken');
    
    await logAuditEvent(req, 'LOGOUT_SUCCESS', { 
      userId: req.userId 
    });
    
    res.json({ 
      success: true, 
      message: 'Logged out successfully' 
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ 
      error: 'Logout failed',
      message: error.message 
    });
  }
};

// Impersonation for admin support
const impersonate = async (req, res) => {
  try {
    const { impersonateUserId } = req.body;
    
    // Only super admins can impersonate
    if (req.user.role !== ROLES.SUPER_ADMIN) {
      return res.status(403).json({ 
        error: 'Impersonation not allowed',
        code: 'IMPERSONATION_DENIED'
      });
    }
    
    const targetUser = await User.findById(impersonateUserId).lean();
    if (!targetUser) {
      return res.status(404).json({ error: 'Target user not found' });
    }
    
    // Generate impersonation token
    const impersonationToken = jwt.sign(
      { 
        userId: targetUser._id,
        tenantId: targetUser.tenantId,
        type: 'access',
        impersonatedBy: req.userId,
        originalUserId: req.userId
      },
      process.env.JWT_SECRET,
      { expiresIn: '2h' } // Shorter expiry for impersonation
    );
    
    await logAuditEvent(req, 'IMPERSONATION_STARTED', { 
      targetUserId: targetUser._id,
      targetUserEmail: targetUser.email 
    });
    
    res.json({
      token: impersonationToken,
      targetUser: {
        _id: targetUser._id,
        email: targetUser.email,
        name: targetUser.name,
        role: targetUser.role
      },
      expiresIn: '2h'
    });
  } catch (error) {
    console.error('Impersonation error:', error);
    res.status(500).json({ 
      error: 'Impersonation failed',
      message: error.message 
    });
  }
};

module.exports = {
  auth,
  authorize,
  tenantIsolation,
  authRateLimiter,
  apiRateLimiter,
  generateTokens,
  logout,
  impersonate,
  ROLES,
  ROLE_HIERARCHY,
  logAuditEvent,
  // Legacy compatibility
  authenticate: auth,
  ensureTenantIsolation: tenantIsolation
};