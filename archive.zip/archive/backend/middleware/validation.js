const validator = require('validator');
const xss = require('xss');
const { body, param, query, validationResult } = require('express-validator');
const mongoose = require('mongoose');

// Deep sanitize objects
const deepSanitize = (obj) => {
    if (typeof obj !== 'object' || obj === null) {
        return sanitizeInput(obj);
    }
    
    if (Array.isArray(obj)) {
        return obj.map(item => deepSanitize(item));
    }
    
    const sanitized = {};
    for (const [key, value] of Object.entries(obj)) {
        sanitized[key] = deepSanitize(value);
    }
    return sanitized;
};

// Sanitize input to prevent XSS
const sanitizeInput = (input) => {
    if (typeof input !== 'string') return input;
    
    // Remove any script tags and dangerous HTML
    return xss(input, {
        whiteList: {}, // No HTML tags allowed
        stripIgnoreTag: true,
        stripIgnoreTagBody: ['script']
    }).trim();
};

// NoSQL Injection prevention
const preventNoSQLInjection = (value) => {
    if (typeof value === 'object' && value !== null) {
        const dangerous = ['$where', '$regex', '$ne', '$gt', '$lt', '$gte', '$lte', '$in', '$nin'];
        
        const checkObject = (obj) => {
            for (const key of Object.keys(obj)) {
                if (dangerous.includes(key)) {
                    throw new Error('Potential NoSQL injection detected');
                }
                if (typeof obj[key] === 'object' && obj[key] !== null) {
                    checkObject(obj[key]);
                }
            }
        };
        
        checkObject(value);
    }
    return value;
};

// Check database connection
const checkDatabaseConnection = (req, res, next) => {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({ 
      success: false, 
      error: 'Database connection not ready' 
    });
  }
  next();
};

// Enhanced sanitization middleware
const sanitizeInputMiddleware = (req, res, next) => {
    try {
        req.body = deepSanitize(req.body);
        req.query = deepSanitize(req.query);
        req.params = deepSanitize(req.params);
        
        // Prevent injection attacks
        preventNoSQLInjection(req.body);
        preventNoSQLInjection(req.query);
        
        next();
    } catch (error) {
        console.error('Input sanitization error:', error);
        return res.status(400).json({
            success: false,
            message: 'Invalid input detected'
        });
    }
};

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
  try {
    // Get validation errors from express-validator
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
      const errorDetails = errors.array();
      
      // Log validation errors for debugging
      console.warn('Validation failed:', {
        endpoint: req.originalUrl,
        method: req.method,
        params: req.params,
        errors: errorDetails
      });
      
      return res.status(400).json({ 
        success: false,
        message: 'Validation failed',
        errors: errorDetails.map(error => ({
          field: error.path || error.param,
          message: error.msg,
          value: error.value,
          location: error.location
        }))
      });
    }
    
    // Additional fallback ObjectId validation for critical parameters
    const criticalParams = ['id', 'bidId', 'vendorId', 'rfqId'];
    for (const param of criticalParams) {
      if (req.params[param] && !mongoose.Types.ObjectId.isValid(req.params[param])) {
        console.warn('Invalid ObjectId detected in fallback validation:', {
          param,
          value: req.params[param],
          endpoint: req.originalUrl
        });
        
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: [{
            field: param,
            message: 'Invalid ObjectId format',
            value: req.params[param],
            location: 'params'
          }]
        });
      }
    }
    
    next();
  } catch (error) {
    console.error('Error in handleValidationErrors middleware:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal validation error'
    });
  }
};

// MongoDB ObjectId validation middleware
const mongoIdValidation = [
  param('id').isMongoId().withMessage('Invalid ID format'),
  param('bidId').optional().isMongoId().withMessage('Invalid bid ID format'),
  param('vendorId').optional().isMongoId().withMessage('Invalid vendor ID format'),
  param('rfqId').optional().isMongoId().withMessage('Invalid RFQ ID format')
];

// Auth validation rules
const authValidationRules = {
  login: [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty()
  ],
  register: [
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }),
    body('name').trim().isLength({ min: 2, max: 50 }),
    body('role').optional().isIn([
      'super_admin', 'admin', 'manager', 'finance', 'hr', 
      'legal', 'operations', 'technician', 'crm', 'support',
      'vendor', 'tenant', 'viewer', 'property_owner'
    ])
  ]
};

module.exports = {
  checkDatabaseConnection,
  sanitizeInput: sanitizeInputMiddleware,
  handleValidationErrors,
  authValidationRules,
  deepSanitize,
  preventNoSQLInjection,
  mongoIdValidation
};
