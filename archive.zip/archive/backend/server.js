import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import winston from 'winston';
import { createServer } from 'http';
import { Server } from 'socket.io';
import pkg from 'pg';
const { Pool } = pkg;
import { v4 as uuidv4 } from 'uuid';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

// Logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

// Middleware
app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json());

// PostgreSQL connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Test connection
pool.connect()
  .then(() => {
    console.log('✅ PostgreSQL connected');
    logger.info('PostgreSQL connected successfully');
  })
  .catch(err => {
    console.error('❌ PostgreSQL connection error:', err);
    logger.error('PostgreSQL connection error:', err);
  });

// Auth middleware
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) throw new Error('No token');
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fixzit-secret-key');
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [decoded.userId]);
    
    if (result.rows.length === 0) throw new Error('User not found');
    
    req.user = result.rows[0];
    req.orgId = req.user.org_id;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

// ==================== AUTH ROUTES ====================
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const result = await pool.query(`
      SELECT u.*, o.name as org_name 
      FROM users u 
      LEFT JOIN organizations o ON u.org_id = o.id 
      WHERE u.email = $1
    `, [email]);
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
      { userId: user.id, orgId: user.org_id, role: user.role }, 
      process.env.JWT_SECRET || 'fixzit-secret-key'
    );
    
    // Update last login
    await pool.query('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [user.id]);
    
    res.json({ 
      token, 
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        organization: user.org_name
      }
    });
    
    logger.info(`User ${email} logged in successfully`);
  } catch (error) {
    logger.error('Login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, role, orgName } = req.body;
    
    // Check if user exists
    const existingUser = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    let orgId;
    if (orgName) {
      // Create or find organization
      const orgResult = await pool.query(`
        INSERT INTO organizations (id, name, subdomain, plan, is_active) 
        VALUES ($1, $2, $3, $4, $5) 
        ON CONFLICT (subdomain) DO UPDATE SET name = EXCLUDED.name
        RETURNING id
      `, [uuidv4(), orgName, orgName.toLowerCase().replace(/\s+/g, '-'), 'basic', true]);
      
      orgId = orgResult.rows[0].id;
    }
    
    const hashedPassword = await bcrypt.hash(password, 12);
    const userId = uuidv4();
    
    await pool.query(`
      INSERT INTO users (id, email, password, first_name, last_name, role, org_id, is_active) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [userId, email, hashedPassword, firstName, lastName, role || 'TENANT', orgId, true]);
    
    res.status(201).json({ message: 'User created successfully', userId });
    logger.info(`New user registered: ${email}`);
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/auth/session', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        u.id, u.email, u.first_name, u.last_name, u.role, u.phone, u.avatar_url,
        u.is_active, u.created_at, u.last_login, u.preferences,
        o.name as org_name, o.subdomain as org_subdomain, o.plan as org_plan
      FROM users u 
      LEFT JOIN organizations o ON u.org_id = o.id 
      WHERE u.id = $1 AND u.is_active = true
    `, [req.user.id]);
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'User not found or inactive' });
    }
    
    const user = result.rows[0];
    
    res.json({
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        phone: user.phone,
        avatarUrl: user.avatar_url,
        isActive: user.is_active,
        createdAt: user.created_at,
        lastLogin: user.last_login,
        preferences: user.preferences || {},
        organization: {
          name: user.org_name,
          subdomain: user.org_subdomain,
          plan: user.org_plan
        }
      }
    });
  } catch (error) {
    logger.error('Session error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/logout', authMiddleware, async (req, res) => {
  try {
    // Update last activity for audit purposes
    await pool.query(
      'UPDATE users SET last_activity = CURRENT_TIMESTAMP WHERE id = $1',
      [req.user.id]
    );
    
    // In a JWT-based system, logout is handled client-side by removing the token
    // But we can track logout events for security auditing
    logger.info(`User ${req.user.id} logged out`);
    
    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    logger.error('Logout error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== DASHBOARD ====================
app.get('/api/dashboard/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM properties WHERE org_id = $1) as properties,
        (SELECT COUNT(*) FROM units WHERE org_id = $1) as units,
        (SELECT COUNT(*) FROM work_orders WHERE org_id = $1 AND status IN ('OPEN', 'IN_PROGRESS')) as active_work_orders,
        (SELECT COUNT(*) FROM work_orders WHERE org_id = $1 AND status = 'COMPLETED') as completed_work_orders
    `, [req.orgId]);
    
    res.json(stats.rows[0]);
  } catch (error) {
    logger.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== WORK ORDERS ====================
app.get('/api/work-orders', authMiddleware, async (req, res) => {
  try {
    const { status, priority, limit = 50 } = req.query;
    let query = `
      SELECT wo.*, p.name as property_name, p.address as property_address,
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM work_orders wo
      LEFT JOIN properties p ON wo.property_id = p.id
      LEFT JOIN users u_assigned ON wo.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON wo.created_by = u_created.id
      WHERE wo.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND wo.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (priority) {
      paramCount++;
      query += ` AND wo.priority = $${paramCount}`;
      queryParams.push(priority);
    }
    
    query += ` ORDER BY wo.created_at DESC LIMIT $${paramCount + 1}`;
    queryParams.push(parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch work orders error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/work-orders', authMiddleware, async (req, res) => {
  try {
    const { title, description, category, priority, propertyId, unitId, assignedTo } = req.body;
    const woNumber = `WO-${Date.now()}-${uuidv4().substring(0, 8).toUpperCase()}`;
    const workOrderId = uuidv4();
    
    await pool.query(`
      INSERT INTO work_orders (
        id, wo_number, title, description, category, priority, status,
        property_id, unit_id, assigned_to, created_by, org_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    `, [
      workOrderId, woNumber, title, description || '', category || 'general',
      priority || 'MEDIUM', 'OPEN', propertyId, unitId, assignedTo, 
      req.user.id, req.orgId
    ]);
    
    // Get the created work order with joins
    const result = await pool.query(`
      SELECT wo.*, p.name as property_name,
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM work_orders wo
      LEFT JOIN properties p ON wo.property_id = p.id
      LEFT JOIN users u_assigned ON wo.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON wo.created_by = u_created.id
      WHERE wo.id = $1
    `, [workOrderId]);
    
    const workOrder = result.rows[0];
    
    // Emit real-time notification
    io.to(`org-${req.orgId}`).emit('workOrderCreated', workOrder);
    
    res.status(201).json(workOrder);
    logger.info(`Work order created: ${woNumber}`);
  } catch (error) {
    logger.error('Create work order error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== PROPERTIES ====================
app.get('/api/properties', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.*, 
             (SELECT COUNT(*) FROM units WHERE property_id = p.id) as total_units,
             (SELECT COUNT(*) FROM units WHERE property_id = p.id AND status = 'occupied') as occupied_units
      FROM properties p 
      WHERE p.org_id = $1 
      ORDER BY p.created_at DESC
    `, [req.orgId]);
    
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch properties error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/properties', authMiddleware, async (req, res) => {
  try {
    const { name, address, type, totalUnits } = req.body;
    const propertyId = uuidv4();
    
    await pool.query(`
      INSERT INTO properties (id, name, address, type, total_units, org_id, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
    `, [propertyId, name, address, type || 'residential', totalUnits || 0, req.orgId, req.user.id]);
    
    const result = await pool.query('SELECT * FROM properties WHERE id = $1', [propertyId]);
    res.status(201).json(result.rows[0]);
    logger.info(`Property created: ${name}`);
  } catch (error) {
    logger.error('Create property error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== FINANCIAL MANAGEMENT SYSTEM ====================

// Initialize financial tables if they don't exist
pool.query(`
  -- Ensure financial tables exist
  CREATE TABLE IF NOT EXISTS invoices (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    invoice_number TEXT UNIQUE NOT NULL,
    tenant_id TEXT REFERENCES tenants(id),
    property_id TEXT REFERENCES properties(id),
    unit_id TEXT REFERENCES units(id),
    type TEXT DEFAULT 'rent',
    status TEXT DEFAULT 'draft',
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    currency TEXT DEFAULT 'SAR',
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    total_amount DECIMAL(12, 2) NOT NULL,
    paid_amount DECIMAL(12, 2) DEFAULT 0,
    notes TEXT,
    terms TEXT,
    org_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    invoice_id TEXT,
    tenant_id TEXT,
    property_id TEXT,
    unit_id TEXT,
    amount DECIMAL(12, 2) NOT NULL,
    currency TEXT DEFAULT 'SAR',
    payment_date DATE NOT NULL,
    due_date DATE,
    status TEXT DEFAULT 'pending',
    method TEXT DEFAULT 'bank_transfer',
    reference TEXT,
    description TEXT NOT NULL,
    notes TEXT,
    late_fee DECIMAL(10, 2) DEFAULT 0,
    discount DECIMAL(10, 2) DEFAULT 0,
    org_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    type TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    currency TEXT DEFAULT 'SAR',
    date DATE NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    property_id TEXT,
    unit_id TEXT,
    tenant_id TEXT,
    payment_id TEXT,
    invoice_id TEXT,
    reference TEXT,
    org_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS expenses (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT,
    unit_id TEXT,
    category TEXT DEFAULT 'maintenance',
    subcategory TEXT,
    description TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    currency TEXT DEFAULT 'SAR',
    expense_date DATE NOT NULL,
    payment_method TEXT DEFAULT 'bank_transfer',
    vendor TEXT,
    receipt_url TEXT,
    tax_deductible BOOLEAN DEFAULT TRUE,
    approved_by TEXT,
    approved_at TIMESTAMP,
    org_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );
`).catch(err => logger.error('Financial tables initialization error:', err));

// Financial Dashboard API
app.get('/api/finances/dashboard', authMiddleware, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    // Get comprehensive dashboard data
    const dashboardData = await pool.query(`
      WITH monthly_revenue AS (
        SELECT 
          TO_CHAR(payment_date, 'Mon YYYY') as month,
          SUM(amount) as revenue,
          COUNT(*) as payment_count
        FROM payments 
        WHERE org_id = $1 AND status = 'received' AND payment_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(payment_date, 'Mon YYYY'), DATE_TRUNC('month', payment_date)
        ORDER BY DATE_TRUNC('month', payment_date)
      ),
      monthly_expenses AS (
        SELECT 
          TO_CHAR(expense_date, 'Mon YYYY') as month,
          SUM(amount) as expenses
        FROM expenses 
        WHERE org_id = $1 AND expense_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(expense_date, 'Mon YYYY'), DATE_TRUNC('month', expense_date)
      ),
      payment_status_summary AS (
        SELECT 
          status,
          COUNT(*) as count,
          SUM(amount) as total_amount
        FROM payments 
        WHERE org_id = $1 AND payment_date >= DATE(NOW() - INTERVAL '3 months')
        GROUP BY status
      ),
      expense_breakdown AS (
        SELECT 
          category,
          SUM(amount) as amount,
          COUNT(*) as count
        FROM expenses 
        WHERE org_id = $1 AND expense_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY category
        ORDER BY SUM(amount) DESC
        LIMIT 10
      ),
      property_performance AS (
        SELECT 
          p.name as property_name,
          COALESCE(SUM(pay.amount), 0) as revenue,
          COALESCE(SUM(exp.amount), 0) as expenses,
          COALESCE(SUM(pay.amount), 0) - COALESCE(SUM(exp.amount), 0) as net_income
        FROM properties p
        LEFT JOIN payments pay ON p.id = pay.property_id AND pay.status = 'received' AND pay.org_id = $1
        LEFT JOIN expenses exp ON p.id = exp.property_id AND exp.org_id = $1
        WHERE p.org_id = $1
        GROUP BY p.id, p.name
        ORDER BY net_income DESC
        LIMIT 10
      )
      SELECT 
        json_build_object(
          'revenueChart', json_agg(DISTINCT mr.*),
          'expenseChart', json_agg(DISTINCT me.*),
          'paymentStatusChart', json_agg(DISTINCT pss.*),
          'expenseBreakdown', json_agg(DISTINCT eb.*),
          'propertyPerformance', json_agg(DISTINCT pp.*)
        ) as dashboard_data
      FROM monthly_revenue mr
      FULL OUTER JOIN monthly_expenses me ON mr.month = me.month
      CROSS JOIN payment_status_summary pss
      CROSS JOIN expense_breakdown eb
      CROSS JOIN property_performance pp
    `, [req.orgId]);
    
    // Get recent transactions
    const recentTransactions = await pool.query(`
      SELECT 
        t.*,
        p.name as property_name,
        ten.first_name || ' ' || ten.last_name as tenant_name
      FROM transactions t
      LEFT JOIN properties p ON t.property_id = p.id
      LEFT JOIN tenants ten ON t.tenant_id = ten.id
      WHERE t.org_id = $1
      ORDER BY t.created_at DESC
      LIMIT 20
    `, [req.orgId]);
    
    // Get overdue payments
    const overduePayments = await pool.query(`
      SELECT 
        p.*,
        ten.first_name,
        ten.last_name,
        EXTRACT(DAY FROM (CURRENT_DATE - p.due_date)) as days_past_due
      FROM payments p
      LEFT JOIN tenants ten ON p.tenant_id = ten.id
      WHERE p.org_id = $1 AND p.status IN ('pending', 'overdue') AND p.due_date < CURRENT_DATE
      ORDER BY p.due_date ASC
    `, [req.orgId]);
    
    const result = dashboardData.rows[0]?.dashboard_data || {};
    result.recentTransactions = recentTransactions.rows;
    result.overduePayments = overduePayments.rows;
    result.cashFlowProjection = []; // Will be calculated client-side or in separate endpoint
    result.upcomingInvoices = []; // Will be calculated client-side or in separate endpoint
    
    res.json(result);
  } catch (error) {
    logger.error('Financial dashboard error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Financial Stats API
app.get('/api/finances/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      WITH revenue_data AS (
        SELECT 
          SUM(CASE WHEN status = 'received' THEN amount ELSE 0 END) as total_revenue,
          SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as outstanding_payments,
          SUM(CASE WHEN status IN ('pending', 'overdue') AND due_date < CURRENT_DATE THEN amount ELSE 0 END) as overdue_amount,
          AVG(CASE WHEN status = 'received' THEN amount ELSE NULL END) as average_payment,
          COUNT(CASE WHEN status = 'received' AND payment_date >= DATE(NOW() - INTERVAL '30 days') THEN 1 END) as recent_payments,
          COUNT(CASE WHEN status = 'received' AND payment_date >= DATE(NOW() - INTERVAL '60 days') AND payment_date < DATE(NOW() - INTERVAL '30 days') THEN 1 END) as previous_payments
        FROM payments 
        WHERE org_id = $1
      ),
      expense_data AS (
        SELECT 
          SUM(amount) as total_expenses,
          AVG(amount) as average_expense
        FROM expenses 
        WHERE org_id = $1 AND expense_date >= DATE(NOW() - INTERVAL '12 months')
      ),
      property_data AS (
        SELECT 
          AVG(rent_amount) as average_rent,
          COUNT(CASE WHEN status = 'occupied' THEN 1 END)::float / NULLIF(COUNT(*), 0) as occupancy_rate
        FROM units u
        JOIN properties p ON u.property_id = p.id
        WHERE p.org_id = $1
      )
      SELECT 
        r.total_revenue,
        e.total_expenses,
        (r.total_revenue - COALESCE(e.total_expenses, 0)) as net_income,
        CASE 
          WHEN r.total_revenue > 0 THEN ((r.total_revenue - COALESCE(e.total_expenses, 0)) / r.total_revenue * 100)
          ELSE 0 
        END as profit_margin,
        r.outstanding_payments,
        r.overdue_amount,
        COALESCE(p.average_rent, 0) as average_rent,
        COALESCE(p.occupancy_rate * r.total_revenue, 0) as occupancy_revenue,
        CASE 
          WHEN r.previous_payments > 0 THEN ((r.recent_payments - r.previous_payments)::float / r.previous_payments * 100)
          ELSE 0 
        END as monthly_growth,
        CASE 
          WHEN r.total_revenue > 0 THEN (COALESCE(e.total_expenses, 0) / r.total_revenue * 100)
          ELSE 0 
        END as expense_ratio
      FROM revenue_data r
      CROSS JOIN expense_data e
      CROSS JOIN property_data p
    `, [req.orgId]);
    
    res.json(stats.rows[0] || {
      totalRevenue: 0,
      totalExpenses: 0,
      netIncome: 0,
      profitMargin: 0,
      outstandingPayments: 0,
      overdueAmount: 0,
      averageRent: 0,
      occupancyRevenue: 0,
      monthlyGrowth: 0,
      expenseRatio: 0
    });
  } catch (error) {
    logger.error('Financial stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Payment Management APIs
app.get('/api/finances/payments', authMiddleware, async (req, res) => {
  try {
    const { status, method, propertyId, tenantId, dateFrom, dateTo, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        p.*,
        i.invoice_number,
        t.first_name || ' ' || t.last_name as tenant_name,
        t.email as tenant_email,
        prop.name as property_name,
        u.unit_number,
        EXTRACT(DAY FROM (CURRENT_DATE - p.due_date)) as days_past_due
      FROM payments p
      LEFT JOIN invoices i ON p.invoice_id = i.id
      LEFT JOIN tenants t ON p.tenant_id = t.id
      LEFT JOIN properties prop ON p.property_id = prop.id
      LEFT JOIN units u ON p.unit_id = u.id
      WHERE p.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND p.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (method) {
      paramCount++;
      query += ` AND p.method = $${paramCount}`;
      queryParams.push(method);
    }
    
    if (propertyId) {
      paramCount++;
      query += ` AND p.property_id = $${paramCount}`;
      queryParams.push(propertyId);
    }
    
    if (tenantId) {
      paramCount++;
      query += ` AND p.tenant_id = $${paramCount}`;
      queryParams.push(tenantId);
    }
    
    if (dateFrom) {
      paramCount++;
      query += ` AND p.payment_date >= $${paramCount}`;
      queryParams.push(dateFrom);
    }
    
    if (dateTo) {
      paramCount++;
      query += ` AND p.payment_date <= $${paramCount}`;
      queryParams.push(dateTo);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (p.description ILIKE $${paramCount} OR p.reference ILIKE $${paramCount} OR t.first_name ILIKE $${paramCount} OR t.last_name ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    // Get total count
    const countQuery = query.replace('SELECT p.*,', 'SELECT COUNT(*) as total FROM (SELECT p.*,') + ') as subquery';
    const totalResult = await pool.query(countQuery, queryParams);
    const total = parseInt(totalResult.rows[0].total);
    
    // Add pagination
    query += ` ORDER BY p.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    
    res.json({
      payments: result.rows,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    logger.error('Fetch payments error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/finances/payments', authMiddleware, async (req, res) => {
  try {
    const { invoiceId, tenantId, propertyId, unitId, amount, paymentDate, method, reference, description, notes } = req.body;
    
    const paymentId = uuidv4();
    
    // Insert payment
    const result = await pool.query(`
      INSERT INTO payments (
        id, invoice_id, tenant_id, property_id, unit_id, amount, payment_date, 
        method, reference, description, notes, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *
    `, [
      paymentId, invoiceId, tenantId, propertyId, unitId, amount, paymentDate,
      method, reference, description, notes, req.orgId, req.user.id
    ]);
    
    // Create transaction record
    await pool.query(`
      INSERT INTO transactions (
        id, type, amount, date, description, category, property_id, unit_id, 
        tenant_id, payment_id, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    `, [
      uuidv4(), 'income', amount, paymentDate, description, 'rent', 
      propertyId, unitId, tenantId, paymentId, req.orgId, req.user.id
    ]);
    
    // Update invoice if applicable
    if (invoiceId) {
      await pool.query(`
        UPDATE invoices 
        SET paid_amount = paid_amount + $1,
            status = CASE 
              WHEN paid_amount + $1 >= total_amount THEN 'paid'
              WHEN paid_amount + $1 > 0 THEN 'partial'
              ELSE status
            END,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $2 AND org_id = $3
      `, [amount, invoiceId, req.orgId]);
    }
    
    // Get the created payment with relations
    const paymentResult = await pool.query(`
      SELECT 
        p.*,
        t.first_name || ' ' || t.last_name as tenant_name,
        prop.name as property_name,
        u.unit_number
      FROM payments p
      LEFT JOIN tenants t ON p.tenant_id = t.id
      LEFT JOIN properties prop ON p.property_id = prop.id
      LEFT JOIN units u ON p.unit_id = u.id
      WHERE p.id = $1
    `, [paymentId]);
    
    res.status(201).json(paymentResult.rows[0]);
    logger.info(`Payment created: ${paymentId} - ${amount}`);
  } catch (error) {
    logger.error('Create payment error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Individual Payment Operations
app.get('/api/finances/payments/:id', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        p.*,
        i.invoice_number,
        t.first_name || ' ' || t.last_name as tenant_name,
        t.email as tenant_email,
        prop.name as property_name,
        u.unit_number
      FROM payments p
      LEFT JOIN invoices i ON p.invoice_id = i.id
      LEFT JOIN tenants t ON p.tenant_id = t.id
      LEFT JOIN properties prop ON p.property_id = prop.id
      LEFT JOIN units u ON p.unit_id = u.id
      WHERE p.id = $1 AND p.org_id = $2
    `, [req.params.id, req.orgId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Fetch payment error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/finances/payments/:id', authMiddleware, async (req, res) => {
  try {
    const { amount, paymentDate, status, method, reference, description, notes } = req.body;
    
    const result = await pool.query(`
      UPDATE payments 
      SET amount = $1, payment_date = $2, status = $3, method = $4, 
          reference = $5, description = $6, notes = $7, updated_at = CURRENT_TIMESTAMP
      WHERE id = $8 AND org_id = $9
      RETURNING *
    `, [amount, paymentDate, status, method, reference, description, notes, req.params.id, req.orgId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    res.json(result.rows[0]);
    logger.info(`Payment updated: ${req.params.id}`);
  } catch (error) {
    logger.error('Update payment error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/finances/payments/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        COUNT(*) as total_payments,
        SUM(CASE WHEN status = 'received' THEN amount ELSE 0 END) as total_received,
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as total_pending,
        SUM(CASE WHEN status IN ('pending', 'overdue') AND due_date < CURRENT_DATE THEN amount ELSE 0 END) as total_overdue,
        AVG(CASE WHEN status = 'received' THEN amount ELSE NULL END) as average_payment,
        COUNT(CASE WHEN status = 'received' AND due_date >= payment_date THEN 1 END)::float / 
          NULLIF(COUNT(CASE WHEN status = 'received' THEN 1 END), 0) * 100 as on_time_payment_rate,
        AVG(CASE WHEN status = 'received' AND payment_date > due_date 
          THEN EXTRACT(DAY FROM (payment_date - due_date)) ELSE NULL END) as average_payment_delay,
        SUM(late_fee) as late_fee_collected
      FROM payments 
      WHERE org_id = $1
    `, [req.orgId]);
    
    res.json(stats.rows[0] || {});
  } catch (error) {
    logger.error('Payment stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Invoice Management APIs
app.get('/api/finances/invoices', authMiddleware, async (req, res) => {
  try {
    const { status, type, propertyId, tenantId, dateFrom, dateTo, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        i.*,
        t.first_name || ' ' || t.last_name as tenant_name,
        t.email as tenant_email,
        prop.name as property_name,
        u.unit_number,
        EXTRACT(DAY FROM (CURRENT_DATE - i.due_date)) as days_past_due,
        (i.total_amount - i.paid_amount) as remaining_amount
      FROM invoices i
      LEFT JOIN tenants t ON i.tenant_id = t.id
      LEFT JOIN properties prop ON i.property_id = prop.id
      LEFT JOIN units u ON i.unit_id = u.id
      WHERE i.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND i.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (type) {
      paramCount++;
      query += ` AND i.type = $${paramCount}`;
      queryParams.push(type);
    }
    
    if (propertyId) {
      paramCount++;
      query += ` AND i.property_id = $${paramCount}`;
      queryParams.push(propertyId);
    }
    
    if (tenantId) {
      paramCount++;
      query += ` AND i.tenant_id = $${paramCount}`;
      queryParams.push(tenantId);
    }
    
    if (dateFrom) {
      paramCount++;
      query += ` AND i.issue_date >= $${paramCount}`;
      queryParams.push(dateFrom);
    }
    
    if (dateTo) {
      paramCount++;
      query += ` AND i.issue_date <= $${paramCount}`;
      queryParams.push(dateTo);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (i.description ILIKE $${paramCount} OR i.invoice_number ILIKE $${paramCount} OR t.first_name ILIKE $${paramCount} OR t.last_name ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    // Get total count
    const countQuery = query.replace('SELECT i.*,', 'SELECT COUNT(*) as total FROM (SELECT i.*,') + ') as subquery';
    const totalResult = await pool.query(countQuery, queryParams);
    const total = parseInt(totalResult.rows[0].total);
    
    // Add pagination
    query += ` ORDER BY i.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    
    res.json({
      invoices: result.rows,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    logger.error('Fetch invoices error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/finances/invoices', authMiddleware, async (req, res) => {
  try {
    const { tenantId, propertyId, unitId, type, issueDate, dueDate, description, amount, taxAmount = 0, discountAmount = 0, notes, terms } = req.body;
    
    const invoiceId = uuidv4();
    const invoiceNumber = `INV-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    const totalAmount = parseFloat(amount) + parseFloat(taxAmount) - parseFloat(discountAmount);
    
    const result = await pool.query(`
      INSERT INTO invoices (
        id, invoice_number, tenant_id, property_id, unit_id, type, issue_date, due_date,
        description, amount, tax_amount, discount_amount, total_amount, notes, terms, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      RETURNING *
    `, [
      invoiceId, invoiceNumber, tenantId, propertyId, unitId, type, issueDate, dueDate,
      description, amount, taxAmount, discountAmount, totalAmount, notes, terms, req.orgId, req.user.id
    ]);
    
    // Get the created invoice with relations
    const invoiceResult = await pool.query(`
      SELECT 
        i.*,
        t.first_name || ' ' || t.last_name as tenant_name,
        prop.name as property_name,
        u.unit_number
      FROM invoices i
      LEFT JOIN tenants t ON i.tenant_id = t.id
      LEFT JOIN properties prop ON i.property_id = prop.id
      LEFT JOIN units u ON i.unit_id = u.id
      WHERE i.id = $1
    `, [invoiceId]);
    
    res.status(201).json(invoiceResult.rows[0]);
    logger.info(`Invoice created: ${invoiceNumber} - ${totalAmount}`);
  } catch (error) {
    logger.error('Create invoice error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/finances/invoices/:id', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        i.*,
        t.first_name || ' ' || t.last_name as tenant_name,
        t.email as tenant_email,
        t.phone as tenant_phone,
        prop.name as property_name,
        prop.address as property_address,
        u.unit_number,
        (i.total_amount - i.paid_amount) as remaining_amount
      FROM invoices i
      LEFT JOIN tenants t ON i.tenant_id = t.id
      LEFT JOIN properties prop ON i.property_id = prop.id
      LEFT JOIN units u ON i.unit_id = u.id
      WHERE i.id = $1 AND i.org_id = $2
    `, [req.params.id, req.orgId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Fetch invoice error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/finances/invoices/:id', authMiddleware, async (req, res) => {
  try {
    const { description, amount, taxAmount, discountAmount, dueDate, notes, terms, status } = req.body;
    const totalAmount = parseFloat(amount || 0) + parseFloat(taxAmount || 0) - parseFloat(discountAmount || 0);
    
    const result = await pool.query(`
      UPDATE invoices 
      SET description = COALESCE($1, description),
          amount = COALESCE($2, amount),
          tax_amount = COALESCE($3, tax_amount),
          discount_amount = COALESCE($4, discount_amount),
          total_amount = COALESCE($5, total_amount),
          due_date = COALESCE($6, due_date),
          notes = COALESCE($7, notes),
          terms = COALESCE($8, terms),
          status = COALESCE($9, status),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $10 AND org_id = $11
      RETURNING *
    `, [description, amount, taxAmount, discountAmount, totalAmount, dueDate, notes, terms, status, req.params.id, req.orgId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    
    res.json(result.rows[0]);
    logger.info(`Invoice updated: ${req.params.id}`);
  } catch (error) {
    logger.error('Update invoice error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/finances/invoices/:id/send', authMiddleware, async (req, res) => {
  try {
    // Update invoice status to sent
    await pool.query(`
      UPDATE invoices 
      SET status = 'sent', sent_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND org_id = $2
    `, [req.params.id, req.orgId]);
    
    res.json({ message: 'Invoice sent successfully' });
    logger.info(`Invoice sent: ${req.params.id}`);
  } catch (error) {
    logger.error('Send invoice error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Expense Management APIs
app.get('/api/finances/expenses', authMiddleware, async (req, res) => {
  try {
    const { category, propertyId, dateFrom, dateTo, vendor, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        e.*,
        prop.name as property_name,
        u.unit_number
      FROM expenses e
      LEFT JOIN properties prop ON e.property_id = prop.id
      LEFT JOIN units u ON e.unit_id = u.id
      WHERE e.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (category) {
      paramCount++;
      query += ` AND e.category = $${paramCount}`;
      queryParams.push(category);
    }
    
    if (propertyId) {
      paramCount++;
      query += ` AND e.property_id = $${paramCount}`;
      queryParams.push(propertyId);
    }
    
    if (vendor) {
      paramCount++;
      query += ` AND e.vendor ILIKE $${paramCount}`;
      queryParams.push(`%${vendor}%`);
    }
    
    if (dateFrom) {
      paramCount++;
      query += ` AND e.expense_date >= $${paramCount}`;
      queryParams.push(dateFrom);
    }
    
    if (dateTo) {
      paramCount++;
      query += ` AND e.expense_date <= $${paramCount}`;
      queryParams.push(dateTo);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (e.description ILIKE $${paramCount} OR e.vendor ILIKE $${paramCount} OR e.subcategory ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    // Get total count
    const countQuery = query.replace('SELECT e.*,', 'SELECT COUNT(*) as total FROM (SELECT e.*,') + ') as subquery';
    const totalResult = await pool.query(countQuery, queryParams);
    const total = parseInt(totalResult.rows[0].total);
    
    // Add pagination
    query += ` ORDER BY e.expense_date DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    
    res.json({
      expenses: result.rows,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    logger.error('Fetch expenses error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/finances/expenses', authMiddleware, async (req, res) => {
  try {
    const { propertyId, unitId, category, subcategory, description, amount, expenseDate, paymentMethod, vendor, taxDeductible = true } = req.body;
    
    const expenseId = uuidv4();
    
    // Insert expense
    const result = await pool.query(`
      INSERT INTO expenses (
        id, property_id, unit_id, category, subcategory, description, amount, 
        expense_date, payment_method, vendor, tax_deductible, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *
    `, [
      expenseId, propertyId, unitId, category, subcategory, description, amount,
      expenseDate, paymentMethod, vendor, taxDeductible, req.orgId, req.user.id
    ]);
    
    // Create transaction record
    await pool.query(`
      INSERT INTO transactions (
        id, type, amount, date, description, category, property_id, unit_id, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
    `, [
      uuidv4(), 'expense', amount, expenseDate, description, category, 
      propertyId, unitId, req.orgId, req.user.id
    ]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Expense created: ${expenseId} - ${amount}`);
  } catch (error) {
    logger.error('Create expense error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/finances/expenses/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        SUM(amount) as total_expenses,
        AVG(amount) as monthly_average,
        (SELECT category FROM (
          SELECT category, SUM(amount) as total 
          FROM expenses 
          WHERE org_id = $1 
          GROUP BY category 
          ORDER BY total DESC 
          LIMIT 1
        ) as top) as top_category,
        COUNT(*) as total_count,
        SUM(CASE WHEN expense_date >= DATE(NOW() - INTERVAL '12 months') THEN amount ELSE 0 END) as year_total,
        SUM(CASE WHEN expense_date >= DATE(NOW() - INTERVAL '24 months') AND expense_date < DATE(NOW() - INTERVAL '12 months') THEN amount ELSE 0 END) as previous_year_total
      FROM expenses 
      WHERE org_id = $1 AND expense_date >= DATE(NOW() - INTERVAL '24 months')
    `, [req.orgId]);
    
    const result = stats.rows[0];
    const yearOverYearGrowth = result.previous_year_total > 0 
      ? ((result.year_total - result.previous_year_total) / result.previous_year_total * 100)
      : 0;
    
    res.json({
      ...result,
      yearOverYearGrowth,
      budgetUtilization: 0, // Would need budget data
      costPerUnit: 0 // Would calculate based on units
    });
  } catch (error) {
    logger.error('Expense stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Transaction APIs
app.get('/api/finances/transactions', authMiddleware, async (req, res) => {
  try {
    const { type, category, propertyId, dateFrom, dateTo, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        t.*,
        prop.name as property_name,
        u.unit_number,
        ten.first_name || ' ' || ten.last_name as tenant_name
      FROM transactions t
      LEFT JOIN properties prop ON t.property_id = prop.id
      LEFT JOIN units u ON t.unit_id = u.id
      LEFT JOIN tenants ten ON t.tenant_id = ten.id
      WHERE t.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (type) {
      paramCount++;
      query += ` AND t.type = $${paramCount}`;
      queryParams.push(type);
    }
    
    if (category) {
      paramCount++;
      query += ` AND t.category = $${paramCount}`;
      queryParams.push(category);
    }
    
    if (propertyId) {
      paramCount++;
      query += ` AND t.property_id = $${paramCount}`;
      queryParams.push(propertyId);
    }
    
    if (dateFrom) {
      paramCount++;
      query += ` AND t.date >= $${paramCount}`;
      queryParams.push(dateFrom);
    }
    
    if (dateTo) {
      paramCount++;
      query += ` AND t.date <= $${paramCount}`;
      queryParams.push(dateTo);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (t.description ILIKE $${paramCount} OR t.reference ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    // Get total count
    const countQuery = query.replace('SELECT t.*,', 'SELECT COUNT(*) as total FROM (SELECT t.*,') + ') as subquery';
    const totalResult = await pool.query(countQuery, queryParams);
    const total = parseInt(totalResult.rows[0].total);
    
    // Add pagination
    query += ` ORDER BY t.date DESC, t.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    
    res.json({
      transactions: result.rows,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    logger.error('Fetch transactions error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Financial Reports API
app.post('/api/finances/reports', authMiddleware, async (req, res) => {
  try {
    const { type, period, startDate, endDate, propertyIds } = req.body;
    
    let reportData = {};
    let reportName = `${type.replace('_', ' ').toUpperCase()} Report - ${period}`;
    
    if (type === 'profit_loss') {
      const result = await pool.query(`
        WITH revenue AS (
          SELECT 
            SUM(amount) as total_revenue,
            TO_CHAR(payment_date, 'YYYY-MM') as month
          FROM payments 
          WHERE org_id = $1 AND status = 'received' 
            AND payment_date >= $2 AND payment_date <= $3
            ${propertyIds?.length ? `AND property_id = ANY($4)` : ''}
          GROUP BY TO_CHAR(payment_date, 'YYYY-MM')
        ),
        expenses AS (
          SELECT 
            SUM(amount) as total_expenses,
            TO_CHAR(expense_date, 'YYYY-MM') as month
          FROM expenses 
          WHERE org_id = $1 
            AND expense_date >= $2 AND expense_date <= $3
            ${propertyIds?.length ? `AND property_id = ANY($4)` : ''}
          GROUP BY TO_CHAR(expense_date, 'YYYY-MM')
        )
        SELECT 
          COALESCE(r.month, e.month) as period,
          COALESCE(r.total_revenue, 0) as revenue,
          COALESCE(e.total_expenses, 0) as expenses,
          COALESCE(r.total_revenue, 0) - COALESCE(e.total_expenses, 0) as net_income
        FROM revenue r
        FULL OUTER JOIN expenses e ON r.month = e.month
        ORDER BY period
      `, propertyIds?.length ? [req.orgId, startDate, endDate, propertyIds] : [req.orgId, startDate, endDate]);
      
      reportData = {
        periods: result.rows,
        totalRevenue: result.rows.reduce((sum, row) => sum + parseFloat(row.revenue), 0),
        totalExpenses: result.rows.reduce((sum, row) => sum + parseFloat(row.expenses), 0),
        totalNetIncome: result.rows.reduce((sum, row) => sum + parseFloat(row.net_income), 0)
      };
    }
    
    // Save report (simplified - in production would save to database)
    const reportId = uuidv4();
    
    res.json({
      id: reportId,
      name: reportName,
      type,
      period,
      startDate,
      endDate,
      data: reportData,
      generatedAt: new Date().toISOString(),
      generatedBy: req.user.id
    });
    
    logger.info(`Financial report generated: ${type} - ${period}`);
  } catch (error) {
    logger.error('Generate report error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/finances/reports', authMiddleware, async (req, res) => {
  try {
    // Return empty array for now - in production would query saved reports
    res.json([]);
  } catch (error) {
    logger.error('Fetch reports error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Financial Analytics API
app.get('/api/finances/analytics', authMiddleware, async (req, res) => {
  try {
    const { period = 'monthly' } = req.query;
    
    const analytics = await pool.query(`
      WITH period_data AS (
        SELECT 
          TO_CHAR(payment_date, 'YYYY-MM') as period,
          SUM(CASE WHEN status = 'received' THEN amount ELSE 0 END) as revenue,
          COUNT(CASE WHEN status = 'received' THEN 1 END) as payment_count,
          AVG(CASE WHEN status = 'received' AND due_date >= payment_date THEN 1 ELSE 0 END) * 100 as on_time_rate
        FROM payments 
        WHERE org_id = $1 AND payment_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(payment_date, 'YYYY-MM')
        ORDER BY period
      ),
      expense_data AS (
        SELECT 
          TO_CHAR(expense_date, 'YYYY-MM') as period,
          SUM(amount) as expenses
        FROM expenses 
        WHERE org_id = $1 AND expense_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(expense_date, 'YYYY-MM')
      ),
      payment_methods AS (
        SELECT 
          method,
          SUM(amount) as total_amount,
          COUNT(*) as count,
          AVG(CASE WHEN due_date < payment_date 
            THEN EXTRACT(DAY FROM (payment_date - due_date)) ELSE 0 END) as avg_delay
        FROM payments 
        WHERE org_id = $1 AND status = 'received'
        GROUP BY method
      )
      SELECT 
        json_build_object(
          'revenueTrend', json_agg(DISTINCT pd.*),
          'expenseTrend', json_agg(DISTINCT ed.*),
          'paymentPatterns', json_agg(DISTINCT pm.*),
          'benchmarkData', json_build_object(
            'industryAvgMargin', 25.5,
            'industryAvgOccupancy', 90.2,
            'industryAvgRent', 2500,
            'performanceRank', 78
          )
        ) as analytics_data
      FROM period_data pd
      LEFT JOIN expense_data ed ON pd.period = ed.period
      CROSS JOIN payment_methods pm
    `, [req.orgId]);
    
    res.json(analytics.rows[0]?.analytics_data || {});
  } catch (error) {
    logger.error('Financial analytics error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== CRM SYSTEM API ====================

// ==================== LEADS MANAGEMENT ====================
app.get('/api/crm/leads', authMiddleware, async (req, res) => {
  try {
    const { status, source, assignedTo, search, limit = 50, offset = 0 } = req.query;
    
    let whereClause = 'WHERE l.org_id = $1';
    let params = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      whereClause += ` AND l.status = $${paramCount}`;
      params.push(status);
    }
    
    if (source) {
      paramCount++;
      whereClause += ` AND l.source = $${paramCount}`;
      params.push(source);
    }
    
    if (assignedTo) {
      paramCount++;
      whereClause += ` AND l.assigned_to = $${paramCount}`;
      params.push(assignedTo);
    }
    
    if (search) {
      paramCount++;
      whereClause += ` AND (l.first_name ILIKE $${paramCount} OR l.last_name ILIKE $${paramCount} OR l.email ILIKE $${paramCount} OR l.company ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }
    
    const result = await pool.query(`
      SELECT l.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name,
             c.first_name || ' ' || c.last_name as converted_contact_name
      FROM leads l
      LEFT JOIN users u_assigned ON l.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON l.created_by = u_created.id
      LEFT JOIN contacts c ON l.converted_to_contact_id = c.id
      ${whereClause}
      ORDER BY l.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `, [...params, limit, offset]);
    
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch leads error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/crm/leads', authMiddleware, async (req, res) => {
  try {
    const { 
      firstName, lastName, email, phone, company, jobTitle, source, sourceDetails,
      budget, timeline, authority, needs, interestedServices, priority, address, 
      city, state, postalCode, country, website, notes, tags, assignedTo 
    } = req.body;
    
    const leadId = uuidv4();
    
    await pool.query(`
      INSERT INTO leads (
        id, first_name, last_name, email, phone, company, job_title, 
        source, source_details, budget, timeline, authority, needs,
        interested_services, priority, address, city, state, postal_code, 
        country, website, notes, tags, assigned_to, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26)
    `, [
      leadId, firstName, lastName, email, phone, company, jobTitle,
      source || 'website', sourceDetails, budget, timeline, authority, needs,
      interestedServices || [], priority || 'medium', address, city, state, 
      postalCode, country || 'SA', website, notes, tags || [], assignedTo,
      req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT l.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM leads l
      LEFT JOIN users u_assigned ON l.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON l.created_by = u_created.id
      WHERE l.id = $1
    `, [leadId]);
    
    const lead = result.rows[0];
    
    // Emit real-time notification
    io.to(`org-${req.orgId}`).emit('leadCreated', lead);
    
    res.status(201).json(lead);
    logger.info(`Lead created: ${firstName} ${lastName} (${email})`);
  } catch (error) {
    logger.error('Create lead error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/crm/leads/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    // Build dynamic update query
    const setClause = Object.keys(updates).map((key, index) => 
      `${key} = $${index + 2}`
    ).join(', ');
    
    await pool.query(`
      UPDATE leads SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
      WHERE id = $1 AND org_id = $${Object.keys(updates).length + 2}
    `, [id, ...Object.values(updates), req.orgId]);
    
    const result = await pool.query(`
      SELECT l.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM leads l
      LEFT JOIN users u_assigned ON l.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON l.created_by = u_created.id
      WHERE l.id = $1
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    const lead = result.rows[0];
    io.to(`org-${req.orgId}`).emit('leadUpdated', lead);
    
    res.json(lead);
    logger.info(`Lead updated: ${id}`);
  } catch (error) {
    logger.error('Update lead error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/crm/leads/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query(
      'DELETE FROM leads WHERE id = $1 AND org_id = $2 RETURNING *', 
      [id, req.orgId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    io.to(`org-${req.orgId}`).emit('leadDeleted', { id });
    res.json({ message: 'Lead deleted successfully' });
    logger.info(`Lead deleted: ${id}`);
  } catch (error) {
    logger.error('Delete lead error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Convert Lead to Contact
app.post('/api/crm/leads/:id/convert', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { customerSince, type = 'customer' } = req.body;
    
    // Get lead data
    const leadResult = await pool.query('SELECT * FROM leads WHERE id = $1 AND org_id = $2', [id, req.orgId]);
    if (leadResult.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }
    
    const lead = leadResult.rows[0];
    const contactId = uuidv4();
    
    // Create contact from lead
    await pool.query(`
      INSERT INTO contacts (
        id, first_name, last_name, email, phone, company, job_title,
        type, source, address, city, state, postal_code, country, 
        website, notes, tags, customer_since, assigned_to, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
    `, [
      contactId, lead.first_name, lead.last_name, lead.email, lead.phone,
      lead.company, lead.job_title, type, lead.source, lead.address, lead.city,
      lead.state, lead.postal_code, lead.country, lead.website, lead.notes,
      lead.tags, customerSince || new Date(), lead.assigned_to, req.orgId, req.user.id
    ]);
    
    // Update lead with conversion info
    await pool.query(`
      UPDATE leads SET 
        status = 'converted', 
        converted_to_contact_id = $1, 
        converted_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
    `, [contactId, id]);
    
    const contactResult = await pool.query(`
      SELECT c.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name
      FROM contacts c
      LEFT JOIN users u_assigned ON c.assigned_to = u_assigned.id
      WHERE c.id = $1
    `, [contactId]);
    
    const contact = contactResult.rows[0];
    
    io.to(`org-${req.orgId}`).emit('leadConverted', { leadId: id, contact });
    
    res.status(201).json(contact);
    logger.info(`Lead converted to contact: ${id} -> ${contactId}`);
  } catch (error) {
    logger.error('Convert lead error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== CONTACTS MANAGEMENT ====================
app.get('/api/crm/contacts', authMiddleware, async (req, res) => {
  try {
    const { type, status, assignedTo, search, limit = 50, offset = 0 } = req.query;
    
    let whereClause = 'WHERE c.org_id = $1';
    let params = [req.orgId];
    let paramCount = 1;
    
    if (type) {
      paramCount++;
      whereClause += ` AND c.type = $${paramCount}`;
      params.push(type);
    }
    
    if (status) {
      paramCount++;
      whereClause += ` AND c.status = $${paramCount}`;
      params.push(status);
    }
    
    if (assignedTo) {
      paramCount++;
      whereClause += ` AND c.assigned_to = $${paramCount}`;
      params.push(assignedTo);
    }
    
    if (search) {
      paramCount++;
      whereClause += ` AND (c.first_name ILIKE $${paramCount} OR c.last_name ILIKE $${paramCount} OR c.email ILIKE $${paramCount} OR c.company ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }
    
    const result = await pool.query(`
      SELECT c.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name,
             COUNT(d.id) as deals_count,
             SUM(CASE WHEN d.stage = 'closed_won' THEN d.value ELSE 0 END) as total_won_value
      FROM contacts c
      LEFT JOIN users u_assigned ON c.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON c.created_by = u_created.id
      LEFT JOIN deals d ON c.id = d.contact_id
      ${whereClause}
      GROUP BY c.id, u_assigned.first_name, u_assigned.last_name, u_created.first_name, u_created.last_name
      ORDER BY c.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `, [...params, limit, offset]);
    
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch contacts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/crm/contacts', authMiddleware, async (req, res) => {
  try {
    const { 
      firstName, lastName, email, phone, mobile, company, jobTitle, department,
      industry, companySize, type, address, city, state, postalCode, country,
      preferredContact, timezone, language, emailOptIn, smsOptIn, website,
      linkedinUrl, twitterHandle, annualRevenue, employeeCount, notes, tags, assignedTo
    } = req.body;
    
    const contactId = uuidv4();
    
    await pool.query(`
      INSERT INTO contacts (
        id, first_name, last_name, email, phone, mobile, company, job_title,
        department, industry, company_size, type, address, city, state, postal_code,
        country, preferred_contact, timezone, language, email_opt_in, sms_opt_in,
        website, linkedin_url, twitter_handle, annual_revenue, employee_count,
        notes, tags, assigned_to, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32)
    `, [
      contactId, firstName, lastName, email, phone, mobile, company, jobTitle,
      department, industry, companySize, type || 'prospect', address, city, state,
      postalCode, country || 'SA', preferredContact || 'email', timezone, 
      language || 'en', emailOptIn !== false, smsOptIn === true, website,
      linkedinUrl, twitterHandle, annualRevenue, employeeCount, notes, tags || [],
      assignedTo, req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT c.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM contacts c
      LEFT JOIN users u_assigned ON c.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON c.created_by = u_created.id
      WHERE c.id = $1
    `, [contactId]);
    
    const contact = result.rows[0];
    
    io.to(`org-${req.orgId}`).emit('contactCreated', contact);
    
    res.status(201).json(contact);
    logger.info(`Contact created: ${firstName} ${lastName} (${email})`);
  } catch (error) {
    logger.error('Create contact error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get contact details with interaction history
app.get('/api/crm/contacts/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const contactResult = await pool.query(`
      SELECT c.*, 
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM contacts c
      LEFT JOIN users u_assigned ON c.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON c.created_by = u_created.id
      WHERE c.id = $1 AND c.org_id = $2
    `, [id, req.orgId]);
    
    if (contactResult.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }
    
    // Get interaction history
    const interactionsResult = await pool.query(`
      SELECT i.*, u.first_name || ' ' || u.last_name as created_by_name
      FROM interactions i
      LEFT JOIN users u ON i.created_by = u.id
      WHERE i.contact_id = $1 AND i.org_id = $2
      ORDER BY i.created_at DESC
    `, [id, req.orgId]);
    
    // Get deals
    const dealsResult = await pool.query(`
      SELECT d.*, u.first_name || ' ' || u.last_name as assigned_to_name
      FROM deals d
      LEFT JOIN users u ON d.assigned_to = u.id
      WHERE d.contact_id = $1 AND d.org_id = $2
      ORDER BY d.created_at DESC
    `, [id, req.orgId]);
    
    // Get tasks
    const tasksResult = await pool.query(`
      SELECT t.*, u.first_name || ' ' || u.last_name as assigned_to_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      WHERE t.contact_id = $1 AND t.org_id = $2
      ORDER BY t.due_date ASC
    `, [id, req.orgId]);
    
    const contact = {
      ...contactResult.rows[0],
      interactions: interactionsResult.rows,
      deals: dealsResult.rows,
      tasks: tasksResult.rows
    };
    
    res.json(contact);
  } catch (error) {
    logger.error('Fetch contact details error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== DEALS MANAGEMENT ====================
app.get('/api/crm/deals', authMiddleware, async (req, res) => {
  try {
    const { stage, pipeline, assignedTo, search, limit = 50, offset = 0 } = req.query;
    
    let whereClause = 'WHERE d.org_id = $1';
    let params = [req.orgId];
    let paramCount = 1;
    
    if (stage) {
      paramCount++;
      whereClause += ` AND d.stage = $${paramCount}`;
      params.push(stage);
    }
    
    if (pipeline) {
      paramCount++;
      whereClause += ` AND d.pipeline = $${paramCount}`;
      params.push(pipeline);
    }
    
    if (assignedTo) {
      paramCount++;
      whereClause += ` AND d.assigned_to = $${paramCount}`;
      params.push(assignedTo);
    }
    
    if (search) {
      paramCount++;
      whereClause += ` AND (d.title ILIKE $${paramCount} OR c.first_name ILIKE $${paramCount} OR c.last_name ILIKE $${paramCount} OR c.company ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }
    
    const result = await pool.query(`
      SELECT d.*, 
             c.first_name || ' ' || c.last_name as contact_name,
             c.company as contact_company,
             c.email as contact_email,
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name,
             u_created.first_name || ' ' || u_created.last_name as created_by_name
      FROM deals d
      LEFT JOIN contacts c ON d.contact_id = c.id
      LEFT JOIN users u_assigned ON d.assigned_to = u_assigned.id
      LEFT JOIN users u_created ON d.created_by = u_created.id
      ${whereClause}
      ORDER BY d.expected_close_date ASC, d.value DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `, [...params, limit, offset]);
    
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch deals error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/crm/deals', authMiddleware, async (req, res) => {
  try {
    const { 
      title, description, contactId, value, currency, probability, stage, pipeline,
      priority, expectedCloseDate, source, dealType, services, products, 
      competitors, decisionMakers, buyingProcess, notes, tags, assignedTo, nextSteps
    } = req.body;
    
    const dealId = uuidv4();
    const expectedRevenue = (value * (probability || 50)) / 100;
    
    await pool.query(`
      INSERT INTO deals (
        id, title, description, contact_id, value, currency, probability,
        expected_revenue, stage, pipeline, priority, expected_close_date,
        source, deal_type, services, products, competitors, decision_makers,
        buying_process, notes, tags, assigned_to, next_steps, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25)
    `, [
      dealId, title, description, contactId, value, currency || 'SAR', probability || 50,
      expectedRevenue, stage || 'prospecting', pipeline || 'sales', priority || 'medium',
      expectedCloseDate, source, dealType || 'new_business', services || [], products || [],
      competitors || [], decisionMakers || [], buyingProcess, notes, tags || [],
      assignedTo, nextSteps, req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT d.*, 
             c.first_name || ' ' || c.last_name as contact_name,
             c.company as contact_company,
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name
      FROM deals d
      LEFT JOIN contacts c ON d.contact_id = c.id
      LEFT JOIN users u_assigned ON d.assigned_to = u_assigned.id
      WHERE d.id = $1
    `, [dealId]);
    
    const deal = result.rows[0];
    
    io.to(`org-${req.orgId}`).emit('dealCreated', deal);
    
    res.status(201).json(deal);
    logger.info(`Deal created: ${title} - ${value} ${currency}`);
  } catch (error) {
    logger.error('Create deal error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update deal stage (for pipeline drag & drop)
app.put('/api/crm/deals/:id/stage', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { stage, probability, lostReason, winReason } = req.body;
    
    // Calculate new expected revenue
    const dealResult = await pool.query('SELECT value FROM deals WHERE id = $1 AND org_id = $2', [id, req.orgId]);
    if (dealResult.rows.length === 0) {
      return res.status(404).json({ error: 'Deal not found' });
    }
    
    const value = dealResult.rows[0].value;
    const expectedRevenue = (value * (probability || 50)) / 100;
    
    let updateQuery = `
      UPDATE deals SET 
        stage = $1, 
        probability = $2, 
        expected_revenue = $3,
        updated_at = CURRENT_TIMESTAMP
    `;
    let params = [stage, probability || 50, expectedRevenue];
    let paramCount = 3;
    
    if (stage === 'closed_won') {
      paramCount++;
      updateQuery += `, actual_close_date = CURRENT_TIMESTAMP, win_reason = $${paramCount}`;
      params.push(winReason);
    } else if (stage === 'closed_lost') {
      paramCount++;
      updateQuery += `, actual_close_date = CURRENT_TIMESTAMP, lost_reason = $${paramCount}`;
      params.push(lostReason);
    }
    
    updateQuery += ` WHERE id = $${paramCount + 1} AND org_id = $${paramCount + 2}`;
    params.push(id, req.orgId);
    
    await pool.query(updateQuery, params);
    
    const result = await pool.query(`
      SELECT d.*, 
             c.first_name || ' ' || c.last_name as contact_name,
             c.company as contact_company,
             u_assigned.first_name || ' ' || u_assigned.last_name as assigned_to_name
      FROM deals d
      LEFT JOIN contacts c ON d.contact_id = c.id
      LEFT JOIN users u_assigned ON d.assigned_to = u_assigned.id
      WHERE d.id = $1
    `, [id]);
    
    const deal = result.rows[0];
    
    io.to(`org-${req.orgId}`).emit('dealStageUpdated', deal);
    
    res.json(deal);
    logger.info(`Deal stage updated: ${id} -> ${stage}`);
  } catch (error) {
    logger.error('Update deal stage error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== CRM ANALYTICS & DASHBOARD ====================
app.get('/api/crm/analytics', authMiddleware, async (req, res) => {
  try {
    const { period = 'monthly' } = req.query;
    
    const analytics = await pool.query(`
      WITH lead_stats AS (
        SELECT 
          COUNT(*) as total_leads,
          COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads,
          COUNT(CASE WHEN created_at >= DATE(NOW() - INTERVAL '30 days') THEN 1 END) as leads_this_month,
          AVG(qualification_score) as avg_qualification_score
        FROM leads WHERE org_id = $1
      ),
      contact_stats AS (
        SELECT 
          COUNT(*) as total_contacts,
          COUNT(CASE WHEN type = 'customer' THEN 1 END) as customers,
          COUNT(CASE WHEN created_at >= DATE(NOW() - INTERVAL '30 days') THEN 1 END) as contacts_this_month,
          AVG(engagement_score) as avg_engagement_score
        FROM contacts WHERE org_id = $1
      ),
      deal_stats AS (
        SELECT 
          COUNT(*) as total_deals,
          COUNT(CASE WHEN stage = 'closed_won' THEN 1 END) as won_deals,
          COUNT(CASE WHEN stage = 'closed_lost' THEN 1 END) as lost_deals,
          COUNT(CASE WHEN stage NOT IN ('closed_won', 'closed_lost') THEN 1 END) as active_deals,
          SUM(CASE WHEN stage = 'closed_won' THEN value ELSE 0 END) as total_revenue,
          SUM(CASE WHEN stage NOT IN ('closed_won', 'closed_lost') THEN expected_revenue ELSE 0 END) as pipeline_value,
          AVG(CASE WHEN stage = 'closed_won' THEN value END) as avg_deal_size,
          AVG(probability) as avg_probability
        FROM deals WHERE org_id = $1
      ),
      pipeline_breakdown AS (
        SELECT 
          stage,
          COUNT(*) as deals_count,
          SUM(value) as stage_value,
          SUM(expected_revenue) as stage_expected_revenue
        FROM deals 
        WHERE org_id = $1 AND stage NOT IN ('closed_won', 'closed_lost')
        GROUP BY stage
      ),
      monthly_trends AS (
        SELECT 
          TO_CHAR(created_at, 'YYYY-MM') as month,
          'leads' as type,
          COUNT(*) as count,
          0 as value
        FROM leads 
        WHERE org_id = $1 AND created_at >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(created_at, 'YYYY-MM')
        
        UNION ALL
        
        SELECT 
          TO_CHAR(actual_close_date, 'YYYY-MM') as month,
          'deals' as type,
          COUNT(*) as count,
          SUM(value) as value
        FROM deals 
        WHERE org_id = $1 AND stage = 'closed_won' AND actual_close_date >= DATE(NOW() - INTERVAL '12 months')
        GROUP BY TO_CHAR(actual_close_date, 'YYYY-MM')
      ),
      source_performance AS (
        SELECT 
          l.source,
          COUNT(l.id) as leads_count,
          COUNT(c.id) as conversions,
          CASE WHEN COUNT(l.id) > 0 THEN (COUNT(c.id)::float / COUNT(l.id)) * 100 ELSE 0 END as conversion_rate
        FROM leads l
        LEFT JOIN contacts c ON l.converted_to_contact_id = c.id
        WHERE l.org_id = $1
        GROUP BY l.source
      )
      SELECT 
        json_build_object(
          'leadStats', json_agg(DISTINCT ls.*),
          'contactStats', json_agg(DISTINCT cs.*),
          'dealStats', json_agg(DISTINCT ds.*),
          'pipelineBreakdown', json_agg(DISTINCT pb.*),
          'monthlyTrends', json_agg(DISTINCT mt.*),
          'sourcePerformance', json_agg(DISTINCT sp.*),
          'summary', json_build_object(
            'totalLeads', (SELECT total_leads FROM lead_stats),
            'conversionRate', CASE WHEN (SELECT total_leads FROM lead_stats) > 0 
              THEN ((SELECT converted_leads FROM lead_stats)::float / (SELECT total_leads FROM lead_stats)) * 100 
              ELSE 0 END,
            'totalRevenue', (SELECT total_revenue FROM deal_stats),
            'pipelineValue', (SELECT pipeline_value FROM deal_stats),
            'winRate', CASE WHEN ((SELECT won_deals FROM deal_stats) + (SELECT lost_deals FROM deal_stats)) > 0 
              THEN ((SELECT won_deals FROM deal_stats)::float / ((SELECT won_deals FROM deal_stats) + (SELECT lost_deals FROM deal_stats))) * 100 
              ELSE 0 END
          )
        ) as analytics_data
      FROM lead_stats ls
      CROSS JOIN contact_stats cs
      CROSS JOIN deal_stats ds
      LEFT JOIN pipeline_breakdown pb ON true
      LEFT JOIN monthly_trends mt ON true
      LEFT JOIN source_performance sp ON true
    `, [req.orgId]);
    
    res.json(analytics.rows[0]?.analytics_data || {});
  } catch (error) {
    logger.error('CRM analytics error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== SUPPORT SYSTEM ====================
app.get('/api/support/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      WITH ticket_stats AS (
        SELECT 
          COUNT(*) as total_tickets,
          COUNT(CASE WHEN status = 'open' THEN 1 END) as open_tickets,
          COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_tickets,
          AVG(CASE WHEN resolved_date IS NOT NULL AND submitted_date IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (resolved_date - submitted_date)) / 3600 / 24 ELSE NULL END) as avg_resolution_time,
          AVG(customer_satisfaction) as avg_satisfaction
        FROM support_tickets 
        WHERE org_id = $1
      ),
      ticket_by_type AS (
        SELECT type, COUNT(*) as count 
        FROM support_tickets 
        WHERE org_id = $1 
        GROUP BY type
      ),
      ticket_by_priority AS (
        SELECT priority, COUNT(*) as count 
        FROM support_tickets 
        WHERE org_id = $1 
        GROUP BY priority
      ),
      monthly_trend AS (
        SELECT 
          TO_CHAR(submitted_date, 'Mon') as month,
          COUNT(*) as tickets,
          COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved
        FROM support_tickets 
        WHERE org_id = $1 AND submitted_date >= NOW() - INTERVAL '6 months'
        GROUP BY DATE_TRUNC('month', submitted_date), TO_CHAR(submitted_date, 'Mon')
        ORDER BY DATE_TRUNC('month', submitted_date)
      )
      SELECT 
        json_build_object(
          'totalTickets', ts.total_tickets,
          'openTickets', ts.open_tickets,
          'resolvedTickets', ts.resolved_tickets,
          'avgResolutionTime', COALESCE(ts.avg_resolution_time, 0),
          'customerSatisfactionScore', COALESCE(ts.avg_satisfaction, 0),
          'ticketsByType', json_object_agg(tbt.type, tbt.count),
          'ticketsByPriority', json_object_agg(tbp.priority, tbp.count),
          'monthlyTrend', json_agg(mt.*)
        ) as stats
      FROM ticket_stats ts
      LEFT JOIN ticket_by_type tbt ON true
      LEFT JOIN ticket_by_priority tbp ON true  
      LEFT JOIN monthly_trend mt ON true
      GROUP BY ts.total_tickets, ts.open_tickets, ts.resolved_tickets, ts.avg_resolution_time, ts.avg_satisfaction
    `, [req.orgId]);
    
    res.json(stats.rows[0]?.stats || {});
  } catch (error) {
    logger.error('Support stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/support/tickets', authMiddleware, async (req, res) => {
  try {
    const { status, type, priority, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        st.*,
        u_submitter.first_name || ' ' || u_submitter.last_name as submitter_name,
        u_assignee.first_name || ' ' || u_assignee.last_name as assignee_name,
        (SELECT COUNT(*) FROM ticket_comments WHERE ticket_id = st.id) as comment_count
      FROM support_tickets st
      LEFT JOIN users u_submitter ON st.submitted_by = u_submitter.id
      LEFT JOIN users u_assignee ON st.assigned_to = u_assignee.id
      WHERE st.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND st.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (type) {
      paramCount++;
      query += ` AND st.type = $${paramCount}`;
      queryParams.push(type);
    }
    
    if (priority) {
      paramCount++;
      query += ` AND st.priority = $${paramCount}`;
      queryParams.push(priority);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (st.subject ILIKE $${paramCount} OR st.description ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    query += ` ORDER BY st.submitted_date DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch support tickets error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/support/tickets', authMiddleware, async (req, res) => {
  try {
    const { subject, description, type, priority, assignedTo } = req.body;
    const ticketNumber = `TKT-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const ticketId = uuidv4();
    
    await pool.query(`
      INSERT INTO support_tickets (
        id, ticket_number, subject, description, type, priority, 
        submitted_by, assigned_to, org_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [
      ticketId, ticketNumber, subject, description, type || 'general',
      priority || 'medium', req.user.id, assignedTo, req.orgId
    ]);
    
    const result = await pool.query(`
      SELECT 
        st.*,
        u_submitter.first_name || ' ' || u_submitter.last_name as submitter_name,
        u_assignee.first_name || ' ' || u_assignee.last_name as assignee_name
      FROM support_tickets st
      LEFT JOIN users u_submitter ON st.submitted_by = u_submitter.id
      LEFT JOIN users u_assignee ON st.assigned_to = u_assignee.id
      WHERE st.id = $1
    `, [ticketId]);
    
    const ticket = result.rows[0];
    
    // Emit real-time notification
    io.to(`org-${req.orgId}`).emit('ticketCreated', ticket);
    
    res.status(201).json(ticket);
    logger.info(`Support ticket created: ${ticketNumber}`);
  } catch (error) {
    logger.error('Create support ticket error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/support/tickets/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query(`
      SELECT 
        st.*,
        u_submitter.first_name || ' ' || u_submitter.last_name as submitter_name,
        u_submitter.email as submitter_email,
        u_assignee.first_name || ' ' || u_assignee.last_name as assignee_name,
        u_assignee.email as assignee_email
      FROM support_tickets st
      LEFT JOIN users u_submitter ON st.submitted_by = u_submitter.id
      LEFT JOIN users u_assignee ON st.assigned_to = u_assignee.id
      WHERE st.id = $1 AND st.org_id = $2
    `, [id, req.orgId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    // Get comments
    const comments = await pool.query(`
      SELECT 
        tc.*,
        u.first_name || ' ' || u.last_name as user_name,
        u.email as user_email
      FROM ticket_comments tc
      LEFT JOIN users u ON tc.user_id = u.id
      WHERE tc.ticket_id = $1
      ORDER BY tc.created_at ASC
    `, [id]);
    
    const ticket = result.rows[0];
    ticket.comments = comments.rows;
    
    res.json(ticket);
  } catch (error) {
    logger.error('Fetch support ticket error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/support/tickets/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, assignedTo, resolution, customerSatisfaction } = req.body;
    
    const updateFields = [];
    const queryParams = [id, req.orgId];
    let paramCount = 2;
    
    if (status) {
      paramCount++;
      updateFields.push(`status = $${paramCount}`);
      queryParams.push(status);
      
      if (status === 'resolved') {
        paramCount++;
        updateFields.push(`resolved_date = $${paramCount}`);
        queryParams.push(new Date());
      }
    }
    
    if (assignedTo !== undefined) {
      paramCount++;
      updateFields.push(`assigned_to = $${paramCount}`);
      queryParams.push(assignedTo);
    }
    
    if (resolution) {
      paramCount++;
      updateFields.push(`resolution = $${paramCount}`);
      queryParams.push(resolution);
    }
    
    if (customerSatisfaction) {
      paramCount++;
      updateFields.push(`customer_satisfaction = $${paramCount}`);
      queryParams.push(customerSatisfaction);
    }
    
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    
    await pool.query(`
      UPDATE support_tickets 
      SET ${updateFields.join(', ')}
      WHERE id = $1 AND org_id = $2
    `, queryParams);
    
    const result = await pool.query(`
      SELECT st.*, 
             u_submitter.first_name || ' ' || u_submitter.last_name as submitter_name,
             u_assignee.first_name || ' ' || u_assignee.last_name as assignee_name
      FROM support_tickets st
      LEFT JOIN users u_submitter ON st.submitted_by = u_submitter.id
      LEFT JOIN users u_assignee ON st.assigned_to = u_assignee.id
      WHERE st.id = $1 AND st.org_id = $2
    `, [id, req.orgId]);
    
    res.json(result.rows[0]);
    logger.info(`Support ticket updated: ${id}`);
  } catch (error) {
    logger.error('Update support ticket error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/support/tickets/:id/comments', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { content, isInternal } = req.body;
    const commentId = uuidv4();
    
    await pool.query(`
      INSERT INTO ticket_comments (id, ticket_id, user_id, content, is_internal)
      VALUES ($1, $2, $3, $4, $5)
    `, [commentId, id, req.user.id, content, isInternal || false]);
    
    const result = await pool.query(`
      SELECT 
        tc.*,
        u.first_name || ' ' || u.last_name as user_name,
        u.email as user_email
      FROM ticket_comments tc
      LEFT JOIN users u ON tc.user_id = u.id
      WHERE tc.id = $1
    `, [commentId]);
    
    const comment = result.rows[0];
    
    // Emit real-time notification
    io.to(`org-${req.orgId}`).emit('ticketCommentAdded', { ticketId: id, comment });
    
    res.status(201).json(comment);
    logger.info(`Comment added to ticket: ${id}`);
  } catch (error) {
    logger.error('Add ticket comment error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/support/knowledge-base', authMiddleware, async (req, res) => {
  try {
    const { category, search, published, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        kb.*,
        u.first_name || ' ' || u.last_name as author_name
      FROM knowledge_base_articles kb
      LEFT JOIN users u ON kb.author = u.id
      WHERE kb.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (category) {
      paramCount++;
      query += ` AND kb.category = $${paramCount}`;
      queryParams.push(category);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (kb.title ILIKE $${paramCount} OR kb.content ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    if (published !== undefined) {
      paramCount++;
      query += ` AND kb.is_published = $${paramCount}`;
      queryParams.push(published === 'true');
    }
    
    query += ` ORDER BY kb.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch knowledge base error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/support/knowledge-base', authMiddleware, async (req, res) => {
  try {
    const { title, content, category, tags, isPublished } = req.body;
    const articleId = uuidv4();
    
    await pool.query(`
      INSERT INTO knowledge_base_articles (
        id, title, content, category, tags, author, is_published, org_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [articleId, title, content, category, tags || [], req.user.id, isPublished || false, req.orgId]);
    
    const result = await pool.query(`
      SELECT 
        kb.*,
        u.first_name || ' ' || u.last_name as author_name
      FROM knowledge_base_articles kb
      LEFT JOIN users u ON kb.author = u.id
      WHERE kb.id = $1
    `, [articleId]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Knowledge base article created: ${title}`);
  } catch (error) {
    logger.error('Create knowledge base article error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== COMPLIANCE MANAGEMENT ====================
app.get('/api/compliance/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      WITH compliance_stats AS (
        SELECT 
          COUNT(*) as total_items,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_items,
          COUNT(CASE WHEN expiry_date < CURRENT_DATE THEN 1 END) as expired_items,
          COUNT(CASE WHEN expiry_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days' THEN 1 END) as expiring_soon,
          AVG(cost) as avg_cost
        FROM compliance_items 
        WHERE org_id = $1
      ),
      inspection_stats AS (
        SELECT 
          COUNT(*) as total_inspections,
          COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_inspections,
          COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as scheduled_inspections,
          AVG(overall_score) as avg_score,
          SUM(cost) as total_inspection_cost
        FROM inspections 
        WHERE org_id = $1
      ),
      monthly_compliance AS (
        SELECT 
          TO_CHAR(created_at, 'Mon') as month,
          COUNT(*) as items_added,
          SUM(cost) as monthly_cost
        FROM compliance_items 
        WHERE org_id = $1 AND created_at >= NOW() - INTERVAL '6 months'
        GROUP BY DATE_TRUNC('month', created_at), TO_CHAR(created_at, 'Mon')
        ORDER BY DATE_TRUNC('month', created_at)
      )
      SELECT 
        json_build_object(
          'totalItems', cs.total_items,
          'activeItems', cs.active_items,
          'expiredItems', cs.expired_items,
          'expiringSoon', cs.expiring_soon,
          'avgCost', COALESCE(cs.avg_cost, 0),
          'totalInspections', ist.total_inspections,
          'completedInspections', ist.completed_inspections,
          'scheduledInspections', ist.scheduled_inspections,
          'avgInspectionScore', COALESCE(ist.avg_score, 0),
          'totalInspectionCost', COALESCE(ist.total_inspection_cost, 0),
          'monthlyTrend', json_agg(mc.*)
        ) as stats
      FROM compliance_stats cs
      CROSS JOIN inspection_stats ist
      LEFT JOIN monthly_compliance mc ON true
      GROUP BY cs.total_items, cs.active_items, cs.expired_items, cs.expiring_soon, cs.avg_cost,
               ist.total_inspections, ist.completed_inspections, ist.scheduled_inspections, ist.avg_score, ist.total_inspection_cost
    `, [req.orgId]);
    
    res.json(stats.rows[0]?.stats || {});
  } catch (error) {
    logger.error('Compliance stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/compliance/permits', authMiddleware, async (req, res) => {
  try {
    const { status, type, property, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        ci.*,
        p.name as property_name,
        p.address as property_address,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM compliance_items ci
      LEFT JOIN properties p ON ci.property_id = p.id
      LEFT JOIN users u_assigned ON ci.assigned_to = u_assigned.id
      LEFT JOIN users u_creator ON ci.created_by = u_creator.id
      WHERE ci.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND ci.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (type) {
      paramCount++;
      query += ` AND ci.type = $${paramCount}`;
      queryParams.push(type);
    }
    
    if (property) {
      paramCount++;
      query += ` AND ci.property_id = $${paramCount}`;
      queryParams.push(property);
    }
    
    query += ` ORDER BY ci.expiry_date ASC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch permits error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/compliance/permits', authMiddleware, async (req, res) => {
  try {
    const { 
      title, type, description, issuer, issueDate, expiryDate, 
      renewalDate, documentUrl, cost, notes, propertyId, assignedTo 
    } = req.body;
    const permitId = uuidv4();
    
    await pool.query(`
      INSERT INTO compliance_items (
        id, title, type, description, issuer, issue_date, expiry_date,
        renewal_date, document_url, cost, notes, property_id, assigned_to,
        org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
    `, [
      permitId, title, type, description, issuer, issueDate, expiryDate,
      renewalDate, documentUrl, cost, notes, propertyId, assignedTo,
      req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT 
        ci.*,
        p.name as property_name,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM compliance_items ci
      LEFT JOIN properties p ON ci.property_id = p.id
      LEFT JOIN users u_assigned ON ci.assigned_to = u_assigned.id
      LEFT JOIN users u_creator ON ci.created_by = u_creator.id
      WHERE ci.id = $1
    `, [permitId]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Compliance permit created: ${title}`);
  } catch (error) {
    logger.error('Create permit error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/compliance/inspections', authMiddleware, async (req, res) => {
  try {
    const { status, type, property, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        i.*,
        p.name as property_name,
        p.address as property_address,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM inspections i
      LEFT JOIN properties p ON i.property_id = p.id
      LEFT JOIN users u_creator ON i.created_by = u_creator.id
      WHERE i.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND i.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (type) {
      paramCount++;
      query += ` AND i.type = $${paramCount}`;
      queryParams.push(type);
    }
    
    if (property) {
      paramCount++;
      query += ` AND i.property_id = $${paramCount}`;
      queryParams.push(property);
    }
    
    query += ` ORDER BY i.scheduled_date DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch inspections error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/compliance/inspections', authMiddleware, async (req, res) => {
  try {
    const { 
      title, type, propertyId, inspectorName, inspectorLicense, 
      scheduledDate, cost, nextInspectionDate 
    } = req.body;
    const inspectionId = uuidv4();
    
    await pool.query(`
      INSERT INTO inspections (
        id, title, type, property_id, inspector_name, inspector_license,
        scheduled_date, cost, next_inspection_date, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    `, [
      inspectionId, title, type, propertyId, inspectorName, inspectorLicense,
      scheduledDate, cost, nextInspectionDate, req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT 
        i.*,
        p.name as property_name,
        p.address as property_address,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM inspections i
      LEFT JOIN properties p ON i.property_id = p.id
      LEFT JOIN users u_creator ON i.created_by = u_creator.id
      WHERE i.id = $1
    `, [inspectionId]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Inspection scheduled: ${title}`);
  } catch (error) {
    logger.error('Create inspection error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/compliance/inspections/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, completedDate, overallScore, certificateUrl } = req.body;
    
    const updateFields = [];
    const queryParams = [id, req.orgId];
    let paramCount = 2;
    
    if (status) {
      paramCount++;
      updateFields.push(`status = $${paramCount}`);
      queryParams.push(status);
    }
    
    if (completedDate) {
      paramCount++;
      updateFields.push(`completed_date = $${paramCount}`);
      queryParams.push(completedDate);
    }
    
    if (overallScore) {
      paramCount++;
      updateFields.push(`overall_score = $${paramCount}`);
      queryParams.push(overallScore);
    }
    
    if (certificateUrl) {
      paramCount++;
      updateFields.push(`certificate_url = $${paramCount}`);
      queryParams.push(certificateUrl);
    }
    
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    
    await pool.query(`
      UPDATE inspections 
      SET ${updateFields.join(', ')}
      WHERE id = $1 AND org_id = $2
    `, queryParams);
    
    const result = await pool.query(`
      SELECT 
        i.*,
        p.name as property_name,
        p.address as property_address
      FROM inspections i
      LEFT JOIN properties p ON i.property_id = p.id
      WHERE i.id = $1 AND i.org_id = $2
    `, [id, req.orgId]);
    
    res.json(result.rows[0]);
    logger.info(`Inspection updated: ${id}`);
  } catch (error) {
    logger.error('Update inspection error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== PREVENTIVE MAINTENANCE ====================
app.get('/api/preventive-maintenance/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      WITH task_stats AS (
        SELECT 
          COUNT(*) as total_tasks,
          COUNT(CASE WHEN is_active = true THEN 1 END) as active_tasks,
          COUNT(CASE WHEN next_due < CURRENT_DATE THEN 1 END) as overdue_tasks,
          COUNT(CASE WHEN next_due BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '7 days' THEN 1 END) as due_this_week,
          AVG(estimated_cost) as avg_cost
        FROM preventive_maintenance_tasks 
        WHERE org_id = $1
      ),
      schedule_stats AS (
        SELECT 
          COUNT(*) as total_schedules,
          COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_schedules,
          COUNT(CASE WHEN status = 'scheduled' THEN 1 END) as scheduled_count,
          SUM(total_cost) as total_maintenance_cost,
          AVG(EXTRACT(EPOCH FROM (actual_end_time - actual_start_time)) / 3600) as avg_completion_time
        FROM maintenance_schedules 
        WHERE org_id = $1 AND actual_end_time IS NOT NULL
      ),
      monthly_maintenance AS (
        SELECT 
          TO_CHAR(created_at, 'Mon') as month,
          COUNT(*) as tasks_created,
          SUM(estimated_cost) as monthly_cost
        FROM preventive_maintenance_tasks 
        WHERE org_id = $1 AND created_at >= NOW() - INTERVAL '6 months'
        GROUP BY DATE_TRUNC('month', created_at), TO_CHAR(created_at, 'Mon')
        ORDER BY DATE_TRUNC('month', created_at)
      )
      SELECT 
        json_build_object(
          'totalTasks', ts.total_tasks,
          'activeTasks', ts.active_tasks,
          'overdueTasks', ts.overdue_tasks,
          'dueThisWeek', ts.due_this_week,
          'avgCost', COALESCE(ts.avg_cost, 0),
          'totalSchedules', ss.total_schedules,
          'completedSchedules', ss.completed_schedules,
          'scheduledCount', ss.scheduled_count,
          'totalMaintenanceCost', COALESCE(ss.total_maintenance_cost, 0),
          'avgCompletionTime', COALESCE(ss.avg_completion_time, 0),
          'monthlyTrend', json_agg(mm.*)
        ) as stats
      FROM task_stats ts
      CROSS JOIN schedule_stats ss
      LEFT JOIN monthly_maintenance mm ON true
      GROUP BY ts.total_tasks, ts.active_tasks, ts.overdue_tasks, ts.due_this_week, ts.avg_cost,
               ss.total_schedules, ss.completed_schedules, ss.scheduled_count, ss.total_maintenance_cost, ss.avg_completion_time
    `, [req.orgId]);
    
    res.json(stats.rows[0]?.stats || {});
  } catch (error) {
    logger.error('Preventive maintenance stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/preventive-maintenance/tasks', authMiddleware, async (req, res) => {
  try {
    const { status, category, property, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        pmt.*,
        p.name as property_name,
        p.address as property_address,
        u.name as unit_name,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM preventive_maintenance_tasks pmt
      LEFT JOIN properties p ON pmt.property_id = p.id
      LEFT JOIN units u ON pmt.unit_id = u.id
      LEFT JOIN users u_assigned ON pmt.assigned_to = u_assigned.id
      LEFT JOIN users u_creator ON pmt.created_by = u_creator.id
      WHERE pmt.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status === 'active') {
      paramCount++;
      query += ` AND pmt.is_active = $${paramCount}`;
      queryParams.push(true);
    } else if (status === 'inactive') {
      paramCount++;
      query += ` AND pmt.is_active = $${paramCount}`;
      queryParams.push(false);
    }
    
    if (category) {
      paramCount++;
      query += ` AND pmt.category = $${paramCount}`;
      queryParams.push(category);
    }
    
    if (property) {
      paramCount++;
      query += ` AND pmt.property_id = $${paramCount}`;
      queryParams.push(property);
    }
    
    query += ` ORDER BY pmt.next_due ASC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch maintenance tasks error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/preventive-maintenance/tasks', authMiddleware, async (req, res) => {
  try {
    const { 
      title, description, category, priority, frequency, duration, 
      estimatedCost, propertyId, unitId, assetId, assignedTo, 
      instructions, safetyNotes, requiredTools, nextDue 
    } = req.body;
    const taskId = uuidv4();
    
    await pool.query(`
      INSERT INTO preventive_maintenance_tasks (
        id, title, description, category, priority, frequency, duration,
        estimated_cost, property_id, unit_id, asset_id, assigned_to,
        instructions, safety_notes, required_tools, next_due, org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
    `, [
      taskId, title, description, category, priority || 'medium', 
      JSON.stringify(frequency), duration, estimatedCost, propertyId, unitId, 
      assetId, assignedTo, instructions, safetyNotes, requiredTools || [], 
      nextDue, req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT 
        pmt.*,
        p.name as property_name,
        u.name as unit_name,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM preventive_maintenance_tasks pmt
      LEFT JOIN properties p ON pmt.property_id = p.id
      LEFT JOIN units u ON pmt.unit_id = u.id
      LEFT JOIN users u_assigned ON pmt.assigned_to = u_assigned.id
      LEFT JOIN users u_creator ON pmt.created_by = u_creator.id
      WHERE pmt.id = $1
    `, [taskId]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Preventive maintenance task created: ${title}`);
  } catch (error) {
    logger.error('Create maintenance task error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/preventive-maintenance/schedules', authMiddleware, async (req, res) => {
  try {
    const { status, assignedTo, date, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        ms.*,
        pmt.title as task_title,
        pmt.description as task_description,
        pmt.category as task_category,
        p.name as property_name,
        p.address as property_address,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name,
        u_creator.first_name || ' ' || u_creator.last_name as creator_name
      FROM maintenance_schedules ms
      LEFT JOIN preventive_maintenance_tasks pmt ON ms.task_id = pmt.id
      LEFT JOIN properties p ON ms.property_id = p.id
      LEFT JOIN users u_assigned ON ms.assigned_to = u_assigned.id
      LEFT JOIN users u_creator ON ms.created_by = u_creator.id
      WHERE ms.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND ms.status = $${paramCount}`;
      queryParams.push(status);
    }
    
    if (assignedTo) {
      paramCount++;
      query += ` AND ms.assigned_to = $${paramCount}`;
      queryParams.push(assignedTo);
    }
    
    if (date) {
      paramCount++;
      query += ` AND ms.scheduled_date = $${paramCount}`;
      queryParams.push(date);
    }
    
    query += ` ORDER BY ms.scheduled_date ASC, ms.scheduled_time ASC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch maintenance schedules error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/preventive-maintenance/schedules', authMiddleware, async (req, res) => {
  try {
    const { 
      taskId, propertyId, assignedTo, scheduledDate, scheduledTime 
    } = req.body;
    const scheduleId = uuidv4();
    
    await pool.query(`
      INSERT INTO maintenance_schedules (
        id, task_id, property_id, assigned_to, scheduled_date, scheduled_time,
        org_id, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `, [
      scheduleId, taskId, propertyId, assignedTo, scheduledDate, 
      scheduledTime, req.orgId, req.user.id
    ]);
    
    const result = await pool.query(`
      SELECT 
        ms.*,
        pmt.title as task_title,
        pmt.description as task_description,
        pmt.category as task_category,
        p.name as property_name,
        u_assigned.first_name || ' ' || u_assigned.last_name as assigned_name
      FROM maintenance_schedules ms
      LEFT JOIN preventive_maintenance_tasks pmt ON ms.task_id = pmt.id
      LEFT JOIN properties p ON ms.property_id = p.id
      LEFT JOIN users u_assigned ON ms.assigned_to = u_assigned.id
      WHERE ms.id = $1
    `, [scheduleId]);
    
    res.status(201).json(result.rows[0]);
    logger.info(`Maintenance schedule created for task: ${taskId}`);
  } catch (error) {
    logger.error('Create maintenance schedule error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/preventive-maintenance/schedules/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { 
      status, actualStartTime, actualEndTime, completionNotes, 
      totalCost, photos, signature 
    } = req.body;
    
    const updateFields = [];
    const queryParams = [id, req.orgId];
    let paramCount = 2;
    
    if (status) {
      paramCount++;
      updateFields.push(`status = $${paramCount}`);
      queryParams.push(status);
    }
    
    if (actualStartTime) {
      paramCount++;
      updateFields.push(`actual_start_time = $${paramCount}`);
      queryParams.push(actualStartTime);
    }
    
    if (actualEndTime) {
      paramCount++;
      updateFields.push(`actual_end_time = $${paramCount}`);
      queryParams.push(actualEndTime);
    }
    
    if (completionNotes) {
      paramCount++;
      updateFields.push(`completion_notes = $${paramCount}`);
      queryParams.push(completionNotes);
    }
    
    if (totalCost) {
      paramCount++;
      updateFields.push(`total_cost = $${paramCount}`);
      queryParams.push(totalCost);
    }
    
    if (photos) {
      paramCount++;
      updateFields.push(`photos = $${paramCount}`);
      queryParams.push(photos);
    }
    
    if (signature) {
      paramCount++;
      updateFields.push(`signature = $${paramCount}`);
      queryParams.push(signature);
    }
    
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    
    await pool.query(`
      UPDATE maintenance_schedules 
      SET ${updateFields.join(', ')}
      WHERE id = $1 AND org_id = $2
    `, queryParams);
    
    // If completed, update the parent task's last_completed and calculate next_due
    if (status === 'completed') {
      await pool.query(`
        UPDATE preventive_maintenance_tasks 
        SET last_completed = CURRENT_TIMESTAMP,
            next_due = CASE 
              WHEN (frequency->>'type')::text = 'weekly' THEN CURRENT_DATE + INTERVAL '1 week' * (frequency->>'interval')::int
              WHEN (frequency->>'type')::text = 'monthly' THEN CURRENT_DATE + INTERVAL '1 month' * (frequency->>'interval')::int
              WHEN (frequency->>'type')::text = 'quarterly' THEN CURRENT_DATE + INTERVAL '3 months' * (frequency->>'interval')::int
              WHEN (frequency->>'type')::text = 'yearly' THEN CURRENT_DATE + INTERVAL '1 year' * (frequency->>'interval')::int
              ELSE CURRENT_DATE + INTERVAL '30 days'
            END
        WHERE id = (SELECT task_id FROM maintenance_schedules WHERE id = $1)
      `, [id]);
    }
    
    const result = await pool.query(`
      SELECT 
        ms.*,
        pmt.title as task_title,
        p.name as property_name
      FROM maintenance_schedules ms
      LEFT JOIN preventive_maintenance_tasks pmt ON ms.task_id = pmt.id
      LEFT JOIN properties p ON ms.property_id = p.id
      WHERE ms.id = $1 AND ms.org_id = $2
    `, [id, req.orgId]);
    
    res.json(result.rows[0]);
    logger.info(`Maintenance schedule updated: ${id}`);
  } catch (error) {
    logger.error('Update maintenance schedule error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== REPORTS & ANALYTICS ====================
app.get('/api/reports/financial', authMiddleware, async (req, res) => {
  try {
    const { period = '12months', propertyId } = req.query;
    
    const stats = await pool.query(`
      WITH financial_overview AS (
        SELECT 
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) as total_income,
          SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END) as total_expenses,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE -t.amount END) as net_income
        FROM transactions t
        WHERE t.org_id = $1 
        ${propertyId ? 'AND t.property_id = $2' : ''}
        AND t.date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
      ),
      monthly_trends AS (
        SELECT 
          DATE_TRUNC('month', t.date) as month,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) as income,
          SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END) as expenses,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE -t.amount END) as net
        FROM transactions t
        WHERE t.org_id = $1 
        ${propertyId ? 'AND t.property_id = $2' : ''}
        AND t.date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        GROUP BY DATE_TRUNC('month', t.date)
        ORDER BY month
      ),
      property_performance AS (
        SELECT 
          p.id,
          p.name,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) as property_income,
          SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END) as property_expenses,
          COUNT(wo.id) as maintenance_requests
        FROM properties p
        LEFT JOIN transactions t ON p.id = t.property_id AND t.date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        LEFT JOIN work_orders wo ON p.id = wo.property_id AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        WHERE p.org_id = $1
        ${propertyId ? 'AND p.id = $2' : ''}
        GROUP BY p.id, p.name
        ORDER BY property_income DESC
      )
      SELECT 
        json_build_object(
          'overview', json_agg(DISTINCT fo.*),
          'monthlyTrends', json_agg(DISTINCT mt.*),
          'propertyPerformance', json_agg(DISTINCT pp.*)
        ) as financial_data
      FROM financial_overview fo
      LEFT JOIN monthly_trends mt ON true
      LEFT JOIN property_performance pp ON true
    `, propertyId ? [req.orgId, propertyId] : [req.orgId]);
    
    res.json(stats.rows[0]?.financial_data || {});
  } catch (error) {
    logger.error('Financial reports error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/reports/property', authMiddleware, async (req, res) => {
  try {
    const { propertyId, period = '12months' } = req.query;
    
    const stats = await pool.query(`
      WITH property_metrics AS (
        SELECT 
          p.id,
          p.name,
          p.address,
          p.type,
          p.status,
          COUNT(DISTINCT u.id) as total_units,
          COUNT(DISTINCT l.id) as active_leases,
          AVG(l.monthly_rent) as avg_rent,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) as total_income,
          SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END) as total_expenses,
          COUNT(DISTINCT wo.id) as work_orders,
          COUNT(DISTINCT CASE WHEN wo.status = 'COMPLETED' THEN wo.id END) as completed_work_orders,
          AVG(CASE WHEN wo.status = 'COMPLETED' AND wo.completed_at IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (wo.completed_at - wo.created_at)) / 3600 / 24 END) as avg_completion_days
        FROM properties p
        LEFT JOIN units u ON p.id = u.property_id
        LEFT JOIN leases l ON u.id = l.unit_id AND l.status = 'ACTIVE'
        LEFT JOIN transactions t ON p.id = t.property_id AND t.date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        LEFT JOIN work_orders wo ON p.id = wo.property_id AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        WHERE p.org_id = $1
        ${propertyId ? 'AND p.id = $2' : ''}
        GROUP BY p.id, p.name, p.address, p.type, p.status
      ),
      occupancy_trends AS (
        SELECT 
          DATE_TRUNC('month', l.start_date) as month,
          COUNT(DISTINCT l.id) as new_leases,
          COUNT(DISTINCT CASE WHEN l.end_date IS NOT NULL AND l.end_date <= DATE_TRUNC('month', l.start_date) + INTERVAL '1 month' THEN l.id END) as ended_leases
        FROM leases l
        JOIN units u ON l.unit_id = u.id
        JOIN properties p ON u.property_id = p.id
        WHERE p.org_id = $1 
        ${propertyId ? 'AND p.id = $2' : ''}
        AND l.start_date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        GROUP BY DATE_TRUNC('month', l.start_date)
        ORDER BY month
      )
      SELECT 
        json_build_object(
          'propertyMetrics', json_agg(DISTINCT pm.*),
          'occupancyTrends', json_agg(DISTINCT ot.*)
        ) as property_data
      FROM property_metrics pm
      LEFT JOIN occupancy_trends ot ON true
    `, propertyId ? [req.orgId, propertyId] : [req.orgId]);
    
    res.json(stats.rows[0]?.property_data || {});
  } catch (error) {
    logger.error('Property reports error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/reports/maintenance', authMiddleware, async (req, res) => {
  try {
    const { period = '12months', propertyId } = req.query;
    
    const stats = await pool.query(`
      WITH maintenance_overview AS (
        SELECT 
          COUNT(*) as total_work_orders,
          COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) as completed_orders,
          COUNT(CASE WHEN status = 'PENDING' THEN 1 END) as pending_orders,
          COUNT(CASE WHEN priority = 'URGENT' THEN 1 END) as urgent_orders,
          AVG(CASE WHEN status = 'COMPLETED' AND completed_at IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (completed_at - created_at)) / 3600 / 24 END) as avg_completion_days,
          SUM(estimated_cost) as total_estimated_cost,
          SUM(actual_cost) as total_actual_cost
        FROM work_orders wo
        WHERE wo.org_id = $1 
        ${propertyId ? 'AND wo.property_id = $2' : ''}
        AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
      ),
      category_breakdown AS (
        SELECT 
          category,
          COUNT(*) as count,
          AVG(CASE WHEN status = 'COMPLETED' AND completed_at IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (completed_at - created_at)) / 3600 / 24 END) as avg_completion_days,
          SUM(actual_cost) as total_cost
        FROM work_orders wo
        WHERE wo.org_id = $1 
        ${propertyId ? 'AND wo.property_id = $2' : ''}
        AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        GROUP BY category
      ),
      monthly_maintenance AS (
        SELECT 
          DATE_TRUNC('month', created_at) as month,
          COUNT(*) as work_orders,
          COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) as completed,
          SUM(actual_cost) as total_cost
        FROM work_orders wo
        WHERE wo.org_id = $1 
        ${propertyId ? 'AND wo.property_id = $2' : ''}
        AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        GROUP BY DATE_TRUNC('month', created_at)
        ORDER BY month
      ),
      preventive_maintenance AS (
        SELECT 
          COUNT(*) as total_tasks,
          COUNT(CASE WHEN is_active = true THEN 1 END) as active_tasks,
          COUNT(CASE WHEN next_due < CURRENT_DATE THEN 1 END) as overdue_tasks,
          AVG(estimated_cost) as avg_task_cost
        FROM preventive_maintenance_tasks pmt
        WHERE pmt.org_id = $1
        ${propertyId ? 'AND pmt.property_id = $2' : ''}
      )
      SELECT 
        json_build_object(
          'overview', json_agg(DISTINCT mo.*),
          'categoryBreakdown', json_agg(DISTINCT cb.*),
          'monthlyTrends', json_agg(DISTINCT mm.*),
          'preventiveMaintenance', json_agg(DISTINCT pm.*)
        ) as maintenance_data
      FROM maintenance_overview mo
      LEFT JOIN category_breakdown cb ON true
      LEFT JOIN monthly_maintenance mm ON true
      LEFT JOIN preventive_maintenance pm ON true
    `, propertyId ? [req.orgId, propertyId] : [req.orgId]);
    
    res.json(stats.rows[0]?.maintenance_data || {});
  } catch (error) {
    logger.error('Maintenance reports error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/reports/analytics', authMiddleware, async (req, res) => {
  try {
    const { period = '12months' } = req.query;
    
    const stats = await pool.query(`
      WITH business_overview AS (
        SELECT 
          COUNT(DISTINCT p.id) as total_properties,
          COUNT(DISTINCT u.id) as total_units,
          COUNT(DISTINCT l.id) as active_leases,
          COUNT(DISTINCT t.id) as active_tenants,
          COUNT(DISTINCT wo.id) as total_work_orders,
          COUNT(DISTINCT st.id) as support_tickets,
          COUNT(DISTINCT ci.id) as compliance_items
        FROM properties p
        LEFT JOIN units u ON p.id = u.property_id
        LEFT JOIN leases l ON u.id = l.unit_id AND l.status = 'ACTIVE'
        LEFT JOIN tenants t ON l.tenant_id = t.id
        LEFT JOIN work_orders wo ON p.id = wo.property_id AND wo.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        LEFT JOIN support_tickets st ON st.org_id = p.org_id AND st.submitted_date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        LEFT JOIN compliance_items ci ON ci.org_id = p.org_id AND ci.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        WHERE p.org_id = $1
      ),
      financial_summary AS (
        SELECT 
          SUM(CASE WHEN type = 'INCOME' THEN amount ELSE 0 END) as total_revenue,
          SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END) as total_expenses,
          SUM(CASE WHEN type = 'INCOME' THEN amount ELSE -amount END) as net_profit,
          COUNT(DISTINCT property_id) as revenue_generating_properties
        FROM transactions
        WHERE org_id = $1 AND date >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
      ),
      performance_metrics AS (
        SELECT 
          AVG(CASE WHEN wo.status = 'COMPLETED' AND wo.completed_at IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (wo.completed_at - wo.created_at)) / 3600 / 24 END) as avg_work_order_completion,
          AVG(CASE WHEN st.status = 'resolved' AND st.resolved_date IS NOT NULL 
            THEN EXTRACT(EPOCH FROM (st.resolved_date - st.submitted_date)) / 3600 / 24 END) as avg_support_resolution,
          AVG(st.customer_satisfaction) as avg_customer_satisfaction,
          COUNT(CASE WHEN ci.expiry_date < CURRENT_DATE THEN 1 END)::float / NULLIF(COUNT(ci.id), 0) * 100 as compliance_risk_percentage
        FROM work_orders wo
        FULL OUTER JOIN support_tickets st ON wo.org_id = st.org_id
        FULL OUTER JOIN compliance_items ci ON wo.org_id = ci.org_id
        WHERE wo.org_id = $1 OR st.org_id = $1 OR ci.org_id = $1
      ),
      growth_trends AS (
        SELECT 
          DATE_TRUNC('month', p.created_at) as month,
          COUNT(DISTINCT p.id) as new_properties,
          COUNT(DISTINCT l.id) as new_leases,
          SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) as monthly_revenue
        FROM properties p
        LEFT JOIN units u ON p.id = u.property_id
        LEFT JOIN leases l ON u.id = l.unit_id AND DATE_TRUNC('month', l.start_date) = DATE_TRUNC('month', p.created_at)
        LEFT JOIN transactions t ON p.id = t.property_id AND DATE_TRUNC('month', t.date) = DATE_TRUNC('month', p.created_at)
        WHERE p.org_id = $1 AND p.created_at >= NOW() - INTERVAL '${period === '6months' ? '6' : '12'} months'
        GROUP BY DATE_TRUNC('month', p.created_at)
        ORDER BY month
      )
      SELECT 
        json_build_object(
          'businessOverview', json_agg(DISTINCT bo.*),
          'financialSummary', json_agg(DISTINCT fs.*),
          'performanceMetrics', json_agg(DISTINCT pm.*),
          'growthTrends', json_agg(DISTINCT gt.*)
        ) as analytics_data
      FROM business_overview bo
      CROSS JOIN financial_summary fs
      CROSS JOIN performance_metrics pm
      LEFT JOIN growth_trends gt ON true
    `, [req.orgId]);
    
    res.json(stats.rows[0]?.analytics_data || {});
  } catch (error) {
    logger.error('Business analytics error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== SYSTEM MANAGEMENT ====================
app.get('/api/system/users', authMiddleware, async (req, res) => {
  try {
    const { role, status, search, page = 1, limit = 20 } = req.query;
    
    let query = `
      SELECT 
        u.id, u.email, u.first_name, u.last_name, u.role, u.phone, 
        u.is_active, u.created_at, u.last_login, u.last_activity,
        o.name as organization_name
      FROM users u
      LEFT JOIN organizations o ON u.org_id = o.id
      WHERE u.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (role) {
      paramCount++;
      query += ` AND u.role = $${paramCount}`;
      queryParams.push(role);
    }
    
    if (status === 'active') {
      paramCount++;
      query += ` AND u.is_active = $${paramCount}`;
      queryParams.push(true);
    } else if (status === 'inactive') {
      paramCount++;
      query += ` AND u.is_active = $${paramCount}`;
      queryParams.push(false);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (u.first_name ILIKE $${paramCount} OR u.last_name ILIKE $${paramCount} OR u.email ILIKE $${paramCount})`;
      queryParams.push(`%${search}%`);
    }
    
    query += ` ORDER BY u.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (error) {
    logger.error('Fetch users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/system/users/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { role, isActive, firstName, lastName, phone } = req.body;
    
    const updateFields = [];
    const queryParams = [id, req.orgId];
    let paramCount = 2;
    
    if (role) {
      paramCount++;
      updateFields.push(`role = $${paramCount}`);
      queryParams.push(role);
    }
    
    if (isActive !== undefined) {
      paramCount++;
      updateFields.push(`is_active = $${paramCount}`);
      queryParams.push(isActive);
    }
    
    if (firstName) {
      paramCount++;
      updateFields.push(`first_name = $${paramCount}`);
      queryParams.push(firstName);
    }
    
    if (lastName) {
      paramCount++;
      updateFields.push(`last_name = $${paramCount}`);
      queryParams.push(lastName);
    }
    
    if (phone) {
      paramCount++;
      updateFields.push(`phone = $${paramCount}`);
      queryParams.push(phone);
    }
    
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    
    await pool.query(`
      UPDATE users 
      SET ${updateFields.join(', ')}
      WHERE id = $1 AND org_id = $2
    `, queryParams);
    
    const result = await pool.query(`
      SELECT 
        u.id, u.email, u.first_name, u.last_name, u.role, u.phone, 
        u.is_active, u.created_at, u.last_login,
        o.name as organization_name
      FROM users u
      LEFT JOIN organizations o ON u.org_id = o.id
      WHERE u.id = $1 AND u.org_id = $2
    `, [id, req.orgId]);
    
    res.json(result.rows[0]);
    logger.info(`User updated: ${id}`);
  } catch (error) {
    logger.error('Update user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/system/audit', authMiddleware, async (req, res) => {
  try {
    const { action, userId, startDate, endDate, page = 1, limit = 50 } = req.query;
    
    // Create audit log query - using work_orders and other existing tables for audit trail
    let query = `
      SELECT 
        'work_order' as entity_type,
        wo.id as entity_id,
        'created' as action,
        wo.created_by as user_id,
        u.first_name || ' ' || u.last_name as user_name,
        wo.created_at as timestamp,
        json_build_object('title', wo.title, 'priority', wo.priority, 'status', wo.status) as details
      FROM work_orders wo
      LEFT JOIN users u ON wo.created_by = u.id
      WHERE wo.org_id = $1
      
      UNION ALL
      
      SELECT 
        'support_ticket' as entity_type,
        st.id as entity_id,
        'created' as action,
        st.submitted_by as user_id,
        u.first_name || ' ' || u.last_name as user_name,
        st.submitted_date as timestamp,
        json_build_object('subject', st.subject, 'type', st.type, 'priority', st.priority) as details
      FROM support_tickets st
      LEFT JOIN users u ON st.submitted_by = u.id
      WHERE st.org_id = $1
      
      UNION ALL
      
      SELECT 
        'compliance_item' as entity_type,
        ci.id as entity_id,
        'created' as action,
        ci.created_by as user_id,
        u.first_name || ' ' || u.last_name as user_name,
        ci.created_at as timestamp,
        json_build_object('title', ci.title, 'type', ci.type, 'expiry_date', ci.expiry_date) as details
      FROM compliance_items ci
      LEFT JOIN users u ON ci.created_by = u.id
      WHERE ci.org_id = $1
    `;
    
    const queryParams = [req.orgId];
    let paramCount = 1;
    
    if (userId) {
      // This would require modifying the UNION queries, so we'll filter in application logic
    }
    
    if (startDate && endDate) {
      query = `
        SELECT * FROM (${query}) audit_log 
        WHERE timestamp BETWEEN $${paramCount + 1} AND $${paramCount + 2}
      `;
      queryParams.push(startDate, endDate);
      paramCount += 2;
    }
    
    query += ` ORDER BY timestamp DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryParams.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    
    const result = await pool.query(query, queryParams);
    
    // Filter by userId if specified (post-query filtering)
    let filteredRows = result.rows;
    if (userId) {
      filteredRows = result.rows.filter(row => row.user_id === userId);
    }
    
    res.json(filteredRows);
  } catch (error) {
    logger.error('Audit log error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/system/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await pool.query(`
      WITH system_overview AS (
        SELECT 
          COUNT(DISTINCT u.id) as total_users,
          COUNT(DISTINCT CASE WHEN u.is_active = true THEN u.id END) as active_users,
          COUNT(DISTINCT p.id) as total_properties,
          COUNT(DISTINCT wo.id) as total_work_orders,
          COUNT(DISTINCT st.id) as total_support_tickets,
          COUNT(DISTINCT ci.id) as total_compliance_items
        FROM users u
        FULL OUTER JOIN properties p ON u.org_id = p.org_id
        FULL OUTER JOIN work_orders wo ON u.org_id = wo.org_id
        FULL OUTER JOIN support_tickets st ON u.org_id = st.org_id
        FULL OUTER JOIN compliance_items ci ON u.org_id = ci.org_id
        WHERE u.org_id = $1 OR p.org_id = $1 OR wo.org_id = $1 OR st.org_id = $1 OR ci.org_id = $1
      ),
      activity_stats AS (
        SELECT 
          COUNT(CASE WHEN wo.created_at >= NOW() - INTERVAL '24 hours' THEN 1 END) as work_orders_today,
          COUNT(CASE WHEN st.submitted_date >= NOW() - INTERVAL '24 hours' THEN 1 END) as support_tickets_today,
          COUNT(CASE WHEN u.last_login >= NOW() - INTERVAL '24 hours' THEN 1 END) as active_users_today
        FROM work_orders wo
        FULL OUTER JOIN support_tickets st ON wo.org_id = st.org_id
        FULL OUTER JOIN users u ON wo.org_id = u.org_id
        WHERE wo.org_id = $1 OR st.org_id = $1 OR u.org_id = $1
      ),
      role_distribution AS (
        SELECT 
          role,
          COUNT(*) as count
        FROM users
        WHERE org_id = $1
        GROUP BY role
      )
      SELECT 
        json_build_object(
          'overview', json_agg(DISTINCT so.*),
          'activity', json_agg(DISTINCT as_.*),
          'roleDistribution', json_object_agg(rd.role, rd.count)
        ) as system_stats
      FROM system_overview so
      CROSS JOIN activity_stats as_
      LEFT JOIN role_distribution rd ON true
      GROUP BY so.total_users, so.active_users, so.total_properties, so.total_work_orders, 
               so.total_support_tickets, so.total_compliance_items,
               as_.work_orders_today, as_.support_tickets_today, as_.active_users_today
    `, [req.orgId]);
    
    res.json(stats.rows[0]?.system_stats || {});
  } catch (error) {
    logger.error('System stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ==================== HEALTH CHECK ====================
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    version: '2.0.26',
    database: 'PostgreSQL',
    modules: ['Dashboard', 'WorkOrders', 'Properties', 'Finance', 'HR', 'Marketplace', 'CRM', 'Support', 'Compliance', 'Admin', 'Reports', 'IoT', 'System', 'Souq', 'Aqar']
  });
});

// ==================== SOCKET.IO ====================
io.on('connection', (socket) => {
  console.log('Client connected');
  
  socket.on('join-org', (orgId) => {
    socket.join(`org-${orgId}`);
    console.log(`Client joined org-${orgId}`);
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`✅ FIXZIT SOUQ Backend running on port ${PORT}`);
  console.log(`🔗 Database: PostgreSQL`);
  console.log(`🔌 Socket.IO enabled`);
  logger.info(`Server started on port ${PORT}`);
});
