const mongoose = require('mongoose');

// Inventory Schema - Complete Implementation as per User's Specification
const InventorySchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant', required: true },
  sku: { type: String, unique: true },
  name: { type: String, required: true },
  category: String,
  description: String,
  unit: String,
  quantity: { type: Number, default: 0 },
  minQuantity: { type: Number, default: 0 },
  maxQuantity: Number,
  reorderPoint: Number,
  location: {
    warehouse: String,
    shelf: String,
    bin: String
  },
  supplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
  cost: Number,
  price: Number,
  images: [String],
  movements: [{
    type: { type: String, enum: ['in', 'out', 'adjustment'] },
    quantity: Number,
    reference: String,
    workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    notes: String,
    date: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Inventory', InventorySchema);