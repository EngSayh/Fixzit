const mongoose = require('mongoose');

const AssetSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, enum: ['equipment', 'vehicle', 'tool', 'other'], default: 'equipment' },
  category: String,
  serialNumber: String,
  purchaseDate: Date,
  purchasePrice: Number,
  currentValue: Number,
  condition: { type: String, enum: ['excellent', 'good', 'fair', 'poor'], default: 'good' },
  location: String,
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  maintenanceSchedule: String,
  lastMaintenance: Date,
  nextMaintenance: Date,
  warranty: {
    provider: String,
    expiryDate: Date,
    terms: String
  },
  documents: [{
    name: String,
    url: String,
    type: String,
    uploadedAt: { type: Date, default: Date.now }
  }],
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Add indexes for performance
AssetSchema.index({ organization: 1, isActive: 1 });
AssetSchema.index({ assignedTo: 1 });
AssetSchema.index({ type: 1, condition: 1 });
AssetSchema.index({ createdAt: -1 });
AssetSchema.index({ serialNumber: 1 });

module.exports = mongoose.model('Asset', AssetSchema);