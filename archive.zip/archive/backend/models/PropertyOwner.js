const mongoose = require('mongoose');

const PropertyOwnerSchema = new mongoose.Schema({
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  properties: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  }],
  deputy: {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    permissions: {
      canApproveWorkOrders: { type: Boolean, default: true },
      maxApprovalAmount: { type: Number, default: 5000 },
      canManageTenants: { type: Boolean, default: true },
      canViewFinancials: { type: Boolean, default: false }
    },
    appointedAt: Date,
    active: { type: Boolean, default: true }
  },
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  }
}, { timestamps: true });

// Instance method to check if user is deputy
PropertyOwnerSchema.methods.isDeputy = function(userId) {
  return this.deputy.user && 
         this.deputy.user.toString() === userId.toString() && 
         this.deputy.active;
};

// Instance method to check deputy permissions
PropertyOwnerSchema.methods.hasDeputyPermission = function(permission, amount = null) {
  if (!this.deputy.active) return false;
  
  switch(permission) {
    case 'approveWorkOrders':
      if (!this.deputy.permissions.canApproveWorkOrders) return false;
      if (amount && amount > this.deputy.permissions.maxApprovalAmount) return false;
      return true;
    case 'manageTenants':
      return this.deputy.permissions.canManageTenants;
    case 'viewFinancials':
      return this.deputy.permissions.canViewFinancials;
    default:
      return false;
  }
};

module.exports = mongoose.model('PropertyOwner', PropertyOwnerSchema);