const mongoose = require('mongoose');

// Organization Schema (Multi-tenant) - Complete Implementation as per User's Specification
const OrganizationSchema = new mongoose.Schema({
  name: { type: String, required: true },
  code: { type: String, unique: true },
  type: { type: String, enum: ['corporate', 'individual', 'government'] },
  subscription: {
    plan: { type: String, enum: ['basic', 'professional', 'enterprise'] },
    status: { type: String, enum: ['active', 'suspended', 'cancelled'] },
    startDate: Date,
    endDate: Date
  },
  settings: {
    language: { type: String, default: 'ar' },
    currency: { type: String, default: 'SAR' },
    timezone: { type: String, default: 'Asia/Riyadh' }
  },
  createdAt: { type: Date, default: Date.now }
});

// Add indexes for performance
OrganizationSchema.index({ code: 1 });
OrganizationSchema.index({ 'subscription.status': 1 });
OrganizationSchema.index({ type: 1 });
OrganizationSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Organization', OrganizationSchema);