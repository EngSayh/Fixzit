// Fix for express-mongo-sanitize conflict
// Place this in your server.js or app.js BEFORE other middleware

const mongoSanitize = require('express-mongo-sanitize');

// Custom wrapper to prevent property assignment error
const sanitizeMiddleware = (req, res, next) => {
    try {
        // Create a new object with sanitized values
        const sanitized = mongoSanitize.sanitize(req.query);
        req.query = sanitized;
        
        if (req.body) {
            req.body = mongoSanitize.sanitize(req.body);
        }
        
        next();
    } catch (error) {
        console.warn('Sanitization warning:', error.message);
        next();
    }
};

module.exports = sanitizeMiddleware;