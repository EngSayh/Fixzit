const mongoose = require('mongoose');

const TicketSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  ticketNumber: {
    type: String,
    required: true,
    unique: true
  },
  subject: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['technical', 'billing', 'property', 'maintenance', 'general', 'complaint', 'feature_request']
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  status: {
    type: String,
    enum: ['open', 'assigned', 'in_progress', 'waiting_customer', 'resolved', 'closed', 'cancelled'],
    default: 'open'
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  propertyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  },
  workOrderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'WorkOrder'
  },
  attachments: [{
    filename: String,
    url: String,
    uploadedAt: { type: Date, default: Date.now },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  comments: [{
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    content: { type: String, required: true },
    isInternal: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  }],
  resolution: {
    description: String,
    resolvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    resolvedAt: Date,
    satisfaction: { type: Number, min: 1, max: 5 }
  },
  sla: {
    responseTime: Number, // in hours
    resolutionTime: Number, // in hours
    firstResponseAt: Date,
    breached: { type: Boolean, default: false }
  },
  tags: [String],
  estimatedHours: Number,
  actualHours: Number,
  cost: {
    estimated: Number,
    actual: Number,
    currency: { type: String, default: 'SAR' }
  },
  escalation: {
    level: { type: Number, default: 0 },
    escalatedAt: Date,
    escalatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reason: String
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  closedAt: Date
});

TicketSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Generate unique ticket number
TicketSchema.pre('save', async function(next) {
  if (this.isNew) {
    const count = await mongoose.model('Ticket').countDocuments({ tenantId: this.tenantId });
    this.ticketNumber = `TK-${this.tenantId.toString().substr(-4).toUpperCase()}-${(count + 1).toString().padStart(6, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Ticket', TicketSchema);