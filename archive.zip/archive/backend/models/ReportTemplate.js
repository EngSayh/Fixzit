const mongoose = require('mongoose');

const ReportTemplateSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  name: {
    type: String,
    required: true
  },
  description: String,
  category: {
    type: String,
    required: true,
    enum: ['financial', 'operational', 'compliance', 'maintenance', 'hr', 'property', 'vendor', 'custom']
  },
  type: {
    type: String,
    required: true,
    enum: ['pdf', 'excel', 'csv', 'json', 'dashboard']
  },
  frequency: {
    type: String,
    enum: ['on_demand', 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
    default: 'on_demand'
  },
  schedule: {
    enabled: { type: Boolean, default: false },
    cron: String,
    timezone: { type: String, default: 'Asia/Riyadh' },
    nextRun: Date,
    lastRun: Date
  },
  filters: {
    dateRange: {
      type: { type: String, enum: ['fixed', 'relative', 'custom'] },
      startDate: Date,
      endDate: Date,
      relativePeriod: String // 'last_30_days', 'current_month', etc.
    },
    properties: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Property' }],
    departments: [String],
    statuses: [String],
    customFilters: mongoose.Schema.Types.Mixed
  },
  columns: [{
    field: { type: String, required: true },
    label: { type: String, required: true },
    type: { type: String, enum: ['text', 'number', 'date', 'currency', 'percentage', 'boolean'] },
    format: String,
    aggregation: { type: String, enum: ['sum', 'avg', 'count', 'min', 'max'] },
    visible: { type: Boolean, default: true },
    sortable: { type: Boolean, default: true }
  }],
  dataSource: {
    type: String,
    required: true,
    enum: ['properties', 'workorders', 'invoices', 'payments', 'vendors', 'contracts', 'employees', 'tickets']
  },
  query: {
    collection: String,
    pipeline: [mongoose.Schema.Types.Mixed], // MongoDB aggregation pipeline
    sql: String, // For SQL-based reports
    customQuery: mongoose.Schema.Types.Mixed
  },
  formatting: {
    orientation: { type: String, enum: ['portrait', 'landscape'], default: 'portrait' },
    pageSize: { type: String, enum: ['A4', 'A3', 'letter', 'legal'], default: 'A4' },
    headers: {
      enabled: { type: Boolean, default: true },
      content: String,
      logo: String
    },
    footers: {
      enabled: { type: Boolean, default: true },
      content: String,
      pageNumbers: { type: Boolean, default: true }
    },
    styling: {
      theme: { type: String, enum: ['default', 'modern', 'classic', 'corporate'] },
      colors: {
        primary: String,
        secondary: String,
        accent: String
      },
      fonts: {
        headers: String,
        body: String,
        size: Number
      }
    }
  },
  distribution: {
    recipients: [{
      type: { type: String, enum: ['user', 'email', 'role'] },
      value: String,
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    }],
    channels: {
      email: { type: Boolean, default: true },
      dashboard: { type: Boolean, default: true },
      storage: { type: Boolean, default: true }
    },
    emailSettings: {
      subject: String,
      body: String,
      attachmentName: String
    }
  },
  permissions: {
    viewRoles: [String],
    editRoles: [String],
    executeRoles: [String]
  },
  metrics: {
    executionCount: { type: Number, default: 0 },
    lastExecutionTime: Number, // in milliseconds
    averageExecutionTime: Number,
    successRate: { type: Number, default: 100 }
  },
  version: { type: Number, default: 1 },
  isActive: { type: Boolean, default: true },
  isSystem: { type: Boolean, default: false },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

ReportTemplateSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('ReportTemplate', ReportTemplateSchema);