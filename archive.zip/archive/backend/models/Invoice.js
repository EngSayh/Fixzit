const mongoose = require('mongoose');

const InvoiceSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  invoiceNumber: {
    type: String,
    required: true,
    unique: true
  },
  // ZATCA Sequential Number (required for ZATCA compliance)
  sequentialNumber: {
    type: Number,
    required: true
  },
  type: {
    type: String,
    enum: ['rent', 'maintenance', 'utility', 'service', 'penalty'],
    required: true
  },
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  propertyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  },
  // Enhanced item structure for ZATCA compliance
  items: [{
    description: {
      type: String,
      required: true
    },
    descriptionArabic: String, // Arabic description for bilingual invoices
    quantity: {
      type: Number,
      required: true,
      min: 0
    },
    unitPrice: {
      type: Number,
      required: true,
      min: 0
    },
    vatRate: {
      type: Number,
      default: 15,
      min: 0,
      max: 100
    },
    vatAmount: Number,
    total: {
      type: Number,
      required: true
    },
    // ZATCA specific fields
    exemptionCode: String, // For VAT-exempt items
    isZeroRated: {
      type: Boolean,
      default: false
    }
  }],
  amounts: {
    subtotal: {
      type: Number,
      required: true,
      min: 0
    },
    totalVatAmount: {
      type: Number,
      required: true,
      min: 0
    },
    totalExemptAmount: {
      type: Number,
      default: 0,
      min: 0
    },
    totalZeroRatedAmount: {
      type: Number,
      default: 0,
      min: 0
    },
    discountAmount: {
      type: Number,
      default: 0,
      min: 0
    },
    total: {
      type: Number,
      required: true,
      min: 0
    }
  },
  // ZATCA Business Information
  businessInfo: {
    // Seller information
    sellerName: {
      type: String,
      required: true
    },
    sellerNameArabic: String,
    vatNumber: {
      type: String,
      required: true,
      match: /^3\d{14}$/  // Saudi VAT number format
    },
    crNumber: String, // Commercial Registration Number
    address: {
      street: String,
      streetArabic: String,
      district: String,
      districtArabic: String,
      city: String,
      cityArabic: String,
      postalCode: String,
      country: {
        type: String,
        default: 'SA'
      }
    },
    // Buyer information
    buyerName: String,
    buyerNameArabic: String,
    buyerVatNumber: String,
    buyerAddress: {
      street: String,
      streetArabic: String,
      district: String,
      districtArabic: String,
      city: String,
      cityArabic: String,
      postalCode: String,
      country: {
        type: String,
        default: 'SA'
      }
    }
  },
  // Date information
  issueDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  issueTime: {
    type: String,
    required: true,
    default: () => new Date().toTimeString().split(' ')[0]
  },
  hijriDate: String, // Hijri calendar date
  dueDate: Date,
  currency: {
    type: String,
    default: 'SAR',
    enum: ['SAR', 'USD', 'EUR']
  },
  status: {
    type: String,
    enum: ['draft', 'sent', 'viewed', 'paid', 'overdue', 'cancelled'],
    default: 'draft'
  },
  paymentMethod: String,
  paidAt: Date,
  // Enhanced ZATCA compliance fields
  zatca: {
    // QR Code data
    qrCode: String,
    qrData: {
      sellerName: String,
      vatNumber: String,
      timestamp: String,
      total: Number,
      vatAmount: Number
    },
    // ZATCA UUID and submission tracking
    uuid: {
      type: String,
      unique: true,
      sparse: true
    },
    submitted: {
      type: Boolean,
      default: false
    },
    submittedAt: Date,
    submissionResponse: {
      status: String,
      message: String,
      clearanceStatus: String,
      warnings: [String]
    },
    // Digital signature
    digitalSignature: String,
    // ZATCA phase tracking
    phase1Compliant: {
      type: Boolean,
      default: true
    },
    phase2Compliant: {
      type: Boolean,
      default: false
    },
    // Previous invoice hash (for chaining)
    previousInvoiceHash: String,
    // Counter value for invoice numbering
    icv: Number // Invoice Counter Value
  },
  // Additional compliance fields
  notes: String,
  notesArabic: String,
  // Audit trail
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Add indexes for performance
InvoiceSchema.index({ tenantId: 1, status: 1 });
InvoiceSchema.index({ invoiceNumber: 1 });
InvoiceSchema.index({ customer: 1 });
InvoiceSchema.index({ dueDate: 1 });
InvoiceSchema.index({ 'zatcaFields.sequentialNumber': 1 });
InvoiceSchema.index({ createdAt: -1 });
InvoiceSchema.index({ propertyId: 1 });

module.exports = mongoose.model('Invoice', InvoiceSchema);