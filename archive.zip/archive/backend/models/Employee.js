const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  employeeId: {
    type: String,
    required: true,
    unique: true
  },
  department: {
    type: String,
    required: true,
    enum: ['maintenance', 'finance', 'hr', 'operations', 'management', 'legal', 'it', 'security']
  },
  position: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'terminated', 'suspended'],
    default: 'active'
  },
  salary: {
    amount: Number,
    currency: { type: String, default: 'SAR' },
    frequency: { type: String, enum: ['monthly', 'annual'], default: 'monthly' }
  },
  contactInfo: {
    phone: String,
    email: String,
    address: {
      street: String,
      city: String,
      state: String,
      zipCode: String,
      country: { type: String, default: 'Saudi Arabia' }
    }
  },
  documents: [{
    type: { type: String, required: true },
    url: String,
    uploadedAt: { type: Date, default: Date.now },
    expiryDate: Date
  }],
  performance: [{
    period: String,
    rating: { type: Number, min: 1, max: 5 },
    notes: String,
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewDate: { type: Date, default: Date.now }
  }],
  skills: [String],
  certifications: [{
    name: String,
    issuer: String,
    dateObtained: Date,
    expiryDate: Date,
    documentUrl: String
  }],
  emergencyContact: {
    name: String,
    relationship: String,
    phone: String,
    email: String
  },
  hireDate: { type: Date, required: true },
  terminationDate: Date,
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

EmployeeSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Add indexes for performance
EmployeeSchema.index({ tenantId: 1, isActive: 1 });
EmployeeSchema.index({ userId: 1 });
EmployeeSchema.index({ employeeId: 1 });
EmployeeSchema.index({ department: 1 });
EmployeeSchema.index({ position: 1 });
EmployeeSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Employee', EmployeeSchema);