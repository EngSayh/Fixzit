const mongoose = require('mongoose');
const { applyTenantFilter } = require('../middleware/multiTenant');

const propertySchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: [true, 'Property name is required'],
    trim: true,
    minlength: [2, 'Name must be at least 2 characters'],
    maxlength: [200, 'Name cannot exceed 200 characters']
  },
  code: {
    type: String,
    unique: true,
    sparse: true,
    uppercase: true,
    trim: true
  },
  type: {
    type: String,
    required: [true, 'Property type is required'],
    enum: {
      values: ['residential', 'commercial', 'industrial', 'mixed', 'land'],
      message: '{VALUE} is not a valid property type'
    }
  },
  subType: {
    type: String,
    enum: ['apartment', 'villa', 'office', 'retail', 'warehouse', 'factory', 'plot']
  },
  
  // Location
  address: {
    street: {
      type: String,
      required: [true, 'Street address is required']
    },
    buildingNumber: String,
    district: String,
    city: {
      type: String,
      required: [true, 'City is required']
    },
    state: String,
    country: {
      type: String,
      default: 'Saudi Arabia'
    },
    postalCode: String,
    latitude: Number,
    longitude: Number
  },
  
  // Property Details
  details: {
    totalArea: {
      type: Number,
      min: 0
    },
    builtArea: {
      type: Number,
      min: 0
    },
    units: {
      type: Number,
      default: 1,
      min: 1
    },
    floors: {
      type: Number,
      default: 1,
      min: 1
    },
    yearBuilt: {
      type: Number,
      min: 1900,
      max: new Date().getFullYear()
    },
    parkingSpaces: {
      type: Number,
      default: 0,
      min: 0
    }
  },
  
  // Ownership & Multi-Tenancy
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: [true, 'Organization is required for multi-tenant isolation'],
    index: true
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Property owner is required']
  },
  manager: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  
  // Financial
  financial: {
    purchasePrice: {
      type: Number,
      min: 0
    },
    purchaseDate: Date,
    marketValue: {
      type: Number,
      min: 0
    },
    valuationDate: Date,
    monthlyRent: {
      type: Number,
      min: 0
    },
    currency: {
      type: String,
      default: 'SAR'
    }
  },
  
  // Legal
  legal: {
    titleDeedNumber: String,
    titleDeedDate: Date,
    landRegistryNumber: String,
    municipalityNumber: String,
    electricityAccount: String,
    waterAccount: String
  },
  
  // Status
  status: {
    type: String,
    enum: ['active', 'inactive', 'maintenance', 'sold'],
    default: 'active'
  },
  occupancyStatus: {
    type: String,
    enum: ['vacant', 'occupied', 'partially_occupied'],
    default: 'vacant'
  },
  
  // Features & Amenities
  features: [{
    type: String,
    enum: [
      'parking', 'elevator', 'security', 'gym', 'pool', 
      'garden', 'balcony', 'storage', 'central_ac', 'internet'
    ]
  }],
  
  // Documents
  documents: [{
    name: String,
    type: String,
    url: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    },
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  }],
  
  // Legacy fields for backward compatibility
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant'
  },
  units: [{
    unitNumber: String,
    type: String,
    size: Number,
    bedrooms: Number,
    bathrooms: Number,
    rent: Number,
    status: { type: String, enum: ['vacant', 'occupied', 'maintenance'] },
    tenant: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  amenities: [String],
  images: [String],
  maintenanceHistory: [{
    workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
    date: Date,
    cost: Number
  }],
  
  // Metadata
  notes: String,
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Apply multi-tenant filter
applyTenantFilter(propertySchema);

// Indexes
propertySchema.index({ organization: 1, status: 1 });
propertySchema.index({ organization: 1, code: 1 });
propertySchema.index({ 'address.city': 1 });
propertySchema.index({ owner: 1 });

// Virtual for full address
propertySchema.virtual('fullAddress').get(function() {
  const parts = [
    this.address.buildingNumber,
    this.address.street,
    this.address.district,
    this.address.city,
    this.address.country
  ].filter(Boolean);
  return parts.join(', ');
});

// Generate property code
propertySchema.pre('save', async function(next) {
  if (!this.code && this.isNew) {
    const prefix = this.type.substring(0, 3).toUpperCase();
    const count = await this.constructor.countDocuments({ organization: this.organization });
    this.code = `${prefix}-${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

// Calculate occupancy rate
propertySchema.methods.calculateOccupancy = async function() {
  const Unit = mongoose.model('Unit');
  const units = await Unit.find({ property: this._id });
  const totalUnits = units.length || this.details.units || 1;
  const occupiedUnits = units.filter(u => u.status === 'occupied').length;
  return (occupiedUnits / totalUnits) * 100;
};

module.exports = mongoose.model('Property', propertySchema);