const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

// SQLite database for reliable local storage
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'fixzit.db'),
  logging: false
});

// User Model
const User = sequelize.define('User', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  role: {
    type: DataTypes.ENUM('admin', 'manager', 'technician', 'customer'),
    defaultValue: 'customer'
  },
  tenantId: {
    type: DataTypes.UUID,
    allowNull: false
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
});

// Property Model
const Property = sequelize.define('Property', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  address: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('residential', 'commercial', 'industrial'),
    defaultValue: 'residential'
  },
  units: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  },
  tenantId: {
    type: DataTypes.UUID,
    allowNull: false
  }
});

// WorkOrder Model
const WorkOrder = sequelize.define('WorkOrder', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT
  },
  status: {
    type: DataTypes.ENUM('open', 'assigned', 'in_progress', 'completed', 'cancelled'),
    defaultValue: 'open'
  },
  priority: {
    type: DataTypes.ENUM('low', 'medium', 'high', 'critical'),
    defaultValue: 'medium'
  },
  propertyId: {
    type: DataTypes.UUID,
    allowNull: false
  },
  tenantId: {
    type: DataTypes.UUID,
    allowNull: false
  },
  assignedTo: {
    type: DataTypes.UUID
  }
});

// Tenant Model
const Tenant = sequelize.define('Tenant', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  plan: {
    type: DataTypes.ENUM('basic', 'pro', 'enterprise'),
    defaultValue: 'basic'
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
});

// Initialize database with sample data
async function initializeDatabase() {
  try {
    await sequelize.sync({ force: true });
    
    // Create default tenant
    const tenant = await Tenant.create({
      name: 'Fixzit Demo',
      plan: 'enterprise'
    });

    // Create admin user
    const bcrypt = require('bcryptjs');
    const hashedPassword = await bcrypt.hash('Admin123!', 10);
    
    await User.create({
      email: 'admin@fixzit.com',
      password: hashedPassword,
      name: 'Admin User',
      role: 'admin',
      tenantId: tenant.id
    });

    // Create sample properties
    const property1 = await Property.create({
      name: 'Riyadh Tower',
      address: 'King Fahd Road, Riyadh',
      type: 'commercial',
      units: 150,
      tenantId: tenant.id
    });

    const property2 = await Property.create({
      name: 'Jeddah Complex',
      address: 'Corniche Road, Jeddah',
      type: 'residential',
      units: 200,
      tenantId: tenant.id
    });

    // Create sample work orders
    await WorkOrder.create({
      title: 'AC Repair - Unit 301',
      description: 'Air conditioning not working properly',
      status: 'open',
      priority: 'high',
      propertyId: property1.id,
      tenantId: tenant.id
    });

    await WorkOrder.create({
      title: 'Plumbing Issue - Unit 205',
      description: 'Water leak in bathroom',
      status: 'in_progress',
      priority: 'medium',
      propertyId: property2.id,
      tenantId: tenant.id
    });

    console.log('✅ Database initialized with sample data');
    return true;
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    return false;
  }
}

module.exports = {
  sequelize,
  User,
  Property,
  WorkOrder,
  Tenant,
  initializeDatabase
};