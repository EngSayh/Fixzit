const mongoose = require('mongoose');

const deputySchema = new mongoose.Schema({
  // Property Reference
  propertyId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Property',
    required: true,
    index: true 
  },
  
  // Primary Owner who assigned the deputy
  primaryOwnerId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  
  // Deputy User
  deputyUserId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  
  // Delegated Permissions
  permissions: {
    // Work Order Permissions
    canViewWorkOrders: { type: Boolean, default: true },
    canCreateWorkOrders: { type: Boolean, default: true },
    canApproveWorkOrders: { type: Boolean, default: true },
    workOrderApprovalLimit: { type: Number, default: 5000 }, // SAR
    
    // Quotation Permissions
    canViewQuotations: { type: Boolean, default: true },
    canApproveQuotations: { type: Boolean, default: false },
    quotationApprovalLimit: { type: Number, default: 10000 }, // SAR
    
    // Financial Permissions
    canViewFinancials: { type: Boolean, default: true },
    canApproveInvoices: { type: Boolean, default: false },
    invoiceApprovalLimit: { type: Number, default: 5000 }, // SAR
    canViewReports: { type: Boolean, default: true },
    
    // Tenant Management
    canManageTenants: { type: Boolean, default: true },
    canApproveTenancy: { type: Boolean, default: true },
    canEvictTenants: { type: Boolean, default: false },
    
    // Property Management
    canEditPropertyDetails: { type: Boolean, default: false },
    canManageUnits: { type: Boolean, default: true },
    canScheduleMaintenance: { type: Boolean, default: true },
    
    // Vendor Management
    canSelectVendors: { type: Boolean, default: true },
    canApproveVendorContracts: { type: Boolean, default: false }
  },
  
  // Validity Period
  validFrom: { type: Date, default: Date.now },
  validUntil: { type: Date }, // null means no expiry
  
  // Status
  status: { 
    type: String, 
    enum: ['active', 'suspended', 'expired', 'revoked'],
    default: 'active' 
  },
  
  // Notes from owner
  notes: String,
  
  // Tracking
  lastActivityAt: Date,
  totalApprovals: { type: Number, default: 0 },
  totalSpendApproved: { type: Number, default: 0 },
  
  // Audit
  createdBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  revokedBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  },
  revokedAt: Date,
  revocationReason: String,

  // Multi-tenant
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  tenantId: {
    type: String,
    required: true
  }
}, { 
  timestamps: true 
});

// Index for quick lookups
deputySchema.index({ deputyUserId: 1, status: 1 });
deputySchema.index({ propertyId: 1, status: 1 });
deputySchema.index({ validUntil: 1 });

// Methods
deputySchema.methods.isValid = function() {
  if (this.status !== 'active') return false;
  if (this.validUntil && this.validUntil < new Date()) {
    this.status = 'expired';
    this.save();
    return false;
  }
  return true;
};

deputySchema.methods.canApprove = function(type, amount) {
  if (!this.isValid()) return false;
  
  switch(type) {
    case 'work_order':
      return this.permissions.canApproveWorkOrders && 
             amount <= this.permissions.workOrderApprovalLimit;
    
    case 'quotation':
      return this.permissions.canApproveQuotations && 
             amount <= this.permissions.quotationApprovalLimit;
    
    case 'invoice':
      return this.permissions.canApproveInvoices && 
             amount <= this.permissions.invoiceApprovalLimit;
    
    default:
      return false;
  }
};

module.exports = mongoose.model('Deputy', deputySchema);