const mongoose = require('mongoose');

const NotificationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  type: {
    type: String,
    required: true,
    enum: [
      'work_order_created',
      'work_order_assigned', 
      'work_order_completed',
      'sla_breach',
      'invoice_generated',
      'payment_received',
      'payment_overdue',
      'maintenance_reminder',
      'system_alert',
      'welcome',
      'general'
    ]
  },
  title: {
    type: String,
    required: true
  },
  message: {
    type: String,
    required: true
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  channels: [{
    type: String,
    enum: ['in_app', 'email', 'sms', 'whatsapp', 'push']
  }],
  priority: {
    type: String,
    enum: ['low', 'normal', 'high', 'urgent'],
    default: 'normal'
  },
  status: {
    type: String,
    enum: ['pending', 'sent', 'delivered', 'failed', 'read'],
    default: 'pending'
  },
  deliveryStatus: {
    in_app: { type: Boolean, default: false },
    email: { type: Boolean, default: false },
    sms: { type: Boolean, default: false },
    whatsapp: { type: Boolean, default: false },
    push: { type: Boolean, default: false }
  },
  delivery: {
    email: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      error: String
    },
    sms: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      error: String
    },
    push: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      error: String
    }
  },
  relatedEntity: {
    type: String,
    enum: ['WorkOrder', 'Property', 'Invoice', 'Ticket', 'Contract', 'Vendor', 'RFQ']
  },
  relatedEntityId: mongoose.Schema.Types.ObjectId,
  actionUrl: String,
  actionLabel: String,
  expiresAt: Date,
  metadata: {
    workOrderId: String,
    propertyId: String,
    invoiceId: String,
    amount: Number,
    dueDate: Date,
    customFields: mongoose.Schema.Types.Mixed
  },
  readAt: {
    type: Date
  },
  deliveredAt: {
    type: Date
  }
});

NotificationSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Index for efficient queries
NotificationSchema.index({ recipient: 1, status: 1, createdAt: -1 });
NotificationSchema.index({ tenantId: 1, type: 1, createdAt: -1 });
NotificationSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Notification', NotificationSchema);