const mongoose = require('mongoose');

// Vendor Schema - Complete Implementation as per User's Specification
const VendorSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  companyName: { type: String, required: true },
  registrationNumber: String,
  vatNumber: String,
  categories: [String],
  services: [{
    name: String,
    description: String,
    price: Number,
    unit: String
  }],
  rating: { type: Number, default: 0 },
  reviews: [{
    reviewer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rating: Number,
    comment: String,
    date: { type: Date, default: Date.now }
  }],
  certifications: [{
    name: String,
    issuer: String,
    expiryDate: Date,
    document: String
  }],
  insurance: {
    provider: String,
    policyNumber: String,
    expiryDate: Date,
    coverage: Number
  },
  bankDetails: {
    bankName: String,
    accountName: String,
    iban: String
  },
  status: { type: String, enum: ['pending', 'approved', 'suspended', 'rejected'], default: 'pending' },
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  approvedDate: Date,
  documents: [{
    name: String,
    url: String,
    type: String
  }],
  performance: {
    completedJobs: { type: Number, default: 0 },
    onTimeDelivery: { type: Number, default: 100 },
    qualityScore: { type: Number, default: 100 }
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Vendor', VendorSchema);