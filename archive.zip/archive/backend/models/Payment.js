const mongoose = require('mongoose');
const { applyTenantFilter } = require('../middleware/multiTenant');

const paymentSchema = new mongoose.Schema({
  // Payment Reference
  paymentNumber: {
    type: String,
    unique: true,
    required: true
  },
  referenceNumber: {
    type: String,
    unique: true,
    sparse: true
  },
  
  // Payment Type & Method
  type: {
    type: String,
    required: true,
    enum: ['invoice', 'deposit', 'refund', 'advance', 'settlement']
  },
  method: {
    type: String,
    required: true,
    enum: ['cash', 'bank_transfer', 'credit_card', 'debit_card', 'check', 'online', 'wallet']
  },
  
  // Amount Details
  amount: {
    type: Number,
    required: [true, 'Payment amount is required'],
    min: [0, 'Amount must be positive']
  },
  currency: {
    type: String,
    default: 'SAR'
  },
  exchangeRate: {
    type: Number,
    default: 1
  },
  
  // Related Entities
  invoice: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Invoice'
  },
  workOrder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'WorkOrder'
  },
  property: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  },
  contract: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contract'
  },
  
  // Payer/Payee Information
  payer: {
    type: {
      type: String,
      enum: ['tenant', 'owner', 'vendor', 'customer', 'organization']
    },
    id: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: 'payer.model'
    },
    model: {
      type: String,
      enum: ['User', 'Vendor', 'Organization']
    },
    name: String,
    email: String,
    phone: String
  },
  
  payee: {
    type: {
      type: String,
      enum: ['organization', 'vendor', 'owner', 'employee']
    },
    id: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: 'payee.model'
    },
    model: {
      type: String,
      enum: ['Organization', 'Vendor', 'User']
    },
    name: String,
    email: String
  },
  
  // Bank Details
  bankDetails: {
    bankName: String,
    accountNumber: String,
    accountName: String,
    iban: String,
    swiftCode: String,
    branchCode: String,
    transactionId: String
  },
  
  // Card Details (Tokenized)
  cardDetails: {
    last4: String,
    brand: String,
    expiryMonth: Number,
    expiryYear: Number,
    cardholderName: String,
    token: String, // Tokenized card info
    authorizationCode: String
  },
  
  // Check Details
  checkDetails: {
    checkNumber: String,
    bankName: String,
    checkDate: Date,
    clearanceDate: Date
  },
  
  // Payment Gateway
  gateway: {
    provider: {
      type: String,
      enum: ['stripe', 'payfort', 'tap', 'stc_pay', 'mada', 'manual']
    },
    transactionId: String,
    referenceId: String,
    status: String,
    response: mongoose.Schema.Types.Mixed,
    fees: {
      type: Number,
      default: 0
    }
  },
  
  // Status & Dates
  status: {
    type: String,
    required: true,
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded', 'partial_refund'],
    default: 'pending'
  },
  paymentDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  processedDate: Date,
  clearedDate: Date,
  
  // Reconciliation
  reconciliation: {
    status: {
      type: String,
      enum: ['pending', 'matched', 'unmatched', 'disputed'],
      default: 'pending'
    },
    matchedDate: Date,
    matchedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    bankStatementRef: String,
    notes: String
  },
  
  // Refund Information
  refund: {
    reason: String,
    requestedAt: Date,
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    approvedAt: Date,
    amount: Number,
    originalPayment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Payment'
    }
  },
  
  // Documents
  attachments: [{
    name: String,
    type: String,
    url: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Notes & Metadata
  description: String,
  internalNotes: String,
  tags: [String],
  
  // Organization (Multi-tenant)
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true,
    index: true
  },
  
  // Audit
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approvedAt: Date
}, {
  timestamps: true
});

// Apply multi-tenant filter
applyTenantFilter(paymentSchema);

// Indexes
paymentSchema.index({ organization: 1, paymentNumber: 1 });
paymentSchema.index({ organization: 1, status: 1 });
paymentSchema.index({ invoice: 1 });
paymentSchema.index({ 'gateway.transactionId': 1 });

// Generate payment number (runs before validation)
paymentSchema.pre('validate', async function(next) {
  if (!this.paymentNumber && this.isNew) {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const count = await this.constructor.countDocuments({
      organization: this.organization,
      createdAt: {
        $gte: new Date(year, date.getMonth(), 1),
        $lt: new Date(year, date.getMonth() + 1, 1)
      }
    });
    this.paymentNumber = `PAY-${year}${month}-${String(count + 1).padStart(5, '0')}`;
  }
  next();
});

// Update invoice payment status
paymentSchema.post('save', async function() {
  if (this.invoice && this.status === 'completed') {
    const Invoice = mongoose.model('Invoice');
    const invoice = await Invoice.findById(this.invoice);
    if (invoice) {
      const Payment = mongoose.model('Payment');
      const payments = await Payment.find({
        invoice: this.invoice,
        status: 'completed'
      });
      
      const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
      invoice.payment.paidAmount = totalPaid;
      
      if (totalPaid >= invoice.totals.payableAmount) {
        invoice.payment.status = 'paid';
        invoice.status = 'paid';
      } else if (totalPaid > 0) {
        invoice.payment.status = 'partial';
        invoice.status = 'partial';
      }
      
      await invoice.save();
    }
  }
});

module.exports = mongoose.model('Payment', paymentSchema);