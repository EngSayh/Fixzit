const mongoose = require('mongoose');
const { applyTenantFilter } = require('../middleware/multiTenant');

const unitSchema = new mongoose.Schema({
  // Basic Information
  unitNumber: {
    type: String,
    required: [true, 'Unit number is required'],
    trim: true
  },
  property: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property',
    required: [true, 'Property is required'],
    index: true
  },
  
  // Unit Details
  type: {
    type: String,
    enum: ['apartment', 'office', 'retail', 'warehouse', 'studio', 'penthouse'],
    required: [true, 'Unit type is required']
  },
  size: {
    type: Number,
    min: 0,
    required: [true, 'Unit size is required']
  },
  bedrooms: {
    type: Number,
    min: 0,
    default: 0
  },
  bathrooms: {
    type: Number,
    min: 0,
    default: 0
  },
  
  // Financial
  rent: {
    type: Number,
    min: 0,
    required: [true, 'Rent amount is required']
  },
  currency: {
    type: String,
    default: 'SAR'
  },
  securityDeposit: {
    type: Number,
    min: 0
  },
  
  // Status
  status: {
    type: String,
    enum: ['vacant', 'occupied', 'maintenance', 'reserved'],
    default: 'vacant',
    index: true
  },
  
  // Tenant Information
  tenant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  leaseStart: Date,
  leaseEnd: Date,
  
  // Features
  features: [{
    type: String,
    enum: [
      'balcony', 'parking', 'storage', 'ac', 'heating', 
      'kitchen', 'furnished', 'internet', 'utilities'
    ]
  }],
  
  // Multi-tenancy - Organization field will be added by applyTenantFilter
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Apply multi-tenant filter
applyTenantFilter(unitSchema);

// Indexes
unitSchema.index({ property: 1, status: 1 });
unitSchema.index({ property: 1, unitNumber: 1 });
unitSchema.index({ tenant: 1 });
unitSchema.index({ organization: 1, status: 1 });

// Virtual for lease status
unitSchema.virtual('leaseStatus').get(function() {
  if (!this.leaseStart || !this.leaseEnd) return null;
  
  const now = new Date();
  if (now < this.leaseStart) return 'future';
  if (now > this.leaseEnd) return 'expired';
  return 'active';
});

// Methods
unitSchema.methods.isAvailable = function() {
  return this.status === 'vacant' && !this.tenant;
};

unitSchema.methods.calculateMonthlyRevenue = function() {
  return this.status === 'occupied' ? this.rent : 0;
};

// Pre-save validation
unitSchema.pre('save', async function(next) {
  // Validate lease dates
  if (this.leaseStart && this.leaseEnd && this.leaseStart >= this.leaseEnd) {
    return next(new Error('Lease start date must be before end date'));
  }
  
  // If occupied, must have tenant
  if (this.status === 'occupied' && !this.tenant) {
    return next(new Error('Occupied units must have a tenant assigned'));
  }
  
  // If vacant, should not have tenant
  if (this.status === 'vacant' && this.tenant) {
    this.tenant = undefined;
    this.leaseStart = undefined;
    this.leaseEnd = undefined;
  }
  
  next();
});

module.exports = mongoose.model('Unit', unitSchema);