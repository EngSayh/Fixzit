const mongoose = require('mongoose');

const ComplianceSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  complianceType: {
    type: String,
    required: true,
    enum: ['zatca', 'vat', 'building_permit', 'fire_safety', 'health_safety', 'environmental', 'labor_law', 'contract_compliance']
  },
  title: {
    type: String,
    required: true
  },
  description: String,
  status: {
    type: String,
    enum: ['compliant', 'non_compliant', 'pending', 'expired', 'warning'],
    default: 'pending'
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium'
  },
  propertyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  },
  relatedEntity: {
    type: String,
    enum: ['Property', 'Contract', 'Invoice', 'WorkOrder', 'Vendor', 'Employee']
  },
  relatedEntityId: mongoose.Schema.Types.ObjectId,
  requirements: [{
    requirement: String,
    status: { type: String, enum: ['met', 'not_met', 'partial', 'na'], default: 'not_met' },
    evidence: String,
    notes: String,
    verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    verifiedAt: Date
  }],
  documents: [{
    name: String,
    type: String,
    url: String,
    uploadedAt: { type: Date, default: Date.now },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    expiryDate: Date,
    status: { type: String, enum: ['valid', 'expired', 'pending_renewal'], default: 'valid' }
  }],
  inspections: [{
    inspectionDate: Date,
    inspector: String,
    result: { type: String, enum: ['pass', 'fail', 'conditional'], required: true },
    notes: String,
    nextInspectionDate: Date,
    certificate: {
      number: String,
      issueDate: Date,
      expiryDate: Date,
      url: String
    }
  }],
  auditTrail: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed,
    ipAddress: String
  }],
  zatcaCompliance: {
    vatRegistrationNumber: String,
    phase1Compliant: { type: Boolean, default: false },
    phase2Compliant: { type: Boolean, default: false },
    lastSubmission: Date,
    certificateUrl: String,
    qrCodeValidation: { type: Boolean, default: false }
  },
  reminders: [{
    type: { type: String, enum: ['renewal', 'inspection', 'submission'] },
    dueDate: Date,
    sentAt: Date,
    recipients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
  }],
  complianceScore: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  lastReviewDate: Date,
  nextReviewDate: Date,
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

ComplianceSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Calculate compliance score before saving
ComplianceSchema.pre('save', function(next) {
  if (this.requirements && this.requirements.length > 0) {
    const metRequirements = this.requirements.filter(req => req.status === 'met').length;
    this.complianceScore = Math.round((metRequirements / this.requirements.length) * 100);
  }
  next();
});

// Add indexes for performance
ComplianceSchema.index({ tenantId: 1, status: 1 });
ComplianceSchema.index({ complianceType: 1 });
ComplianceSchema.index({ severity: 1, status: 1 });
ComplianceSchema.index({ propertyId: 1 });
ComplianceSchema.index({ relatedEntity: 1, relatedEntityId: 1 });
ComplianceSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Compliance', ComplianceSchema);