const mongoose = require('mongoose');

const DoAMatrixSchema = new mongoose.Schema({
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  rules: [{
    module: {
      type: String,
      enum: ['work_orders', 'purchases', 'contracts', 'expenses', 'property_changes'],
      required: true
    },
    thresholds: [{
      minAmount: { type: Number, default: 0 },
      maxAmount: { type: Number, required: true },
      approvers: [{
        role: {
          type: String,
          enum: ['property_owner', 'deputy', 'manager', 'admin', 'super_admin'],
          required: true
        },
        sequence: { type: Number, required: true },
        mandatory: { type: Boolean, default: true }
      }],
      escalationHours: { type: Number, default: 24 },
      parallel: { type: Boolean, default: false }
    }]
  }],
  active: { type: Boolean, default: true }
}, { timestamps: true });

// Method to get required approvers for amount
DoAMatrixSchema.methods.getApprovers = function(module, amount) {
  const rule = this.rules.find(r => r.module === module);
  if (!rule) return [];
  
  const threshold = rule.thresholds.find(t => 
    amount >= t.minAmount && amount <= t.maxAmount
  );
  
  return threshold ? threshold.approvers.sort((a, b) => a.sequence - b.sequence) : [];
};

// Method to check if approval is required
DoAMatrixSchema.methods.requiresApproval = function(module, amount) {
  const approvers = this.getApprovers(module, amount);
  return approvers.length > 0;
};

// Static method to get matrix for organization
DoAMatrixSchema.statics.getActiveMatrix = async function(organizationId) {
  return await this.findOne({ 
    organization: organizationId, 
    active: true 
  });
};

module.exports = mongoose.model('DoAMatrix', DoAMatrixSchema);