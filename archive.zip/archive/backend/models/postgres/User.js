// PostgreSQL User Model for Fixzit Souq
const { DataTypes } = require('sequelize');
const bcrypt = require('bcryptjs');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes.ENUM([
        'super_admin', 'admin', 'manager', 'finance_officer', 'hr_officer',
        'legal_officer', 'operations', 'technician', 'crm_sales', 'support_agent',
        'vendor', 'customer', 'viewer', 'owner'
      ]),
      defaultValue: 'viewer'
    },
    organizationId: {
      type: DataTypes.UUID,
      allowNull: true
    },
    tenantId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    phone: {
      type: DataTypes.STRING
    },
    avatar: {
      type: DataTypes.STRING
    },
    language: {
      type: DataTypes.STRING,
      defaultValue: 'ar'
    },
    status: {
      type: DataTypes.ENUM(['active', 'inactive', 'suspended']),
      defaultValue: 'active'
    },
    permissions: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    lastLogin: {
      type: DataTypes.DATE
    }
  }, {
    timestamps: true,
    hooks: {
      beforeCreate: async (user) => {
        if (user.password) {
          user.password = await bcrypt.hash(user.password, 10);
        }
      },
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          user.password = await bcrypt.hash(user.password, 10);
        }
      }
    }
  });

  // Instance method to compare password
  User.prototype.comparePassword = async function(password) {
    return await bcrypt.compare(password, this.password);
  };

  return User;
};