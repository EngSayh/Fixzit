// PostgreSQL Models Index for Fixzit Souq
const { sequelize } = require('../../database/config');

// Import model factories
const User = require('./User')(sequelize);
const Tenant = require('./Tenant')(sequelize);
const Property = require('./Property')(sequelize);
const WorkOrder = require('./WorkOrder')(sequelize);

// Define associations
// User associations
User.belongsTo(Tenant, { foreignKey: 'tenantId', as: 'tenant' });
Tenant.hasMany(User, { foreignKey: 'tenantId', as: 'users' });

// Property associations
Property.belongsTo(Tenant, { foreignKey: 'tenantId', as: 'tenant' });
Property.belongsTo(User, { foreignKey: 'ownerId', as: 'owner' });
Property.belongsTo(User, { foreignKey: 'managerId', as: 'manager' });

Tenant.hasMany(Property, { foreignKey: 'tenantId', as: 'properties' });

// WorkOrder associations
WorkOrder.belongsTo(Tenant, { foreignKey: 'tenantId', as: 'tenant' });
WorkOrder.belongsTo(Property, { foreignKey: 'propertyId', as: 'property' });
WorkOrder.belongsTo(User, { foreignKey: 'requestedById', as: 'requestedBy' });
WorkOrder.belongsTo(User, { foreignKey: 'assignedToId', as: 'assignedTo' });

Property.hasMany(WorkOrder, { foreignKey: 'propertyId', as: 'workOrders' });
User.hasMany(WorkOrder, { foreignKey: 'requestedById', as: 'requestedWorkOrders' });
User.hasMany(WorkOrder, { foreignKey: 'assignedToId', as: 'assignedWorkOrders' });

module.exports = {
  sequelize,
  User,
  Tenant,
  Property,
  WorkOrder
};