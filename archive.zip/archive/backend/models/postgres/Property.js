// PostgreSQL Property Model for Fixzit Souq
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Property = sequelize.define('Property', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    organizationId: {
      type: DataTypes.UUID,
      allowNull: true
    },
    tenantId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    type: {
      type: DataTypes.ENUM(['residential', 'commercial', 'industrial', 'mixed'])
    },
    address: {
      type: DataTypes.JSONB,
      defaultValue: {
        street: '',
        city: '',
        state: '',
        country: 'Saudi Arabia',
        postalCode: '',
        coordinates: { lat: 0, lng: 0 }
      }
    },
    ownerId: {
      type: DataTypes.UUID
    },
    managerId: {
      type: DataTypes.UUID
    },
    units: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    amenities: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    images: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    documents: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    maintenanceHistory: {
      type: DataTypes.JSONB,
      defaultValue: []
    }
  }, {
    timestamps: true
  });

  return Property;
};