// PostgreSQL Tenant Model for Fixzit Souq
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Tenant = sequelize.define('Tenant', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    domain: {
      type: DataTypes.STRING,
      unique: true
    },
    status: {
      type: DataTypes.ENUM(['active', 'inactive', 'suspended']),
      defaultValue: 'active'
    },
    settings: {
      type: DataTypes.JSONB,
      defaultValue: {
        currency: 'SAR',
        language: 'ar',
        timezone: 'Asia/Riyadh'
      }
    },
    subscription: {
      type: DataTypes.JSONB,
      defaultValue: {
        plan: 'basic',
        status: 'active'
      }
    },
    logo: {
      type: DataTypes.STRING
    },
    primaryColor: {
      type: DataTypes.STRING,
      defaultValue: '#1f2937'
    },
    secondaryColor: {
      type: DataTypes.STRING,
      defaultValue: '#3b82f6'
    }
  }, {
    timestamps: true
  });

  return Tenant;
};