// PostgreSQL WorkOrder Model for Fixzit Souq
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const WorkOrder = sequelize.define('WorkOrder', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    tenantId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    propertyId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    unitNumber: {
      type: DataTypes.STRING
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT
    },
    category: {
      type: DataTypes.ENUM(['plumbing', 'electrical', 'hvac', 'appliance', 'general', 'emergency']),
      defaultValue: 'general'
    },
    priority: {
      type: DataTypes.ENUM(['low', 'medium', 'high', 'emergency']),
      defaultValue: 'medium'
    },
    status: {
      type: DataTypes.ENUM(['open', 'assigned', 'in_progress', 'on_hold', 'completed', 'closed']),
      defaultValue: 'open'
    },
    requestedById: {
      type: DataTypes.UUID
    },
    assignedToId: {
      type: DataTypes.UUID
    },
    vendorId: {
      type: DataTypes.UUID
    },
    estimatedCost: {
      type: DataTypes.DECIMAL(10, 2),
      defaultValue: 0
    },
    actualCost: {
      type: DataTypes.DECIMAL(10, 2),
      defaultValue: 0
    },
    scheduledDate: {
      type: DataTypes.DATE
    },
    completedDate: {
      type: DataTypes.DATE
    },
    images: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    notes: {
      type: DataTypes.JSONB,
      defaultValue: []
    },
    materials: {
      type: DataTypes.JSONB,
      defaultValue: []
    }
  }, {
    timestamps: true
  });

  return WorkOrder;
};