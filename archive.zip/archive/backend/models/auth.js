const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const asyncHandler = require('../utils/asyncHandler');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const User = require('../models/User');
const Tenant = require('../models/Tenant');
const authMiddleware = require('../middleware/auth');
const { 
  checkDatabaseConnection, 
  sanitizeInput, 
  handleValidationErrors, 
  authValidationRules 
} = require('../middleware/validation');
const { body, validationResult } = require('express-validator');

// Login
router.post('/login', 
  sanitizeInput,
  authValidationRules.login,
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    
    // Find user with timeout
    const user = await Promise.race([
      User.findOne({ email }).select('+password'),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Database timeout')), 5000)
      )
    ]);
    
    if (!user) {
      return res.status(401).json({ 
        success: false,
        error: 'Invalid credentials' 
      });
    }
    
    // Check password
    const isValid = await user.comparePassword(password);
    if (!isValid) {
      return res.status(401).json({ 
        success: false,
        error: 'Invalid credentials' 
      });
    }
    
    // Generate token
    if (!process.env.JWT_SECRET) {
      throw new Error('JWT_SECRET environment variable is required');
    }
    
    const token = jwt.sign(
      { 
        userId: user._id, 
        email: user.email,
        role: user.role, 
        organization: user.organization,
        tenantId: user.tenantId || user.organization
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    // Update last login (non-blocking)
    user.lastLogin = new Date();
    user.save().catch(err => console.warn('Could not update last login:', err.message));
    
    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        organization: user.organization
      }
    });
  })
);

// Register
router.post('/register', 
  sanitizeInput,
  authValidationRules.register,
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { email, password, name, role, tenantName } = req.body;
    
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ 
        success: false,
        error: 'User already exists' 
      });
    }
    
    // Create or find tenant
    let tenant = await Tenant.findOne({ name: tenantName });
    
    if (!tenant) {
      tenant = await Tenant.create({
        name: tenantName,
        plan: 'basic',
        status: 'active'
      });
    }
    
    // Create user
    const user = await User.create({
      email,
      password,
      name,
      role: role || 'tenant',
      organization: tenant._id,
      tenantId: tenant._id,
      status: 'active'
    });
    
    res.status(201).json({
      success: true,
      message: 'User created successfully',
      userId: user._id
    });
  })
);

// Forgot Password
router.post('/forgot-password',
  sanitizeInput,
  [
    body('email')
      .isEmail()
      .normalizeEmail()
      .withMessage('Please provide a valid email address')
  ],
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { email } = req.body;
    
    const user = await User.findOne({ email });
    
    if (!user) {
      // Don't reveal if user exists
      return res.json({ 
        success: true,
        message: 'If your email is registered, you will receive a password reset link.' 
      });
    }
    
    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenHash = crypto.createHash('sha256').update(resetToken).digest('hex');
    
    user.passwordResetToken = resetTokenHash;
    user.passwordResetExpires = Date.now() + 10 * 60 * 1000; // 10 minutes
    await user.save();
    
    // TODO: Send email with resetToken
    console.log('Reset token generated for:', email);
    
    res.json({ 
      success: true,
      message: 'If your email is registered, you will receive a password reset link.' 
    });
  })
);

// Reset Password
router.post('/reset-password',
  sanitizeInput,
  [
    body('token')
      .isLength({ min: 64, max: 64 })
      .withMessage('Invalid reset token'),
    body('password')
      .isLength({ min: 8 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('Password must be at least 8 characters with uppercase, lowercase, and number')
  ],
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { token, password } = req.body;
    
    const resetTokenHash = crypto.createHash('sha256').update(token).digest('hex');
    
    const user = await User.findOne({
      passwordResetToken: resetTokenHash,
      passwordResetExpires: { $gt: Date.now() }
    });
    
    if (!user) {
      return res.status(400).json({ 
        success: false,
        error: 'Invalid or expired reset token' 
      });
    }
    
    // Update password
    user.password = password;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();
    
    res.json({ 
      success: true,
      message: 'Password reset successfully' 
    });
  })
);

// Change Password (authenticated)
router.put('/change-password',
  authMiddleware,
  sanitizeInput,
  [
    body('currentPassword')
      .notEmpty()
      .withMessage('Current password is required'),
    body('newPassword')
      .isLength({ min: 8 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('New password must be at least 8 characters with uppercase, lowercase, and number')
  ],
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    
    const user = await User.findById(req.userId).select('+password');
    
    if (!user) {
      return res.status(404).json({ 
        success: false,
        error: 'User not found' 
      });
    }
    
    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    if (!isCurrentPasswordValid) {
      return res.status(400).json({ 
        success: false,
        error: 'Current password is incorrect' 
      });
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    res.json({ 
      success: true,
      message: 'Password changed successfully' 
    });
  })
);

// Get Profile
router.get('/profile',
  authMiddleware,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.userId)
      .select('-password -passwordResetToken -passwordResetExpires')
      .populate('organization', 'name plan')
      .populate('tenantId', 'name plan settings');
    
    if (!user) {
      return res.status(404).json({ 
        success: false,
        error: 'User not found' 
      });
    }
    
    res.json({ 
      success: true,
      user 
    });
  })
);

// Update Profile
router.put('/profile',
  authMiddleware,
  sanitizeInput,
  [
    body('name')
      .optional()
      .trim()
      .isLength({ min: 2, max: 50 })
      .matches(/^[a-zA-Z\s]+$/)
      .withMessage('Name must be 2-50 characters and contain only letters'),
    body('phone')
      .optional()
      .matches(/^[\+]?[1-9][\d]{0,15}$/)
      .withMessage('Please provide a valid phone number'),
    body('language')
      .optional()
      .isIn(['en', 'ar'])
      .withMessage('Language must be en or ar')
  ],
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const { name, phone, language, avatar } = req.body;
    
    const updateData = {};
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (language) updateData.language = language;
    if (avatar) updateData.avatar = avatar;
    
    const user = await User.findByIdAndUpdate(
      req.userId,
      updateData,
      { new: true, runValidators: true }
    ).select('-password -passwordResetToken -passwordResetExpires');
    
    if (!user) {
      return res.status(404).json({ 
        success: false,
        error: 'User not found' 
      });
    }
    
    res.json({ 
      success: true,
      message: 'Profile updated successfully',
      user 
    });
  })
);

// Refresh Token
router.post('/refresh-token',
  authMiddleware,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.userId)
      .select('_id email role tenantId organization status');
    
    if (!user || user.status !== 'active') {
      return res.status(401).json({ 
        success: false,
        error: 'User not found or inactive' 
      });
    }
    
    const newToken = jwt.sign(
      { 
        userId: user._id,
        email: user.email,
        role: user.role, 
        organization: user.organization,
        tenantId: user.tenantId || user.organization
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({ 
      success: true,
      token: newToken 
    });
  })
);

// Verify Token
router.get('/verify-token',
  authMiddleware,
  (req, res) => {
    res.json({ 
      success: true,
      valid: true,
      userId: req.userId,
      role: req.userRole,
      tenantId: req.tenantId,
      organization: req.organizationId
    });
  }
);

// Logout
router.post('/logout',
  authMiddleware,
  asyncHandler(async (req, res) => {
    // TODO: Implement token blacklisting if needed
    res.json({ 
      success: true,
      message: 'Logged out successfully' 
    });
  })
);

// Get Users (Admin only)
router.get('/users',
  authMiddleware,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    // Check permissions
    if (!['super_admin', 'admin', 'manager'].includes(req.userRole)) {
      return res.status(403).json({ 
        success: false,
        error: 'Insufficient permissions' 
      });
    }
    
    const { page = 1, limit = 20, role, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const filter = { 
      organization: req.organizationId 
    };
    if (role) filter.role = role;
    if (status) filter.status = status;
    
    const [users, total] = await Promise.all([
      User.find(filter)
        .select('-password -passwordResetToken -passwordResetExpires')
        .populate('organization', 'name')
        .skip(skip)
        .limit(parseInt(limit))
        .sort({ createdAt: -1 }),
      User.countDocuments(filter)
    ]);
    
    res.json({
      success: true,
      users,
      pagination: {
        current: parseInt(page),
        total: Math.ceil(total / parseInt(limit)),
        count: users.length,
        totalRecords: total
      }
    });
  })
);

// Update User Role (Admin only)
router.put('/users/:userId/role',
  authMiddleware,
  sanitizeInput,
  [
    body('role')
      .isIn(['super_admin', 'admin', 'manager', 'finance', 'hr', 
             'legal', 'operations', 'technician', 'crm', 'support',
             'vendor', 'tenant', 'viewer', 'property_owner'])
      .withMessage('Invalid role specified')
  ],
  handleValidationErrors,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    // Check permissions
    if (!['super_admin', 'admin'].includes(req.userRole)) {
      return res.status(403).json({ 
        success: false,
        error: 'Insufficient permissions' 
      });
    }
    
    const { role } = req.body;
    const { userId } = req.params;
    
    const user = await User.findOneAndUpdate(
      { 
        _id: userId, 
        organization: req.organizationId 
      },
      { 
        role,
        updatedAt: new Date() 
      },
      { 
        new: true,
        runValidators: true 
      }
    ).select('-password');
    
    if (!user) {
      return res.status(404).json({ 
        success: false,
        error: 'User not found' 
      });
    }
    
    res.json({ 
      success: true,
      message: 'User role updated successfully',
      user 
    });
  })
);

// Delete User (Admin only)
router.delete('/users/:userId',
  authMiddleware,
  checkDatabaseConnection,
  asyncHandler(async (req, res) => {
    // Check permissions
    if (!['super_admin', 'admin'].includes(req.userRole)) {
      return res.status(403).json({ 
        success: false,
        error: 'Insufficient permissions' 
      });
    }
    
    const { userId } = req.params;
    
    // Prevent self-deletion
    if (userId === req.userId) {
      return res.status(400).json({ 
        success: false,
        error: 'Cannot delete your own account' 
      });
    }
    
    const user = await User.findOneAndDelete({
      _id: userId,
      organization: req.organizationId
    });
    
    if (!user) {
      return res.status(404).json({ 
        success: false,
        error: 'User not found' 
      });
    }
    
    res.json({ 
      success: true,
      message: 'User deleted successfully' 
    });
  })
);

module.exports = router;