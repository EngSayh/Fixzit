const mongoose = require('mongoose');

const SubscriptionSchema = new mongoose.Schema({
  organization: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true
  },
  plan: {
    type: String,
    enum: ['basic', 'standard', 'pro', 'enterprise'],
    required: true
  },
  seats: {
    purchased: { type: Number, required: true },
    used: { type: Number, default: 0 }
  },
  modules: [{
    name: {
      type: String,
      enum: ['dashboard', 'workOrders', 'properties', 'finance', 'hr', 'administration', 
             'crm', 'marketplace', 'support', 'compliance', 'reports', 'system', 'preventive']
    },
    enabled: { type: Boolean, default: true },
    addon: { type: Boolean, default: false },
    price: { type: Number, default: 0 }
  }],
  billing: {
    cycle: { type: String, enum: ['monthly', 'annual'], default: 'monthly' },
    amount: { type: Number, required: true },
    currency: { type: String, default: 'SAR' },
    nextBillingDate: { type: Date, required: true },
    paymentMethod: { type: String, enum: ['card', 'bank_transfer', 'invoice'], default: 'card' },
    lastPaymentDate: Date,
    lastPaymentAmount: Number
  },
  status: {
    type: String,
    enum: ['trial', 'active', 'suspended', 'cancelled', 'expired'],
    default: 'trial'
  },
  trialEndsAt: { type: Date, required: true },
  features: {
    maxProperties: { type: Number, default: 10 },
    maxUsers: { type: Number, default: 5 },
    maxWorkOrders: { type: Number, default: 100 },
    maxStorage: { type: Number, default: 1000 }, // MB
    zatcaCompliance: { type: Boolean, default: false },
    multiTenant: { type: Boolean, default: false },
    apiAccess: { type: Boolean, default: false },
    customBranding: { type: Boolean, default: false }
  },
  usage: {
    properties: { type: Number, default: 0 },
    users: { type: Number, default: 0 },
    workOrders: { type: Number, default: 0 },
    storage: { type: Number, default: 0 } // MB
  }
}, { timestamps: true });

// Instance methods
SubscriptionSchema.methods.isActive = function() {
  return this.status === 'active' && new Date() < this.billing.nextBillingDate;
};

SubscriptionSchema.methods.isTrialExpired = function() {
  return this.status === 'trial' && new Date() > this.trialEndsAt;
};

SubscriptionSchema.methods.canUseFeature = function(feature) {
  if (!this.isActive() && this.status !== 'trial') return false;
  return this.features[feature] || false;
};

SubscriptionSchema.methods.hasCapacity = function(resource) {
  const limit = this.features[`max${resource.charAt(0).toUpperCase() + resource.slice(1)}`];
  const current = this.usage[resource];
  // Treat -1 as unlimited capacity
  if (limit === -1) return true;
  return current < limit;
};

// Static methods
SubscriptionSchema.statics.getByOrganization = async function(organizationId) {
  return await this.findOne({ 
    organization: organizationId,
    status: { $in: ['trial', 'active'] }
  }).populate('organization');
};

module.exports = mongoose.model('Subscription', SubscriptionSchema);