const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
// COMPLETE FIXZIT SOUQ DATABASE MODELS
// Part 1: All Mongoose Schemas for 13 Modules & 14 Roles
// File: /models/index.js


// ==================== 1. ORGANIZATION SCHEMA (MULTI-TENANT) ====================
const organizationSchema = new mongoose.Schema({
  // Basic Information
  name: { type: String, required: true },
  code: { type: String, unique: true, required: true },
  type: { 
    type: String, 
    enum: ['corporate', 'individual', 'government', 'non_profit'],
    required: true 
  },
  
  // Registration Details
  registration: {
    commercialNumber: String,
    vatNumber: String,
    municipalityLicense: String,
    chamberId: String,
    iban: String,
    bankName: String
  },
  
  // Contact Information
  contact: {
    phone: { type: String, required: true },
    email: { type: String, required: true },
    website: String,
    address: {
      street: String,
      city: String,
      state: String,
      country: { type: String, default: 'Saudi Arabia' },
      postalCode: String,
      coordinates: {
        lat: Number,
        lng: Number
      }
    }
  },
  
  // Subscription Management
  subscription: {
    plan: { 
      type: String, 
      enum: ['trial', 'basic', 'professional', 'enterprise', 'custom'],
      default: 'trial'
    },
    status: { 
      type: String, 
      enum: ['active', 'suspended', 'cancelled', 'expired'],
      default: 'active'
    },
    startDate: { type: Date, default: Date.now },
    endDate: Date,
    seats: { type: Number, default: 5 },
    usedSeats: { type: Number, default: 0 },
    features: [{
      name: String,
      enabled: { type: Boolean, default: true }
    }],
    billing: {
      cycle: { type: String, enum: ['monthly', 'quarterly', 'annual'], default: 'monthly' },
      amount: Number,
      currency: { type: String, default: 'SAR' },
      nextBillingDate: Date,
      paymentMethod: String
    }
  },
  
  // Settings
  settings: {
    language: { type: String, enum: ['ar', 'en'], default: 'ar' },
    currency: { type: String, default: 'SAR' },
    timezone: { type: String, default: 'Asia/Riyadh' },
    dateFormat: { type: String, default: 'DD/MM/YYYY' },
    fiscalYearStart: { type: Number, default: 1 }, // Month
    workWeek: {
      start: { type: String, default: 'Sunday' },
      end: { type: String, default: 'Thursday' },
      workingHours: {
        start: { type: String, default: '08:00' },
        end: { type: String, default: '17:00' }
      }
    },
    notifications: {
      email: { type: Boolean, default: true },
      sms: { type: Boolean, default: true },
      whatsapp: { type: Boolean, default: false },
      push: { type: Boolean, default: true }
    }
  },
  
  // ZATCA Configuration
  zatca: {
    enabled: { type: Boolean, default: false },
    environment: { type: String, enum: ['sandbox', 'production'], default: 'sandbox' },
    certificateSerial: String,
    privateKey: String,
    csid: String,
    otp: String,
    invoiceCounter: { type: Number, default: 1 }
  },
  
  // Statistics
  stats: {
    totalProperties: { type: Number, default: 0 },
    totalUnits: { type: Number, default: 0 },
    totalWorkOrders: { type: Number, default: 0 },
    totalInvoices: { type: Number, default: 0 },
    totalRevenue: { type: Number, default: 0 }
  },
  
  // Metadata
  isActive: { type: Boolean, default: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 2. USER SCHEMA (14 ROLES) ====================
const userSchema = new mongoose.Schema({
  // Basic Information
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  
  // Role Management - All 14 Roles
  role: {
    type: String,
    enum: [
      'super_admin',     // 1. Platform administrator
      'admin',          // 2. Organization administrator  
      'manager',        // 3. Property/Facility manager
      'finance_officer', // 4. Financial management
      'hr_officer',     // 5. Human resources
      'legal_officer',  // 6. Legal & compliance
      'operations',     // 7. Operations/Dispatcher
      'technician',     // 8. Field technician
      'crm_sales',      // 9. CRM & Sales
      'support_agent',  // 10. Customer support
      'vendor',         // 11. External vendor
      'customer',       // 12. Customer/Tenant
      'viewer',         // 13. Read-only viewer
      'owner'           // 14. Property owner
    ],
    required: true
  },
  
  // Organization & Access
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  properties: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Property' }], // Assigned properties
  departments: [String],
  
  // Permissions & Features
  permissions: {
    modules: [{
      name: String,
      access: { type: String, enum: ['none', 'read', 'write', 'full'], default: 'none' }
    }],
    customPermissions: [String],
    delegations: [{
      from: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      permissions: [String],
      startDate: Date,
      endDate: Date
    }]
  },
  
  // Profile Information
  profile: {
    employeeId: String,
    nationalId: String,
    phone: { type: String, required: true },
    alternatePhone: String,
    avatar: String,
    designation: String,
    department: String,
    reportingTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    
    // Address
    address: {
      street: String,
      city: String,
      state: String,
      country: String,
      postalCode: String
    },
    
    // Emergency Contact
    emergencyContact: {
      name: String,
      relationship: String,
      phone: String
    },
    
    // Employment Details
    employment: {
      joinDate: Date,
      confirmationDate: Date,
      exitDate: Date,
      employmentType: { 
        type: String, 
        enum: ['full_time', 'part_time', 'contract', 'internship'] 
      },
      salary: Number,
      bankDetails: {
        bankName: String,
        accountNumber: String,
        iban: String
      }
    }
  },
  
  // Authentication & Security
  auth: {
    twoFactorEnabled: { type: Boolean, default: false },
    twoFactorSecret: String,
    passwordResetToken: String,
    passwordResetExpires: Date,
    emailVerificationToken: String,
    emailVerified: { type: Boolean, default: false },
    lastLogin: Date,
    lastLoginIP: String,
    loginAttempts: { type: Number, default: 0 },
    lockUntil: Date,
    sessions: [{
      token: String,
      device: String,
      ip: String,
      createdAt: Date
    }]
  },
  
  // Preferences
  preferences: {
    language: { type: String, enum: ['ar', 'en'], default: 'ar' },
    theme: { type: String, enum: ['light', 'dark', 'auto'], default: 'light' },
    notifications: {
      email: { type: Boolean, default: true },
      sms: { type: Boolean, default: true },
      push: { type: Boolean, default: true },
      desktop: { type: Boolean, default: true }
    },
    dashboard: {
      widgets: [String],
      layout: mongoose.Schema.Types.Mixed
    }
  },
  
  // Status & Metadata
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'suspended', 'terminated'],
    default: 'active'
  },
  isOnline: { type: Boolean, default: false },
  lastSeen: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// User methods
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// ==================== 3. PROPERTY SCHEMA ====================
const propertySchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Basic Information
  name: { type: String, required: true },
  code: { type: String, required: true },
  type: { 
    type: String, 
    enum: ['residential', 'commercial', 'industrial', 'mixed', 'land'],
    required: true
  },
  subType: String, // Villa, Apartment, Office, Warehouse, etc.
  
  // Location
  address: {
    buildingNumber: String,
    street: String,
    district: String,
    city: { type: String, required: true },
    state: String,
    country: { type: String, default: 'Saudi Arabia' },
    postalCode: String,
    coordinates: {
      lat: Number,
      lng: Number
    },
    landmark: String
  },
  
  // Ownership & Management
  ownership: {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    coOwners: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    managementCompany: String,
    manager: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    ownershipType: { type: String, enum: ['owned', 'leased', 'managed'] },
    titleDeed: {
      number: String,
      issueDate: Date,
      document: String
    }
  },
  
  // Property Details
  details: {
    totalArea: Number,
    builtArea: Number,
    floors: Number,
    yearBuilt: Number,
    renovationYear: Number,
    parkingSpaces: Number,
    condition: { 
      type: String, 
      enum: ['excellent', 'good', 'fair', 'poor', 'under_construction'] 
    },
    furnishingStatus: { 
      type: String, 
      enum: ['furnished', 'semi_furnished', 'unfurnished'] 
    }
  },
  
  // Units (for multi-unit properties)
  units: [{
    unitNumber: { type: String, required: true },
    floor: Number,
    type: String, // 1BHK, 2BHK, Studio, etc.
    area: Number,
    bedrooms: Number,
    bathrooms: Number,
    balconies: Number,
    
    // Rental Information
    rental: {
      status: { 
        type: String, 
        enum: ['vacant', 'occupied', 'maintenance', 'reserved'],
        default: 'vacant'
      },
      monthlyRent: Number,
      deposit: Number,
      tenant: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      leaseStart: Date,
      leaseEnd: Date,
      lastRentPaid: Date,
      rentDueDate: Number // Day of month
    },
    
    // Utilities
    utilities: {
      electricity: {
        accountNumber: String,
        provider: String,
        includedInRent: { type: Boolean, default: false }
      },
      water: {
        accountNumber: String,
        provider: String,
        includedInRent: { type: Boolean, default: false }
      },
      gas: {
        accountNumber: String,
        provider: String,
        includedInRent: { type: Boolean, default: false }
      },
      internet: {
        provider: String,
        plan: String,
        includedInRent: { type: Boolean, default: false }
      }
    },
    
    // Features
    features: [String],
    images: [String],
    virtualTour: String,
    
    // Maintenance
    lastMaintenanceDate: Date,
    nextMaintenanceDate: Date,
    maintenanceNotes: String
  }],
  
  // Amenities & Features
  amenities: {
    general: [String], // Pool, Gym, Garden, etc.
    security: [String], // CCTV, Guards, Access Control, etc.
    utilities: [String], // Central AC, Solar, Generator, etc.
    accessibility: [String] // Wheelchair access, Elevators, etc.
  },
  
  // Financial
  financial: {
    purchasePrice: Number,
    purchaseDate: Date,
    currentValue: Number,
    valuationDate: Date,
    monthlyExpenses: Number,
    yearlyTax: Number,
    insurance: {
      provider: String,
      policyNumber: String,
      premium: Number,
      expiryDate: Date,
      coverage: Number
    }
  },
  
  // Documents
  documents: [{
    name: String,
    type: String, // Title Deed, Insurance, Tax, etc.
    url: String,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now },
    expiryDate: Date
  }],
  
  // Assets (Equipment, Furniture, etc.)
  assets: [{
    name: String,
    category: String,
    brand: String,
    model: String,
    serialNumber: String,
    purchaseDate: Date,
    warrantyExpiry: Date,
    value: Number,
    location: String,
    condition: String,
    maintenanceSchedule: String
  }],
  
  // Media
  media: {
    images: [{
      url: String,
      caption: String,
      type: String, // exterior, interior, floor_plan, etc.
      isPrimary: { type: Boolean, default: false }
    }],
    videos: [{
      url: String,
      title: String,
      description: String
    }],
    virtualTour: String,
    floorPlan: String
  },
  
  // Compliance & Certifications
  compliance: {
    municipality: {
      licenseNumber: String,
      expiryDate: Date,
      status: String
    },
    civilDefense: {
      certificateNumber: String,
      expiryDate: Date,
      lastInspection: Date
    },
    environmental: {
      certificateNumber: String,
      expiryDate: Date,
      rating: String
    }
  },
  
  // Statistics
  stats: {
    totalUnits: { type: Number, default: 0 },
    occupiedUnits: { type: Number, default: 0 },
    monthlyRevenue: { type: Number, default: 0 },
    yearlyRevenue: { type: Number, default: 0 },
    maintenanceCost: { type: Number, default: 0 },
    occupancyRate: { type: Number, default: 0 }
  },
  
  // Status
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'sold', 'under_construction'],
    default: 'active'
  },
  
  // Metadata
  tags: [String],
  notes: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 4. WORK ORDER SCHEMA ====================
const workOrderSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Identification
  orderNumber: { type: String, unique: true, required: true },
  referenceNumber: String, // External reference
  
  // Location
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property', required: true },
  unit: String,
  location: String, // Specific location within property
  
  // Classification
  category: { 
    type: String, 
    enum: ['maintenance', 'repair', 'inspection', 'cleaning', 'installation', 'emergency'],
    required: true
  },
  subCategory: String,
  type: { 
    type: String, 
    enum: ['corrective', 'preventive', 'predictive', 'emergency'],
    default: 'corrective'
  },
  
  // Priority & Timing
  priority: { 
    type: String, 
    enum: ['low', 'medium', 'high', 'urgent', 'emergency'],
    default: 'medium'
  },
  
  // Status Workflow
  status: { 
    type: String, 
    enum: [
      'draft',
      'pending',
      'approved',
      'assigned',
      'in_progress',
      'on_hold',
      'completed',
      'verified',
      'closed',
      'cancelled'
    ],
    default: 'draft'
  },
  
  // Details
  title: { type: String, required: true },
  description: { type: String, required: true },
  scope: String,
  
  // People
  requester: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  team: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  supervisor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  
  // Vendor Assignment
  vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
  vendorQuotation: {
    amount: Number,
    document: String,
    approvedAt: Date
  },
  
  // Scheduling
  scheduling: {
    requestedDate: Date,
    scheduledDate: Date,
    startDate: Date,
    completionDate: Date,
    actualStartDate: Date,
    actualEndDate: Date,
    estimatedHours: Number,
    actualHours: Number,
    
    // Recurrence (for PM)
    recurrence: {
      enabled: { type: Boolean, default: false },
      pattern: { type: String, enum: ['daily', 'weekly', 'monthly', 'yearly'] },
      interval: Number,
      endDate: Date,
      nextDue: Date
    }
  },
  
  // Cost & Budget
  financial: {
    estimatedCost: Number,
    quotedCost: Number,
    approvedBudget: Number,
    actualCost: Number,
    
    // Cost Breakdown
    labor: {
      hours: Number,
      rate: Number,
      total: Number
    },
    materials: [{
      item: String,
      quantity: Number,
      unitPrice: Number,
      total: Number,
      supplier: String
    }],
    other: [{
      description: String,
      amount: Number
    }],
    
    // Billing
    billable: { type: Boolean, default: false },
    billedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    invoice: { type: mongoose.Schema.Types.ObjectId, ref: 'Invoice' }
  },
  
  // SLA Management
  sla: {
    responseTime: Number, // Hours
    resolutionTime: Number, // Hours
    responseDeadline: Date,
    resolutionDeadline: Date,
    respondedAt: Date,
    breached: { type: Boolean, default: false },
    breachReason: String
  },
  
  // Work Details
  workDetails: {
    diagnosis: String,
    rootCause: String,
    actionTaken: String,
    partsReplaced: [String],
    recommendations: String,
    
    // Checklist
    checklist: [{
      item: String,
      completed: { type: Boolean, default: false },
      completedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      completedAt: Date,
      notes: String
    }],
    
    // Safety
    safety: {
      hazardsIdentified: [String],
      ppe: [String],
      permits: [String],
      incidents: [{
        description: String,
        severity: String,
        reportedAt: Date
      }]
    }
  },
  
  // Quality Control
  quality: {
    inspection: {
      required: { type: Boolean, default: false },
      inspector: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      inspectedAt: Date,
      status: { type: String, enum: ['passed', 'failed', 'conditional'] },
      notes: String
    },
    rating: Number,
    feedback: String
  },
  
  // Attachments
  attachments: [{
    name: String,
    url: String,
    type: { type: String, enum: ['before', 'during', 'after', 'document', 'quotation'] },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now }
  }],
  
  // Comments & Activity
  comments: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    text: String,
    type: { type: String, enum: ['comment', 'note', 'update'] },
    visibility: { type: String, enum: ['internal', 'external'], default: 'internal' },
    timestamp: { type: Date, default: Date.now }
  }],
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Parent/Child Relationships
  parent: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
  children: [{ type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' }],
  
  // Metadata
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  source: { type: String, enum: ['manual', 'email', 'portal', 'phone', 'automatic'] },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 5. INVOICE SCHEMA (WITH ZATCA) ====================
const invoiceSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Invoice Identification
  invoiceNumber: { type: String, unique: true, required: true },
  invoiceType: { 
    type: String, 
    enum: ['standard', 'simplified', 'credit_note', 'debit_note', 'proforma'],
    default: 'standard'
  },
  
  // References
  workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
  contract: { type: mongoose.Schema.Types.ObjectId, ref: 'Contract' },
  previousInvoice: { type: mongoose.Schema.Types.ObjectId, ref: 'Invoice' }, // For credit/debit notes
  
  // Parties
  seller: {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
    name: String,
    vatNumber: String,
    address: String,
    city: String,
    country: String,
    postalCode: String
  },
  
  buyer: {
    type: { type: String, enum: ['individual', 'company'] },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    name: { type: String, required: true },
    vatNumber: String,
    nationalId: String,
    address: String,
    city: String,
    country: String,
    postalCode: String,
    email: String,
    phone: String
  },
  
  // Property Reference
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  unit: String,
  
  // Line Items
  items: [{
    description: { type: String, required: true },
    code: String,
    category: String,
    quantity: { type: Number, required: true },
    unit: String,
    unitPrice: { type: Number, required: true },
    
    // Discounts
    discount: {
      type: { type: String, enum: ['percentage', 'amount'] },
      value: Number,
      amount: Number
    },
    
    // Tax
    tax: {
      rate: { type: Number, default: 15 }, // VAT %
      amount: Number,
      exemptionReason: String
    },
    
    // Totals
    subtotal: Number,
    total: Number
  }],
  
  // Summary
  summary: {
    subtotal: { type: Number, required: true },
    totalDiscount: Number,
    totalTaxExclusive: Number,
    totalVAT: { type: Number, required: true },
    totalWithVAT: { type: Number, required: true },
    prepaidAmount: Number,
    payableAmount: { type: Number, required: true },
    roundingAmount: Number
  },
  
  // Currency
  currency: {
    code: { type: String, default: 'SAR' },
    exchangeRate: { type: Number, default: 1 }
  },
  
  // Dates
  dates: {
    issue: { type: Date, default: Date.now },
    supply: Date,
    due: Date,
    paid: Date
  },
  
  // Payment
  payment: {
    status: { 
      type: String, 
      enum: ['draft', 'sent', 'viewed', 'partial', 'paid', 'overdue', 'cancelled', 'refunded'],
      default: 'draft'
    },
    method: { 
      type: String, 
      enum: ['cash', 'bank_transfer', 'credit_card', 'cheque', 'online'] 
    },
    terms: String,
    
    // Bank Details
    bankDetails: {
      bankName: String,
      accountName: String,
      iban: String,
      swift: String
    },
    
    // Payments Received
    payments: [{
      amount: Number,
      date: Date,
      method: String,
      reference: String,
      receipt: String
    }],
    
    // Balance
    totalPaid: { type: Number, default: 0 },
    balance: Number
  },
  
  // ZATCA Compliance
  zatca: {
    uuid: { type: String, default: () => crypto.randomUUID() },
    hash: String,
    previousHash: String,
    qrCode: String,
    cryptographicStamp: String,
    signedXML: String,
    counter: Number,
    
    // Submission
    submitted: { type: Boolean, default: false },
    submissionDate: Date,
    clearanceStatus: String,
    clearanceDate: Date,
    rejectionReason: String,
    
    // Reporting
    reported: { type: Boolean, default: false },
    reportingDate: Date,
    reportingStatus: String,
    
    // PIH (Previous Invoice Hash)
    pih: String
  },
  
  // Notes & Terms
  notes: String,
  internalNotes: String,
  termsAndConditions: String,
  
  // Delivery
  delivery: {
    method: String,
    address: String,
    date: Date,
    recipient: String,
    notes: String
  },
  
  // Attachments
  attachments: [{
    name: String,
    url: String,
    type: String,
    uploadedAt: { type: Date, default: Date.now }
  }],
  
  // Approval Workflow
  approval: {
    required: { type: Boolean, default: false },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    approvedAt: Date,
    rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rejectedAt: Date,
    rejectionReason: String
  },
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Metadata
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== CONTINUE IN NEXT PART ====================

// COMPLETE FIXZIT SOUQ DATABASE MODELS - PART 2
// File: /models/index.js (continued)

// ==================== 6. VENDOR SCHEMA ====================
const vendorSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  
  // User Account
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  // Company Information
  company: {
    name: { type: String, required: true },
    legalName: String,
    type: { 
      type: String, 
      enum: ['individual', 'company', 'partnership', 'corporation'],
      required: true
    },
    
    // Registration
    registration: {
      commercialNumber: { type: String, required: true },
      vatNumber: { type: String, required: true },
      municipalityLicense: String,
      chamberId: String,
      gosiNumber: String,
      nitaqatRating: { type: String, enum: ['platinum', 'green', 'yellow', 'red'] },
      saudizationPercentage: Number
    },
    
    // Contact
    contact: {
      primaryEmail: { type: String, required: true },
      secondaryEmail: String,
      primaryPhone: { type: String, required: true },
      secondaryPhone: String,
      fax: String,
      website: String,
      
      // Address
      address: {
        street: String,
        city: String,
        state: String,
        country: { type: String, default: 'Saudi Arabia' },
        postalCode: String,
        coordinates: {
          lat: Number,
          lng: Number
        }
      }
    },
    
    // Key Personnel
    keyPersonnel: [{
      name: String,
      position: String,
      email: String,
      phone: String,
      nationalId: String
    }]
  },
  
  // Services & Products
  offerings: {
    categories: [{
      type: String,
      enum: [
        'plumbing',
        'electrical',
        'hvac',
        'carpentry',
        'painting',
        'cleaning',
        'landscaping',
        'security',
        'it_services',
        'general_maintenance',
        'construction',
        'renovation',
        'supplies',
        'equipment'
      ]
    }],
    
    services: [{
      name: { type: String, required: true },
      description: String,
      category: String,
      subcategory: String,
      unit: String,
      
      // Pricing
      pricing: {
        type: { type: String, enum: ['fixed', 'hourly', 'quote'] },
        amount: Number,
        currency: { type: String, default: 'SAR' },
        validFrom: Date,
        validTo: Date
      },
      
      // SLA
      sla: {
        responseTime: Number, // Hours
        resolutionTime: Number, // Hours
        availability: String,
        warranty: String
      },
      
      active: { type: Boolean, default: true }
    }],
    
    // Service Areas
    serviceAreas: [{
      city: String,
      districts: [String],
      surcharge: Number // Additional charge for area
    }]
  },
  
  // Qualifications
  qualifications: {
    certifications: [{
      name: String,
      issuer: String,
      number: String,
      issueDate: Date,
      expiryDate: Date,
      document: String,
      verified: { type: Boolean, default: false }
    }],
    
    licenses: [{
      type: String,
      number: String,
      issuer: String,
      issueDate: Date,
      expiryDate: Date,
      document: String,
      verified: { type: Boolean, default: false }
    }],
    
    insurance: [{
      type: String, // General Liability, Professional, Workers Comp
      provider: String,
      policyNumber: String,
      coverage: Number,
      expiryDate: Date,
      document: String,
      verified: { type: Boolean, default: false }
    }],
    
    // Bank Guarantee
    bankGuarantee: {
      bank: String,
      amount: Number,
      referenceNumber: String,
      validUntil: Date,
      document: String
    }
  },
  
  // Financial
  financial: {
    bankDetails: {
      bankName: String,
      accountName: String,
      accountNumber: String,
      iban: String,
      swift: String,
      branch: String
    },
    
    creditLimit: Number,
    paymentTerms: Number, // Days
    
    // Tax Information
    tax: {
      taxExempt: { type: Boolean, default: false },
      exemptionCertificate: String,
      withholdingTax: Number // Percentage
    }
  },
  
  // Performance & Rating
  performance: {
    rating: { 
      overall: { type: Number, default: 0, min: 0, max: 5 },
      quality: { type: Number, default: 0, min: 0, max: 5 },
      timeliness: { type: Number, default: 0, min: 0, max: 5 },
      price: { type: Number, default: 0, min: 0, max: 5 },
      communication: { type: Number, default: 0, min: 0, max: 5 }
    },
    
    reviews: [{
      reviewer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
      rating: Number,
      comment: String,
      response: String, // Vendor response
      date: { type: Date, default: Date.now }
    }],
    
    statistics: {
      totalJobs: { type: Number, default: 0 },
      completedJobs: { type: Number, default: 0 },
      onTimeDelivery: { type: Number, default: 100 }, // Percentage
      repeatCustomers: { type: Number, default: 0 },
      totalRevenue: { type: Number, default: 0 },
      averageResponseTime: Number, // Hours
      slaBreaches: { type: Number, default: 0 }
    }
  },
  
  // Compliance
  compliance: {
    blacklisted: { type: Boolean, default: false },
    blacklistReason: String,
    blacklistDate: Date,
    
    violations: [{
      type: String,
      description: String,
      date: Date,
      penalty: Number,
      resolved: { type: Boolean, default: false }
    }],
    
    audits: [{
      date: Date,
      auditor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      score: Number,
      findings: String,
      nextAudit: Date
    }]
  },
  
  // Registration & Approval
  registration: {
    status: { 
      type: String, 
      enum: ['pending', 'approved', 'rejected', 'suspended', 'expired'],
      default: 'pending'
    },
    
    submittedAt: { type: Date, default: Date.now },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    approvedAt: Date,
    rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rejectedAt: Date,
    rejectionReason: String,
    
    // Documents
    documents: [{
      type: String,
      name: String,
      url: String,
      verified: { type: Boolean, default: false },
      verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      verifiedAt: Date,
      expiryDate: Date
    }],
    
    // Terms Acceptance
    termsAccepted: { type: Boolean, default: false },
    termsAcceptedAt: Date
  },
  
  // Subscription (for marketplace)
  subscription: {
    plan: { type: String, enum: ['free', 'basic', 'premium', 'enterprise'] },
    status: { type: String, enum: ['active', 'suspended', 'expired'] },
    startDate: Date,
    endDate: Date,
    autoRenew: { type: Boolean, default: true },
    
    // Features
    features: {
      maxBids: Number,
      priorityListing: { type: Boolean, default: false },
      verified: { type: Boolean, default: false },
      analytics: { type: Boolean, default: false }
    }
  },
  
  // Warranty Tracking
  warranties: [{
    product: String,
    serialNumber: String,
    purchaseDate: Date,
    warrantyPeriod: Number, // Months
    expiryDate: Date,
    terms: String,
    claimProcess: String,
    documents: [String]
  }],
  
  // Activity & Stats
  lastActive: Date,
  totalBids: { type: Number, default: 0 },
  wonBids: { type: Number, default: 0 },
  
  // Metadata
  tags: [String],
  notes: String,
  internalNotes: String,
  customFields: mongoose.Schema.Types.Mixed,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 7. RFQ (REQUEST FOR QUOTATION) SCHEMA ====================
const rfqSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Identification
  rfqNumber: { type: String, unique: true, required: true },
  title: { type: String, required: true },
  
  // Related Entities
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
  
  // Category
  category: {
    type: String,
    enum: [
      'maintenance',
      'repair',
      'renovation',
      'construction',
      'supplies',
      'equipment',
      'services'
    ],
    required: true
  },
  subCategory: String,
  
  // Description
  description: { type: String, required: true },
  scope: String,
  specifications: String,
  
  // Items
  items: [{
    description: { type: String, required: true },
    quantity: { type: Number, required: true },
    unit: String,
    specifications: String,
    brand: String,
    model: String,
    attachments: [String]
  }],
  
  // Requirements
  requirements: {
    technical: String,
    commercial: String,
    delivery: String,
    warranty: String,
    payment: String,
    
    // Mandatory Documents
    mandatoryDocuments: [{
      type: String,
      description: String
    }]
  },
  
  // Budget
  budget: {
    estimated: Number,
    maximum: Number,
    currency: { type: String, default: 'SAR' },
    showToVendors: { type: Boolean, default: false }
  },
  
  // Timeline
  timeline: {
    publishDate: { type: Date, default: Date.now },
    submissionDeadline: { type: Date, required: true },
    clarificationDeadline: Date,
    expectedAwardDate: Date,
    deliveryDate: Date,
    completionDate: Date
  },
  
  // Vendor Management
  vendors: {
    invitationType: { 
      type: String, 
      enum: ['open', 'selective', 'direct'],
      default: 'selective'
    },
    invitedVendors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' }],
    minimumVendors: { type: Number, default: 3 },
    maximumVendors: Number
  },
  
  // Bidding Rules
  bidding: {
    allowMultipleBids: { type: Boolean, default: false },
    allowAlternatives: { type: Boolean, default: true },
    allowPartialBids: { type: Boolean, default: false },
    sealedBids: { type: Boolean, default: true },
    
    // Evaluation Criteria
    evaluation: {
      priceWeight: { type: Number, default: 40 },
      technicalWeight: { type: Number, default: 30 },
      experienceWeight: { type: Number, default: 20 },
      deliveryWeight: { type: Number, default: 10 }
    }
  },
  
  // Bids Received
  bids: [{
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor', required: true },
    bidNumber: String,
    
    // Amounts
    amounts: {
      total: { type: Number, required: true },
      currency: { type: String, default: 'SAR' },
      
      // Item-wise Pricing
      items: [{
        itemIndex: Number,
        unitPrice: Number,
        totalPrice: Number,
        notes: String
      }],
      
      // Additional Costs
      additionalCosts: [{
        description: String,
        amount: Number
      }],
      
      discount: {
        type: { type: String, enum: ['percentage', 'amount'] },
        value: Number
      }
    },
    
    // Technical Proposal
    technical: {
      approach: String,
      methodology: String,
      timeline: String,
      team: String,
      equipment: String
    },
    
    // Commercial Terms
    commercial: {
      paymentTerms: String,
      deliveryTerms: String,
      warranty: String,
      validity: Number, // Days
      notes: String
    },
    
    // Documents
    documents: [{
      type: String,
      name: String,
      url: String
    }],
    
    // Clarifications
    clarifications: [{
      question: String,
      answer: String,
      date: Date
    }],
    
    // Status
    status: { 
      type: String, 
      enum: ['draft', 'submitted', 'qualified', 'disqualified', 'shortlisted', 'awarded', 'rejected'],
      default: 'draft'
    },
    
    // Evaluation
    evaluation: {
      technical: {
        score: Number,
        maxScore: Number,
        evaluatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        comments: String
      },
      commercial: {
        score: Number,
        maxScore: Number,
        evaluatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        comments: String
      },
      overall: {
        score: Number,
        rank: Number,
        recommendation: String
      }
    },
    
    // Timestamps
    submittedAt: Date,
    evaluatedAt: Date
  }],
  
  // Q&A / Clarifications
  clarifications: [{
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
    question: String,
    answer: String,
    answeredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    isPublic: { type: Boolean, default: true },
    askedAt: { type: Date, default: Date.now },
    answeredAt: Date
  }],
  
  // Award
  award: {
    status: { 
      type: String, 
      enum: ['pending', 'awarded', 'cancelled', 'failed'],
      default: 'pending'
    },
    awardedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
    awardedAmount: Number,
    awardedAt: Date,
    awardedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    
    // Purchase Order
    purchaseOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'PurchaseOrder' },
    
    // Rejection (for other vendors)
    rejectionLetterSent: { type: Boolean, default: false }
  },
  
  // Status
  status: { 
    type: String, 
    enum: ['draft', 'published', 'closed', 'evaluation', 'awarded', 'cancelled'],
    default: 'draft'
  },
  
  // Approval
  approval: {
    required: { type: Boolean, default: true },
    approvers: [{
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      role: String,
      status: { type: String, enum: ['pending', 'approved', 'rejected'] },
      comments: String,
      date: Date
    }]
  },
  
  // Documents
  attachments: [{
    name: String,
    url: String,
    type: String,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now }
  }],
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Metadata
  tags: [String],
  notes: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 8. INVENTORY SCHEMA ====================
const inventorySchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Item Identification
  sku: { type: String, unique: true, required: true },
  barcode: String,
  qrCode: String,
  
  // Basic Information
  name: { type: String, required: true },
  arabicName: String,
  description: String,
  
  // Category
  category: {
    type: String,
    enum: [
      'spare_parts',
      'consumables',
      'tools',
      'equipment',
      'cleaning_supplies',
      'safety_equipment',
      'office_supplies',
      'raw_materials',
      'finished_goods'
    ],
    required: true
  },
  subCategory: String,
  
  // Specifications
  specifications: {
    brand: String,
    model: String,
    partNumber: String,
    color: String,
    size: String,
    weight: Number,
    dimensions: {
      length: Number,
      width: Number,
      height: Number,
      unit: String
    },
    material: String,
    countryOfOrigin: String
  },
  
  // Units & Packaging
  units: {
    base: { type: String, required: true }, // piece, kg, liter, meter
    purchase: String,
    issue: String,
    
    // Conversion
    conversion: {
      fromUnit: String,
      toUnit: String,
      factor: Number
    }
  },
  
  // Stock Levels
  stock: {
    onHand: { type: Number, default: 0 },
    available: { type: Number, default: 0 },
    allocated: { type: Number, default: 0 },
    onOrder: { type: Number, default: 0 },
    
    // Thresholds
    minimum: { type: Number, default: 0 },
    maximum: Number,
    reorderPoint: { type: Number, default: 0 },
    reorderQuantity: Number,
    safetyStock: Number,
    
    // Locations
    locations: [{
      warehouse: { type: mongoose.Schema.Types.ObjectId, ref: 'Warehouse' },
      location: String,
      shelf: String,
      bin: String,
      quantity: Number
    }]
  },
  
  // Suppliers
  suppliers: [{
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
    supplierSKU: String,
    leadTime: Number, // Days
    minimumOrder: Number,
    unitCost: Number,
    preferred: { type: Boolean, default: false },
    lastPurchaseDate: Date,
    lastPurchasePrice: Number
  }],
  
  // Pricing
  pricing: {
    // Cost
    averageCost: Number,
    lastCost: Number,
    standardCost: Number,
    
    // Selling
    sellingPrice: Number,
    minimumPrice: Number,
    
    // Markup
    markup: Number, // Percentage
    margin: Number, // Percentage
    
    // Price History
    priceHistory: [{
      type: { type: String, enum: ['cost', 'selling'] },
      oldPrice: Number,
      newPrice: Number,
      changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      changedAt: { type: Date, default: Date.now },
      reason: String
    }]
  },
  
  // Tracking
  tracking: {
    trackBySerial: { type: Boolean, default: false },
    trackByBatch: { type: Boolean, default: false },
    trackExpiry: { type: Boolean, default: false },
    
    // Serial Numbers
    serials: [{
      number: String,
      status: { type: String, enum: ['available', 'sold', 'returned', 'damaged'] },
      location: String,
      soldTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      soldDate: Date
    }],
    
    // Batches
    batches: [{
      number: String,
      quantity: Number,
      manufactureDate: Date,
      expiryDate: Date,
      location: String,
      status: String
    }]
  },
  
  // Movement History
  movements: [{
    type: { 
      type: String, 
      enum: ['receipt', 'issue', 'transfer', 'adjustment', 'return', 'damage', 'loss'],
      required: true
    },
    
    // Quantities
    quantity: { type: Number, required: true },
    balanceBefore: Number,
    balanceAfter: Number,
    
    // References
    reference: {
      type: { type: String, enum: ['purchase_order', 'work_order', 'transfer', 'adjustment'] },
      id: mongoose.Schema.Types.ObjectId,
      number: String
    },
    
    // Details
    from: {
      location: String,
      warehouse: { type: mongoose.Schema.Types.ObjectId, ref: 'Warehouse' }
    },
    to: {
      location: String,
      warehouse: { type: mongoose.Schema.Types.ObjectId, ref: 'Warehouse' }
    },
    
    // Cost
    unitCost: Number,
    totalCost: Number,
    
    // Metadata
    reason: String,
    notes: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    date: { type: Date, default: Date.now }
  }],
  
  // Maintenance (for equipment)
  maintenance: {
    required: { type: Boolean, default: false },
    schedule: String,
    lastServiceDate: Date,
    nextServiceDate: Date,
    serviceHistory: [{
      date: Date,
      type: String,
      description: String,
      cost: Number,
      performedBy: String,
      nextService: Date
    }]
  },
  
  // Images & Documents
  media: {
    images: [{
      url: String,
      caption: String,
      isPrimary: { type: Boolean, default: false }
    }],
    documents: [{
      name: String,
      url: String,
      type: String
    }]
  },
  
  // Status & Flags
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'discontinued', 'out_of_stock'],
    default: 'active'
  },
  flags: {
    hazardous: { type: Boolean, default: false },
    fragile: { type: Boolean, default: false },
    perishable: { type: Boolean, default: false },
    highValue: { type: Boolean, default: false },
    controlled: { type: Boolean, default: false }
  },
  
  // Metadata
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 9. CONTRACT SCHEMA ====================
const contractSchema = new mongoose.Schema({
  // Identification
  contractNumber: { type: String, unique: true, required: true },
  title: { type: String, required: true },
  
  // Type
  type: {
    type: String,
    enum: [
      'service',
      'maintenance',
      'lease',
      'purchase',
      'rental',
      'employment',
      'vendor',
      'customer',
      'partnership'
    ],
    required: true
  },
  subType: String,
  
  // Parties
  parties: {
    // First Party (Usually Organization)
    firstParty: {
      type: { type: String, enum: ['organization', 'individual'] },
      organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
      individual: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      name: String,
      role: String,
      signatory: {
        name: String,
        title: String,
        email: String,
        phone: String
      }
    },
    
    // Second Party
    secondParty: {
      type: { type: String, enum: ['vendor', 'customer', 'tenant', 'employee', 'partner'] },
      vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
      customer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      name: String,
      role: String,
      signatory: {
        name: String,
        title: String,
        email: String,
        phone: String
      }
    },
    
    // Witnesses
    witnesses: [{
      name: String,
      nationalId: String,
      signature: String
    }]
  },
  
  // Property/Asset Reference
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  assets: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Asset' }],
  
  // Duration
  duration: {
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    
    // Renewal
    renewal: {
      autoRenew: { type: Boolean, default: false },
      renewalPeriod: Number, // Months
      renewalNotice: Number, // Days before expiry
      maxRenewals: Number,
      renewalCount: { type: Number, default: 0 }
    },
    
    // Termination
    termination: {
      noticePeriod: Number, // Days
      earlyTerminationAllowed: { type: Boolean, default: false },
      penaltyAmount: Number,
      terminationClauses: String
    }
  },
  
  // Financial Terms
  financial: {
    // Value
    totalValue: { type: Number, required: true },
    currency: { type: String, default: 'SAR' },
    
    // Payment Schedule
    paymentSchedule: {
      frequency: { 
        type: String, 
        enum: ['one_time', 'monthly', 'quarterly', 'semi_annual', 'annual'],
        required: true
      },
      amount: Number,
      
      // Installments
      installments: [{
        number: Number,
        amount: Number,
        dueDate: Date,
        description: String,
        status: { type: String, enum: ['pending', 'paid', 'overdue'] },
        paidDate: Date,
        invoice: { type: mongoose.Schema.Types.ObjectId, ref: 'Invoice' }
      }]
    },
    
    // Payment Terms
    paymentTerms: {
      method: String,
      terms: Number, // Days
      latePenalty: Number, // Percentage
      discount: {
        earlyPayment: Number, // Percentage
        days: Number
      }
    },
    
    // Security Deposit
    securityDeposit: {
      amount: Number,
      received: { type: Boolean, default: false },
      receivedDate: Date,
      returnDate: Date,
      deductions: [{
        amount: Number,
        reason: String,
        date: Date
      }]
    },
    
    // Bank Guarantee
    bankGuarantee: {
      required: { type: Boolean, default: false },
      amount: Number,
      bank: String,
      referenceNumber: String,
      validUntil: Date
    }
  },
  
  // Scope & Deliverables
  scope: {
    description: String,
    
    // Deliverables
    deliverables: [{
      description: String,
      quantity: Number,
      unit: String,
      dueDate: Date,
      status: { type: String, enum: ['pending', 'delivered', 'accepted', 'rejected'] },
      deliveredDate: Date,
      acceptedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    }],
    
    // Milestones
    milestones: [{
      name: String,
      description: String,
      dueDate: Date,
      payment: Number,
      status: { type: String, enum: ['pending', 'completed', 'delayed'] },
      completedDate: Date,
      verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    }],
    
    // SLA
    sla: {
      responseTime: Number, // Hours
      resolutionTime: Number, // Hours
      uptime: Number, // Percentage
      penalties: String
    }
  },
  
  // Terms & Conditions
  terms: {
    general: String,
    payment: String,
    delivery: String,
    warranty: String,
    liability: String,
    confidentiality: String,
    disputeResolution: String,
    governingLaw: String,
    specialConditions: String
  },
  
  // Insurance Requirements
  insurance: [{
    type: String,
    coverage: Number,
    provider: String,
    policyNumber: String,
    expiryDate: Date,
    verified: { type: Boolean, default: false }
  }],
  
  // Compliance
  compliance: {
    // Required Documents
    requiredDocuments: [{
      type: String,
      description: String,
      submitted: { type: Boolean, default: false },
      submittedDate: Date,
      verified: { type: Boolean, default: false },
      document: String
    }],
    
    // Certifications
    certifications: [{
      type: String,
      required: { type: Boolean, default: true },
      submitted: { type: Boolean, default: false },
      document: String,
      expiryDate: Date
    }]
  },
  
  // Amendments
  amendments: [{
    number: Number,
    date: Date,
    description: String,
    changes: String,
    document: String,
    approvedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    effectiveDate: Date
  }],
  
  // Signatures & Execution
  execution: {
    status: { 
      type: String, 
      enum: ['draft', 'review', 'pending_signature', 'executed', 'expired', 'terminated'],
      default: 'draft'
    },
    
    // DocuSign Integration
    docusign: {
      envelopeId: String,
      status: String,
      sentDate: Date,
      completedDate: Date,
      document: String
    },
    
    // Manual Signatures
    signatures: [{
      party: String,
      signatory: String,
      signature: String,
      date: Date,
      ip: String
    }],
    
    executionDate: Date
  },
  
  // Documents
  documents: [{
    type: { 
      type: String, 
      enum: ['contract', 'amendment', 'attachment', 'correspondence'] 
    },
    name: String,
    url: String,
    version: Number,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now }
  }],
  
  // Performance
  performance: {
    reviews: [{
      date: Date,
      reviewer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      rating: Number,
      comments: String,
      issues: String,
      recommendations: String
    }],
    
    // KPIs
    kpis: [{
      name: String,
      target: Number,
      actual: Number,
      unit: String,
      period: String,
      status: { type: String, enum: ['met', 'not_met', 'exceeded'] }
    }],
    
    // Penalties/Bonuses
    penalties: [{
      reason: String,
      amount: Number,
      date: Date,
      applied: { type: Boolean, default: false }
    }],
    bonuses: [{
      reason: String,
      amount: Number,
      date: Date,
      paid: { type: Boolean, default: false }
    }]
  },
  
  // Notifications & Alerts
  notifications: {
    renewal: {
      enabled: { type: Boolean, default: true },
      days: { type: [Number], default: [90, 60, 30, 14, 7] }, // Days before expiry
      sentTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      lastSent: Date
    },
    
    expiry: {
      enabled: { type: Boolean, default: true },
      days: { type: [Number], default: [30, 14, 7, 1] },
      sentTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      lastSent: Date
    },
    
    milestone: {
      enabled: { type: Boolean, default: true },
      days: { type: [Number], default: [7, 3, 1] },
      sentTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
    }
  },
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Metadata
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  notes: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== EXPORTS ====================
// COMPLETE FIXZIT SOUQ DATABASE MODELS - PART 3
// File: /models/index.js (continued)

// ==================== 10. EMPLOYEE SCHEMA (HR MODULE) ====================
const employeeSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  // Employee Information
  employeeId: { type: String, unique: true, required: true },
  
  // Personal Information
  personal: {
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    middleName: String,
    arabicName: {
      first: String,
      last: String,
      middle: String
    },
    
    // Identification
    nationalId: {
      number: { type: String, required: true },
      expiryDate: Date,
      copy: String
    },
    passport: {
      number: String,
      nationality: String,
      issueDate: Date,
      expiryDate: Date,
      copy: String
    },
    
    // Contact
    email: { type: String, required: true },
    personalEmail: String,
    mobile: { type: String, required: true },
    alternatePhone: String,
    
    // Address
    currentAddress: {
      street: String,
      city: String,
      state: String,
      country: String,
      postalCode: String
    },
    permanentAddress: {
      street: String,
      city: String,
      state: String,
      country: String,
      postalCode: String
    },
    
    // Personal Details
    dateOfBirth: Date,
    gender: { type: String, enum: ['male', 'female'] },
    maritalStatus: { type: String, enum: ['single', 'married', 'divorced', 'widowed'] },
    bloodGroup: String,
    nationality: String,
    religion: String,
    
    // Emergency Contact
    emergencyContacts: [{
      name: String,
      relationship: String,
      phone: String,
      email: String,
      address: String
    }],
    
    // Family Information
    dependents: [{
      name: String,
      relationship: String,
      dateOfBirth: Date,
      nationalId: String
    }]
  },
  
  // Employment Details
  employment: {
    // Position
    designation: { type: String, required: true },
    department: { type: String, required: true },
    division: String,
    grade: String,
    reportingTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
    
    // Dates
    joiningDate: { type: Date, required: true },
    confirmationDate: Date,
    probationEndDate: Date,
    contractEndDate: Date,
    lastWorkingDate: Date,
    
    // Type
    employmentType: {
      type: String,
      enum: ['permanent', 'contract', 'temporary', 'intern', 'consultant'],
      required: true
    },
    workSchedule: {
      type: String,
      enum: ['full_time', 'part_time', 'flexible'],
      default: 'full_time'
    },
    
    // Location
    location: String,
    workStation: String,
    
    // Status
    status: {
      type: String,
      enum: ['active', 'on_leave', 'suspended', 'terminated', 'resigned'],
      default: 'active'
    },
    
    // Exit Details
    exit: {
      type: String,
      reason: String,
      exitInterview: {
        conducted: { type: Boolean, default: false },
        date: Date,
        feedback: String,
        document: String
      },
      clearance: {
        completed: { type: Boolean, default: false },
        items: [{
          item: String,
          returned: { type: Boolean, default: false },
          date: Date
        }]
      }
    }
  },
  
  // Compensation & Benefits
  compensation: {
    // Salary
    salary: {
      basic: Number,
      housing: Number,
      transport: Number,
      other: [{
        component: String,
        amount: Number
      }],
      total: Number,
      currency: { type: String, default: 'SAR' },
      frequency: { type: String, enum: ['monthly', 'weekly', 'hourly'] }
    },
    
    // Bank Details
    bankDetails: {
      bankName: String,
      accountName: String,
      accountNumber: String,
      iban: String,
      branch: String
    },
    
    // Benefits
    benefits: {
      healthInsurance: {
        enrolled: { type: Boolean, default: false },
        provider: String,
        policyNumber: String,
        coverageAmount: Number,
        dependentsCovered: Number
      },
      lifeInsurance: {
        enrolled: { type: Boolean, default: false },
        provider: String,
        policyNumber: String,
        coverageAmount: Number
      },
      gosi: {
        registered: { type: Boolean, default: false },
        number: String,
        salary: Number
      },
      endOfService: {
        eligible: { type: Boolean, default: true },
        accrued: Number,
        lastCalculation: Date
      }
    },
    
    // Allowances
    allowances: [{
      type: String,
      amount: Number,
      frequency: String,
      startDate: Date,
      endDate: Date
    }],
    
    // Deductions
    deductions: [{
      type: String,
      amount: Number,
      frequency: String,
      startDate: Date,
      endDate: Date
    }]
  },
  
  // Leave Management
  leave: {
    // Entitlements
    entitlements: [{
      type: { 
        type: String, 
        enum: ['annual', 'sick', 'maternity', 'paternity', 'hajj', 'unpaid'] 
      },
      days: Number,
      used: Number,
      balance: Number,
      year: Number
    }],
    
    // Leave Records
    records: [{
      type: String,
      startDate: Date,
      endDate: Date,
      days: Number,
      reason: String,
      status: { 
        type: String, 
        enum: ['pending', 'approved', 'rejected', 'cancelled'] 
      },
      approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
      approvalDate: Date,
      documents: [String],
      notes: String
    }],
    
    // Holidays
    holidays: [{
      name: String,
      date: Date,
      type: { type: String, enum: ['public', 'religious', 'company'] }
    }]
  },
  
  // Attendance
  attendance: {
    // Work Schedule
    schedule: {
      sunday: { start: String, end: String, isWorkingDay: Boolean },
      monday: { start: String, end: String, isWorkingDay: Boolean },
      tuesday: { start: String, end: String, isWorkingDay: Boolean },
      wednesday: { start: String, end: String, isWorkingDay: Boolean },
      thursday: { start: String, end: String, isWorkingDay: Boolean },
      friday: { start: String, end: String, isWorkingDay: Boolean },
      saturday: { start: String, end: String, isWorkingDay: Boolean }
    },
    
    // Attendance Records
    records: [{
      date: Date,
      checkIn: Date,
      checkOut: Date,
      totalHours: Number,
      overtime: Number,
      status: { 
        type: String, 
        enum: ['present', 'absent', 'late', 'early_leave', 'holiday', 'leave'] 
      },
      notes: String
    }],
    
    // Summary
    summary: {
      month: Number,
      year: Number,
      totalDays: Number,
      present: Number,
      absent: Number,
      late: Number,
      leaves: Number,
      overtime: Number
    }
  },
  
  // Payroll
  payroll: {
    // Pay Slips
    payslips: [{
      month: Number,
      year: Number,
      basic: Number,
      allowances: Number,
      deductions: Number,
      net: Number,
      status: { type: String, enum: ['draft', 'approved', 'paid'] },
      paidDate: Date,
      document: String,
      bankReference: String
    }],
    
    // Loans
    loans: [{
      type: String,
      amount: Number,
      installments: Number,
      monthlyDeduction: Number,
      startDate: Date,
      endDate: Date,
      balance: Number,
      status: { type: String, enum: ['active', 'paid', 'defaulted'] }
    }],
    
    // Advances
    advances: [{
      amount: Number,
      reason: String,
      requestDate: Date,
      approvedAmount: Number,
      approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
      approvalDate: Date,
      deductionDate: Date,
      status: { type: String, enum: ['pending', 'approved', 'rejected', 'recovered'] }
    }]
  },
  
  // Documents
  documents: {
    // Required Documents
    required: [{
      type: String,
      name: String,
      submitted: { type: Boolean, default: false },
      document: String,
      verified: { type: Boolean, default: false },
      verified: { type: Boolean, default: false },
      expiryDate: Date,
      reminder: Date
    }],
    
    // Additional Documents
    additional: [{
      type: String,
      name: String,
      document: String,
      uploadedDate: Date
    }]
  },
  
  // Training & Development
  training: {
    // Skills
    skills: [{
      skill: String,
      level: { type: String, enum: ['beginner', 'intermediate', 'advanced', 'expert'] },
      certified: { type: Boolean, default: false }
    }],
    
    // Training Records
    records: [{
      title: String,
      type: { type: String, enum: ['internal', 'external', 'online', 'certification'] },
      provider: String,
      startDate: Date,
      endDate: Date,
      hours: Number,
      cost: Number,
      status: { type: String, enum: ['planned', 'ongoing', 'completed', 'cancelled'] },
      certificate: String,
      score: Number,
      feedback: String
    }],
    
    // Development Plan
    developmentPlan: {
      goals: [{
        goal: String,
        targetDate: Date,
        status: { type: String, enum: ['pending', 'in_progress', 'achieved'] }
      }],
      nextReview: Date
    }
  },
  
  // Performance
  performance: {
    // Reviews
    reviews: [{
      period: String,
      reviewDate: Date,
      reviewer: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
      overallRating: Number,
      
      // Ratings
      ratings: {
        quality: Number,
        productivity: Number,
        knowledge: Number,
        communication: Number,
        teamwork: Number,
        leadership: Number,
        innovation: Number
      },
      
      strengths: String,
      improvements: String,
      goals: String,
      feedback: String,
      employeeComments: String,
      
      status: { type: String, enum: ['draft', 'submitted', 'reviewed', 'finalized'] },
      acknowledgment: {
        acknowledged: { type: Boolean, default: false },
        date: Date
      }
    }],
    
    // Disciplinary Actions
    disciplinary: [{
      type: { type: String, enum: ['verbal_warning', 'written_warning', 'suspension', 'termination'] },
      date: Date,
      reason: String,
      description: String,
      issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
      document: String,
      expiryDate: Date
    }],
    
    // Recognition
    recognition: [{
      type: { type: String, enum: ['appreciation', 'award', 'promotion', 'bonus'] },
      date: Date,
      title: String,
      description: String,
      value: Number,
      givenBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' }
    }]
  },
  
  // Metadata
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 11. TICKET SCHEMA (SUPPORT MODULE) ====================
const ticketSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Identification
  ticketNumber: { type: String, unique: true, required: true },
  
  // Requester
  requester: {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    name: String,
    email: String,
    phone: String,
    type: { type: String, enum: ['tenant', 'owner', 'employee', 'vendor', 'guest'] }
  },
  
  // Property/Unit Reference
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  unit: String,
  
  // Classification
  category: {
    type: String,
    enum: [
      'maintenance',
      'billing',
      'complaint',
      'inquiry',
      'request',
      'feedback',
      'technical',
      'emergency'
    ],
    required: true
  },
  subCategory: String,
  
  // Priority & Severity
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  severity: {
    type: String,
    enum: ['minor', 'moderate', 'major', 'critical'],
    default: 'moderate'
  },
  
  // Details
  subject: { type: String, required: true },
  description: { type: String, required: true },
  
  // Assignment
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  assignedTeam: String,
  assignedAt: Date,
  
  // Status & Workflow
  status: {
    type: String,
    enum: [
      'new',
      'open',
      'assigned',
      'in_progress',
      'pending_customer',
      'pending_third_party',
      'resolved',
      'closed',
      'cancelled'
    ],
    default: 'new'
  },
  
  // Resolution
  resolution: {
    resolvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    resolvedAt: Date,
    resolutionType: {
      type: String,
      enum: ['solved', 'workaround', 'duplicate', 'cannot_reproduce', 'wont_fix']
    },
    resolutionNotes: String,
    rootCause: String
  },
  
  // Related Entities
  relatedTickets: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Ticket' }],
  workOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' },
  
  // SLA
  sla: {
    responseTarget: Date,
    resolutionTarget: Date,
    responseActual: Date,
    resolutionActual: Date,
    breached: { type: Boolean, default: false },
    breachReason: String
  },
  
  // Communication
  communications: [{
    type: { type: String, enum: ['comment', 'email', 'call', 'chat', 'note'] },
    direction: { type: String, enum: ['inbound', 'outbound', 'internal'] },
    from: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    to: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    subject: String,
    message: String,
    attachments: [String],
    isPublic: { type: Boolean, default: true },
    timestamp: { type: Date, default: Date.now }
  }],
  
  // Attachments
  attachments: [{
    name: String,
    url: String,
    type: String,
    size: Number,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now }
  }],
  
  // Customer Satisfaction
  satisfaction: {
    rating: { type: Number, min: 1, max: 5 },
    feedback: String,
    surveyDate: Date,
    surveyLink: String
  },
  
  // Escalation
  escalation: {
    isEscalated: { type: Boolean, default: false },
    escalatedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    escalatedAt: Date,
    escalationLevel: Number,
    escalationReason: String
  },
  
  // Time Tracking
  timeTracking: {
    totalTime: Number, // Minutes
    billableTime: Number,
    entries: [{
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      startTime: Date,
      endTime: Date,
      duration: Number,
      description: String,
      billable: { type: Boolean, default: false }
    }]
  },
  
  // Tags & Custom Fields
  tags: [String],
  customFields: mongoose.Schema.Types.Mixed,
  
  // Source
  source: {
    type: String,
    enum: ['portal', 'email', 'phone', 'chat', 'walk_in', 'automatic'],
    default: 'portal'
  },
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Metadata
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 12. NOTIFICATION SCHEMA ====================
const notificationSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  
  // Recipient
  recipient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  // Type & Category
  type: {
    type: String,
    enum: [
      'work_order',
      'invoice',
      'payment',
      'contract',
      'ticket',
      'approval',
      'reminder',
      'alert',
      'announcement',
      'system'
    ],
    required: true
  },
  category: String,
  
  // Content
  title: { type: String, required: true },
  message: { type: String, required: true },
  arabicTitle: String,
  arabicMessage: String,
  
  // Priority
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  
  // Reference
  reference: {
    model: String,
    id: mongoose.Schema.Types.ObjectId,
    url: String
  },
  
  // Delivery Channels
  channels: {
    inApp: { type: Boolean, default: true },
    email: { type: Boolean, default: false },
    sms: { type: Boolean, default: false },
    push: { type: Boolean, default: false },
    whatsapp: { type: Boolean, default: false }
  },
  
  // Delivery Status
  delivery: {
    inApp: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      read: { type: Boolean, default: false },
      readAt: Date
    },
    email: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      opened: { type: Boolean, default: false },
      openedAt: Date,
      messageId: String
    },
    sms: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      delivered: { type: Boolean, default: false },
      deliveredAt: Date,
      messageId: String
    },
    push: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      received: { type: Boolean, default: false },
      receivedAt: Date
    },
    whatsapp: {
      sent: { type: Boolean, default: false },
      sentAt: Date,
      delivered: { type: Boolean, default: false },
      deliveredAt: Date,
      read: { type: Boolean, default: false },
      readAt: Date,
      messageId: String
    }
  },
  
  // Action Required
  action: {
    required: { type: Boolean, default: false },
    type: { type: String, enum: ['approve', 'reject', 'review', 'respond', 'acknowledge'] },
    url: String,
    deadline: Date,
    completed: { type: Boolean, default: false },
    completedAt: Date,
    completedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  },
  
  // Scheduling
  scheduling: {
    scheduled: { type: Boolean, default: false },
    scheduledFor: Date,
    recurring: { type: Boolean, default: false },
    recurrence: {
      pattern: { type: String, enum: ['daily', 'weekly', 'monthly'] },
      interval: Number,
      endDate: Date
    }
  },
  
  // Metadata
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  expiresAt: Date
});

// ==================== 13. COMPLIANCE SCHEMA ====================
const complianceSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Type
  type: {
    type: String,
    enum: [
      'permit',
      'license',
      'certificate',
      'inspection',
      'audit',
      'violation',
      'fine'
    ],
    required: true
  },
  category: String,
  
  // Details
  name: { type: String, required: true },
  description: String,
  referenceNumber: String,
  
  // Authority
  authority: {
    name: String,
    department: String,
    contactPerson: String,
    phone: String,
    email: String,
    website: String
  },
  
  // Property/Asset Reference
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  assets: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Asset' }],
  
  // Validity
  validity: {
    issueDate: Date,
    expiryDate: Date,
    renewalDate: Date,
    gracePeriod: Number, // Days
    
    // Status
    status: {
      type: String,
      enum: ['valid', 'expired', 'pending_renewal', 'suspended', 'revoked'],
      default: 'valid'
    }
  },
  
  // Requirements
  requirements: [{
    item: String,
    description: String,
    mandatory: { type: Boolean, default: true },
    completed: { type: Boolean, default: false },
    completedDate: Date,
    document: String,
    notes: String
  }],
  
  // Inspection/Audit
  inspection: {
    required: { type: Boolean, default: false },
    frequency: { type: String, enum: ['monthly', 'quarterly', 'semi_annual', 'annual'] },
    lastInspection: {
      date: Date,
      inspector: String,
      result: { type: String, enum: ['passed', 'failed', 'conditional'] },
      report: String,
      findings: String,
      recommendations: String
    },
    nextInspection: Date,
    
    // History
    history: [{
      date: Date,
      inspector: String,
      result: String,
      report: String
    }]
  },
  
  // Violations & Fines
  violations: [{
    date: Date,
    description: String,
    severity: { type: String, enum: ['minor', 'major', 'critical'] },
    fine: Number,
    deadline: Date,
    resolved: { type: Boolean, default: false },
    resolvedDate: Date,
    resolution: String,
    documents: [String]
  }],
  
  // Renewal
  renewal: {
    required: { type: Boolean, default: true },
    reminderDays: { type: [Number], default: [90, 60, 30, 14, 7] }, // Days before expiry
    
    // Process
    process: {
      initiated: { type: Boolean, default: false },
      initiatedDate: Date,
      initiatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      
      // Steps
      steps: [{
        name: String,
        description: String,
        completed: { type: Boolean, default: false },
        completedDate: Date,
        completedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        document: String
      }],
      
      // Payment
      payment: {
        amount: Number,
        paid: { type: Boolean, default: false },
        paidDate: Date,
        receipt: String
      },
      
      // New Document
      newDocument: String,
      newExpiryDate: Date
    }
  },
  
  // Documents
  documents: [{
    type: String,
    name: String,
    url: String,
    version: Number,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: { type: Date, default: Date.now },
    expiryDate: Date
  }],
  
  // Responsible Parties
  responsible: {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    manager: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    alternates: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
  },
  
  // Costs
  costs: {
    application: Number,
    renewal: Number,
    inspection: Number,
    other: [{
      description: String,
      amount: Number,
      date: Date
    }],
    total: Number
  },
  
  // Notifications
  notifications: {
    enabled: { type: Boolean, default: true },
    recipients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    lastSent: Date,
    
    // History
    history: [{
      type: String,
      sentTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      sentAt: Date,
      message: String
    }]
  },
  
  // Activity Log
  activities: [{
    action: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    timestamp: { type: Date, default: Date.now },
    details: mongoose.Schema.Types.Mixed
  }],
  
  // Metadata
  tags: [String],
  notes: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 14. REPORT TEMPLATE SCHEMA ====================
const reportTemplateSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  
  // Identification
  name: { type: String, required: true },
  code: { type: String, unique: true },
  
  // Type
  type: {
    type: String,
    enum: [
      'operational',
      'financial',
      'maintenance',
      'occupancy',
      'vendor',
      'compliance',
      'custom'
    ],
    required: true
  },
  category: String,
  
  // Description
  description: String,
  purpose: String,
  
  // Data Source
  dataSource: {
    modules: [String], // Which modules to pull data from
    collections: [String], // MongoDB collections
    
    // Query
    query: mongoose.Schema.Types.Mixed,
    aggregation: mongoose.Schema.Types.Mixed,
    
    // Filters
    filters: [{
      field: String,
      label: String,
      type: { type: String, enum: ['date', 'select', 'multiselect', 'text', 'number'] },
      required: { type: Boolean, default: false },
      defaultValue: mongoose.Schema.Types.Mixed,
      options: [mongoose.Schema.Types.Mixed]
    }]
  },
  
  // Layout
  layout: {
    orientation: { type: String, enum: ['portrait', 'landscape'], default: 'portrait' },
    pageSize: { type: String, default: 'A4' },
    margins: {
      top: Number,
      bottom: Number,
      left: Number,
      right: Number
    },
    
    // Header
    header: {
      show: { type: Boolean, default: true },
      logo: String,
      title: String,
      subtitle: String,
      showDate: { type: Boolean, default: true },
      showPageNumber: { type: Boolean, default: true }
    },
    
    // Footer
    footer: {
      show: { type: Boolean, default: true },
      text: String,
      showPageNumber: { type: Boolean, default: true }
    }
  },
  
  // Components
  components: [{
    type: { 
      type: String, 
      enum: ['table', 'chart', 'summary', 'text', 'image', 'pagebreak'] 
    },
    
    // Common Properties
    title: String,
    subtitle: String,
    order: Number,
    
    // Table Configuration
    table: {
      columns: [{
        field: String,
        label: String,
        width: Number,
        align: String,
        format: String,
        aggregate: String
      }],
      showTotal: { type: Boolean, default: false },
      groupBy: String,
      sortBy: String
    },
    
    // Chart Configuration
    chart: {
      chartType: { type: String, enum: ['bar', 'line', 'pie', 'donut', 'area'] },
      xAxis: String,
      yAxis: String,
      series: [String],
      colors: [String],
      showLegend: { type: Boolean, default: true },
      showValues: { type: Boolean, default: false }
    },
    
    // Summary Configuration
    summary: {
      metrics: [{
        label: String,
        field: String,
        aggregate: String,
        format: String,
        icon: String
      }]
    },
    
    // Text Configuration
    text: {
      content: String,
      style: mongoose.Schema.Types.Mixed
    }
  }],
  
  // Schedule
  schedule: {
    enabled: { type: Boolean, default: false },
    frequency: { 
      type: String, 
      enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'] 
    },
    time: String,
    dayOfWeek: Number,
    dayOfMonth: Number,
    recipients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    format: { type: String, enum: ['pdf', 'excel', 'csv'], default: 'pdf' },
    lastRun: Date,
    nextRun: Date
  },
  
  // Permissions
  permissions: {
    isPublic: { type: Boolean, default: false },
    roles: [String],
    users: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
  },
  
  // Generated Reports
  generated: [{
    generatedAt: Date,
    generatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    filters: mongoose.Schema.Types.Mixed,
    format: String,
    url: String,
    size: Number,
    rowCount: Number
  }],
  
  // Status
  status: {
    type: String,
    enum: ['draft', 'active', 'inactive'],
    default: 'draft'
  },
  
  // Metadata
  tags: [String],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// ==================== 15. AUDIT LOG SCHEMA ====================
const auditLogSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  
  // Actor
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userDetails: {
    name: String,
    email: String,
    role: String,
    ip: String,
    userAgent: String,
    device: String
  },
  
  // Action
  action: {
    type: String,
    enum: [
      'create',
      'read',
      'update',
      'delete',
      'login',
      'logout',
      'export',
      'import',
      'approve',
      'reject',
      'assign',
      'complete'
    ],
    required: true
  },
  
  // Resource
  resource: {
    model: String,
    id: mongoose.Schema.Types.ObjectId,
    name: String,
    type: String
  },
  
  // Changes
  changes: {
    before: mongoose.Schema.Types.Mixed,
    after: mongoose.Schema.Types.Mixed,
    fields: [String]
  },
  
  // Context
  context: {
    module: String,
    feature: String,
    reason: String,
    notes: String
  },
  
  // Result
  result: {
    success: { type: Boolean, default: true },
    error: String,
    duration: Number // Milliseconds
  },
  
  // Session
  session: {
    id: String,
    startTime: Date,
    endTime: Date
  },
  
  // Timestamp
  timestamp: { type: Date, default: Date.now, index: true }
});

// Create indexes for better query performance
auditLogSchema.index({ organization: 1, timestamp: -1 });
auditLogSchema.index({ 'user': 1, timestamp: -1 });
auditLogSchema.index({ 'resource.model': 1, 'resource.id': 1 });

// ==================== EXPORTS ====================

// ==================== FINAL CONSOLIDATED EXPORT ====================
module.exports = {
  Organization: mongoose.model('Organization', organizationSchema),
  User: mongoose.model('User', userSchema),
  Property: mongoose.model('Property', propertySchema),
  WorkOrder: mongoose.model('WorkOrder', workOrderSchema),
  Invoice: mongoose.model('Invoice', invoiceSchema),
  Vendor: mongoose.model('Vendor', vendorSchema),
  RFQ: mongoose.model('RFQ', rfqSchema),
  Inventory: mongoose.model('Inventory', inventorySchema),
  Contract: mongoose.model('Contract', contractSchema),
  Employee: mongoose.model('Employee', employeeSchema),
  Ticket: mongoose.model('Ticket', ticketSchema),
  Notification: mongoose.model('Notification', notificationSchema),
  Compliance: mongoose.model('Compliance', complianceSchema),
  ReportTemplate: mongoose.model('ReportTemplate', reportTemplateSchema),
  AuditLog: mongoose.model('AuditLog', auditLogSchema)
};
