const mongoose = require('mongoose');

const TenantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  plan: {
    type: String,
    enum: ['basic', 'professional', 'enterprise'],
    default: 'basic'
  },
  settings: {
    currency: {
      type: String,
      default: 'SAR'
    },
    language: {
      type: String,
      default: 'en'
    },
    timeZone: {
      type: String,
      default: 'Asia/Riyadh'
    },
    features: {
      marketplace: {
        type: Boolean,
        default: true
      },
      rfq: {
        type: Boolean,
        default: true
      },
      finance: {
        type: Boolean,
        default: true
      },
      compliance: {
        type: Boolean,
        default: false
      }
    }
  },
  billing: {
    address: String,
    vatNumber: String,
    crNumber: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Tenant', TenantSchema);