const mongoose = require('mongoose');

const doaRuleSchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization',
    required: true,
    index: true 
  },
  
  // Rule Details
  name: { type: String, required: true },
  description: String,
  code: { type: String, unique: true }, // e.g., "WO-HIGH-VALUE"
  
  // Module/Type
  module: { 
    type: String, 
    enum: ['work_order', 'quotation', 'purchase_order', 'invoice', 'contract', 'vendor'],
    required: true 
  },
  
  // Trigger Conditions
  conditions: {
    // Amount Thresholds
    amountFrom: { type: Number, default: 0 },
    amountTo: Number, // null means no upper limit
    
    // Categories
    categories: [String], // e.g., ['electrical', 'plumbing', 'hvac']
    excludeCategories: [String],
    
    // Priority
    priorities: [String], // e.g., ['high', 'emergency']
    
    // Property Types
    propertyTypes: [String], // e.g., ['residential', 'commercial']
    
    // Vendor Types
    vendorTypes: [String],
    
    // Custom Conditions
    customConditions: [{
      field: String,
      operator: { type: String, enum: ['equals', 'not_equals', 'greater_than', 'less_than', 'contains'] },
      value: mongoose.Schema.Types.Mixed
    }]
  },
  
  // Approval Matrix
  approvalLevels: [{
    level: { type: Number, required: true }, // 1, 2, 3...
    name: String, // e.g., "Direct Manager", "Department Head"
    
    // Who can approve at this level
    approvers: {
      type: { 
        type: String, 
        enum: ['specific_users', 'role', 'department', 'reporting_manager', 'property_owner', 'deputy'],
        required: true 
      },
      
      // For specific users
      userIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      
      // For role-based
      roles: [String],
      
      // For department
      departments: [String],
      
      // For dynamic (reporting manager, property owner)
      dynamicField: String // Field to look up dynamically
    },
    
    // Approval Requirements
    requiredApprovals: { type: Number, default: 1 }, // How many must approve
    unanimousRequired: { type: Boolean, default: false }, // All must approve
    
    // Timing
    slaHours: { type: Number, default: 24 }, // Time to approve
    escalateAfterHours: Number, // Auto-escalate after X hours
    autoApproveAfterHours: Number, // Auto-approve if no response
    
    // Escalation
    escalateTo: {
      type: { 
        type: String, 
        enum: ['next_level', 'specific_users', 'role', 'skip'],
      },
      userIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
      roles: [String]
    },
    
    // Notifications
    notificationTemplate: String,
    reminderAfterHours: Number,
    
    // Out of Office
    allowDelegation: { type: Boolean, default: true },
    skipIfOutOfOffice: { type: Boolean, default: false }
  }],
  
  // Workflow Type
  workflowType: { 
    type: String, 
    enum: ['sequential', 'parallel', 'mixed'],
    default: 'sequential' 
  },
  
  // Actions on Approval/Rejection
  onApproval: {
    updateStatus: String,
    triggerWebhook: String,
    sendNotifications: [String],
    executeScript: String
  },
  
  onRejection: {
    updateStatus: String,
    allowResubmission: { type: Boolean, default: true },
    notifyInitiator: { type: Boolean, default: true }
  },
  
  // Settings
  isActive: { type: Boolean, default: true },
  priority: { type: Number, default: 0 }, // Higher priority rules evaluated first
  effectiveFrom: Date,
  effectiveUntil: Date,
  
  // Audit
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  lastModifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { 
  timestamps: true 
});

// Approval Request Schema
const approvalRequestSchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization',
    required: true,
    index: true 
  },
  
  // What needs approval
  requestType: { 
    type: String, 
    enum: ['work_order', 'quotation', 'purchase_order', 'invoice', 'contract', 'vendor'],
    required: true 
  },
  
  requestId: { 
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    index: true 
  },
  
  // DoA Rule Applied
  doaRuleId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'DoARule',
    required: true 
  },
  
  // Request Details
  title: String,
  description: String,
  amount: Number,
  currency: { type: String, default: 'SAR' },
  priority: String,
  category: String,
  
  // Requester
  requestedBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  
  requestedAt: { type: Date, default: Date.now },
  
  // Property Reference (if applicable)
  propertyId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Property' 
  },
  
  // Overall Status
  status: { 
    type: String, 
    enum: ['pending', 'approved', 'rejected', 'cancelled', 'expired'],
    default: 'pending',
    index: true 
  },
  
  // Current approval level
  currentLevel: { type: Number, default: 1 },
  
  // Approval Steps
  approvalSteps: [{
    level: Number,
    approverIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    requiredApprovals: Number,
    receivedApprovals: Number,
    
    status: { 
      type: String, 
      enum: ['pending', 'approved', 'rejected', 'skipped', 'escalated'],
      default: 'pending' 
    },
    
    approvals: [{
      approverId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      decision: { type: String, enum: ['approved', 'rejected'] },
      comments: String,
      approvedAt: Date,
      ipAddress: String,
      userAgent: String
    }],
    
    // Timing
    assignedAt: Date,
    dueAt: Date,
    completedAt: Date,
    escalatedAt: Date,
    
    // Reminders sent
    remindersSent: [{ sentAt: Date, type: String }]
  }],
  
  // Final decision
  finalDecision: { 
    type: String, 
    enum: ['approved', 'rejected'] 
  },
  finalDecisionBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  },
  finalDecisionAt: Date,
  finalComments: String,
  
  // SLA tracking
  sla: {
    deadline: Date,
    breached: { type: Boolean, default: false },
    breachedAt: Date
  },
  
  // Escalation history
  escalationHistory: [{
    fromLevel: Number,
    toLevel: Number,
    reason: String,
    escalatedAt: Date,
    escalatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  
  // Notifications sent
  notificationHistory: [{
    type: String,
    recipients: [String],
    sentAt: Date,
    template: String,
    success: Boolean
  }],
  
  // Attachments
  attachments: [{
    filename: String,
    url: String,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    uploadedAt: Date
  }],
  
  // Comments thread
  comments: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    comment: String,
    createdAt: { type: Date, default: Date.now },
    type: { type: String, enum: ['comment', 'system'] }
  }],
  
  // Metadata
  metadata: mongoose.Schema.Types.Mixed,
  externalReference: String
}, { 
  timestamps: true 
});

// Indexes
doaRuleSchema.index({ organizationId: 1, module: 1, isActive: 1 });
doaRuleSchema.index({ 'conditions.amountFrom': 1, 'conditions.amountTo': 1 });

approvalRequestSchema.index({ organizationId: 1, status: 1 });
approvalRequestSchema.index({ requestType: 1, requestId: 1 });
approvalRequestSchema.index({ requestedBy: 1, status: 1 });
approvalRequestSchema.index({ 'sla.deadline': 1 });

// Methods
doaRuleSchema.methods.matchesConditions = function(requestData) {
  const conditions = this.conditions;
  
  // Check amount
  if (requestData.amount) {
    if (requestData.amount < conditions.amountFrom) return false;
    if (conditions.amountTo && requestData.amount > conditions.amountTo) return false;
  }
  
  // Check categories
  if (conditions.categories && conditions.categories.length > 0) {
    if (!conditions.categories.includes(requestData.category)) return false;
  }
  
  if (conditions.excludeCategories && conditions.excludeCategories.length > 0) {
    if (conditions.excludeCategories.includes(requestData.category)) return false;
  }
  
  // Check priority
  if (conditions.priorities && conditions.priorities.length > 0) {
    if (!conditions.priorities.includes(requestData.priority)) return false;
  }
  
  return true;
};

approvalRequestSchema.methods.advance = async function() {
  const currentStep = this.approvalSteps.find(step => step.level === this.currentLevel);
  
  if (currentStep && currentStep.status === 'approved') {
    // Move to next level
    const nextLevel = this.currentLevel + 1;
    const nextStep = this.approvalSteps.find(step => step.level === nextLevel);
    
    if (nextStep) {
      this.currentLevel = nextLevel;
      nextStep.status = 'pending';
      nextStep.assignedAt = new Date();
      
      // Set due date based on SLA
      const doaRule = await mongoose.model('DoARule').findById(this.doaRuleId);
      const levelConfig = doaRule.approvalLevels.find(level => level.level === nextLevel);
      if (levelConfig && levelConfig.slaHours) {
        nextStep.dueAt = new Date(Date.now() + levelConfig.slaHours * 60 * 60 * 1000);
      }
    } else {
      // Final approval
      this.status = 'approved';
      this.finalDecision = 'approved';
      this.finalDecisionAt = new Date();
    }
  }
  
  await this.save();
};

module.exports = {
  DoARule: mongoose.model('DoARule', doaRuleSchema),
  ApprovalRequest: mongoose.model('ApprovalRequest', approvalRequestSchema)
};