const mongoose = require('mongoose');

// Contract Schema - Complete Implementation as per User's Specification
const ContractSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant', required: true },
  contractNumber: { type: String, unique: true },
  type: { type: String, enum: ['service', 'maintenance', 'lease', 'purchase'] },
  title: { type: String, required: true },
  party: {
    type: { type: String, enum: ['vendor', 'customer', 'tenant'] },
    id: { type: mongoose.Schema.Types.ObjectId, refPath: 'party.type' }
  },
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  startDate: Date,
  endDate: Date,
  value: Number,
  paymentTerms: String,
  status: { type: String, enum: ['draft', 'active', 'expired', 'terminated'], default: 'draft' },
  autoRenew: { type: Boolean, default: false },
  documents: [{
    name: String,
    url: String,
    type: String,
    uploadedAt: { type: Date, default: Date.now }
  }],
  terms: [{
    clause: String,
    description: String
  }],
  renewalHistory: [{
    renewedDate: Date,
    newEndDate: Date,
    renewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Add indexes for performance
ContractSchema.index({ organization: 1, status: 1 });
ContractSchema.index({ tenantId: 1 });
ContractSchema.index({ contractNumber: 1 });
ContractSchema.index({ endDate: 1 });
ContractSchema.index({ 'party.id': 1, 'party.type': 1 });
ContractSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Contract', ContractSchema);