const mongoose = require('mongoose');

// RFQ (Request for Quotation) Schema - Complete Implementation as per User's Specification
const RFQSchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
  tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant', required: true },
  rfqNumber: { type: String, unique: true },
  title: { type: String, required: true },
  description: String,
  property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
  category: String,
  items: [{
    description: String,
    quantity: Number,
    unit: String,
    specifications: String
  }],
  budget: {
    min: Number,
    max: Number
  },
  deliveryDate: Date,
  submissionDeadline: Date,
  status: { type: String, enum: ['draft', 'published', 'closed', 'awarded', 'cancelled'], default: 'draft' },
  invitedVendors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' }],
  bids: [{
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
    totalAmount: Number,
    items: [{
      itemId: String,
      unitPrice: Number,
      totalPrice: Number
    }],
    deliveryTime: String,
    validUntil: Date,
    notes: String,
    attachments: [String],
    status: { type: String, enum: ['submitted', 'shortlisted', 'awarded', 'rejected'], default: 'submitted' },
    submittedAt: { type: Date, default: Date.now }
  }],
  awardedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' },
  awardedDate: Date,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('RFQ', RFQSchema);