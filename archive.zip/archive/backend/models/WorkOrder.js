const mongoose = require('mongoose');
const logger = require('../utils/logger');

const workOrderSchema = new mongoose.Schema({
  // Work Order Identification
  workOrderNumber: { type: String, unique: true },
  
  // Core Fields
  title: { type: String, required: true },
  description: String,
  priority: { 
    type: String, 
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  
  // CRITICAL: Enhanced References for proper linking
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true,
    index: true
  },
  
  propertyId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Property',
    required: true,
    index: true  // CRITICAL: Index for fast property queries
  },
  
  unitId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Unit'
  },
  
  // Status Tracking
  status: {
    type: String,
    enum: ['draft', 'open', 'assigned', 'in_progress', 'on_hold',
           'pending_quotation', 'pending_approval', 'approved', 
           'completed', 'closed', 'cancelled'],
    default: 'draft',
    index: true
  },
  
  // People Involved
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  
  assignedTeam: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Team'
  },
  
  // ENHANCED: Cost Tracking for Property Owner Dashboard
  costTracking: {
    // Estimated Costs
    estimated: {
      labor: { type: Number, default: 0 },
      materials: { type: Number, default: 0 },
      equipment: { type: Number, default: 0 },
      other: { type: Number, default: 0 },
      total: { type: Number, default: 0 }
    },
    
    // Actual Costs
    actual: {
      labor: { type: Number, default: 0 },
      materials: { type: Number, default: 0 },
      equipment: { type: Number, default: 0 },
      other: { type: Number, default: 0 },
      total: { type: Number, default: 0 }
    },
    
    // Variance
    variance: {
      amount: { type: Number, default: 0 },
      percentage: { type: Number, default: 0 }
    },
    
    // Billing
    billable: { type: Boolean, default: true },
    billedTo: {
      type: { type: String, enum: ['tenant', 'owner', 'organization', 'warranty'] },
      entityId: mongoose.Schema.Types.ObjectId
    },
    
    // Invoice Reference
    invoiceId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Invoice'
    },
    invoiceStatus: {
      type: String,
      enum: ['not_invoiced', 'invoiced', 'paid', 'disputed'],
      default: 'not_invoiced'
    }
  },
  
  category: {
    type: String,
    enum: ['HVAC', 'Plumbing', 'Electrical', 'General', 'Cleaning', 'Security', 'Landscaping'],
    required: true
  },
  
  // Enhanced Materials Used
  materials: [{
    itemId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'InventoryItem'
    },
    name: String,
    quantity: Number,
    unit: String,
    unitCost: Number,
    totalCost: Number,
    source: {
      type: String,
      enum: ['inventory', 'purchased', 'vendor_supplied']
    },
    vendorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Vendor'
    }
  }],
  
  // Labor Tracking
  laborTracking: [{
    technicianId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    startTime: Date,
    endTime: Date,
    hours: Number,
    hourlyRate: Number,
    totalCost: Number,
    overtimeHours: Number,
    overtimeCost: Number,
    description: String
  }],
  
  // Important Dates
  dates: {
    created: { type: Date, default: Date.now },
    assigned: Date,
    started: Date,
    completed: Date,
    closed: Date,
    cancelled: Date,
    lastUpdated: { type: Date, default: Date.now }
  },
  
  // SLA & Timing
  sla: {
    priority: String,
    responseTime: Number, // hours
    resolutionTime: Number, // hours
    deadline: Date,
    breached: { type: Boolean, default: false },
    breachedAt: Date
  },
  
  // Photos & Documents
  attachments: [{
    type: {
      type: String,
      enum: ['before', 'during', 'after', 'quotation', 'invoice', 'other']
    },
    url: String,
    thumbnailUrl: String,
    fileName: String,
    fileSize: Number,
    mimeType: String,
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    uploadedAt: Date,
    description: String
  }],
  
  // Legacy fields for backward compatibility
  estimatedCost: Number,
  actualCost: Number,
  beforePhotos: [String],
  afterPhotos: [String],
  laborHours: Number,
  technicianNotes: String,
  requiresApproval: Boolean,
  approvalStatus: String,
  slaBreachTime: Date,
  completedAt: Date,
  
  // System
  tenantId: { type: String, required: true }
}, { 
  timestamps: true 
});

// Indexes for performance
workOrderSchema.index({ organizationId: 1, status: 1 });
workOrderSchema.index({ propertyId: 1, status: 1 });
workOrderSchema.index({ assignedTo: 1, status: 1 });
workOrderSchema.index({ 'dates.created': -1 });
workOrderSchema.index({ 'sla.deadline': 1 });
workOrderSchema.index({ 'costTracking.invoiceStatus': 1 });

// Methods for cost calculations
workOrderSchema.methods.calculateCostVariance = function() {
  const estimatedTotal = this.costTracking.estimated.total;
  const actualTotal = this.costTracking.actual.total;
  
  this.costTracking.variance.amount = actualTotal - estimatedTotal;
  this.costTracking.variance.percentage = estimatedTotal > 0 
    ? ((actualTotal - estimatedTotal) / estimatedTotal) * 100 
    : 0;
};

workOrderSchema.methods.updateActualCosts = function() {
  // Calculate labor costs
  let laborCost = 0;
  this.laborTracking.forEach(entry => {
    laborCost += entry.totalCost + (entry.overtimeCost || 0);
  });
  this.costTracking.actual.labor = laborCost;
  
  // Calculate material costs
  let materialCost = 0;
  this.materials.forEach(material => {
    materialCost += material.totalCost || 0;
  });
  this.costTracking.actual.materials = materialCost;
  
  // Update total
  this.costTracking.actual.total = 
    this.costTracking.actual.labor +
    this.costTracking.actual.materials +
    this.costTracking.actual.equipment +
    this.costTracking.actual.other;
  
  // Calculate variance
  this.calculateCostVariance();
  
  // Update legacy field for backward compatibility
  this.actualCost = this.costTracking.actual.total;
};

// CRITICAL: Middleware to update property statistics for Property Owner Dashboard
workOrderSchema.post('save', async function(doc, next) {
  if (doc.propertyId) {
    const Property = mongoose.model('Property');
    const WorkOrder = mongoose.model('WorkOrder');
    
    try {
      // Count work orders for property with cost aggregation
      const stats = await WorkOrder.aggregate([
        { 
          $match: { 
            propertyId: doc.propertyId 
          } 
        },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            totalCost: { $sum: '$costTracking.actual.total' },
            totalEstimatedCost: { $sum: '$costTracking.estimated.total' }
          }
        }
      ]);
      
      // Calculate totals
      let totalWorkOrders = 0;
      let activeWorkOrders = 0;
      let totalMaintenanceCost = 0;
      let totalEstimatedCost = 0;
      
      stats.forEach(stat => {
        totalWorkOrders += stat.count;
        totalMaintenanceCost += stat.totalCost || 0;
        totalEstimatedCost += stat.totalEstimatedCost || 0;
        
        if (!['closed', 'cancelled'].includes(stat._id)) {
          activeWorkOrders += stat.count;
        }
      });
      
      // Update property with maintenance statistics
      await Property.findByIdAndUpdate(doc.propertyId, {
        'maintenanceHistory': {
          $push: {
            workOrder: doc._id,
            date: doc.dates.created,
            cost: doc.costTracking.actual.total || doc.actualCost || 0
          }
        },
        $set: {
          'statistics.totalWorkOrders': totalWorkOrders,
          'statistics.activeWorkOrders': activeWorkOrders,
          'statistics.totalMaintenanceCost': totalMaintenanceCost,
          'statistics.lastMaintenanceDate': doc.dates.created
        }
      });
      
    } catch (error) {
    logger.error('Error in WorkOrder.js:', error);
    throw error;
  }
  }
  
  next();
});

module.exports = mongoose.model('WorkOrder', workOrderSchema);