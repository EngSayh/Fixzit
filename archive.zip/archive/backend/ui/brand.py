import os
import base64
import streamlit as st

BRAND_ORANGE = "#F6851F"
BRAND_NAVY = "#023047"


def ensure_brand_theme() -> None:
    # Load Disparador if present
    for fp in (
        "assets/fonts/Disparador-Regular.ttf",
        "assets/fonts/Disparador-Regular.ttf",
    ):
        if os.path.exists(fp):
            b64 = base64.b64encode(open(fp, "rb").read()).decode("utf-8")
            st.markdown(
                f"""
            <style>
            @font-face {{
              font-family:'Disparador';
              src:url(data:font/ttf;base64,{b64}) format('truetype');
              font-weight:400; font-style:normal; font-display:swap;
            }}
            :root {{ --fx-font:'Disparador',-apple-system,system-ui,'Segoe UI',Roboto,Arial,'Noto Sans',sans-serif; }}
            html,body,[class^="css"] {{ font-family: var(--fx-font); }}
            </style>""",
                unsafe_allow_html=True,
            )
            break

    # Brand tokens + buttons
    st.markdown(
        f"""
    <style>
      :root {{ --fx-orange:{BRAND_ORANGE}; --fx-navy:{BRAND_NAVY}; }}
      .stButton>button, button[kind="primary"] {{
        background: var(--fx-orange); color:#fff; border:none; border-radius:12px;
      }}
      .stButton>button:hover {{ filter: brightness(.97); }}
      a {{ color: var(--fx-navy); }}
    </style>
    """,
        unsafe_allow_html=True,
    )


def logo_data_url() -> str | None:
    for p in (
        "assets/logo.svg",
        "assets/logo.png",
        "assets/logo.jpg",
        "assets/logo.jpeg",
        "assets/fixzit_logo.svg",
        "assets/fixzit_logo.png",
    ):
        if os.path.exists(p):
            ext = p.split(".")[-1].lower()
            mime = (
                "image/svg+xml"
                if ext == "svg"
                else ("image/jpeg" if ext in ("jpg", "jpeg") else "image/png")
            )
            import base64

            return f"data:{mime};base64,{base64.b64encode(open(p,'rb').read()).decode('utf-8')}"
    return None
