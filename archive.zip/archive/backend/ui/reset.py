# ui/reset.py
import streamlit as st
import streamlit.components.v1 as components

# If you created a brand helper earlier, this call is safe. If not, it's a no-op.
try:
    from ui.brand import ensure_brand_theme
except Exception:

    def ensure_brand_theme():  # fallback stub
        pass


def activate_app_chrome(
    open_sidebar: bool = True, hide_default_nav: bool = False
) -> None:
    """
    Call this at the VERY TOP of EVERY non-login page.
    - Removes any login-only CSS/classes
    - Ensures the sidebar is visible and OPEN
    - Optionally hides Streamlit's default page list (set hide_default_nav=True if you render your own sidebar)
    """
    # 1) Leave "login" mode completely and remove any critical CSS that hid the sidebar
    components.html(
        """
    <script>
    (function(){
      const d=(window.parent||window).document;
      d.body.classList.remove('fx-login');
      const crit=d.getElementById('fxCritical'); if(crit) crit.remove();

      // Force OPEN the sidebar and keep it open across re-renders
      function openSB(){
        const sb = d.querySelector('section[data-testid="stSidebar"]');
        const cc = d.querySelector('[data-testid="collapsedControl"]');  // Streamlit toggle
        const nav= d.querySelector('[data-testid="stSidebarNav"]');

        if (sb) {
          const hidden = getComputedStyle(sb).display==='none' || sb.offsetWidth===0;
          if (hidden && cc) cc.click();  // click the toggle if collapsed
          sb.style.display   = 'block';
          sb.style.minWidth  = '280px';
          sb.style.width     = '280px';
          sb.style.transform = 'translateX(0)';
          sb.removeAttribute('hidden');
        }
        if (nav){ nav.style.display='block'; nav.removeAttribute('hidden'); }
      }
      openSB();
      new MutationObserver(openSB).observe(d.body,{childList:true,subtree:true});
    })();
    </script>
    """,
        height=0,
    )

    # 2) Brand theme (colors/fonts) if available
    ensure_brand_theme()

    # 3) App padding & (optional) hide default Streamlit page list
    css = [
        "<style>",
        "body:not(.fx-login) main .block-container{padding-top:1rem;padding-bottom:max(1rem, env(safe-area-inset-bottom));}",
    ]
    if hide_default_nav:
        css.append('[data-testid="stSidebarNav"]{display:none !important;}')
    css.append("</style>")
    st.markdown("\n".join(css), unsafe_allow_html=True)


def clean_sidebar() -> None:
    """Clean sidebar styling that might have leaked from login page"""
    st.markdown(
        """
    <style>
    /* Reset sidebar visibility */
    section[data-testid="stSidebar"] {
        display: block !important;
    }
    
    /* Clean workspace styling */
    .main .block-container {
        padding-top: 1rem;
        padding-bottom: 1rem;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )
