# ui/branding.py
import os
import json
import base64
import streamlit as st
from pathlib import Path

CFG_PATH = Path("config/branding.json")
ASSETS = Path("assets")
LOGO_CAND = ["logo_custom.png", "logo_custom.jpg", "logo.png", "logo.jpg", "logo.svg"]
DEFAULTS = {
    "company": "Fixzit",
    "primary": "#F6851F",
    "text": "#023047",
    "bg": "#FFFFFF",
    "logo": None,
}


def _ensure_dirs():
    (ASSETS / "fonts").mkdir(parents=True, exist_ok=True)
    CFG_PATH.parent.mkdir(parents=True, exist_ok=True)


def load_branding() -> dict:
    _ensure_dirs()
    data = DEFAULTS.copy()
    if CFG_PATH.exists():
        try:
            data.update(json.loads(CFG_PATH.read_text()))
        except Exception:
            pass
    for name in LOGO_CAND:
        p = ASSETS / name
        if p.exists():
            data["logo"] = str(p)
            break
    return data


def save_branding(**updates):
    _ensure_dirs()
    data = load_branding()
    data.update(updates)
    CFG_PATH.write_text(
        json.dumps(
            {
                "company": data["company"],
                "primary": data["primary"],
                "text": data["text"],
                "bg": data["bg"],
                "logo": data.get("logo"),
            },
            indent=2,
        )
    )
    return data


def logo_data_url() -> str | None:
    data = load_branding()
    p = data.get("logo")
    if not p or not os.path.exists(p):
        return None
    ext = os.path.splitext(p)[1].lower()
    mime = (
        "image/svg+xml"
        if ext == ".svg"
        else ("image/jpeg" if ext in (".jpg", ".jpeg") else "image/png")
    )
    b64 = base64.b64encode(open(p, "rb").read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def apply_brand_theme():
    b = load_branding()
    # Optional brand font (Disparador) if present
    font_css = ""
    for fp in (
        ASSETS / "fonts" / "Disparador-Regular.ttf",
        Path("assets/fonts/Disparador-Regular.ttf"),
    ):
        if fp.exists():
            b64 = base64.b64encode(open(fp, "rb").read()).decode("utf-8")
            font_css = f"""
            @font-face {{
              font-family:'Disparador';
              src:url(data:font/ttf;base64,{b64}) format('truetype');
              font-display:swap; font-weight:400;
            }}
            :root {{ --fx-font:'Disparador',-apple-system,system-ui,'Segoe UI',Roboto,Arial,'Noto Sans',sans-serif; }}
            html,body,[class^="css"] {{ font-family: var(--fx-font); }}
            """
            break

    st.markdown(
        f"""
    <style>
      {font_css}
      :root {{ --fx-primary:{b['primary']}; --fx-text:{b['text']}; --fx-bg:{b['bg']}; }}
      .stButton>button, button[kind="primary"] {{
        background: var(--fx-primary); color:#fff; border:none; border-radius:12px;
      }}
      .stButton>button:hover {{ filter: brightness(.97); }}
      a {{ color: var(--fx-text); }}
    </style>
    """,
        unsafe_allow_html=True,
    )
    return b
