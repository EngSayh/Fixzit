# ui/nav/universal_nav.py
# This file now serves as a wrapper for the new Firebase-style navigation
# It maintains backward compatibility with existing code

import sys
import os

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from navigation import render_sidebar as firebase_render_sidebar


def render_sidebar(
    show_on_this_page: bool = True, active_path: str | None = None
) -> str:
    """
    Wrapper function for backward compatibility
    Renders the Firebase-style accordion sidebar

    Args:
        show_on_this_page: Whether to show sidebar on this page (False for login/signup)
        active_path: Legacy parameter for active page (not used in new system)

    Returns:
        Current route ID or None if sidebar is hidden
    """
    # Only render sidebar if we should show it on this page
    if not show_on_this_page:
        return ""

    # Call the new Firebase-style sidebar (no parameters needed)
    result = firebase_render_sidebar()
    return result if result else ""
