# Fixzit/ui/router.py
import os
import streamlit as st
import streamlit.components.v1 as components


def _exists(path: str) -> bool:
    try:
        return os.path.exists(path)
    except Exception:
        return False


def goto_dashboard() -> bool:
    """
    Switch to the dashboard page. Try multiple likely filenames.
    Return True if we switched, else False (caller can JS-redirect).
    """
    candidates = [
        # most common names/locations
        "pages/01_Dashboard_WorkOS.py",
        "pages/Dashboard_WorkOS.py",
        "pages/020_Dashboard_WorkOS.py",
        "pages/020_Dashboard.py",
        "pages/Dashboard.py",
    ]
    for p in candidates:
        if _exists(p):
            try:
                st.switch_page(p)  # Streamlit ≥1.22
                return True
            except Exception:
                pass
    # JS fallback: change the path to proper Streamlit format
    components.html(
        """
        <script>
          // Redirect to the proper Streamlit dashboard page
          if (window.parent) {
            window.parent.location.href = window.parent.location.origin + '/01_Dashboard_WorkOS';
          } else {
            window.location.href = window.location.origin + '/01_Dashboard_WorkOS';
          }
        </script>
    """,
        height=0,
    )
    return False
