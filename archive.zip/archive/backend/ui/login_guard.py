# ui/login_guard.py
import streamlit.components.v1 as components


def enforce_clean_login_dom():
    """
    Hard-cleans the Streamlit container on /Login so ONLY the login card remains.
    Kills any hero/banner/image siblings, removes extra top padding, and ensures
    background hero images can't reappear. Works together with CSS fallback.
    """
    components.html(
        """
    <script>
    (function(){
      const d=(window.parent||window).document;
      d.body.classList.add('fx-login-hard');   // mark login page

      function isKeeper(node){
        if(!node || !node.classList) return false;
        return node.classList.contains('auth-card') || node.classList.contains('fx-keep');
      }

      function clean(){
        const app  = d.querySelector('[data-testid="stAppViewContainer"]');
        const main = d.querySelector('main .block-container');
        if(app){ app.style.paddingTop = '0px'; app.style.marginTop = '0px'; }
        if(!main) return;

        // Hide every direct child that is not the login card / explicit keeper.
        Array.from(main.children).forEach(node=>{
          if(isKeeper(node)) return;
          node.style.setProperty('display','none','important');
          node.style.setProperty('height','0','important');
          node.style.setProperty('margin','0','important');
          node.style.setProperty('padding','0','important');
          node.style.setProperty('overflow','hidden','important');
          node.setAttribute('data-fx-hidden','1');
        });

        // Also nuke Streamlit header/sidebar controls if injected
        const header = d.querySelector('header[data-testid="stHeader"]');
        if(header){ header.style.display='none'; header.style.height='0'; }

        const collapsed = d.querySelector('[data-testid="collapsedControl"]');
        if(collapsed){ collapsed.style.display='none'; }
      }

      clean(); new MutationObserver(clean).observe(d.body,{childList:true,subtree:true});
    })();
    </script>
    <style>
      /* CSS fallback in case JS executes late */
      header[data-testid="stHeader"]{ display:none !important; height:0 !important; }
      body.fx-login-hard main .block-container{ padding-top:8px !important; margin-top:0 !important; }
      body.fx-login-hard main .block-container > :not(.auth-card):not(.fx-keep){
        display:none !important; height:0 !important; overflow:hidden !important; margin:0 !important; padding:0 !important;
      }
      body.fx-login-hard{ background-image:none !important; }
    </style>
    """,
        height=0,
    )
