# ui/layout.py
import streamlit as st
import streamlit.components.v1 as components


def login_chrome_off():
    """Use only on the Login page. Removes top header & sidebar and fixes top gap permanently."""
    st.set_page_config(layout="centered", initial_sidebar_state="collapsed")

    # 1) Hide header + sidebar at the DOM level and keep them hidden across re-renders
    components.html(
        """
    <script>
    (function(){
      const d=(window.parent||window).document;
      d.body.classList.add('fx-login');
      function hide(){
        // Hide Streamlit header (top toolbar) and all sidebar variants
        const sel=[
          'header[data-testid="stHeader"]',
          'section[data-testid="stSidebar"]',
          '[data-testid="stSidebarNav"]',
          'aside[aria-label="sidebar"]',
          '[data-testid="collapsedControl"]'
        ];
        for(const s of sel){
          const el=d.querySelector(s);
          if(el){ el.style.display='none'; el.style.width='0'; el.style.minWidth='0'; el.style.transform='translateX(-100vw)'; }
        }
        const hb=d.querySelector('button[kind="hamburger"]'); if(hb){ hb.style.display='none'; }
      }
      hide(); new MutationObserver(hide).observe(d.body,{childList:true,subtree:true});
    })();
    </script>
    """,
        height=0,
    )

    # 2) Remove the page's default top padding and any extra margins
    st.markdown(
        """
    <style id="fxLoginLayout">
      /* Kill the top white band by fully removing the header area */
      header[data-testid="stHeader"]{ display:none !important; height:0 !important; overflow:hidden; }

      /* Tight, predictable padding for the main container on login */
      body.fx-login main .block-container{
        padding-top: 8px !important;
        padding-bottom: max(12px, env(safe-area-inset-bottom));
      }

      /* No accidental top margin on wrappers */
      .auth-wrap{ margin: 8px auto 24px !important; }
    </style>
    """,
        unsafe_allow_html=True,
    )
