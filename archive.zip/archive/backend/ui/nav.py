# ui/nav.py
import os
import streamlit as st
import streamlit.components.v1 as components
from ui.branding import apply_brand_theme, load_branding, logo_data_url

# ====== Define your modules → submodules here (edit this dictionary only) ======
NAV_TREE = {
    "Workspace": {
        "🏠 Dashboard": ("dashboard", "workos"),
        "📊 My work": ("my", "work"),
        "🔔 Notifications": ("notification",),
    },
    "Boards": {
        "🏢 Properties": ("properties", "workos"),
        "🎫 Tickets": {
            "📋 All tickets": ("tickets", "workos"),
            "🆕 Open": ("tickets", "open"),
            "⏰ SLA": ("tickets", "sla"),
            "📈 Reports": ("ticket", "report"),
        },
        "📄 Contracts": ("contracts", "workos"),
        "💳 Payments": ("payments", "workos"),
        "💼 Financials": {
            "📊 Overview": ("financials",),
            "🧾 Invoices": ("invoice",),
            "💸 Expenses": ("expense",),
        },
    },
    "Apps": {
        "⚡ Automations": ("automations", "workos"),
        "📊 Analytics": ("analytics", "workos"),
        "🛍️ Marketplace": ("marketplace", "workos"),
    },
    "Admin": {
        "🧪 Code Quality": ("code", "quality"),
        "🏳️ Feature Flags": ("feature", "flags"),
        "🛠️ Remote Config": ("remote", "config"),
        "📦 Module Manager": ("module", "manager"),
        "🎨 Branding": ("095", "loginbranding"),
        "👥 Users": ("users", "workos"),
        "⚙️ Settings": ("settings", "workos"),
    },
}


def _norm(s: str) -> str:
    return "".join(ch.lower() for ch in s if ch.isalnum())


def _find_page(*keywords) -> str | None:
    """Find a Streamlit page by keywords in filename"""
    if not keywords:
        return None
    keys = [_norm(k) for k in keywords if k]
    if not keys:
        return None

    for root in ("pages", "."):
        if not os.path.isdir(root):
            continue
        for dp, _, files in os.walk(root):
            for f in files:
                if not f.endswith(".py"):
                    continue
                nf = _norm(f)
                if all(k in nf for k in keys):
                    return os.path.join(dp, f)
    return None


def _render_nav_item(label: str, target, level: int = 0):
    """Render a single navigation item (with nested support)"""
    if isinstance(target, dict):
        # This is a submenu - use expander
        expanded = st.session_state.get(f"nav_expanded_{_norm(label)}", False)
        with st.sidebar.expander(label, expanded=expanded):
            for sublabel, subtarget in target.items():
                _render_nav_item(sublabel, subtarget, level + 1)
        # Update expansion state
        st.session_state[f"nav_expanded_{_norm(label)}"] = expanded
    elif isinstance(target, tuple):
        # Keywords to search for
        path = _find_page(*target)
        if path:
            if st.sidebar.button(
                label, key=f"nav_{_norm(label)}_{level}", use_container_width=True
            ):
                st.switch_page(path)
        else:
            st.sidebar.write(f"• {label} (not found)")
    elif isinstance(target, str):
        # Direct file path
        if os.path.exists(target):
            if st.sidebar.button(
                label, key=f"nav_{_norm(label)}_{level}", use_container_width=True
            ):
                st.switch_page(target)
        else:
            st.sidebar.write(f"• {label} (missing)")


def boot_nav_auto():
    """Universal bootstrap - call this at the top of every non-login page"""

    # 1. Remove login CSS + force sidebar visible + hide old nav
    components.html(
        """
    <script>
    (function(){
      const d = (window.parent || window).document;
      d.body.classList.remove('fx-login');
      
      // Remove login-only CSS
      const crit = d.getElementById('fxCritical'); 
      if(crit) crit.remove();
      
      // Force sidebar open and visible
      function openSB(){
        const sb = d.querySelector('section[data-testid="stSidebar"]');
        const cc = d.querySelector('[data-testid="collapsedControl"]');
        const nav = d.querySelector('[data-testid="stSidebarNav"]');
        
        if (sb) {
          const hidden = getComputedStyle(sb).display === 'none' || sb.offsetWidth === 0;
          if (hidden && cc) cc.click();
          sb.style.display = 'block';
          sb.style.minWidth = '280px';
          sb.style.width = '280px';
          sb.style.transform = 'translateX(0)';
          sb.removeAttribute('hidden');
        }
        
        // Hide Streamlit's default page navigation
        if (nav) { 
          nav.style.display = 'none'; 
          nav.setAttribute('hidden', 'true'); 
        }
      }
      
      openSB();
      new MutationObserver(openSB).observe(d.body, {childList: true, subtree: true});
    })();
    </script>
    """,
        height=0,
    )

    # 2. Apply branding theme
    apply_brand_theme()

    # 3. Custom sidebar styling
    st.markdown(
        """
    <style>
    [data-testid="stSidebarNav"] { display: none !important; }
    .nav-header {
        padding: 16px 0;
        border-bottom: 1px solid #e6e9ef;
        margin-bottom: 16px;
        text-align: center;
    }
    .nav-header img {
        height: 40px;
        width: auto;
        margin-bottom: 8px;
    }
    .stButton > button {
        width: 100%;
        text-align: left;
        background: transparent;
        border: none;
        color: #676879;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
    }
    .stButton > button:hover {
        background: #f6f7fb;
        color: var(--fx-text);
    }
    .stExpander {
        border: none;
        box-shadow: none;
    }
    .stExpander > details > summary {
        background: transparent;
        color: var(--fx-text);
        font-weight: 600;
        padding: 8px 12px;
        border-radius: 6px;
    }
    .stExpander > details > summary:hover {
        background: #f6f7fb;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )

    # 4. Header with logo and company name
    with st.sidebar:
        st.markdown('<div class="nav-header">', unsafe_allow_html=True)

        logo_url = logo_data_url()
        if logo_url:
            st.markdown(f'<img src="{logo_url}" alt="Logo">', unsafe_allow_html=True)

        brand = load_branding()
        st.markdown(
            f'<div style="font-weight: 600; color: var(--fx-text);">{brand["company"]}</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div style="color: #676879; font-size: 12px;">Work OS</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        # 5. Render navigation sections
        for section_name, items in NAV_TREE.items():
            # Check user role access
            user_role = st.session_state.get("user_role", "tenant")
            if section_name == "Admin" and user_role not in ["admin"]:
                continue

            st.markdown(f"**{section_name}**")
            for label, target in items.items():
                _render_nav_item(label, target)
            st.markdown("---")
