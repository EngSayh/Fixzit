# ui/auth_providers.py
import json
import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path

CFG = Path("config/auth.json")
DEFAULT = {
    "google": {"enabled": True},
    "apple": {"enabled": True},
    "email_magic": {"enabled": True},
}


def load_auth_cfg() -> dict:
    CFG.parent.mkdir(parents=True, exist_ok=True)
    if CFG.exists():
        try:
            data = DEFAULT.copy()
            data.update(json.loads(CFG.read_text()))
            return data
        except Exception:
            pass
    CFG.write_text(json.dumps(DEFAULT, indent=2))
    return DEFAULT


def _authorize_url(provider: str) -> str:
    try:
        from auth.multi_auth import MultiAuthManager

        return MultiAuthManager().oauth_authorize_url(provider, "/AuthCallback") or "#"
    except Exception:
        return "#"


def send_magic_link(email: str):
    try:
        from auth.multi_auth import MultiAuthManager

        ok = MultiAuthManager().send_magic_link(email)
        if ok:
            st.success("We've sent you a sign‑in link. Check your inbox.")
        else:
            st.error("Could not send the sign‑in link.")
    except Exception as ex:
        st.warning(f"Magic‑link email is not available: {ex}")


def render_provider_row():
    cfg = load_auth_cfg()
    google_url = _authorize_url("google") if cfg["google"]["enabled"] else "#"
    apple_url = _authorize_url("apple") if cfg["apple"]["enabled"] else "#"

    html = """
    <style>
      .fx-social { display:flex; gap:12px; flex-wrap:wrap; }
      .fx-provider { display:flex; align-items:center; gap:10px; justify-content:center;
                      height:44px; border-radius:8px; padding:0 16px; text-decoration:none;
                      font-weight:600; letter-spacing:.2px; }
      .fx-provider span { white-space:nowrap; }
      .fx-google { background:#fff; color:#3c4043; border:1px solid #dadce0; }
      .fx-google:hover { box-shadow:0 1px 1px rgba(0,0,0,.1); }
      .fx-apple  { background:#000; color:#fff; }
      .fx-apple:hover { filter:brightness(.96); }
      .fx-provider svg{ width:18px; height:18px; }
    </style>
    <div class="fx-social">
    """
    if cfg["google"]["enabled"]:
        html += f"""
        <a class="fx-provider fx-google" href="{google_url}">
          <svg viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#EA4335" d="M24 9.5c3.5 0 6 1.5 7.4 2.8l5.1-5.1C33.6 4.6 29.2 3 24 3 14.7 3 6.9 8.3 3.5 16l6.8 5.3C12 15.5 17.5 9.5 24 9.5z"/>
            <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-2.7-.4-3.9H24v7.4h12.7c-.3 2-1.9 5-5.3 7.1l6.1 4.7c3.6-3.3 9-8.3 9-15.3z"/>
            <path fill="#FBBC04" d="M10.3 28.4c-.5-1.5-.8-3.2-.8-4.9s.3-3.4.8-4.9L3.5 13.3C2 16.6 1.2 20.2 1.2 23.5s.8 6.9 2.3 10.2l6.8-5.3z"/>
            <path fill="#34A853" d="M24 45c6.5 0 12-2.1 16-5.8l-6.1-4.7c-3.2 2.1-5.9 3.3-9.9 3.3-6.5 0-12-4.3-14-10.1l-6.8 5.3C7 40.2 14.7 45 24 45z"/>
          </svg>
          <span>Sign in with Google</span>
        </a>
        """
    if cfg["apple"]["enabled"]:
        html += f"""
        <a class="fx-provider fx-apple" href="{apple_url}">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path fill="#fff" d="M16.365 1.43c.01 1.1-.41 2.1-1.2 2.9-.77.8-1.84 1.3-2.95 1.2-.09-1.06.43-2.1 1.2-2.9.76-.8 1.99-1.3 2.95-1.2zM21 17.4c-.36.83-.78 1.6-1.28 2.32-.68.98-1.4 1.94-2.54 1.96-1.11.02-1.46-.64-2.72-.64s-1.66.62-2.71.66c-1.1.04-1.94-1.05-2.62-2.03-1.43-2.06-2.52-5.8-1.05-8.35.73-1.27 2.02-2.08 3.45-2.1 1.07-.02 2.08.7 2.72.7.64 0 1.87-.86 3.16-.73.54.02 2.07.22 3.05 1.66-.08.05-1.82 1.07-1.8 3.03.02 2.41 2.2 3.21 2.24 3.22z"/>
          </svg>
          <span>Sign in with Apple</span>
        </a>
        """
    html += "</div>"
    components.html(html, height=120, scrolling=False)

    if cfg["email_magic"]["enabled"]:
        with st.expander("✉️  Use personal email (magic link)"):
            email = st.text_input(
                "Email", key="magic_email", placeholder="someone@example.com"
            )
            if st.button("Send sign‑in link", type="primary"):
                if email.strip():
                    send_magic_link(email.strip())
                else:
                    st.warning("Please enter a valid email.")
