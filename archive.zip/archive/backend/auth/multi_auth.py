# Fixzit/auth/multi_auth.py
from __future__ import annotations
import os
import logging
from typing import Optional, Dict, Any, List, Tuple
import bcrypt
import psycopg2
from psycopg2.extras import RealDictCursor, RealDictRow

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _get_conn():
    url = os.getenv("DATABASE_URL")
    if url:
        return psycopg2.connect(url, cursor_factory=RealDictCursor)
    return psycopg2.connect(
        host=os.getenv("PGHOST", "localhost"),
        port=os.getenv("PGPORT", "5432"),
        dbname=os.getenv("PGDATABASE", "fixzit"),
        user=os.getenv("PGUSER", "postgres"),
        password=os.getenv("PGPASSWORD", "postgres"),
        cursor_factory=RealDictCursor,
    )


class MultiAuthManager:
    """Authenticate against either:
    (A) users_enhanced + subscriptions   OR
    (B) users + user_subscriptions
    """

    LOCK_THRESHOLD = 5

    def __init__(self):
        self._conn_factory = _get_conn
        self.users_table = "users_enhanced"
        self.mode = "enhanced"
        self.sub_table = "subscriptions"
        self._detect_schema()

    def authenticate_user(self, email: str, password: str) -> Optional[Dict[str, Any]]:
        email = (email or "").strip().lower()
        if not email or not password:
            return None
        try:
            with self._conn_factory() as conn, conn.cursor() as cur:
                user = (
                    self._fetch_user_enhanced(cur, email)
                    if self.mode == "enhanced"
                    else self._fetch_user_classic(cur, email)
                )
                if not user:
                    logger.info("User not found: %s", email)
                    return None

                # Convert to dict for safe access
                user_dict = dict(user) if user else {}

                user_id = user_dict.get("id")
                if not user_id:
                    return None

                pw_hash = user_dict.get("password_hash", "")
                if user_dict.get("account_locked") or not user_dict.get(
                    "is_active", True
                ):
                    return None

                ok = False
                try:
                    ok = bcrypt.checkpw(
                        password.encode("utf-8"), pw_hash.encode("utf-8")
                    )
                except Exception:
                    ok = False

                if not ok:
                    new_attempts = int(user_dict.get("login_attempts", 0)) + 1
                    self._update_lock_state(
                        cur,
                        conn,
                        user_id,
                        new_attempts,
                        new_attempts >= self.LOCK_THRESHOLD,
                    )
                    return None

                self._reset_lock_state(cur, conn, user_id)
                status, expiry = self._fetch_subscription(
                    cur, user_dict.get("subscription_ref")
                )

                role = (user_dict.get("role") or "user").lower()
                return {
                    "id": user_id,
                    "email": (user_dict.get("email") or "").lower(),
                    "full_name": user_dict.get("full_name", ""),
                    "role": role,
                    "modules": self.get_user_modules_by_role(role),
                    "subscription_status": status,
                    "subscription_expiry": expiry,
                    "last_login": user_dict.get("last_login"),
                }
        except Exception as e:
            logger.exception("authenticate_user error for %s: %s", email, e)
            return None

    # ---- schema detection / fetchers ----
    def _detect_schema(self):
        try:
            with self._conn_factory() as conn, conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                      EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='users_enhanced') AS has_ue,
                      EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='subscriptions') AS has_subs,
                      EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='users') AS has_u,
                      EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='user_subscriptions') AS has_us
                """
                )
                result = cur.fetchone()
                r = dict(result) if result else {}

                if r.get("has_ue"):
                    self.users_table, self.mode = "users_enhanced", "enhanced"
                elif r.get("has_u"):
                    self.users_table, self.mode = "users", "classic"

                if r.get("has_subs"):
                    self.sub_table = "subscriptions"
                elif r.get("has_us"):
                    self.sub_table = "user_subscriptions"
        except Exception as e:
            logger.exception("Schema detection failed: %s", e)

    def _fetch_user_enhanced(self, cur, email: str) -> Optional[RealDictRow]:
        cur.execute(
            """
          SELECT id, email, password_hash,
                 COALESCE(full_name,'') AS full_name,
                 COALESCE(user_role,'user') AS role,
                 COALESCE(is_active, TRUE) AS is_active,
                 COALESCE(account_locked, FALSE) AS account_locked,
                 COALESCE(login_attempts, 0) AS login_attempts,
                 last_login,
                 subscription_id AS subscription_ref
            FROM users_enhanced
           WHERE LOWER(email)=%s
        """,
            (email,),
        )
        return cur.fetchone()

    def _fetch_user_classic(self, cur, email: str) -> Optional[RealDictRow]:
        cur.execute(
            """
          SELECT id, email, password_hash,
                 TRIM(CONCAT(COALESCE(first_name,''),' ',COALESCE(last_name,''))) AS full_name,
                 COALESCE(role,'user') AS role,
                 COALESCE(is_active, TRUE) AS is_active,
                 COALESCE(account_locked, FALSE) AS account_locked,
                 COALESCE(login_attempts, 0) AS login_attempts,
                 last_login,
                 id AS subscription_ref
            FROM users
           WHERE LOWER(email)=%s
        """,
            (email,),
        )
        return cur.fetchone()

    def _fetch_subscription(self, cur, ref: Any) -> Tuple[str, Any]:
        try:
            if self.mode == "enhanced" and self.sub_table == "subscriptions" and ref:
                cur.execute(
                    "SELECT COALESCE(subscription_status,'active') AS status, end_date FROM subscriptions WHERE id=%s",
                    (ref,),
                )
                row = cur.fetchone()
                if row:
                    row_dict = dict(row)
                    return (row_dict.get("status", "active"), row_dict.get("end_date"))
                return ("active", None)

            if self.mode == "classic" and self.sub_table == "user_subscriptions":
                cur.execute(
                    """
                    SELECT COALESCE(is_active, TRUE) AS is_active, expiry_date
                      FROM user_subscriptions
                     WHERE user_id=%s
                  ORDER BY expiry_date DESC
                     LIMIT 1
                """,
                    (ref,),
                )
                row = cur.fetchone()
                if row:
                    row_dict = dict(row)
                    is_active = row_dict.get("is_active", True)
                    expiry_date = row_dict.get("expiry_date")
                    return ("active" if is_active else "expired", expiry_date)
                return ("active", None)
        except Exception:
            pass
        return ("active", None)

    # ---- lock helpers ----
    def _update_lock_state(self, cur, conn, user_id: int, attempts: int, lock: bool):
        table = "users_enhanced" if self.mode == "enhanced" else "users"
        cur.execute(
            f"UPDATE {table} SET login_attempts=%s, account_locked=%s WHERE id=%s",
            (attempts, lock, user_id),
        )
        conn.commit()

    def _reset_lock_state(self, cur, conn, user_id: int):
        table = "users_enhanced" if self.mode == "enhanced" else "users"
        cur.execute(
            f"UPDATE {table} SET login_attempts=0, account_locked=FALSE, last_login=NOW() WHERE id=%s",
            (user_id,),
        )
        conn.commit()

    # ---- utilities ----
    @staticmethod
    def get_user_modules_by_role(role: str) -> List[str]:
        r = (role or "user").lower()
        if r in ("super_admin", "admin"):
            return ["All"]
        if r in ("manager", "corporate"):
            return [
                "Boards",
                "Properties",
                "Contracts",
                "Payments",
                "Users",
                "Analytics",
                "Settings",
            ]
        if r == "employee":
            return ["Boards", "Tickets", "Payments"]
        return ["Boards", "Tickets"]

    @staticmethod
    def hash_password(plain: str) -> str:
        return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    # Backward compatibility methods
    def authenticate_user_auto_detect(
        self, email: str, password: str
    ) -> Optional[Dict[str, Any]]:
        """Backward compatibility wrapper"""
        return self.authenticate_user(email, password)

    def check_subscription_expiry(self, user_id: int) -> Tuple[bool, Optional[Any]]:
        """Check subscription status - simplified"""
        return True, None  # Default to active

    def get_user_modules(self, login_type: str) -> List[str]:
        """Backward compatibility for module access"""
        return self.get_user_modules_by_role(login_type)
    
    # OAuth/SSO Methods (placeholder implementations)
    def oauth_authorize_url(self, provider: str, callback_url: str = "/AuthCallback") -> Optional[str]:
        """Generate OAuth authorization URL - placeholder implementation"""
        logger.warning(f"OAuth provider '{provider}' not configured. Add OAuth configuration.")
        
        # OAuth is not fully configured, return None to disable the functionality
        return None
    
    def send_magic_link(self, email: str) -> bool:
        """Send magic link email - placeholder implementation"""
        logger.warning(f"Magic link email not configured for {email}. Add email service configuration.")
        
        # Magic link is not configured, return False
        return False
    
    def complete_oauth(self, provider: str, code: str) -> Optional[Dict[str, Any]]:
        """Complete OAuth flow - placeholder implementation"""
        logger.warning(f"OAuth completion not configured for provider '{provider}'. Add OAuth configuration.")
        
        # OAuth completion is not configured, return None
        return None
