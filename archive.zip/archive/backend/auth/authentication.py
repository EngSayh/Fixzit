import bcrypt
import re
import secrets
import string
from datetime import datetime, timedelta
from utils.database import get_db_connection
from psycopg2.extras import RealDictCursor
from auth.otp_service import verify_otp


class AuthManager:
    def __init__(self):
        pass

    def validate_email(self, email):
        """Validate email format"""
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        return re.match(pattern, email) is not None

    def validate_phone(self, phone):
        """Validate phone format"""
        # Remove spaces and special characters
        phone_clean = re.sub(r"[^0-9+]", "", phone)
        # Check if it's a valid format (basic validation)
        return len(phone_clean) >= 10 and len(phone_clean) <= 15

    def hash_password(self, password):
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    def verify_password(self, password, hashed):
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))

    def register_user(
        self,
        first_name,
        last_name,
        email,
        phone,
        national_id,
        password,
        created_by_admin_id=None,
        role=None,
        nationality=None,
        country=None,
        phone_country_code=None,
        preferred_currency=None,
    ):
        """Register a new user (tenant or employee) with enhanced international fields"""
        conn = get_db_connection()
        if not conn:
            return False, "Database connection failed"

        try:
            # Validate inputs
            if not self.validate_email(email):
                return False, "Invalid email format"

            if not self.validate_phone(phone):
                return False, "Invalid phone format"

            if len(password) < 6:
                return False, "Password must be at least 6 characters"

            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Check if user already exists
            cur.execute(
                """
                SELECT id FROM users 
                WHERE email = %s OR phone = %s OR national_id = %s
            """,
                (email, phone, national_id),
            )

            if cur.fetchone():
                return (
                    False,
                    "User with this email, phone, or national ID already exists",
                )

            # Hash password
            password_hash = self.hash_password(password)

            # Determine role and created_by based on who is creating the user
            # Default role is tenant, but can be overridden when needed
            if role is None:
                role = "tenant" if created_by_admin_id is None else "employee"

            # Set default values for new international fields
            if nationality is None:
                nationality = "SA"
            if country is None:
                country = "SA"
            if phone_country_code is None:
                phone_country_code = "+966"
            if preferred_currency is None:
                preferred_currency = "SAR"

            # Set financial permissions based on role
            can_manage_margin = role in ["super_admin", "ceo"]
            can_view_financial = role in ["super_admin", "ceo", "finance", "admin"]
            can_modify_commission = role in ["super_admin", "ceo"]
            permission_level = {
                "super_admin": 5,
                "ceo": 4,
                "admin": 3,
                "finance": 3,
                "employee": 2,
                "tenant": 1,
            }.get(role, 1)

            # Insert new user with enhanced fields and financial permissions
            cur.execute(
                """
                INSERT INTO users (first_name, last_name, email, phone, national_id, password_hash, role, created_by,
                                 nationality, country, phone_country_code, preferred_currency,
                                 can_manage_software_margin, can_view_financial_settings, can_modify_commission_rates, 
                                 permission_level, department, last_permission_update, permission_updated_by)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, %s)
                RETURNING id
            """,
                (
                    first_name,
                    last_name,
                    email,
                    phone,
                    national_id,
                    password_hash,
                    role,
                    created_by_admin_id,
                    nationality,
                    country,
                    phone_country_code,
                    preferred_currency,
                    can_manage_margin,
                    can_view_financial,
                    can_modify_commission,
                    permission_level,
                    "General",
                    created_by_admin_id,
                ),
            )

            result = cur.fetchone()
            if result:
                user_id = result[0] if isinstance(result, tuple) else result["id"]
                conn.commit()
            else:
                return False, "Failed to create user account"

            # For now, skip OTP verification since Twilio credentials aren't configured
            # This will be enabled once user provides Twilio credentials
            print(f"User {user_id} registered successfully, skipping OTP for now")
            return (
                True,
                "Registration successful! You can now log in with your credentials.",
            )

        except Exception as e:
            print(f"Registration exception: {type(e).__name__}: {str(e)}")
            if conn:
                conn.rollback()
            return False, f"Registration failed: {str(e)}"
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def authenticate_user(self, login_input, password):
        """Authenticate user with email, phone, or national ID"""
        conn = get_db_connection()
        if not conn:
            return None

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Try to find user by email, phone, or national ID
            # First try to identify the input type, then try all if ambiguous
            user_data = None

            if "@" in login_input:
                # Clearly an email
                cur.execute("SELECT * FROM users WHERE email = %s", (login_input,))
                user_data = cur.fetchone()
            elif login_input.isdigit() or "+" in login_input:
                # Clearly a phone number
                cur.execute("SELECT * FROM users WHERE phone = %s", (login_input,))
                user_data = cur.fetchone()
            else:
                # Could be email, phone, or national ID - try all
                # Try email first
                cur.execute("SELECT * FROM users WHERE email = %s", (login_input,))
                user_data = cur.fetchone()

                # If not found, try phone
                if not user_data:
                    cur.execute("SELECT * FROM users WHERE phone = %s", (login_input,))
                    user_data = cur.fetchone()

                # If still not found, try national ID
                if not user_data:
                    cur.execute(
                        "SELECT * FROM users WHERE national_id = %s", (login_input,)
                    )
                    user_data = cur.fetchone()

            if user_data and self.verify_password(password, user_data["password_hash"]):
                # Convert to dictionary
                user = {
                    "id": user_data["id"],
                    "first_name": user_data["first_name"],
                    "last_name": user_data["last_name"],
                    "email": user_data["email"],
                    "phone": user_data["phone"],
                    "national_id": user_data["national_id"],
                    "role": user_data["role"],
                    "language": user_data["language"],
                    "is_verified": user_data["is_verified"],
                }
                return user

            return None

        except Exception as e:
            print(f"Authentication error: {e}")
            return None
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def update_user_location(self, user_id, lat, lng):
        """Update user location"""
        conn = get_db_connection()
        if not conn:
            return False

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute(
                """
                UPDATE users 
                SET location_lat = %s, location_lng = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """,
                (lat, lng, user_id),
            )

            conn.commit()
            return True

        except Exception as e:
            print(f"Location update error: {e}")
            conn.rollback()
            return False
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def verify_phone_number(self, phone, otp_code):
        """Verify phone number with OTP"""
        if verify_otp(phone, otp_code):
            # Update user verification status
            conn = get_db_connection()
            if conn:
                try:
                    cur = conn.cursor(cursor_factory=RealDictCursor)
                    cur.execute(
                        """
                        UPDATE users 
                        SET is_verified = TRUE, updated_at = CURRENT_TIMESTAMP
                        WHERE phone = %s
                    """,
                        (phone,),
                    )
                    conn.commit()
                    return True
                except Exception as e:
                    print(f"Verification update error: {e}")
                    conn.rollback()
                finally:
                    if "cur" in locals():
                        cur.close()
                    conn.close()

        return False

    def find_contracts_by_national_id(self, national_id):
        """Find contracts by national ID for auto-fetch"""
        conn = get_db_connection()
        if not conn:
            return []

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute(
                """
                SELECT c.*, p.name as property_name, p.address, u.unit_number
                FROM contracts c
                JOIN users usr ON c.tenant_id = usr.id
                JOIN properties p ON c.property_id = p.id
                JOIN units u ON c.unit_id = u.id
                WHERE usr.national_id = %s
                ORDER BY c.created_at DESC
            """,
                (national_id,),
            )

            contracts = cur.fetchall()
            return contracts

        except Exception as e:
            print(f"Contract lookup error: {e}")
            return []
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def verify_contract_manually(
        self, contract_number, tenant_name, start_date, end_date
    ):
        """Manually verify contract details"""
        conn = get_db_connection()
        if not conn:
            return None

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute(
                """
                SELECT c.*, u.first_name, u.last_name, p.name as property_name
                FROM contracts c
                JOIN users u ON c.tenant_id = u.id
                JOIN properties p ON c.property_id = p.id
                WHERE c.contract_number = %s 
                AND c.start_date = %s 
                AND c.end_date = %s
                AND (LOWER(u.first_name || ' ' || u.last_name) = LOWER(%s)
                     OR LOWER(u.first_name) = LOWER(%s)
                     OR LOWER(u.last_name) = LOWER(%s))
            """,
                (
                    contract_number,
                    start_date,
                    end_date,
                    tenant_name,
                    tenant_name,
                    tenant_name,
                ),
            )

            contract = cur.fetchone()
            return contract

        except Exception as e:
            print(f"Manual contract verification error: {e}")
            return None
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def check_field_availability(self, field_name, field_value):
        """Check if email, phone, or national_id is already registered"""
        conn = get_db_connection()
        if not conn:
            return True  # Assume available if DB error

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            query = f"SELECT COUNT(*) as count FROM users WHERE {field_name} = %s"
            cur.execute(query, (field_value,))
            result = cur.fetchone()
            return result["count"] == 0  # Return True if available (count is 0)
        except Exception as e:
            print(f"Field availability check error: {e}")
            return True
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def generate_password_reset_token(self, email_or_phone):
        """Generate password reset token"""
        conn = get_db_connection()
        if not conn:
            return False, "Database connection failed"

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Find user by email or phone
            if "@" in email_or_phone:
                cur.execute("SELECT id FROM users WHERE email = %s", (email_or_phone,))
            else:
                cur.execute("SELECT id FROM users WHERE phone = %s", (email_or_phone,))

            user = cur.fetchone()
            if not user:
                return False, "No account found with this email or phone number"

            # Generate secure token
            token = "".join(
                secrets.choice(string.ascii_letters + string.digits) for i in range(32)
            )
            expires_at = datetime.now() + timedelta(hours=1)  # Token expires in 1 hour

            # Store token in database
            cur.execute(
                """
                INSERT INTO password_reset_tokens (user_id, token, expires_at)
                VALUES (%s, %s, %s)
            """,
                (user["id"], token, expires_at),
            )

            conn.commit()

            # In a real implementation, send email/SMS with the token
            # For now, we'll just return the token
            return True, token

        except Exception as e:
            print(f"Password reset token generation error: {e}")
            conn.rollback()
            return False, "Failed to generate reset token"
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def reset_password_with_token(self, token, new_password):
        """Reset password using token"""
        conn = get_db_connection()
        if not conn:
            return False, "Database connection failed"

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Verify token is valid and not expired
            cur.execute(
                """
                SELECT user_id FROM password_reset_tokens 
                WHERE token = %s AND expires_at > NOW() AND is_used = FALSE
            """,
                (token,),
            )

            token_data = cur.fetchone()
            if not token_data:
                return False, "Invalid or expired reset token"

            # Hash new password
            password_hash = self.hash_password(new_password)

            # Update user password
            cur.execute(
                """
                UPDATE users 
                SET password_hash = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """,
                (password_hash, token_data["user_id"]),
            )

            # Mark token as used
            cur.execute(
                """
                UPDATE password_reset_tokens 
                SET is_used = TRUE 
                WHERE token = %s
            """,
                (token,),
            )

            conn.commit()
            return True, "Password reset successfully"

        except Exception as e:
            print(f"Password reset error: {e}")
            conn.rollback()
            return False, "Failed to reset password"
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def get_user_permissions(self, user_id):
        """Get user permissions for access control"""
        conn = get_db_connection()
        if not conn:
            return {}

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute(
                """
                SELECT module, can_view, can_create, can_edit, can_delete 
                FROM user_permissions 
                WHERE user_id = %s
            """,
                (user_id,),
            )

            permissions = {}
            for perm in cur.fetchall():
                permissions[perm["module"]] = {
                    "view": perm["can_view"],
                    "create": perm["can_create"],
                    "edit": perm["can_edit"],
                    "delete": perm["can_delete"],
                }

            return permissions

        except Exception as e:
            print(f"Permission retrieval error: {e}")
            return {}
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()

    def set_user_permissions(self, user_id, module, permissions):
        """Set permissions for a user on a specific module"""
        conn = get_db_connection()
        if not conn:
            return False

        try:
            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Delete existing permissions for this user/module
            cur.execute(
                """
                DELETE FROM user_permissions 
                WHERE user_id = %s AND module = %s
            """,
                (user_id, module),
            )

            # Insert new permissions
            cur.execute(
                """
                INSERT INTO user_permissions (user_id, module, can_view, can_create, can_edit, can_delete)
                VALUES (%s, %s, %s, %s, %s, %s)
            """,
                (
                    user_id,
                    module,
                    permissions.get("view", False),
                    permissions.get("create", False),
                    permissions.get("edit", False),
                    permissions.get("delete", False),
                ),
            )

            conn.commit()
            return True

        except Exception as e:
            print(f"Permission setting error: {e}")
            conn.rollback()
            return False
        finally:
            if "cur" in locals():
                cur.close()
            conn.close()
