# auth/access_control.py
"""
Enhanced access control system for multi-tenant architecture
Handles property owner segregation, corporate user isolation, and role-based permissions
"""
import streamlit as st
from typing import Dict, List, Any
from utils.database import get_db_connection


class AccessControlManager:
    """Manages user access permissions and data segregation"""

    @staticmethod
    def get_user_access_scope() -> Dict[str, Any]:
        """Get current user's access scope from session"""
        return st.session_state.get(
            "access_scope",
            {
                "account_type": "Individual Customer",
                "declared_role": "Customer",
                "corporate_id": None,
                "user_id": "",
                "can_access_all_properties": False,
                "restricted_to_corp": False,
                "property_filter": None,
            },
        )

    @staticmethod
    def can_access_property(property_id: str) -> bool:
        """Check if current user can access a specific property"""
        scope = AccessControlManager.get_user_access_scope()

        # System admins can access everything
        if scope.get("can_access_all_properties", False):
            return True

        # Get property details from database
        conn = get_db_connection()
        if not conn:
            return False

        try:
            cursor = conn.cursor()

            # Check property ownership/assignment
            if scope.get("restricted_to_corp"):
                # Corporate users: check corporate_id match
                cursor.execute(
                    """
                    SELECT corporate_id, assigned_manager 
                    FROM properties 
                    WHERE id = %s
                """,
                    (property_id,),
                )
            else:
                # Individual users: check direct ownership
                cursor.execute(
                    """
                    SELECT owner_user_id, assigned_manager
                    FROM properties 
                    WHERE id = %s
                """,
                    (property_id,),
                )

            result = cursor.fetchone()
            if not result:
                return False

            # Corporate access control
            if scope.get("restricted_to_corp"):
                corp_id, assigned_manager = result
                user_corp_id = scope.get("corporate_id")
                user_id = scope.get("user_id")

                # Same corporate ID or assigned as manager
                return (corp_id == user_corp_id) or (assigned_manager == user_id)
            else:
                # Individual access control
                owner_id, assigned_manager = result
                user_session_id = st.session_state.get("user_id")

                # Direct owner or assigned manager
                return (owner_id == user_session_id) or (
                    assigned_manager == user_session_id
                )

        except Exception as e:
            st.error(f"Access control error: {e}")
            return False
        finally:
            if conn:
                conn.close()

    @staticmethod
    def get_accessible_properties() -> List[Dict[str, Any]]:
        """Get list of properties accessible to current user"""
        scope = AccessControlManager.get_user_access_scope()

        conn = get_db_connection()
        if not conn:
            return []

        try:
            cursor = conn.cursor()

            if scope.get("can_access_all_properties", False):
                # System admin: all properties
                cursor.execute(
                    """
                    SELECT p.*, u.full_name as owner_name
                    FROM properties p
                    LEFT JOIN users u ON p.owner_user_id = u.id
                    ORDER BY p.name
                """
                )
            elif scope.get("restricted_to_corp"):
                # Corporate user: properties within their corporate ID
                cursor.execute(
                    """
                    SELECT p.*, u.full_name as owner_name
                    FROM properties p
                    LEFT JOIN users u ON p.owner_user_id = u.id
                    WHERE p.corporate_id = %s OR p.assigned_manager = %s
                    ORDER BY p.name
                """,
                    (scope.get("corporate_id"), scope.get("user_id")),
                )
            else:
                # Individual user: owned or managed properties
                user_id = st.session_state.get("user_id")
                cursor.execute(
                    """
                    SELECT p.*, u.full_name as owner_name
                    FROM properties p
                    LEFT JOIN users u ON p.owner_user_id = u.id
                    WHERE p.owner_user_id = %s OR p.assigned_manager = %s
                    ORDER BY p.name
                """,
                    (user_id, user_id),
                )

            columns = [desc[0] for desc in cursor.description]
            results = []
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))

            return results

        except Exception as e:
            st.error(f"Database error: {e}")
            return []
        finally:
            if conn:
                conn.close()

    @staticmethod
    def get_role_permissions() -> Dict[str, List[str]]:
        """Get permissions matrix for different roles"""
        scope = AccessControlManager.get_user_access_scope()
        role = scope.get("declared_role", "Customer")
        account_type = scope.get("account_type", "Individual Customer")

        # Base permissions by role
        permissions = {
            "Admin": [
                "view_all_properties",
                "create_property",
                "edit_property",
                "delete_property",
                "manage_users",
                "manage_contracts",
                "manage_tickets",
                "view_reports",
                "manage_billing",
            ],
            "Employee": [
                "view_assigned_properties",
                "manage_tickets",
                "view_contracts",
                "create_tickets",
            ],
            "Property Owner": [
                "view_own_properties",
                "manage_own_properties",
                "view_own_contracts",
                "create_tickets",
                "view_own_reports",
            ],
            "Vendor": [
                "view_assigned_tickets",
                "update_ticket_status",
                "upload_work_photos",
                "submit_invoices",
            ],
            "Customer": [
                "view_own_properties",
                "create_tickets",
                "view_own_contracts",
                "make_payments",
            ],
        }

        user_permissions = permissions.get(role, permissions["Customer"])

        # Corporate accounts get additional segregation
        if account_type.startswith("Corporate"):
            user_permissions.append("corporate_segregated_data")

        return {role: user_permissions}

    @staticmethod
    def check_permission(permission: str) -> bool:
        """Check if current user has specific permission"""
        role_perms = AccessControlManager.get_role_permissions()
        scope = AccessControlManager.get_user_access_scope()
        role = scope.get("declared_role", "Customer")

        user_permissions = role_perms.get(role, [])
        return permission in user_permissions
