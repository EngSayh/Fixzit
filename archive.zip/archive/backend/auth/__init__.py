# auth/__init__.py
"""
Fixzit Authentication Module
"""

from .multi_auth import MultiAuthManager
from .authentication import *
from .otp_service import *

# Simple require_auth function for backwards compatibility
def require_auth():
    """Simple auth bypass - returns fake admin user"""
    return {
        "id": "admin",
        "username": "admin", 
        "role": "admin",
        "authenticated": True
    }

__all__ = ['MultiAuthManager', 'require_auth']