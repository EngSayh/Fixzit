import os
import random
import string
from datetime import datetime, timedelta
from twilio.rest import Client
from utils.database import get_db_connection

# Twilio configuration
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")


def generate_otp():
    """Generate a 6-digit OTP"""
    return "".join(random.choices(string.digits, k=6))


def send_otp(phone_number):
    """Send OTP via SMS using Twilio"""
    if not all([TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER]):
        print("Twilio credentials not configured")
        return False

    conn = None
    cur = None
    try:
        # Generate OTP
        otp_code = generate_otp()

        # Store OTP in database
        conn = get_db_connection()
        if not conn:
            return False

        cur = conn.cursor()

        # Clean up old OTPs for this phone number
        cur.execute("DELETE FROM otp_codes WHERE phone = %s", (phone_number,))

        # Store new OTP
        expires_at = datetime.now() + timedelta(minutes=10)  # OTP expires in 10 minutes
        cur.execute(
            """
            INSERT INTO otp_codes (phone, code, expires_at)
            VALUES (%s, %s, %s)
        """,
            (phone_number, otp_code, expires_at),
        )

        conn.commit()

        # Send SMS via Twilio
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

        message_body = f"Your Real Estate Management verification code is: {otp_code}. This code will expire in 10 minutes."

        message = client.messages.create(
            body=message_body, from_=TWILIO_PHONE_NUMBER, to=phone_number
        )

        print(f"OTP sent successfully. Message SID: {message.sid}")
        return True

    except Exception as e:
        print(f"Error sending OTP: {e}")
        if conn:
            conn.rollback()
        return False
    finally:
        if cur is not None:
            cur.close()
        if conn is not None:
            conn.close()


def verify_otp(phone_number, otp_code):
    """Verify OTP code"""
    conn = get_db_connection()
    if not conn:
        return False

    cur = None
    try:
        cur = conn.cursor()

        # Check if OTP is valid and not expired
        cur.execute(
            """
            SELECT id FROM otp_codes 
            WHERE phone = %s AND code = %s 
            AND expires_at > NOW() AND is_used = FALSE
        """,
            (phone_number, otp_code),
        )

        otp_record = cur.fetchone()

        if otp_record:
            # Mark OTP as used
            cur.execute(
                """
                UPDATE otp_codes 
                SET is_used = TRUE 
                WHERE id = %s
            """,
                (otp_record[0],),
            )

            conn.commit()
            return True

        return False

    except Exception as e:
        print(f"Error verifying OTP: {e}")
        return False
    finally:
        if cur is not None:
            cur.close()
        if conn is not None:
            conn.close()


def resend_otp(phone_number):
    """Resend OTP to phone number"""
    return send_otp(phone_number)
