import streamlit as st
import bcrypt
from utils.database import get_db_connection
from utils.audit_logger import log_action
from datetime import datetime, timedelta


class RoleBasedAuthManager:
    """Enhanced authentication system with role-based login similar to Amazon"""

    def __init__(self):
        self.initialize_auth_tables()

    def initialize_auth_tables(self):
        """Initialize enhanced authentication tables"""
        try:
            conn = get_db_connection()
            if conn is None:
                return
            cur = conn.cursor()

            # Enhanced users table with role-based authentication
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS enhanced_users (
                    id SERIAL PRIMARY KEY,
                    user_type VARCHAR(20) NOT NULL, -- 'vendor', 'customer', 'employee'
                    email VARCHAR(255) UNIQUE NOT NULL,
                    phone VARCHAR(20) UNIQUE,
                    password_hash VARCHAR(255) NOT NULL,
                    
                    -- Personal Information
                    first_name VARCHAR(100) NOT NULL,
                    last_name VARCHAR(100) NOT NULL,
                    full_name_ar VARCHAR(200),
                    
                    -- Contact Information
                    whatsapp VARCHAR(20),
                    preferred_language VARCHAR(10) DEFAULT 'en',
                    
                    -- For Vendors
                    vendor_id INTEGER REFERENCES vendors(id),
                    
                    -- For Customers
                    customer_type VARCHAR(50), -- 'individual', 'business'
                    
                    -- For Employees
                    employee_role VARCHAR(50), -- 'admin', 'manager', 'staff'
                    department VARCHAR(100),
                    employee_id VARCHAR(50),
                    
                    -- Account Status
                    is_active BOOLEAN DEFAULT TRUE,
                    is_verified BOOLEAN DEFAULT FALSE,
                    email_verified BOOLEAN DEFAULT FALSE,
                    phone_verified BOOLEAN DEFAULT FALSE,
                    
                    -- Security
                    last_login TIMESTAMP,
                    failed_login_attempts INTEGER DEFAULT 0,
                    account_locked_until TIMESTAMP,
                    
                    -- Metadata
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # Create login sessions table
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS user_sessions (
                    id SERIAL PRIMARY KEY,
                    user_id INTEGER REFERENCES enhanced_users(id) ON DELETE CASCADE,
                    session_token VARCHAR(255) UNIQUE NOT NULL,
                    user_type VARCHAR(20) NOT NULL,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    is_active BOOLEAN DEFAULT TRUE
                )
            """
            )

            # Create role permissions table
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS role_permissions (
                    id SERIAL PRIMARY KEY,
                    role VARCHAR(50) NOT NULL,
                    permission VARCHAR(100) NOT NULL,
                    resource VARCHAR(100),
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # Insert default role permissions if empty
            cur.execute("SELECT COUNT(*) FROM role_permissions")
            result = cur.fetchone()
            count = result[0] if result else 0

            if count == 0:
                default_permissions = [
                    # Vendor permissions
                    ("vendor", "manage_products", "vendor_products"),
                    ("vendor", "manage_services", "vendor_services"),
                    ("vendor", "view_orders", "orders"),
                    ("vendor", "manage_profile", "vendor_profile"),
                    ("vendor", "view_earnings", "financial_reports"),
                    # Customer permissions
                    ("customer", "place_orders", "orders"),
                    ("customer", "view_orders", "orders"),
                    ("customer", "manage_profile", "customer_profile"),
                    ("customer", "view_invoices", "invoices"),
                    ("customer", "book_services", "services"),
                    # Employee permissions
                    ("admin", "manage_all", "all_resources"),
                    ("manager", "manage_properties", "properties"),
                    ("manager", "manage_contracts", "contracts"),
                    ("manager", "view_reports", "reports"),
                    ("staff", "basic_operations", "basic_resources"),
                ]

                for role, permission, resource in default_permissions:
                    cur.execute(
                        """
                        INSERT INTO role_permissions (role, permission, resource) 
                        VALUES (%s, %s, %s)
                    """,
                        (role, permission, resource),
                    )

            conn.commit()
            conn.close()

        except Exception as e:
            # Silently handle initialization errors - not critical for main app function
            try:
                if st.secrets.get("general", {}).get("debug_mode", False):
                    st.error(f"Debug: Enhanced auth initialization: {str(e)}")
            except Exception:
                pass
            pass

    def show_role_selection_interface(self, language="en"):
        """Show Amazon-style role selection interface"""

        # Role selection CSS
        st.markdown(
            """
        <style>
        .role-selection-header {
            background: linear-gradient(135deg, #232F3E 0%, #37475A 100%);
            padding: 40px;
            border-radius: 20px;
            color: white;
            text-align: center;
            margin: 30px 0;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        .role-card {
            background: white;
            border: 3px solid #e9ecef;
            border-radius: 20px;
            padding: 40px;
            margin: 20px 0;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
        }
        .role-card:hover {
            border-color: #FF9900;
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.2);
        }
        .role-card.selected {
            border-color: #FF9900;
            background: linear-gradient(135deg, #fff8f0, #ffe6cc);
            transform: translateY(-5px);
        }
        .role-icon {
            font-size: 64px;
            margin-bottom: 20px;
            color: #FF9900;
        }
        .role-title {
            font-size: 24px;
            font-weight: bold;
            color: #232F3E;
            margin-bottom: 15px;
        }
        .role-description {
            font-size: 16px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .role-features {
            font-size: 14px;
            color: #888;
            text-align: left;
            margin-top: 20px;
        }
        .continue-btn {
            background: linear-gradient(135deg, #FF9900, #FF6600);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: bold;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            margin-top: 30px;
        }
        </style>
        """,
            unsafe_allow_html=True,
        )

        # Header
        if language == "ar":
            st.markdown(
                """
            <div class="role-selection-header">
                <h1>🏪 مرحباً بك في منصة فكسيت</h1>
                <p>اختر نوع حسابك للمتابعة</p>
                <p>نظام إدارة شامل للعقارات والخدمات</p>
            </div>
            """,
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                """
            <div class="role-selection-header">
                <h1>🏪 Welcome to Fixzit Platform</h1>
                <p>Choose your account type to continue</p>
                <p>Comprehensive property and services management system</p>
            </div>
            """,
                unsafe_allow_html=True,
            )

        # Role selection
        if language == "ar":
            roles = [
                {
                    "type": "vendor",
                    "icon": "🏪",
                    "title": "بائع / مقدم خدمة",
                    "description": "قدم خدماتك التقنية أو بع منتجاتك عبر المنصة",
                    "features": [
                        "• إدارة الخدمات والمنتجات",
                        "• تلقي طلبات العملاء",
                        "• تتبع الأرباح والمبيعات",
                        "• نظام تقييم العملاء",
                    ],
                },
                {
                    "type": "customer",
                    "title": "عميل",
                    "icon": "👥",
                    "description": "احجز الخدمات واشتري المنتجات بسهولة",
                    "features": [
                        "• حجز الخدمات التقنية",
                        "• شراء المواد والمنتجات",
                        "• تتبع الطلبات والفواتير",
                        "• إدارة العقارات والعقود",
                    ],
                },
                {
                    "type": "employee",
                    "icon": "👔",
                    "title": "موظف",
                    "description": "إدارة العمليات والعملاء والنظام",
                    "features": [
                        "• إدارة العقارات والعقود",
                        "• خدمة العملاء والدعم",
                        "• تقارير مالية ومتابعة",
                        "• إدارة النظام والمستخدمين",
                    ],
                },
            ]
        else:
            roles = [
                {
                    "type": "vendor",
                    "icon": "🏪",
                    "title": "Vendor / Service Provider",
                    "description": "Provide technical services or sell products through the platform",
                    "features": [
                        "• Manage services and products",
                        "• Receive customer orders",
                        "• Track earnings and sales",
                        "• Customer rating system",
                    ],
                },
                {
                    "type": "customer",
                    "icon": "👥",
                    "title": "Customer",
                    "description": "Book services and purchase products easily",
                    "features": [
                        "• Book technical services",
                        "• Purchase materials and products",
                        "• Track orders and invoices",
                        "• Manage properties and contracts",
                    ],
                },
                {
                    "type": "employee",
                    "icon": "👔",
                    "title": "Employee",
                    "description": "Manage operations, customers, and system",
                    "features": [
                        "• Manage properties and contracts",
                        "• Customer service and support",
                        "• Financial reports and tracking",
                        "• System and user management",
                    ],
                },
            ]

        # Display role cards
        selected_role = st.session_state.get("selected_role_type", None)

        for role in roles:
            card_class = (
                "role-card selected" if selected_role == role["type"] else "role-card"
            )

            if st.button(
                f"{role['icon']} {role['title']}",
                key=f"role_{role['type']}",
                help=role["description"],
            ):
                st.session_state.selected_role_type = role["type"]
                st.rerun()

            # Show details if selected
            if selected_role == role["type"]:
                st.markdown(
                    f"""
                <div class="{card_class}">
                    <div class="role-icon">{role['icon']}</div>
                    <div class="role-title">{role['title']}</div>
                    <div class="role-description">{role['description']}</div>
                    <div class="role-features">
                        {'<br>'.join(role['features'])}
                    </div>
                </div>
                """,
                    unsafe_allow_html=True,
                )

        # Continue button
        if selected_role:
            if st.button(
                "Continue" if language == "en" else "متابعة",
                key="continue_with_role",
                type="primary",
            ):
                st.session_state.auth_step = "login_form"
                st.rerun()

        # Language selection at bottom
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            selected_lang = st.selectbox(
                "Language / اللغة",
                ["English", "العربية"],
                index=0 if language == "en" else 1,
                key="role_selection_language",
            )

            new_lang = "en" if selected_lang == "English" else "ar"
            if new_lang != language:
                st.session_state.language = new_lang
                st.rerun()

    def show_login_form(self, language="en"):
        """Show login form based on selected role"""

        selected_role = st.session_state.get("selected_role_type")
        if not selected_role:
            st.session_state.auth_step = "role_selection"
            st.rerun()
            return

        # Login form CSS
        st.markdown(
            """
        <style>
        .login-header {
            background: linear-gradient(135deg, #232F3E 0%, #37475A 100%);
            padding: 30px;
            border-radius: 15px;
            color: white;
            text-align: center;
            margin: 20px 0;
        }
        .login-form {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            border: 2px solid #e9ecef;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .login-btn {
            background: linear-gradient(135deg, #FF9900, #FF6600);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-weight: bold;
            width: 100%;
            font-size: 16px;
        }
        .register-link {
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        </style>
        """,
            unsafe_allow_html=True,
        )

        # Header with role context
        role_icons = {"vendor": "🏪", "customer": "👥", "employee": "👔"}
        role_names = {
            "vendor": ("Vendor Login", "تسجيل دخول البائع"),
            "customer": ("Customer Login", "تسجيل دخول العميل"),
            "employee": ("Employee Login", "تسجيل دخول الموظف"),
        }

        role_icon = role_icons.get(selected_role, "🏪")
        role_name = role_names.get(selected_role, ("Login", "تسجيل الدخول"))
        display_name = role_name[1] if language == "ar" else role_name[0]

        st.markdown(
            f"""
        <div class="login-header">
            <h2>{role_icon} {display_name}</h2>
            <p>{'أدخل بيانات الدخول الخاصة بك' if language == 'ar' else 'Enter your login credentials'}</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Back to role selection
        if st.button(
            (
                "← Back to Role Selection"
                if language == "en"
                else "← العودة لاختيار النوع"
            ),
            key="back_to_roles",
        ):
            st.session_state.auth_step = "role_selection"
            del st.session_state.selected_role_type
            st.rerun()

        # Login form
        st.markdown('<div class="login-form">', unsafe_allow_html=True)

        with st.form("role_based_login_form"):
            st.markdown('<div class="form-group">', unsafe_allow_html=True)

            # Email or phone login
            login_method = st.radio(
                "Login Method" if language == "en" else "طريقة تسجيل الدخول",
                (
                    ["Email", "Phone"]
                    if language == "en"
                    else ["البريد الإلكتروني", "الهاتف"]
                ),
                horizontal=True,
                key="login_method",
            )

            if login_method in ["Email", "البريد الإلكتروني"]:
                identifier = st.text_input(
                    "Email Address" if language == "en" else "البريد الإلكتروني",
                    placeholder="your@email.com",
                    key="email_login",
                )
            else:
                identifier = st.text_input(
                    "Phone Number" if language == "en" else "رقم الهاتف",
                    placeholder="+966XXXXXXXXX",
                    key="phone_login",
                )

            password = st.text_input(
                "Password" if language == "en" else "كلمة المرور",
                type="password",
                key="password_login",
            )

            st.checkbox(
                "Remember me" if language == "en" else "تذكرني", key="remember_me"
            )

            st.markdown("</div>", unsafe_allow_html=True)

            # Login button
            login_submitted = st.form_submit_button(
                "Sign In" if language == "en" else "تسجيل الدخول",
                use_container_width=True,
                type="primary",
            )

            if login_submitted:
                if identifier and password:
                    success, user_data = self.authenticate_user(
                        identifier, password, selected_role, login_method
                    )

                    if success and user_data:
                        # Set session state
                        st.session_state.authenticated = True
                        st.session_state.user_id = user_data["id"]
                        st.session_state.user_type = user_data["user_type"]
                        st.session_state.user_role = user_data.get(
                            "employee_role", user_data["user_type"]
                        )
                        st.session_state.user_name = (
                            f"{user_data['first_name']} {user_data['last_name']}"
                        )
                        # Set user's preferred language immediately and apply consistent styling
                        preferred_lang = user_data.get("preferred_language", "en")
                        st.session_state.language = preferred_lang

                        # Apply immediate language-specific styling for consistency
                        if preferred_lang == "ar":
                            st.markdown(
                                """
                            <style>
                            .main > div, .stApp > div, body {
                                direction: rtl !important;
                                text-align: right !important;
                            }
                            .stSelectbox > div > div, .stTextInput > div > div, 
                            .stTextArea > div > div, .stNumberInput > div > div {
                                direction: rtl !important;
                            }
                            .stTextInput > div > div > input,
                            .stTextArea > div > div > textarea,
                            .stNumberInput > div > div > input {
                                direction: rtl !important;
                                text-align: right !important;
                            }
                            </style>
                            """,
                                unsafe_allow_html=True,
                            )

                        # Log successful login
                        log_action(
                            "user_login_success",
                            additional_data={
                                "user_type": selected_role,
                                "login_method": login_method,
                            },
                        )

                        st.success(
                            "Login successful!"
                            if language == "en"
                            else "تم تسجيل الدخول بنجاح!"
                        )
                        st.rerun()
                    else:
                        st.error(
                            "Invalid credentials"
                            if language == "en"
                            else "بيانات خاطئة"
                        )
                else:
                    st.warning(
                        "Please fill all fields"
                        if language == "en"
                        else "يرجى ملء جميع الحقول"
                    )

        st.markdown("</div>", unsafe_allow_html=True)

        # Registration links based on role
        st.markdown('<div class="register-link">', unsafe_allow_html=True)

        if selected_role == "vendor":
            if language == "ar":
                st.markdown(
                    "**ليس لديك حساب؟** [سجل كبائع جديد](pages/100_VendorRegistration.py)"
                )
            else:
                st.markdown(
                    "**Don't have an account?** [Register as new vendor](pages/100_VendorRegistration.py)"
                )

            if st.button(
                "🏪 Register as Vendor" if language == "en" else "🏪 التسجيل كبائع",
                key="goto_vendor_registration",
            ):
                st.switch_page("pages/100_VendorRegistration.py")

        elif selected_role == "customer":
            if language == "ar":
                st.markdown(
                    "**ليس لديك حساب؟** [سجل كعميل جديد](pages/2_Registrations.py)"
                )
            else:
                st.markdown(
                    "**Don't have an account?** [Register as new customer](pages/2_Registrations.py)"
                )

            if st.button(
                "👥 Register as Customer" if language == "en" else "👥 التسجيل كعميل",
                key="goto_customer_registration",
            ):
                st.switch_page("pages/2_Registrations.py")

        elif selected_role == "employee":
            if language == "ar":
                st.markdown("**موظف جديد؟** اتصل بالإدارة للحصول على بيانات الدخول")
            else:
                st.markdown(
                    "**New employee?** Contact administration for login credentials"
                )

        st.markdown("</div>", unsafe_allow_html=True)

    def authenticate_user(self, identifier, password, user_type, login_method):
        """Authenticate user based on role and credentials"""
        try:
            conn = get_db_connection()
            if conn is None:
                return False, None
            cur = conn.cursor()

            # Determine field to search
            field = (
                "email" if login_method in ["Email", "البريد الإلكتروني"] else "phone"
            )

            # Query user
            cur.execute(
                f"""
                SELECT id, user_type, email, phone, password_hash, first_name, last_name,
                       preferred_language, employee_role, is_active, failed_login_attempts,
                       account_locked_until
                FROM enhanced_users 
                WHERE {field} = %s AND user_type = %s AND is_active = TRUE
            """,
                (identifier, user_type),
            )

            user = cur.fetchone()

            if not user:
                return False, None

            # Check if account is locked
            if user[11] and user[11] > datetime.now():  # account_locked_until
                return False, None

            # Verify password
            if bcrypt.checkpw(password.encode("utf-8"), user[4].encode("utf-8")):
                # Reset failed attempts on successful login
                cur.execute(
                    """
                    UPDATE enhanced_users 
                    SET failed_login_attempts = 0, last_login = CURRENT_TIMESTAMP 
                    WHERE id = %s
                """,
                    (user[0],),
                )

                user_data = {
                    "id": user[0],
                    "user_type": user[1],
                    "email": user[2],
                    "phone": user[3],
                    "first_name": user[5],
                    "last_name": user[6],
                    "preferred_language": user[7],
                    "employee_role": user[8],
                }

                conn.commit()
                conn.close()
                return True, user_data
            else:
                # Increment failed attempts
                failed_attempts = user[10] + 1
                lock_until = None

                if failed_attempts >= 5:
                    lock_until = datetime.now() + timedelta(minutes=30)

                cur.execute(
                    """
                    UPDATE enhanced_users 
                    SET failed_login_attempts = %s, account_locked_until = %s 
                    WHERE id = %s
                """,
                    (failed_attempts, lock_until, user[0]),
                )

                conn.commit()
                conn.close()
                return False, None

        except Exception as e:
            st.error(f"Authentication error: {str(e)}")
            return False, None


# Global instance
role_auth_manager = RoleBasedAuthManager()


def show_role_based_authentication(language="en"):
    """Show role-based authentication interface"""

    # Initialize auth step
    if "auth_step" not in st.session_state:
        st.session_state.auth_step = "role_selection"

    if st.session_state.auth_step == "role_selection":
        role_auth_manager.show_role_selection_interface(language)
    elif st.session_state.auth_step == "login_form":
        role_auth_manager.show_login_form(language)
