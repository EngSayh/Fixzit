-- FIXZIT SOUQ PostgreSQL Schema

-- Organizations
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  subdomain VARCHAR(100) UNIQUE NOT NULL,
  plan VARCHAR(50) DEFAULT 'basic',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users with 14 roles
CREATE TYPE user_role AS ENUM (
  'SUPER_ADMIN', 'ADMIN', 'PROPERTY_MANAGER', 'MAINTENANCE_MANAGER',
  'TECHNICIAN', 'TENANT', 'OWNER', 'FINANCE_OFFICER', 'HR_OFFICER',
  'LEGAL_COMPLIANCE', 'CRM_SALES', 'SUPPORT_AGENT', 'VENDOR', 'VIEWER'
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  role user_role NOT NULL,
  org_id UUID REFERENCES organizations(id),
  phone VARCHAR(20),
  avatar VARCHAR(500),
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Properties
CREATE TYPE property_type AS ENUM ('residential', 'commercial', 'mixed');

CREATE TABLE IF NOT EXISTS properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  address TEXT NOT NULL,
  type property_type DEFAULT 'residential',
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_by UUID REFERENCES users(id),
  total_units INTEGER DEFAULT 0,
  area_sqm DECIMAL,
  year_built INTEGER,
  monthly_revenue DECIMAL,
  monthly_expenses DECIMAL,
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Units
CREATE TYPE unit_status AS ENUM ('vacant', 'occupied', 'maintenance', 'reserved');

CREATE TABLE IF NOT EXISTS units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES properties(id) NOT NULL,
  unit_number VARCHAR(50) NOT NULL,
  type VARCHAR(50),
  bedrooms INTEGER,
  bathrooms INTEGER,
  area_sqm DECIMAL,
  floor_number INTEGER,
  rent_amount DECIMAL,
  status unit_status DEFAULT 'vacant',
  tenant_id UUID REFERENCES users(id),
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(property_id, unit_number)
);

-- Work Orders
CREATE TYPE wo_category AS ENUM ('hvac', 'plumbing', 'electrical', 'general', 'cleaning', 'maintenance');
CREATE TYPE wo_priority AS ENUM ('emergency', 'high', 'medium', 'low');
CREATE TYPE wo_status AS ENUM ('draft', 'open', 'assigned', 'in_progress', 'on_hold', 'completed', 'closed', 'cancelled');

CREATE TABLE IF NOT EXISTS work_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wo_number VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category wo_category DEFAULT 'general',
  priority wo_priority DEFAULT 'medium',
  status wo_status DEFAULT 'draft',
  property_id UUID REFERENCES properties(id),
  unit_id UUID REFERENCES units(id),
  assigned_to UUID REFERENCES users(id),
  created_by UUID REFERENCES users(id),
  org_id UUID REFERENCES organizations(id) NOT NULL,
  due_date TIMESTAMP,
  completed_at TIMESTAMP,
  estimated_hours DECIMAL,
  actual_hours DECIMAL,
  estimated_cost DECIMAL,
  actual_cost DECIMAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_org_id ON users(org_id);
CREATE INDEX IF NOT EXISTS idx_properties_org_id ON properties(org_id);
CREATE INDEX IF NOT EXISTS idx_units_property_id ON units(property_id);
CREATE INDEX IF NOT EXISTS idx_units_org_id ON units(org_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_org_id ON work_orders(org_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_property_id ON work_orders(property_id);

-- Update timestamp triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON properties FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_units_updated_at BEFORE UPDATE ON units FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_work_orders_updated_at BEFORE UPDATE ON work_orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
