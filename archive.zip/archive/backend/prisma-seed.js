// FIXZIT SOUQ Enterprise - Enhanced Database Seed with Role Management System
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { ROLES, PERMISSIONS } from '../config/roles-permissions.js';

const prisma = new PrismaClient();

async function seed() {
  console.log('🌱 Starting FIXZIT SOUQ Enterprise seed process with Role Management...');
  
  try {
    // Clear existing data in correct order (respecting foreign key constraints)
    console.log('🧹 Clearing existing data...');
    await prisma.userSession.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.userRole.deleteMany();
    await prisma.workOrder.deleteMany();
    await prisma.unit.deleteMany();
    await prisma.property.deleteMany();
    await prisma.user.deleteMany();
    await prisma.role.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.organization.deleteMany();

    // Create Demo Organization
    console.log('🏢 Creating demo organization...');
    const orgId = uuidv4();
    const organization = await prisma.organization.create({
      data: {
        id: orgId,
        name: 'FIXZIT SOUQ Enterprise Demo',
        subdomain: 'demo',
        plan: 'enterprise',
        isActive: true
      }
    });

    // Create Permissions
    console.log('🔐 Creating permissions...');
    const createdPermissions = {};
    for (const permissionData of PERMISSIONS) {
      const permission = await prisma.permission.create({
        data: {
          name: permissionData.name,
          displayName: permissionData.displayName,
          description: permissionData.description || `${permissionData.displayName} permission`,
          module: permissionData.module,
          action: permissionData.action,
          isSystem: true
        }
      });
      createdPermissions[permissionData.name] = permission;
    }
    console.log(`✅ Created ${Object.keys(createdPermissions).length} permissions`);

    // Create Roles
    console.log('👑 Creating roles...');
    const createdRoles = {};
    for (const roleData of ROLES) {
      const role = await prisma.role.create({
        data: {
          name: roleData.name,
          displayName: roleData.displayName,
          description: roleData.description,
          level: roleData.level,
          isSystem: roleData.isSystem || false,
          isActive: true
        }
      });
      createdRoles[roleData.name] = role;

      // Assign permissions to role
      for (const permissionName of roleData.permissions) {
        if (createdPermissions[permissionName]) {
          await prisma.rolePermission.create({
            data: {
              roleId: role.id,
              permissionId: createdPermissions[permissionName].id
            }
          });
        }
      }
    }
    console.log(`✅ Created ${Object.keys(createdRoles).length} roles`);

    // Create Demo Users with Different Roles
    console.log('👥 Creating demo users...');
    const demoUsers = [
      {
        email: 'superadmin@fixzit.com',
        password: 'SuperAdmin@123',
        firstName: 'Super',
        lastName: 'Administrator',
        role: 'SUPER_ADMIN'
      },
      {
        email: 'admin@fixzit.com',
        password: 'Admin@123',
        firstName: 'Organization',
        lastName: 'Administrator',
        role: 'ORGANIZATION_ADMIN'
      },
      {
        email: 'manager@fixzit.com',
        password: 'Manager@123',
        firstName: 'Property',
        lastName: 'Manager',
        role: 'PROPERTY_MANAGER'
      },
      {
        email: 'facility@fixzit.com',
        password: 'Facility@123',
        firstName: 'Facility',
        lastName: 'Manager',
        role: 'FACILITY_MANAGER'
      },
      {
        email: 'finance@fixzit.com',
        password: 'Finance@123',
        firstName: 'Finance',
        lastName: 'Manager',
        role: 'FINANCE_MANAGER'
      },
      {
        email: 'hr@fixzit.com',
        password: 'HR@123',
        firstName: 'Human Resources',
        lastName: 'Manager',
        role: 'HR_MANAGER'
      },
      {
        email: 'compliance@fixzit.com',
        password: 'Compliance@123',
        firstName: 'Compliance',
        lastName: 'Officer',
        role: 'COMPLIANCE_OFFICER'
      },
      {
        email: 'supervisor@fixzit.com',
        password: 'Supervisor@123',
        firstName: 'Maintenance',
        lastName: 'Supervisor',
        role: 'MAINTENANCE_SUPERVISOR'
      },
      {
        email: 'tech@fixzit.com',
        password: 'Tech@123',
        firstName: 'Lead',
        lastName: 'Technician',
        role: 'TECHNICIAN'
      },
      {
        email: 'crm@fixzit.com',
        password: 'CRM@123',
        firstName: 'CRM',
        lastName: 'Manager',
        role: 'CRM_MANAGER'
      },
      {
        email: 'support@fixzit.com',
        password: 'Support@123',
        firstName: 'Support',
        lastName: 'Agent',
        role: 'SUPPORT_AGENT'
      },
      {
        email: 'marketplace@fixzit.com',
        password: 'Marketplace@123',
        firstName: 'Marketplace',
        lastName: 'Manager',
        role: 'MARKETPLACE_MANAGER'
      },
      {
        email: 'vendor@fixzit.com',
        password: 'Vendor@123',
        firstName: 'External',
        lastName: 'Vendor',
        role: 'VENDOR'
      },
      {
        email: 'tenant@fixzit.com',
        password: 'Tenant@123',
        firstName: 'Property',
        lastName: 'Tenant',
        role: 'TENANT'
      },
      {
        email: 'auditor@fixzit.com',
        password: 'Auditor@123',
        firstName: 'System',
        lastName: 'Auditor',
        role: 'AUDITOR'
      },
      {
        email: 'guest@fixzit.com',
        password: 'Guest@123',
        firstName: 'Guest',
        lastName: 'User',
        role: 'GUEST'
      }
    ];

    const createdUsers = [];
    for (const userData of demoUsers) {
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      const userId = uuidv4();
      
      // Create user
      const user = await prisma.user.create({
        data: {
          id: userId,
          email: userData.email,
          password: hashedPassword,
          firstName: userData.firstName,
          lastName: userData.lastName,
          orgId: organization.id,
          isActive: true
        }
      });

      // Assign role to user
      if (createdRoles[userData.role]) {
        await prisma.userRole.create({
          data: {
            userId: user.id,
            roleId: createdRoles[userData.role].id,
            isActive: true
          }
        });
      }

      createdUsers.push({
        ...user,
        role: userData.role,
        plainPassword: userData.password
      });
    }

    // Create Sample Properties
    console.log('🏠 Creating sample properties...');
    const properties = [
      {
        name: 'Sunset Towers',
        address: 'King Fahd Road, Riyadh 12345, Saudi Arabia',
        type: 'residential',
        totalUnits: 48
      },
      {
        name: 'Business Plaza',
        address: 'Olaya Street, Riyadh 11372, Saudi Arabia',
        type: 'commercial',
        totalUnits: 24
      },
      {
        name: 'Royal Gardens',
        address: 'Prince Mohammed Bin Salman Road, Riyadh 12244, Saudi Arabia',
        type: 'residential',
        totalUnits: 72
      }
    ];

    const createdProperties = [];
    for (const propData of properties) {
      const property = await prisma.property.create({
        data: {
          id: uuidv4(),
          name: propData.name,
          address: propData.address,
          type: propData.type,
          totalUnits: propData.totalUnits,
          orgId: organization.id,
          createdBy: createdUsers[0].id // Super Admin creates properties
        }
      });
      createdProperties.push(property);
    }

    // Create Sample Units
    console.log('🏠 Creating sample units...');
    for (const property of createdProperties) {
      const unitCount = Math.min(property.totalUnits, 10); // Create 10 sample units per property
      for (let i = 1; i <= unitCount; i++) {
        const unitNumber = property.type === 'residential' 
          ? `${property.name.charAt(0)}${i.toString().padStart(3, '0')}`
          : `B${i.toString().padStart(3, '0')}`;
        
        await prisma.unit.create({
          data: {
            id: uuidv4(),
            propertyId: property.id,
            unitNumber,
            type: property.type === 'residential' ? '2BR' : 'Office',
            bedrooms: property.type === 'residential' ? 2 : 0,
            bathrooms: property.type === 'residential' ? 2 : 1,
            areaSqm: property.type === 'residential' ? 120.0 : 50.0,
            rentAmount: property.type === 'residential' ? 3500.00 : 5000.00,
            status: i <= unitCount * 0.8 ? 'occupied' : 'vacant',
            orgId: organization.id
          }
        });
      }
    }

    // Create Sample Work Orders
    console.log('🔧 Creating sample work orders...');
    const workOrderTemplates = [
      {
        title: 'Air Conditioning Maintenance',
        description: 'Scheduled AC maintenance for optimal performance',
        category: 'hvac',
        priority: 'medium',
        status: 'open'
      },
      {
        title: 'Elevator Inspection',
        description: 'Monthly elevator safety inspection required',
        category: 'maintenance',
        priority: 'high',
        status: 'in_progress'
      },
      {
        title: 'Plumbing Repair',
        description: 'Water leak reported in unit bathroom',
        category: 'plumbing',
        priority: 'high',
        status: 'open'
      },
      {
        title: 'Electrical Safety Check',
        description: 'Routine electrical system safety inspection',
        category: 'electrical',
        priority: 'medium',
        status: 'completed'
      },
      {
        title: 'Fire Safety System Test',
        description: 'Monthly fire alarm and sprinkler system test',
        category: 'safety',
        priority: 'high',
        status: 'scheduled'
      }
    ];

    for (const woData of workOrderTemplates) {
      const woNumber = `WO-${Date.now()}-${uuidv4().substring(0, 8).toUpperCase()}`;
      await prisma.workOrder.create({
        data: {
          id: uuidv4(),
          woNumber,
          title: woData.title,
          description: woData.description,
          category: woData.category,
          priority: woData.priority,
          status: woData.status,
          propertyId: createdProperties[Math.floor(Math.random() * createdProperties.length)].id,
          orgId: organization.id,
          createdBy: createdUsers[0].id, // Super Admin creates work orders
          assignedTo: woData.status === 'in_progress' ? createdUsers.find(u => u.role === 'TECHNICIAN')?.id : null,
          completedAt: woData.status === 'completed' ? new Date() : null
        }
      });

      // Small delay for unique timestamps
      await new Promise(resolve => setTimeout(resolve, 10));
    }

    // Success summary
    console.log('');
    console.log('✅ FIXZIT SOUQ Enterprise seed completed successfully!');
    console.log('');
    console.log('📋 System Overview:');
    console.log(`🏢 Organizations: 1`);
    console.log(`👥 Users: ${createdUsers.length}`);
    console.log(`👑 Roles: ${Object.keys(createdRoles).length}`);
    console.log(`🔐 Permissions: ${Object.keys(createdPermissions).length}`);
    console.log(`🏠 Properties: ${createdProperties.length}`);
    console.log(`🏠 Units: ${createdProperties.length * 10}`);
    console.log(`🔧 Work Orders: ${workOrderTemplates.length}`);
    console.log('');
    console.log('🔑 Available Test Accounts:');
    createdUsers.forEach(user => {
      console.log(`   ${user.role}: ${user.email} / ${user.plainPassword}`);
    });
    console.log('');
    console.log('🎯 Role Hierarchy (Level):');
    ROLES.sort((a, b) => b.level - a.level).forEach(role => {
      console.log(`   ${role.level.toString().padStart(3)}: ${role.name} - ${role.displayName}`);
    });

  } catch (error) {
    console.error('❌ Seed error:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });