const socketIO = require('socket.io');

let io = null;

const initNotificationSocket = (server) => {
  io = socketIO(server, {
    cors: {
      origin: process.env.CLIENT_URL || 'http://localhost:3000',
      credentials: true
    }
  });

  // Authentication middleware for WebSocket
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('Authentication token required'));
    }
    
    try {
      // Basic token validation - in real implementation, verify JWT
      socket.userId = socket.handshake.auth.userId;
      socket.tenantId = socket.handshake.auth.tenantId;
      next();
    } catch (error) {
      next(new Error('Invalid authentication token'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`✅ User connected: ${socket.userId}`);

    // Join user to their personal room
    socket.join(`user:${socket.userId}`);

    // Join tenant room if available
    if (socket.tenantId) {
      socket.join(`tenant:${socket.tenantId}`);
    }

    // Handle notification read events
    socket.on('notification:read', (notificationId) => {
      // Broadcast to other devices of same user
      socket.to(`user:${socket.userId}`).emit('notification:read', notificationId);
    });

    // Handle notification read-all events
    socket.on('notification:read-all', () => {
      socket.to(`user:${socket.userId}`).emit('notification:read-all');
    });

    socket.on('disconnect', () => {
      console.log(`❌ User disconnected: ${socket.userId}`);
    });
  });

  console.log('🚀 Notification WebSocket service initialized');
  return io;
};

// Function to emit notifications to users
const emitToUser = (userId, event, data) => {
  if (io) {
    io.to(`user:${userId}`).emit(event, data);
  }
};

const emitToTenant = (tenantId, event, data) => {
  if (io) {
    io.to(`tenant:${tenantId}`).emit(event, data);
  }
};

module.exports = { 
  initNotificationSocket,
  emitToUser,
  emitToTenant
};