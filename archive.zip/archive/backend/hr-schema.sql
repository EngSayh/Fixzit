-- FIXZIT SOUQ Enterprise HR Management System Schema
-- Comprehensive HR database tables with real PostgreSQL integration

-- ==============================================
-- HR Management System Tables
-- ==============================================

-- Departments Table
CREATE TABLE IF NOT EXISTS departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  code VARCHAR(20) UNIQUE NOT NULL,
  manager_id UUID REFERENCES users(id),
  parent_id UUID REFERENCES departments(id),
  budget DECIMAL(12,2),
  location VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Employee Extended Information
-- Employment status enum
CREATE TYPE employment_status AS ENUM (
  'active', 'inactive', 'terminated', 'on_leave', 'probation'
);

-- Employment type enum  
CREATE TYPE employment_type AS ENUM (
  'full_time', 'part_time', 'contract', 'intern', 'consultant'
);

-- Pay schedule enum
CREATE TYPE pay_schedule AS ENUM (
  'monthly', 'bi_weekly', 'weekly', 'hourly'
);

-- Marital status enum
CREATE TYPE marital_status AS ENUM (
  'single', 'married', 'divorced', 'widowed', 'separated'
);

-- Gender enum
CREATE TYPE gender AS ENUM (
  'male', 'female', 'other', 'prefer_not_to_say'
);

CREATE TABLE IF NOT EXISTS employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  employee_number VARCHAR(50) UNIQUE NOT NULL,
  department_id UUID REFERENCES departments(id),
  position VARCHAR(255) NOT NULL,
  job_title VARCHAR(255) NOT NULL,
  hire_date DATE NOT NULL,
  termination_date DATE,
  employment_status employment_status DEFAULT 'active',
  employment_type employment_type DEFAULT 'full_time',
  work_location VARCHAR(255),
  direct_reporter_id UUID REFERENCES employees(id),
  
  -- Personal Information
  national_id VARCHAR(50),
  passport VARCHAR(50),
  date_of_birth DATE,
  marital_status marital_status,
  gender gender,
  nationality VARCHAR(100),
  address TEXT,
  emergency_contact VARCHAR(255),
  emergency_phone VARCHAR(20),
  
  -- Compensation
  base_salary DECIMAL(12,2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'SAR',
  pay_schedule pay_schedule DEFAULT 'monthly',
  benefits_package JSON,
  
  -- Leave Balances
  annual_leave_balance DECIMAL(5,2) DEFAULT 21,
  sick_leave_balance DECIMAL(5,2) DEFAULT 15,
  personal_leave_balance DECIMAL(5,2) DEFAULT 7,
  
  -- System fields
  profile_photo VARCHAR(500),
  is_active BOOLEAN DEFAULT true,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Records
CREATE TYPE attendance_status AS ENUM (
  'present', 'absent', 'late', 'half_day', 'on_leave', 'holiday'
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  check_in TIMESTAMP,
  check_out TIMESTAMP,
  break_start TIMESTAMP,
  break_end TIMESTAMP,
  total_hours DECIMAL(5,2) DEFAULT 0,
  regular_hours DECIMAL(5,2) DEFAULT 0,
  overtime_hours DECIMAL(5,2) DEFAULT 0,
  status attendance_status DEFAULT 'present',
  work_location VARCHAR(255),
  check_in_location JSON, -- GPS coordinates
  check_out_location JSON,
  notes TEXT,
  is_manual_entry BOOLEAN DEFAULT false,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMP,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(employee_id, date)
);

-- Leave Requests
CREATE TYPE leave_type AS ENUM (
  'annual', 'sick', 'personal', 'maternity', 'paternity', 
  'emergency', 'unpaid', 'bereavement', 'study', 'hajj'
);

CREATE TYPE leave_status AS ENUM (
  'pending', 'approved', 'rejected', 'cancelled'
);

CREATE TABLE IF NOT EXISTS leave_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  department_id UUID REFERENCES departments(id),
  type leave_type NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_days DECIMAL(5,2) NOT NULL,
  reason TEXT NOT NULL,
  status leave_status DEFAULT 'pending',
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMP,
  rejected_reason TEXT,
  emergency_contact VARCHAR(255),
  documents TEXT[], -- Document URLs
  is_half_day BOOLEAN DEFAULT false,
  substitute_id UUID REFERENCES employees(id),
  handover_notes TEXT,
  return_date DATE,
  actual_return_date DATE,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service Catalog (1,150+ services)
CREATE TYPE service_category AS ENUM (
  'maintenance', 'cleaning', 'security', 'technical', 'administrative',
  'hvac', 'plumbing', 'electrical', 'landscaping', 'pest_control',
  'painting', 'flooring', 'carpentry', 'masonry', 'roofing',
  'installation', 'repair', 'inspection', 'testing', 'certification'
);

CREATE TYPE skill_level AS ENUM (
  'beginner', 'intermediate', 'advanced', 'expert'
);

CREATE TYPE service_priority AS ENUM (
  'low', 'medium', 'high', 'critical'
);

CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category service_category NOT NULL,
  subcategory VARCHAR(100),
  department_id UUID REFERENCES departments(id),
  estimated_hours DECIMAL(5,2) DEFAULT 0,
  skill_level skill_level DEFAULT 'intermediate',
  tools TEXT[], -- Required tools/equipment
  materials TEXT[], -- Required materials
  certifications TEXT[], -- Required certifications
  priority service_priority DEFAULT 'medium',
  cost DECIMAL(10,2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'SAR',
  is_active BOOLEAN DEFAULT true,
  workflow JSON, -- Workflow steps
  quality_checks JSON, -- Quality control checklist
  safety_requirements JSON,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service Assignments
CREATE TYPE assignment_status AS ENUM (
  'assigned', 'in_progress', 'completed', 'cancelled'
);

CREATE TABLE IF NOT EXISTS service_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id UUID REFERENCES services(id) NOT NULL,
  employee_id UUID REFERENCES employees(id) NOT NULL,
  property_id UUID REFERENCES properties(id),
  work_order_id UUID REFERENCES work_orders(id),
  status assignment_status DEFAULT 'assigned',
  priority service_priority DEFAULT 'medium',
  assigned_date TIMESTAMP NOT NULL,
  start_date TIMESTAMP,
  due_date TIMESTAMP,
  completed_date TIMESTAMP,
  actual_hours DECIMAL(5,2) DEFAULT 0,
  notes TEXT,
  quality_rating INTEGER CHECK (quality_rating >= 1 AND quality_rating <= 5),
  feedback TEXT,
  assigned_by UUID REFERENCES users(id) NOT NULL,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payroll Records
CREATE TYPE payroll_status AS ENUM (
  'draft', 'processed', 'paid', 'cancelled'
);

CREATE TABLE IF NOT EXISTS payroll_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  pay_period_start DATE NOT NULL,
  pay_period_end DATE NOT NULL,
  pay_date DATE NOT NULL,
  
  -- Earnings
  base_salary DECIMAL(12,2) DEFAULT 0,
  regular_hours DECIMAL(5,2) DEFAULT 0,
  overtime_hours DECIMAL(5,2) DEFAULT 0,
  overtime_rate DECIMAL(3,2) DEFAULT 1.5,
  bonus DECIMAL(10,2) DEFAULT 0,
  commission DECIMAL(10,2) DEFAULT 0,
  allowances DECIMAL(10,2) DEFAULT 0,
  gross_pay DECIMAL(12,2) DEFAULT 0,
  
  -- Deductions
  tax_deduction DECIMAL(10,2) DEFAULT 0,
  social_security DECIMAL(10,2) DEFAULT 0,
  insurance DECIMAL(10,2) DEFAULT 0,
  other_deductions DECIMAL(10,2) DEFAULT 0,
  total_deductions DECIMAL(10,2) DEFAULT 0,
  
  -- Net Pay
  net_pay DECIMAL(12,2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'SAR',
  
  -- Status and Processing
  status payroll_status DEFAULT 'draft',
  processed_by UUID REFERENCES users(id),
  processed_at TIMESTAMP,
  payment_method VARCHAR(50),
  payment_reference VARCHAR(100),
  notes TEXT,
  
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(employee_id, pay_period_start, pay_period_end)
);

-- Employee Documents
CREATE TYPE document_category AS ENUM (
  'contract', 'id_copy', 'certificate', 'photo', 'resume',
  'performance_review', 'training', 'medical', 'visa', 
  'insurance', 'education', 'reference', 'other'
);

CREATE TABLE IF NOT EXISTS employee_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  filename VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  url VARCHAR(500) NOT NULL,
  size INTEGER NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  category document_category NOT NULL,
  description TEXT,
  is_confidential BOOLEAN DEFAULT true,
  expiry_date DATE, -- For documents that expire
  is_verified BOOLEAN DEFAULT false,
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMP,
  tags TEXT[] DEFAULT '{}',
  uploaded_by UUID REFERENCES users(id) NOT NULL,
  org_id UUID REFERENCES organizations(id) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================
-- Indexes for Performance
-- ==============================================

-- Department indexes
CREATE INDEX IF NOT EXISTS idx_departments_org_id ON departments(org_id);
CREATE INDEX IF NOT EXISTS idx_departments_manager_id ON departments(manager_id);
CREATE INDEX IF NOT EXISTS idx_departments_parent_id ON departments(parent_id);
CREATE INDEX IF NOT EXISTS idx_departments_code ON departments(code);

-- Employee indexes
CREATE INDEX IF NOT EXISTS idx_employees_user_id ON employees(user_id);
CREATE INDEX IF NOT EXISTS idx_employees_org_id ON employees(org_id);
CREATE INDEX IF NOT EXISTS idx_employees_department_id ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_employees_employee_number ON employees(employee_number);
CREATE INDEX IF NOT EXISTS idx_employees_employment_status ON employees(employment_status);
CREATE INDEX IF NOT EXISTS idx_employees_direct_reporter_id ON employees(direct_reporter_id);

-- Attendance indexes
CREATE INDEX IF NOT EXISTS idx_attendance_employee_id ON attendance_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance_records(date);
CREATE INDEX IF NOT EXISTS idx_attendance_org_id ON attendance_records(org_id);
CREATE INDEX IF NOT EXISTS idx_attendance_status ON attendance_records(status);

-- Leave request indexes
CREATE INDEX IF NOT EXISTS idx_leave_requests_employee_id ON leave_requests(employee_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_org_id ON leave_requests(org_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_status ON leave_requests(status);
CREATE INDEX IF NOT EXISTS idx_leave_requests_start_date ON leave_requests(start_date);
CREATE INDEX IF NOT EXISTS idx_leave_requests_type ON leave_requests(type);

-- Service indexes
CREATE INDEX IF NOT EXISTS idx_services_org_id ON services(org_id);
CREATE INDEX IF NOT EXISTS idx_services_code ON services(code);
CREATE INDEX IF NOT EXISTS idx_services_category ON services(category);
CREATE INDEX IF NOT EXISTS idx_services_department_id ON services(department_id);
CREATE INDEX IF NOT EXISTS idx_services_is_active ON services(is_active);

-- Service assignment indexes
CREATE INDEX IF NOT EXISTS idx_service_assignments_service_id ON service_assignments(service_id);
CREATE INDEX IF NOT EXISTS idx_service_assignments_employee_id ON service_assignments(employee_id);
CREATE INDEX IF NOT EXISTS idx_service_assignments_org_id ON service_assignments(org_id);
CREATE INDEX IF NOT EXISTS idx_service_assignments_status ON service_assignments(status);

-- Payroll indexes
CREATE INDEX IF NOT EXISTS idx_payroll_employee_id ON payroll_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_payroll_org_id ON payroll_records(org_id);
CREATE INDEX IF NOT EXISTS idx_payroll_pay_date ON payroll_records(pay_date);
CREATE INDEX IF NOT EXISTS idx_payroll_status ON payroll_records(status);

-- Document indexes
CREATE INDEX IF NOT EXISTS idx_employee_documents_employee_id ON employee_documents(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_documents_org_id ON employee_documents(org_id);
CREATE INDEX IF NOT EXISTS idx_employee_documents_category ON employee_documents(category);

-- ==============================================
-- Update Triggers
-- ==============================================

-- Add update triggers for all HR tables
CREATE TRIGGER update_departments_updated_at 
  BEFORE UPDATE ON departments 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at 
  BEFORE UPDATE ON employees 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_attendance_records_updated_at 
  BEFORE UPDATE ON attendance_records 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leave_requests_updated_at 
  BEFORE UPDATE ON leave_requests 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_services_updated_at 
  BEFORE UPDATE ON services 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_service_assignments_updated_at 
  BEFORE UPDATE ON service_assignments 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payroll_records_updated_at 
  BEFORE UPDATE ON payroll_records 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employee_documents_updated_at 
  BEFORE UPDATE ON employee_documents 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();