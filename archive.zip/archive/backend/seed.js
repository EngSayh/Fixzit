import pkg from 'pg';
const { Pool } = pkg;
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

async function seed() {
  console.log('🌱 Starting FIXZIT SOUQ seed process...');
  
  try {
    await pool.connect();
    console.log('✅ Connected to PostgreSQL');
    
    // Clear existing data
    console.log('🧹 Clearing existing data...');
    await pool.query('TRUNCATE TABLE work_orders, units, properties, users, organizations CASCADE');
    
    // Create Demo Organization
    console.log('🏢 Creating organization...');
    const orgId = uuidv4();
    await pool.query(`
      INSERT INTO organizations (id, name, subdomain, plan, is_active)
      VALUES ($1, $2, $3, $4, $5)
    `, [orgId, 'FIXZIT Demo Corporation', 'demo', 'enterprise', true]);
    
    // Create Users
    console.log('👥 Creating users...');
    const users = [
      {
        id: uuidv4(),
        email: 'admin@fixzit.com',
        password: 'Admin@123',
        firstName: 'System',
        lastName: 'Administrator',
        role: 'SUPER_ADMIN'
      },
      {
        id: uuidv4(),
        email: 'manager@fixzit.com',
        password: 'Manager@123',
        firstName: 'Property',
        lastName: 'Manager',
        role: 'PROPERTY_MANAGER'
      },
      {
        id: uuidv4(),
        email: 'tech@fixzit.com',
        password: 'Tech@123',
        firstName: 'Lead',
        lastName: 'Technician',
        role: 'TECHNICIAN'
      }
    ];
    
    const createdUsers = [];
    for (const userData of users) {
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      await pool.query(`
        INSERT INTO users (id, email, password, first_name, last_name, role, org_id, is_active)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [userData.id, userData.email, hashedPassword, userData.firstName, userData.lastName, userData.role, orgId, true]);
      
      createdUsers.push(userData);
    }
    
    // Create Properties
    console.log('🏠 Creating properties...');
    const properties = [
      {
        id: uuidv4(),
        name: 'Sunset Towers',
        address: 'King Fahd Road, Riyadh 12345, Saudi Arabia',
        type: 'residential',
        totalUnits: 48
      },
      {
        id: uuidv4(),
        name: 'Business Plaza',
        address: 'Olaya Street, Riyadh 11372, Saudi Arabia',
        type: 'commercial',
        totalUnits: 24
      }
    ];
    
    const createdProperties = [];
    for (const propData of properties) {
      await pool.query(`
        INSERT INTO properties (id, name, address, type, total_units, org_id, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [propData.id, propData.name, propData.address, propData.type, propData.totalUnits, orgId, createdUsers[0].id]);
      
      createdProperties.push(propData);
    }
    
    // Create Units
    console.log('🏠 Creating units...');
    for (const property of createdProperties) {
      const unitCount = Math.min(property.totalUnits, 10); // Create 10 sample units
      for (let i = 1; i <= unitCount; i++) {
        const unitNumber = property.type === 'residential' ? `A${i.toString().padStart(3, '0')}` : `B${i.toString().padStart(3, '0')}`;
        await pool.query(`
          INSERT INTO units (id, property_id, unit_number, type, bedrooms, bathrooms, area_sqm, rent_amount, status, org_id)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `, [
          uuidv4(), property.id, unitNumber, 
          property.type === 'residential' ? '2BR' : 'Office',
          property.type === 'residential' ? 2 : 0,
          property.type === 'residential' ? 2 : 1,
          property.type === 'residential' ? 120 : 50,
          property.type === 'residential' ? 3500 : 5000,
          i <= unitCount * 0.8 ? 'occupied' : 'vacant',
          orgId
        ]);
      }
    }
    
    // Create Sample Work Orders
    console.log('🔧 Creating work orders...');
    const workOrders = [
      {
        title: 'Air Conditioning Repair',
        description: 'AC unit not cooling properly in unit A001. Requires immediate attention.',
        category: 'hvac',
        priority: 'high',
        status: 'open'
      },
      {
        title: 'Elevator Maintenance',
        description: 'Scheduled monthly maintenance for elevator in Business Plaza',
        category: 'maintenance',
        priority: 'medium',
        status: 'in_progress'
      },
      {
        title: 'Plumbing Issue',
        description: 'Water leak reported in bathroom of unit A025',
        category: 'plumbing',
        priority: 'high',
        status: 'completed'
      }
    ];
    
    for (const woData of workOrders) {
      const woNumber = `WO-${Date.now()}-${uuidv4().substring(0, 8).toUpperCase()}`;
      await pool.query(`
        INSERT INTO work_orders (id, wo_number, title, description, category, priority, status, property_id, org_id, created_by, assigned_to)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      `, [
        uuidv4(), woNumber, woData.title, woData.description, woData.category,
        woData.priority, woData.status, createdProperties[0].id, orgId, 
        createdUsers[0].id, woData.status === 'in_progress' ? createdUsers[2].id : null
      ]);
      
      // Small delay for unique timestamps
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    
    console.log('✅ FIXZIT SOUQ seed completed successfully!');
    console.log('');
    console.log('📋 Available Accounts:');
    console.log('🔑 Super Admin: admin@fixzit.com / Admin@123');
    console.log('🔑 Property Manager: manager@fixzit.com / Manager@123');
    console.log('🔑 Technician: tech@fixzit.com / Tech@123');
    console.log('');
    console.log('📊 Data Summary:');
    console.log(`🏢 Organizations: 1`);
    console.log(`👥 Users: ${createdUsers.length}`);
    console.log(`🏠 Properties: ${createdProperties.length}`);
    console.log(`🏠 Units: ${createdProperties.reduce((sum, p) => sum + Math.min(p.totalUnits, 10), 0)}`);
    console.log(`🔧 Work Orders: ${workOrders.length}`);
    
  } catch (error) {
    console.error('❌ Seed error:', error);
  } finally {
    await pool.end();
    process.exit(0);
  }
}

seed();
