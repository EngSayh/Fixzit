// FIXZIT SOUQ Enterprise - Comprehensive Role and Permission System
// 14+ User Roles with Module-based Permissions

export const MODULES = {
  DASHBOARD: 'dashboard',
  WORK_ORDERS: 'work-orders',
  PROPERTIES: 'properties', 
  FINANCE: 'finance',
  HR: 'hr',
  ADMIN: 'admin',
  CRM: 'crm',
  MARKETPLACE: 'marketplace',
  SUPPORT: 'support',
  COMPLIANCE: 'compliance',
  REPORTS: 'reports',
  SYSTEM: 'system',
  PREVENTIVE_MAINTENANCE: 'preventive-maintenance',
  IOT: 'iot',
  SOUQ: 'souq',
  AQAR: 'aqar'
};

export const ACTIONS = {
  READ: 'read',
  WRITE: 'write', 
  DELETE: 'delete',
  APPROVE: 'approve',
  MANAGE: 'manage',
  EXECUTE: 'execute',
  EXPORT: 'export',
  AUDIT: 'audit'
};

// Comprehensive Permission Definitions
export const PERMISSIONS = [
  // Dashboard Permissions
  { name: 'dashboard.read', displayName: 'View Dashboard', module: MODULES.DASHBOARD, action: ACTIONS.READ },
  { name: 'dashboard.manage', displayName: 'Manage Dashboard', module: MODULES.DASHBOARD, action: ACTIONS.MANAGE },
  
  // Work Orders Permissions
  { name: 'work-orders.read', displayName: 'View Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.READ },
  { name: 'work-orders.write', displayName: 'Create/Edit Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.WRITE },
  { name: 'work-orders.delete', displayName: 'Delete Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.DELETE },
  { name: 'work-orders.approve', displayName: 'Approve Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.APPROVE },
  { name: 'work-orders.execute', displayName: 'Execute Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.EXECUTE },
  { name: 'work-orders.manage', displayName: 'Manage Work Orders', module: MODULES.WORK_ORDERS, action: ACTIONS.MANAGE },
  
  // Properties Permissions
  { name: 'properties.read', displayName: 'View Properties', module: MODULES.PROPERTIES, action: ACTIONS.READ },
  { name: 'properties.write', displayName: 'Create/Edit Properties', module: MODULES.PROPERTIES, action: ACTIONS.WRITE },
  { name: 'properties.delete', displayName: 'Delete Properties', module: MODULES.PROPERTIES, action: ACTIONS.DELETE },
  { name: 'properties.manage', displayName: 'Manage Properties', module: MODULES.PROPERTIES, action: ACTIONS.MANAGE },
  
  // Finance Permissions
  { name: 'finance.read', displayName: 'View Financial Data', module: MODULES.FINANCE, action: ACTIONS.READ },
  { name: 'finance.write', displayName: 'Create/Edit Financial Records', module: MODULES.FINANCE, action: ACTIONS.WRITE },
  { name: 'finance.approve', displayName: 'Approve Financial Transactions', module: MODULES.FINANCE, action: ACTIONS.APPROVE },
  { name: 'finance.manage', displayName: 'Manage Finance Module', module: MODULES.FINANCE, action: ACTIONS.MANAGE },
  { name: 'finance.export', displayName: 'Export Financial Reports', module: MODULES.FINANCE, action: ACTIONS.EXPORT },
  
  // HR Permissions
  { name: 'hr.read', displayName: 'View HR Data', module: MODULES.HR, action: ACTIONS.READ },
  { name: 'hr.write', displayName: 'Create/Edit HR Records', module: MODULES.HR, action: ACTIONS.WRITE },
  { name: 'hr.approve', displayName: 'Approve HR Actions', module: MODULES.HR, action: ACTIONS.APPROVE },
  { name: 'hr.manage', displayName: 'Manage HR Module', module: MODULES.HR, action: ACTIONS.MANAGE },
  
  // Admin Permissions
  { name: 'admin.read', displayName: 'View Admin Panel', module: MODULES.ADMIN, action: ACTIONS.READ },
  { name: 'admin.write', displayName: 'Create/Edit Admin Settings', module: MODULES.ADMIN, action: ACTIONS.WRITE },
  { name: 'admin.manage', displayName: 'Full Admin Access', module: MODULES.ADMIN, action: ACTIONS.MANAGE },
  { name: 'admin.audit', displayName: 'Audit System Activity', module: MODULES.ADMIN, action: ACTIONS.AUDIT },
  
  // CRM Permissions
  { name: 'crm.read', displayName: 'View CRM Data', module: MODULES.CRM, action: ACTIONS.READ },
  { name: 'crm.write', displayName: 'Create/Edit CRM Records', module: MODULES.CRM, action: ACTIONS.WRITE },
  { name: 'crm.manage', displayName: 'Manage CRM Module', module: MODULES.CRM, action: ACTIONS.MANAGE },
  
  // Marketplace Permissions
  { name: 'marketplace.read', displayName: 'View Marketplace', module: MODULES.MARKETPLACE, action: ACTIONS.READ },
  { name: 'marketplace.write', displayName: 'Create/Edit Marketplace Items', module: MODULES.MARKETPLACE, action: ACTIONS.WRITE },
  { name: 'marketplace.manage', displayName: 'Manage Marketplace', module: MODULES.MARKETPLACE, action: ACTIONS.MANAGE },
  
  // Support Permissions
  { name: 'support.read', displayName: 'View Support Tickets', module: MODULES.SUPPORT, action: ACTIONS.READ },
  { name: 'support.write', displayName: 'Create/Edit Support Tickets', module: MODULES.SUPPORT, action: ACTIONS.WRITE },
  { name: 'support.manage', displayName: 'Manage Support System', module: MODULES.SUPPORT, action: ACTIONS.MANAGE },
  
  // Compliance Permissions
  { name: 'compliance.read', displayName: 'View Compliance Data', module: MODULES.COMPLIANCE, action: ACTIONS.READ },
  { name: 'compliance.write', displayName: 'Create/Edit Compliance Records', module: MODULES.COMPLIANCE, action: ACTIONS.WRITE },
  { name: 'compliance.approve', displayName: 'Approve Compliance Items', module: MODULES.COMPLIANCE, action: ACTIONS.APPROVE },
  { name: 'compliance.manage', displayName: 'Manage Compliance Module', module: MODULES.COMPLIANCE, action: ACTIONS.MANAGE },
  
  // Reports Permissions
  { name: 'reports.read', displayName: 'View Reports', module: MODULES.REPORTS, action: ACTIONS.READ },
  { name: 'reports.write', displayName: 'Create/Edit Reports', module: MODULES.REPORTS, action: ACTIONS.WRITE },
  { name: 'reports.export', displayName: 'Export Reports', module: MODULES.REPORTS, action: ACTIONS.EXPORT },
  { name: 'reports.manage', displayName: 'Manage Reports Module', module: MODULES.REPORTS, action: ACTIONS.MANAGE },
  
  // System Permissions
  { name: 'system.read', displayName: 'View System Settings', module: MODULES.SYSTEM, action: ACTIONS.READ },
  { name: 'system.write', displayName: 'Edit System Settings', module: MODULES.SYSTEM, action: ACTIONS.WRITE },
  { name: 'system.manage', displayName: 'Full System Management', module: MODULES.SYSTEM, action: ACTIONS.MANAGE },
  
  // Preventive Maintenance Permissions
  { name: 'preventive-maintenance.read', displayName: 'View Preventive Maintenance', module: MODULES.PREVENTIVE_MAINTENANCE, action: ACTIONS.READ },
  { name: 'preventive-maintenance.write', displayName: 'Create/Edit Maintenance Plans', module: MODULES.PREVENTIVE_MAINTENANCE, action: ACTIONS.WRITE },
  { name: 'preventive-maintenance.execute', displayName: 'Execute Maintenance Plans', module: MODULES.PREVENTIVE_MAINTENANCE, action: ACTIONS.EXECUTE },
  { name: 'preventive-maintenance.manage', displayName: 'Manage Preventive Maintenance', module: MODULES.PREVENTIVE_MAINTENANCE, action: ACTIONS.MANAGE },
  
  // IoT Permissions
  { name: 'iot.read', displayName: 'View IoT Data', module: MODULES.IOT, action: ACTIONS.READ },
  { name: 'iot.write', displayName: 'Configure IoT Devices', module: MODULES.IOT, action: ACTIONS.WRITE },
  { name: 'iot.manage', displayName: 'Manage IoT System', module: MODULES.IOT, action: ACTIONS.MANAGE },
  
  // Souq Permissions
  { name: 'souq.read', displayName: 'View Souq', module: MODULES.SOUQ, action: ACTIONS.READ },
  { name: 'souq.write', displayName: 'Create/Edit Souq Items', module: MODULES.SOUQ, action: ACTIONS.WRITE },
  { name: 'souq.manage', displayName: 'Manage Souq Module', module: MODULES.SOUQ, action: ACTIONS.MANAGE },
  
  // Aqar Permissions
  { name: 'aqar.read', displayName: 'View Aqar', module: MODULES.AQAR, action: ACTIONS.READ },
  { name: 'aqar.write', displayName: 'Create/Edit Aqar Listings', module: MODULES.AQAR, action: ACTIONS.WRITE },
  { name: 'aqar.manage', displayName: 'Manage Aqar Module', module: MODULES.AQAR, action: ACTIONS.MANAGE }
];

// 14+ Comprehensive User Roles
export const ROLES = [
  {
    name: 'SUPER_ADMIN',
    displayName: 'Super Administrator',
    description: 'Full system access with all permissions',
    level: 100,
    isSystem: true,
    permissions: PERMISSIONS.map(p => p.name), // All permissions
    defaultRedirect: '/dashboard'
  },
  {
    name: 'SYSTEM_ADMIN',
    displayName: 'System Administrator',
    description: 'System-level administration and configuration',
    level: 90,
    permissions: [
      'dashboard.read', 'dashboard.manage',
      'admin.read', 'admin.write', 'admin.manage', 'admin.audit',
      'system.read', 'system.write', 'system.manage',
      'reports.read', 'reports.write', 'reports.export', 'reports.manage'
    ],
    defaultRedirect: '/admin'
  },
  {
    name: 'ORGANIZATION_ADMIN',
    displayName: 'Organization Administrator',
    description: 'Organization-wide administration',
    level: 80,
    permissions: [
      'dashboard.read', 'dashboard.manage',
      'work-orders.read', 'work-orders.write', 'work-orders.approve', 'work-orders.manage',
      'properties.read', 'properties.write', 'properties.manage',
      'finance.read', 'finance.write', 'finance.approve',
      'hr.read', 'hr.write', 'hr.approve',
      'admin.read', 'admin.write',
      'crm.read', 'crm.write', 'crm.manage',
      'reports.read', 'reports.write', 'reports.export'
    ],
    defaultRedirect: '/dashboard'
  },
  {
    name: 'PROPERTY_MANAGER',
    displayName: 'Property Manager',
    description: 'Manages specific properties and related work orders',
    level: 70,
    permissions: [
      'dashboard.read',
      'work-orders.read', 'work-orders.write', 'work-orders.approve',
      'properties.read', 'properties.write',
      'preventive-maintenance.read', 'preventive-maintenance.write', 'preventive-maintenance.execute',
      'crm.read', 'crm.write',
      'reports.read'
    ],
    defaultRedirect: '/properties'
  },
  {
    name: 'FACILITY_MANAGER',
    displayName: 'Facility Manager',
    description: 'Manages facility operations and maintenance',
    level: 65,
    permissions: [
      'dashboard.read',
      'work-orders.read', 'work-orders.write', 'work-orders.execute',
      'properties.read',
      'preventive-maintenance.read', 'preventive-maintenance.write', 'preventive-maintenance.execute', 'preventive-maintenance.manage',
      'iot.read', 'iot.write',
      'compliance.read', 'compliance.write'
    ],
    defaultRedirect: '/preventive-maintenance'
  },
  {
    name: 'FINANCE_MANAGER',
    displayName: 'Finance Manager',
    description: 'Manages financial operations and approvals',
    level: 60,
    permissions: [
      'dashboard.read',
      'finance.read', 'finance.write', 'finance.approve', 'finance.manage', 'finance.export',
      'reports.read', 'reports.write', 'reports.export',
      'work-orders.read',
      'properties.read'
    ],
    defaultRedirect: '/finance'
  },
  {
    name: 'HR_MANAGER',
    displayName: 'HR Manager',
    description: 'Manages human resources operations',
    level: 60,
    permissions: [
      'dashboard.read',
      'hr.read', 'hr.write', 'hr.approve', 'hr.manage',
      'reports.read', 'reports.write',
      'compliance.read', 'compliance.write'
    ],
    defaultRedirect: '/hr'
  },
  {
    name: 'COMPLIANCE_OFFICER',
    displayName: 'Compliance Officer',
    description: 'Manages compliance and regulatory requirements',
    level: 55,
    permissions: [
      'dashboard.read',
      'compliance.read', 'compliance.write', 'compliance.approve', 'compliance.manage',
      'reports.read', 'reports.write',
      'work-orders.read',
      'properties.read'
    ],
    defaultRedirect: '/compliance'
  },
  {
    name: 'MAINTENANCE_SUPERVISOR',
    displayName: 'Maintenance Supervisor',
    description: 'Supervises maintenance teams and work orders',
    level: 50,
    permissions: [
      'dashboard.read',
      'work-orders.read', 'work-orders.write', 'work-orders.approve', 'work-orders.execute',
      'preventive-maintenance.read', 'preventive-maintenance.write', 'preventive-maintenance.execute',
      'properties.read',
      'iot.read'
    ],
    defaultRedirect: '/work-orders'
  },
  {
    name: 'TECHNICIAN',
    displayName: 'Technician',
    description: 'Executes work orders and maintenance tasks',
    level: 30,
    permissions: [
      'dashboard.read',
      'work-orders.read', 'work-orders.execute',
      'preventive-maintenance.read', 'preventive-maintenance.execute',
      'properties.read',
      'iot.read'
    ],
    defaultRedirect: '/work-orders'
  },
  {
    name: 'CRM_MANAGER',
    displayName: 'CRM Manager',
    description: 'Manages customer relationships and support',
    level: 50,
    permissions: [
      'dashboard.read',
      'crm.read', 'crm.write', 'crm.manage',
      'support.read', 'support.write', 'support.manage',
      'reports.read'
    ],
    defaultRedirect: '/crm'
  },
  {
    name: 'SUPPORT_AGENT',
    displayName: 'Support Agent',
    description: 'Handles customer support and tickets',
    level: 25,
    permissions: [
      'dashboard.read',
      'support.read', 'support.write',
      'crm.read', 'crm.write',
      'work-orders.read'
    ],
    defaultRedirect: '/support'
  },
  {
    name: 'MARKETPLACE_MANAGER',
    displayName: 'Marketplace Manager',
    description: 'Manages marketplace operations and vendors',
    level: 45,
    permissions: [
      'dashboard.read',
      'marketplace.read', 'marketplace.write', 'marketplace.manage',
      'souq.read', 'souq.write', 'souq.manage',
      'crm.read', 'crm.write',
      'reports.read'
    ],
    defaultRedirect: '/marketplace'
  },
  {
    name: 'VENDOR',
    displayName: 'Vendor',
    description: 'External vendor with limited marketplace access',
    level: 20,
    permissions: [
      'dashboard.read',
      'marketplace.read',
      'souq.read',
      'work-orders.read'
    ],
    defaultRedirect: '/marketplace'
  },
  {
    name: 'TENANT',
    displayName: 'Tenant',
    description: 'Property tenant with basic access',
    level: 10,
    permissions: [
      'dashboard.read',
      'work-orders.read', 'work-orders.write',
      'support.read', 'support.write',
      'marketplace.read'
    ],
    defaultRedirect: '/work-orders'
  },
  {
    name: 'AUDITOR',
    displayName: 'Auditor',
    description: 'Read-only access for audit purposes',
    level: 40,
    permissions: [
      'dashboard.read',
      'work-orders.read',
      'properties.read',
      'finance.read',
      'hr.read',
      'compliance.read',
      'reports.read',
      'admin.audit'
    ],
    defaultRedirect: '/reports'
  },
  {
    name: 'GUEST',
    displayName: 'Guest User',
    description: 'Limited guest access',
    level: 5,
    permissions: [
      'dashboard.read',
      'marketplace.read'
    ],
    defaultRedirect: '/dashboard'
  }
];

// Helper functions for role management
export const getRoleByName = (roleName) => {
  return ROLES.find(role => role.name === roleName);
};

export const getPermissionsByRole = (roleName) => {
  const role = getRoleByName(roleName);
  return role ? role.permissions : [];
};

export const hasPermission = (userPermissions, requiredPermission) => {
  return userPermissions.includes(requiredPermission);
};

export const hasAnyPermission = (userPermissions, requiredPermissions) => {
  return requiredPermissions.some(permission => userPermissions.includes(permission));
};

export const hasAllPermissions = (userPermissions, requiredPermissions) => {
  return requiredPermissions.every(permission => userPermissions.includes(permission));
};

export const getAccessibleModules = (userPermissions) => {
  const accessibleModules = new Set();
  
  PERMISSIONS.forEach(permission => {
    if (userPermissions.includes(permission.name)) {
      accessibleModules.add(permission.module);
    }
  });
  
  return Array.from(accessibleModules);
};