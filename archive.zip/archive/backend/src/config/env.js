/**
 * FIXZIT SOUQ - Secure Environment Configuration
 * Validates environment variables without exposing secrets
 */

const logger = require('../logger');

// Basic validation function (replacing zod for now)
const validateEnv = (env) => {
  const required = [
    'DATABASE_URL',
    'JWT_SECRET'
  ];

  const optional = {
    'NODE_ENV': 'development',
    'PORT': '5000',
    'LOG_LEVEL': 'info'
  };

  const missing = [];
  const validated = {};

  // Check required variables
  for (const key of required) {
    if (!env[key]) {
      missing.push(key);
    } else {
      validated[key] = env[key];
    }
  }

  // Set optional variables with defaults
  for (const [key, defaultValue] of Object.entries(optional)) {
    validated[key] = env[key] || defaultValue;
  }

  // Additional validations
  if (validated.JWT_SECRET && validated.JWT_SECRET.length < 32) {
    missing.push('JWT_SECRET (must be at least 32 characters)');
  }

  if (missing.length > 0) {
    // DO NOT log actual values - only list missing keys
    logger.error(`Invalid/missing environment variables: ${missing.join(', ')}`);
    logger.error('Please check your .env file and ensure all required variables are set');
    process.exit(1);
  }

  return validated;
};

const Env = validateEnv(process.env);

// Log successful validation (without values)
logger.info('Environment validation successful');

module.exports = Env;