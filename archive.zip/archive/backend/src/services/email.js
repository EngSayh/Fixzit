/**
 * FIXZIT SOUQ - Email Service
 * Secure email handling for notifications and password resets
 */

const logger = require('../logger');

class EmailService {
  constructor() {
    this.isConfigured = false;
    this.fromAddress = 'no-reply@fixzit.world';
    
    // Check if SendGrid is available
    try {
      this.sgMail = require('@sendgrid/mail');
      if (process.env.SENDGRID_API_KEY) {
        this.sgMail.setApiKey(process.env.SENDGRID_API_KEY);
        this.isConfigured = true;
        logger.info('Email service configured with SendGrid');
      }
    } catch (err) {
      logger.warn('SendGrid not available, using mock email service');
    }
  }

  async send(options) {
    const { to, subject, html, text } = options;
    
    if (!to || !subject || (!html && !text)) {
      throw new Error('Missing required email parameters');
    }

    if (this.isConfigured) {
      try {
        await this.sgMail.send({
          to,
          from: this.fromAddress,
          subject,
          html: html || text,
          text: text || html
        });
        logger.info({ to, subject }, 'Email sent successfully');
        return { success: true };
      } catch (error) {
        logger.error({ error, to, subject }, 'Failed to send email');
        throw error;
      }
    } else {
      // Mock email service for development
      logger.info({ to, subject, mock: true }, 'Mock email sent (no email service configured)');
      return { success: true, mock: true };
    }
  }

  async sendPasswordReset(email, resetToken) {
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password?token=${resetToken}`;
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0061A8;">Password Reset Request</h2>
        <p>You requested a password reset for your Fixzit account.</p>
        <p>Click the link below to reset your password:</p>
        <a href="${resetUrl}" style="background: #0061A8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Reset Password</a>
        <p><small>This link will expire in 1 hour. If you didn't request this, please ignore this email.</small></p>
      </div>
    `;

    return this.send({
      to: email,
      subject: 'Fixzit - Password Reset Request',
      html
    });
  }

  async sendWelcome(email, name) {
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0061A8;">Welcome to Fixzit!</h2>
        <p>Hello ${name},</p>
        <p>Welcome to the Fixzit platform. Your account has been successfully created.</p>
        <p>You can now access all our services and manage your properties efficiently.</p>
        <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}" style="background: #00A859; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Access Platform</a>
      </div>
    `;

    return this.send({
      to: email,
      subject: 'Welcome to Fixzit Platform',
      html
    });
  }
}

module.exports = new EmailService();