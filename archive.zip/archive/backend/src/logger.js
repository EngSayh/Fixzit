/**
 * FIXZIT SOUQ - Secure Logger
 * Replaces all console.* usage with structured logging
 */

const util = require('util');

const logger = {
  level: process.env.LOG_LEVEL || 'info',
  
  // Redact sensitive information
  redact: (obj) => {
    if (typeof obj !== 'object' || obj === null) return obj;
    
    const redacted = { ...obj };
    const sensitiveFields = ['password', 'token', 'authorization', 'jwtSecret', 'api_key'];
    
    for (const field of sensitiveFields) {
      if (redacted[field]) {
        redacted[field] = '[REDACTED]';
      }
    }
    
    // Redact nested objects
    Object.keys(redacted).forEach(key => {
      if (typeof redacted[key] === 'object' && redacted[key] !== null) {
        redacted[key] = logger.redact(redacted[key]);
      }
    });
    
    return redacted;
  },

  formatMessage: (level, message, context) => {
    const timestamp = new Date().toISOString();
    const contextStr = context ? ` | Context: ${util.inspect(logger.redact(context), { depth: 2 })}` : '';
    return `[${timestamp}] ${level.toUpperCase()}: ${message}${contextStr}`;
  },

  error: (context, message = '') => {
    if (typeof context === 'string') {
      message = context;
      context = null;
    }
    console.error(logger.formatMessage('error', message, context));
  },

  warn: (context, message = '') => {
    if (typeof context === 'string') {
      message = context;
      context = null;
    }
    if (logger.level === 'error') return;
    console.warn(logger.formatMessage('warn', message, context));
  },

  info: (context, message = '') => {
    if (typeof context === 'string') {
      message = context;
      context = null;
    }
    if (['error', 'warn'].includes(logger.level)) return;
    console.log(logger.formatMessage('info', message, context));
  },

  debug: (context, message = '') => {
    if (typeof context === 'string') {
      message = context;
      context = null;
    }
    if (logger.level !== 'debug') return;
    console.log(logger.formatMessage('debug', message, context));
  }
};

module.exports = logger;