/**
 * FIXZIT SOUQ - Security Middleware Stack
 * Comprehensive security hardening
 */

const logger = require('../logger');

// Basic rate limiting implementation
const rateLimitStore = new Map();

const createRateLimit = (options = {}) => {
  const {
    windowMs = 15 * 60 * 1000, // 15 minutes
    max = 100,
    message = 'Too many requests'
  } = options;

  return (req, res, next) => {
    const key = req.ip || req.connection.remoteAddress;
    const now = Date.now();
    
    if (!rateLimitStore.has(key)) {
      rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
      return next();
    }

    const record = rateLimitStore.get(key);
    
    if (now > record.resetTime) {
      record.count = 1;
      record.resetTime = now + windowMs;
      return next();
    }

    if (record.count >= max) {
      return res.status(429).json({
        code: 'RATE_LIMIT_EXCEEDED',
        message: message
      });
    }

    record.count++;
    next();
  };
};

// Basic CORS implementation
const corsMiddleware = (req, res, next) => {
  const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:5000',
    'https://fixzit.com',
    'https://www.fixzit.com',
    'https://app.fixzit.com'
  ];

  const origin = req.headers.origin;
  
  if (!origin || allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin || '*');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin,X-Requested-With,Content-Type,Accept,Authorization,Cache-Control');
  }

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
};

// Security headers middleware
const securityHeaders = (req, res, next) => {
  res.header('X-Content-Type-Options', 'nosniff');
  res.header('X-Frame-Options', 'DENY');
  res.header('X-XSS-Protection', '1; mode=block');
  res.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.header('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  next();
};

// Setup function to apply all security middleware
const setupSecurity = (app) => {
  logger.info('Setting up security middleware...');

  // Apply security headers
  app.use(securityHeaders);
  
  // Apply CORS
  app.use(corsMiddleware);

  // Rate limiting for different endpoints
  const generalLimiter = createRateLimit({ max: 1000, windowMs: 15 * 60 * 1000 });
  const authLimiter = createRateLimit({ max: 100, windowMs: 15 * 60 * 1000 });
  const strictLimiter = createRateLimit({ max: 10, windowMs: 15 * 60 * 1000 });

  // Apply rate limits
  app.use('/auth', authLimiter);
  app.use('/integrations/email', strictLimiter);
  app.use('/files', authLimiter);
  app.use(generalLimiter);

  logger.info('Security middleware configured successfully');
};

module.exports = {
  setupSecurity,
  createRateLimit,
  corsMiddleware,
  securityHeaders
};