/**
 * FIXZIT SOUQ - Centralized Error Handler
 * Replaces scattered error responses with structured handling
 */

const logger = require('../logger');

module.exports = (err, req, res, next) => {
  // Log error with context
  if (req.log) {
    req.log.error({ err: err.stack || err }, 'Unhandled error');
  } else {
    logger.error({ 
      err: err.stack || err,
      url: req.originalUrl,
      method: req.method 
    }, 'Unhandled error');
  }

  const status = err.statusCode || err.status || 500;
  const body = {
    code: err.code || (status === 500 ? 'INTERNAL_ERROR' : 'REQUEST_ERROR'),
    message: status === 500 ? 'Unexpected server error' : err.message || 'Request failed'
  };

  // Include details in development mode only
  if (process.env.NODE_ENV !== 'production' && err.details) {
    body.details = err.details;
  }

  res.status(status).json(body);
};