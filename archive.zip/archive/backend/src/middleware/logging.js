/**
 * FIXZIT SOUQ - Request Logging Middleware
 * Adds structured logging to Express requests
 */

const logger = require('../logger');
const { v4: uuidv4 } = require('uuid');

module.exports = (req, res, next) => {
  // Generate request ID
  req.id = uuidv4();
  
  // Add logger to request object
  req.log = {
    error: (context, message) => {
      const enrichedContext = {
        ...context,
        requestId: req.id,
        tenantId: req.tenant?.id,
        userId: req.user?.id,
        method: req.method,
        url: req.originalUrl,
        ip: req.ip
      };
      logger.error(enrichedContext, message);
    },
    warn: (context, message) => {
      const enrichedContext = {
        ...context,
        requestId: req.id,
        tenantId: req.tenant?.id,
        userId: req.user?.id,
        method: req.method,
        url: req.originalUrl
      };
      logger.warn(enrichedContext, message);
    },
    info: (context, message) => {
      const enrichedContext = {
        ...context,
        requestId: req.id,
        tenantId: req.tenant?.id,
        userId: req.user?.id,
        method: req.method,
        url: req.originalUrl
      };
      logger.info(enrichedContext, message);
    }
  };

  // Log request start
  const start = Date.now();
  req.log.info(`${req.method} ${req.originalUrl} - Request started`);

  // Log response
  const originalEnd = res.end;
  res.end = function(...args) {
    const duration = Date.now() - start;
    req.log.info({
      statusCode: res.statusCode,
      duration: `${duration}ms`
    }, `${req.method} ${req.originalUrl} - Request completed`);
    
    originalEnd.apply(this, args);
  };

  next();
};