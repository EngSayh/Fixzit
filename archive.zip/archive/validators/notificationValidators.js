const { body, validationResult } = require('express-validator');

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

const validateNotification = [
  body('recipientId')
    .notEmpty().withMessage('Recipient ID is required')
    .isMongoId().withMessage('Invalid recipient ID'),
  
  body('title')
    .trim()
    .notEmpty().withMessage('Title is required')
    .isLength({ max: 100 }).withMessage('Title must not exceed 100 characters'),
  
  body('message')
    .trim()
    .notEmpty().withMessage('Message is required')
    .isLength({ max: 500 }).withMessage('Message must not exceed 500 characters'),
  
  body('type')
    .isIn(['maintenance', 'payment', 'lease', 'system', 'alert', 'info', 'marketing'])
    .withMessage('Invalid notification type'),
  
  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'urgent'])
    .withMessage('Invalid priority level'),
  
  body('channels')
    .optional()
    .isArray().withMessage('Channels must be an array')
    .custom(channels => {
      const validChannels = ['in-app', 'email', 'sms', 'push'];
      return channels.every(channel => validChannels.includes(channel));
    }).withMessage('Invalid channel specified'),
  
  handleValidationErrors
];

const validatePreferences = [
  body('channels.email')
    .optional()
    .isBoolean().withMessage('Email preference must be boolean'),
  
  body('channels.sms')
    .optional()
    .isBoolean().withMessage('SMS preference must be boolean'),
  
  body('channels.push')
    .optional()
    .isBoolean().withMessage('Push preference must be boolean'),
  
  body('channels.inApp')
    .optional()
    .isBoolean().withMessage('In-app preference must be boolean'),
  
  body('quietHours.enabled')
    .optional()
    .isBoolean().withMessage('Quiet hours enabled must be boolean'),
  
  body('quietHours.start')
    .optional()
    .matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/)
    .withMessage('Start time must be in HH:MM format'),
  
  body('quietHours.end')
    .optional()
    .matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/)
    .withMessage('End time must be in HH:MM format'),
  
  body('language')
    .optional()
    .isIn(['en', 'ar'])
    .withMessage('Language must be either en or ar'),
  
  handleValidationErrors
];

module.exports = {
  validateNotification,
  validatePreferences
};