const { body, validationResult } = require('express-validator');

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

const validateProperty = [
  body('name')
    .trim()
    .notEmpty().withMessage('Property name is required')
    .isLength({ min: 3, max: 100 }).withMessage('Name must be between 3 and 100 characters'),
  
  body('type')
    .isIn(['residential', 'commercial', 'industrial', 'mixed'])
    .withMessage('Invalid property type'),
  
  body('address.street')
    .trim()
    .notEmpty().withMessage('Street address is required'),
  
  body('address.city')
    .trim()
    .notEmpty().withMessage('City is required'),
  
  body('address.country')
    .trim()
    .notEmpty().withMessage('Country is required'),
  
  body('totalArea')
    .optional()
    .isNumeric().withMessage('Total area must be a number'),
  
  body('yearBuilt')
    .optional()
    .isInt({ min: 1800, max: new Date().getFullYear() })
    .withMessage('Invalid year built'),
  
  handleValidationErrors
];

const validateUnit = [
  body('unitNumber')
    .trim()
    .notEmpty().withMessage('Unit number is required'),
  
  body('type')
    .isIn(['apartment', 'villa', 'studio', 'office', 'retail', 'warehouse'])
    .withMessage('Invalid unit type'),
  
  body('floor')
    .optional()
    .isInt({ min: -5, max: 200 }).withMessage('Invalid floor number'),
  
  body('area')
    .optional()
    .isNumeric().withMessage('Area must be a number'),
  
  body('bedrooms')
    .optional()
    .isInt({ min: 0, max: 20 }).withMessage('Invalid number of bedrooms'),
  
  body('bathrooms')
    .optional()
    .isNumeric().withMessage('Bathrooms must be a number'),
  
  body('monthlyRent')
    .optional()
    .isNumeric().withMessage('Monthly rent must be a number'),
  
  handleValidationErrors
];

const validateLease = [
  body('unitId')
    .notEmpty().withMessage('Unit ID is required')
    .isMongoId().withMessage('Invalid unit ID'),
  
  body('tenantId')
    .notEmpty().withMessage('Tenant ID is required')
    .isMongoId().withMessage('Invalid tenant ID'),
  
  body('startDate')
    .notEmpty().withMessage('Start date is required')
    .isISO8601().withMessage('Invalid start date format'),
  
  body('endDate')
    .notEmpty().withMessage('End date is required')
    .isISO8601().withMessage('Invalid end date format')
    .custom((value, { req }) => {
      if (new Date(value) <= new Date(req.body.startDate)) {
        throw new Error('End date must be after start date');
      }
      return true;
    }),
  
  body('monthlyRent')
    .notEmpty().withMessage('Monthly rent is required')
    .isNumeric().withMessage('Monthly rent must be a number')
    .isFloat({ min: 0 }).withMessage('Monthly rent must be positive'),
  
  body('securityDeposit')
    .optional()
    .isNumeric().withMessage('Security deposit must be a number'),
  
  body('paymentMethod')
    .isIn(['bank_transfer', 'cash', 'check', 'online'])
    .withMessage('Invalid payment method'),
  
  handleValidationErrors
];

module.exports = {
  validateProperty,
  validateUnit,
  validateLease
};