"""
Main Dashboard Page - Custom Routed
"""

import streamlit as st
from navigation_new import render_sidebar
from custom_router import get_current_page, navigate_to_page

# COMPLETELY ELIMINATE ALL STREAMLIT NAVIGATION
st.markdown("""
<style>
/* NUCLEAR ELIMINATION - HIDE EVERYTHING */
[data-testid="stSidebarNav"] { display: none !important; visibility: hidden !important; }
[data-testid="stSidebarNavItems"] { display: none !important; visibility: hidden !important; }
[data-testid="stSidebarNavSeparator"] { display: none !important; visibility: hidden !important; }
[data-testid="stSidebarNavLink"] { display: none !important; visibility: hidden !important; }

/* Hide any auto-generated navigation */
.css-1d391kg, .css-pkbazv, .css-1rs6os, .css-ng1t4o, .css-hxt7ib, 
.css-nahz7x, .css-1y4p8pa { display: none !important; visibility: hidden !important; }

/* Force sidebar visible */
section[data-testid="stSidebar"] {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    width: 300px !important;
}
</style>
""", unsafe_allow_html=True)

# Page configuration
st.set_page_config(
    page_title="Fixzit Work OS",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Render custom navigation
render_sidebar()

# Get current page and load it
current_page = get_current_page()

if current_page and current_page != "dashboard.py":
    # Load the requested module dynamically
    navigate_to_page(current_page)
else:
    # Default dashboard content
    st.markdown("""
    <div style="background: linear-gradient(135deg, #F6851F 0%, #037F4C 100%); 
               color: white; padding: 2rem; border-radius: 15px; margin: 2rem 0; text-align: center;">
        <h1 style="margin: 0; color: white; font-size: 48px;">🔧 Fixzit Dashboard</h1>
        <p style="margin: 1rem 0 0 0; opacity: 0.9; font-size: 18px;">
            Work Management System - All modules accessible via sidebar
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Feature overview
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div style="background: white; padding: 1.5rem; border-radius: 10px; border-left: 4px solid #F6851F;">
            <h3 style="color: #023047;">🛠️ Work Management</h3>
            <p style="color: #666;">Boards, Tickets, Technician Dashboard</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background: white; padding: 1.5rem; border-radius: 10px; border-left: 4px solid #F6851F;">
            <h3 style="color: #023047;">🏢 Properties</h3>
            <p style="color: #666;">Property Management & Contracts</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style="background: white; padding: 1.5rem; border-radius: 10px; border-left: 4px solid #F6851F;">
            <h3 style="color: #023047;">💰 Finance</h3>
            <p style="color: #666;">Payments & Financial Reports</p>
        </div>
        """, unsafe_allow_html=True)