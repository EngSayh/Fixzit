// ============================================
// FIXZIT SOUQ - REACT NATIVE TENANT APP
// Complete Mobile Implementation for Saudi Market
// Expo Compatible Version
// ============================================

import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Alert,
  I18nManager,
  Platform,
  StatusBar,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  FlatList,
  Modal,
  KeyboardAvoidingView
} from 'react-native';

// Configure API for local backend
const API_URL = 'http://localhost:5000'; // Local backend URL
const { width, height } = Dimensions.get('window');

// Enable RTL for Arabic
I18nManager.forceRTL(false); // Will be toggled based on language

// Simple HTTP client (replacing axios for now)
const httpClient = {
  defaults: {
    baseURL: API_URL,
    headers: {
      'Content-Type': 'application/json'
    }
  },
  
  async post(url, data) {
    try {
      const response = await fetch(`${this.defaults.baseURL}${url}`, {
        method: 'POST',
        headers: this.defaults.headers,
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      throw error;
    }
  },

  async get(url) {
    try {
      const response = await fetch(`${this.defaults.baseURL}${url}`, {
        method: 'GET',
        headers: this.defaults.headers
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      throw error;
    }
  }
};

// ============================================
// AUTHENTICATION CONTEXT
// ============================================

const AuthContext = React.createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      // For now, skip AsyncStorage and just set loading to false
      setLoading(false);
    } catch (error) {
      console.error('Auth check error:', error);
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    try {
      const response = await httpClient.post('/api/auth/login', { 
        email, 
        password 
      });
      
      const { token, user } = response;
      
      setToken(token);
      setUser(user);
      httpClient.defaults.headers['Authorization'] = `Bearer ${token}`;
      
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.message || 'Login failed' 
      };
    }
  };

  const logout = async () => {
    setToken(null);
    setUser(null);
    delete httpClient.defaults.headers['Authorization'];
  };

  const toggleLanguage = async () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
    I18nManager.forceRTL(newLang === 'ar');
    // Restart app to apply RTL changes
    if (Platform.OS === 'ios') {
      Alert.alert(
        translations[newLang].restartRequired || 'Restart Required',
        translations[newLang].restartMessage || 'Please restart the app to apply language changes',
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      language,
      login,
      logout,
      toggleLanguage
    }}>
      {children}
    </AuthContext.Provider>
  );
};

// ============================================
// TRANSLATIONS
// ============================================

const translations = {
  en: {
    // Auth
    welcome: 'Welcome to Fixzit',
    email: 'Email',
    password: 'Password',
    phone: 'Phone Number',
    login: 'Login',
    logout: 'Logout',
    register: 'Register',
    forgotPassword: 'Forgot Password?',
    
    // Navigation
    home: 'Home',
    requests: 'Requests',
    myUnit: 'My Unit',
    payments: 'Payments',
    profile: 'Profile',
    
    // Dashboard
    activeRequests: 'Active Requests',
    pendingPayments: 'Pending Payments',
    upcomingMaintenance: 'Upcoming Maintenance',
    notifications: 'Notifications',
    
    // Work Orders
    newRequest: 'New Request',
    category: 'Category',
    urgency: 'Urgency',
    description: 'Description',
    attachPhoto: 'Attach Photo',
    submit: 'Submit',
    viewDetails: 'View Details',
    status: 'Status',
    
    // Categories
    plumbing: 'Plumbing',
    electrical: 'Electrical',
    hvac: 'HVAC',
    carpentry: 'Carpentry',
    painting: 'Painting',
    cleaning: 'Cleaning',
    other: 'Other',
    
    // Status
    new: 'New',
    inProgress: 'In Progress',
    pending: 'Pending',
    completed: 'Completed',
    cancelled: 'Cancelled',
    
    // Common
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    cancel: 'Cancel',
    confirm: 'Confirm',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    search: 'Search',
    filter: 'Filter',
    refresh: 'Refresh',
    noData: 'No data available',
    tryAgain: 'Try Again',
    
    // Saudi specific
    sar: 'SAR',
    vat: 'VAT',
    cr: 'CR Number',
  },
  ar: {
    // Auth
    welcome: 'مرحباً بك في فيكسيت',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    phone: 'رقم الجوال',
    login: 'تسجيل الدخول',
    logout: 'تسجيل الخروج',
    register: 'التسجيل',
    forgotPassword: 'نسيت كلمة المرور؟',
    
    // Navigation
    home: 'الرئيسية',
    requests: 'الطلبات',
    myUnit: 'وحدتي',
    payments: 'المدفوعات',
    profile: 'الملف الشخصي',
    
    // Dashboard
    activeRequests: 'الطلبات النشطة',
    pendingPayments: 'المدفوعات المعلقة',
    upcomingMaintenance: 'الصيانة القادمة',
    notifications: 'الإشعارات',
    
    // Work Orders
    newRequest: 'طلب جديد',
    category: 'الفئة',
    urgency: 'الأولوية',
    description: 'الوصف',
    attachPhoto: 'إرفاق صورة',
    submit: 'إرسال',
    viewDetails: 'عرض التفاصيل',
    status: 'الحالة',
    
    // Categories
    plumbing: 'السباكة',
    electrical: 'الكهرباء',
    hvac: 'التكييف',
    carpentry: 'النجارة',
    painting: 'الدهان',
    cleaning: 'التنظيف',
    other: 'أخرى',
    
    // Status
    new: 'جديد',
    inProgress: 'قيد التنفيذ',
    pending: 'معلق',
    completed: 'مكتمل',
    cancelled: 'ملغي',
    
    // Common
    loading: 'جاري التحميل...',
    error: 'خطأ',
    success: 'نجاح',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    save: 'حفظ',
    delete: 'حذف',
    edit: 'تعديل',
    search: 'بحث',
    filter: 'تصفية',
    refresh: 'تحديث',
    noData: 'لا توجد بيانات',
    tryAgain: 'حاول مجدداً',
    
    // Saudi specific
    sar: 'ريال',
    vat: 'ضريبة القيمة المضافة',
    cr: 'رقم السجل التجاري',
  }
};

// ============================================
// LOGIN SCREEN
// ============================================

const LoginScreen = ({ navigation }) => {
  const { login, language, toggleLanguage } = React.useContext(AuthContext);
  const [email, setEmail] = useState('admin@fixzit.com'); // Pre-filled for testing
  const [password, setPassword] = useState('Admin@1234'); // Pre-filled for testing
  const [phone, setPhone] = useState('');
  const [isPhoneLogin, setIsPhoneLogin] = useState(false);
  const [loading, setLoading] = useState(false);
  const t = translations[language];

  const handleLogin = async () => {
    if ((!email && !phone) || !password) {
      Alert.alert(t.error, 'Please fill all fields');
      return;
    }

    setLoading(true);
    const loginData = isPhoneLogin 
      ? { phone: `+966${phone}`, password }
      : { email, password };
    
    const result = await login(loginData.email || loginData.phone, password);
    setLoading(false);

    if (!result.success) {
      Alert.alert(t.error, result.error);
    }
  };

  const validateSaudiPhone = (text) => {
    // Remove any non-numeric characters
    const cleaned = text.replace(/\D/g, '');
    // Limit to 9 digits (Saudi phone without country code)
    if (cleaned.length <= 9) {
      setPhone(cleaned);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Language Toggle */}
        <TouchableOpacity 
          style={styles.languageToggle}
          onPress={toggleLanguage}
        >
          <Text style={styles.languageText}>
            {language === 'en' ? 'عربي' : 'EN'}
          </Text>
        </TouchableOpacity>

        {/* Logo */}
        <View style={styles.logoContainer}>
          <View style={styles.logo}>
            <Text style={styles.logoText}>FIXZIT</Text>
            <Text style={styles.logoSubtext}>SOUQ</Text>
          </View>
        </View>

        {/* Welcome Text */}
        <Text style={styles.welcomeText}>{t.welcome}</Text>

        {/* Login Form */}
        <View style={styles.formContainer}>
          {/* Toggle Phone/Email Login */}
          <View style={styles.loginToggle}>
            <TouchableOpacity
              style={[
                styles.toggleButton,
                !isPhoneLogin && styles.toggleButtonActive
              ]}
              onPress={() => setIsPhoneLogin(false)}
            >
              <Text style={[
                styles.toggleText,
                !isPhoneLogin && styles.toggleTextActive
              ]}>
                {t.email}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.toggleButton,
                isPhoneLogin && styles.toggleButtonActive
              ]}
              onPress={() => setIsPhoneLogin(true)}
            >
              <Text style={[
                styles.toggleText,
                isPhoneLogin && styles.toggleTextActive
              ]}>
                {t.phone}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Email or Phone Input */}
          {isPhoneLogin ? (
            <View style={styles.phoneInputContainer}>
              <Text style={styles.countryCode}>+966</Text>
              <TextInput
                style={styles.phoneInput}
                placeholder="5XXXXXXXX"
                value={phone}
                onChangeText={validateSaudiPhone}
                keyboardType="phone-pad"
                maxLength={9}
              />
            </View>
          ) : (
            <TextInput
              style={styles.input}
              placeholder={t.email}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          )}

          {/* Password Input */}
          <TextInput
            style={styles.input}
            placeholder={t.password}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          {/* Forgot Password */}
          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={styles.forgotPasswordText}>{t.forgotPassword}</Text>
          </TouchableOpacity>

          {/* Login Button */}
          <TouchableOpacity 
            style={[styles.loginButton, loading && styles.buttonDisabled]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.loginButtonText}>{t.login}</Text>
            )}
          </TouchableOpacity>

          {/* Register Link */}
          <TouchableOpacity style={styles.registerLink}>
            <Text style={styles.registerText}>
              Don't have an account? {t.register}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

// ============================================
// DASHBOARD SCREEN
// ============================================

const DashboardScreen = ({ navigation }) => {
  const { user, language, logout } = React.useContext(AuthContext);
  const [stats, setStats] = useState({
    activeRequests: 5,
    pendingPayments: 2,
    upcomingMaintenance: 1
  });
  const [notifications, setNotifications] = useState([
    { id: 1, title: 'Work order completed', time: '2 hours ago', type: 'info' },
    { id: 2, title: 'Payment reminder', time: '1 day ago', type: 'alert' }
  ]);
  const [refreshing, setRefreshing] = useState(false);
  const t = translations[language];

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Try to load from backend, fallback to mock data
      const response = await httpClient.get('/api/dashboard/kpis');
      console.log('Dashboard data loaded:', response);
    } catch (error) {
      console.log('Using mock dashboard data:', error.message);
      // Mock data is already set in state
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const StatCard = ({ title, value, color, icon, onPress }) => (
    <TouchableOpacity style={[styles.statCard, { borderLeftColor: color }]} onPress={onPress}>
      <Text style={styles.statIcon}>{icon}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statTitle}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      {/* Welcome Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>
            {language === 'ar' ? 'مرحباً' : 'Hello'},
          </Text>
          <Text style={styles.userName}>{user?.name || 'Tenant'}</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={() => Alert.alert('Notifications', 'Coming soon!')}>
            <View>
              <Text style={styles.iconText}>🔔</Text>
              {notifications.length > 0 && (
                <View style={styles.notificationBadge}>
                  <Text style={styles.badgeText}>{notifications.length}</Text>
                </View>
              )}
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.logoutButton} onPress={logout}>
            <Text style={styles.logoutText}>{t.logout}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Quick Stats */}
      <View style={styles.statsContainer}>
        <StatCard
          title={t.activeRequests}
          value={stats.activeRequests}
          color="#F6851F"
          icon="🔧"
          onPress={() => Alert.alert('Requests', 'Work orders coming soon!')}
        />
        <StatCard
          title={t.pendingPayments}
          value={stats.pendingPayments}
          color="#FFB400"
          icon="💳"
          onPress={() => Alert.alert('Payments', 'Payment section coming soon!')}
        />
        <StatCard
          title={t.upcomingMaintenance}
          value={stats.upcomingMaintenance}
          color="#00A859"
          icon="📅"
          onPress={() => Alert.alert('Maintenance', 'Maintenance schedule coming soon!')}
        />
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => Alert.alert(t.newRequest, 'New request form coming soon!')}
          >
            <Text style={styles.actionIcon}>➕</Text>
            <Text style={styles.actionText}>{t.newRequest}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => Alert.alert(t.myUnit, 'Unit details coming soon!')}
          >
            <Text style={styles.actionIcon}>🏠</Text>
            <Text style={styles.actionText}>{t.myUnit}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => Alert.alert(t.payments, 'Payment history coming soon!')}
          >
            <Text style={styles.actionIcon}>🧾</Text>
            <Text style={styles.actionText}>{t.payments}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Recent Notifications */}
      <View style={styles.notificationsSection}>
        <Text style={styles.sectionTitle}>{t.notifications}</Text>
        {notifications.map((notif) => (
          <TouchableOpacity key={notif.id} style={styles.notificationItem}>
            <Text style={styles.notificationIcon}>
              {notif.type === 'alert' ? '⚠️' : 'ℹ️'}
            </Text>
            <View style={styles.notificationContent}>
              <Text style={styles.notificationTitle}>{notif.title}</Text>
              <Text style={styles.notificationTime}>{notif.time}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
};

// ============================================
// MAIN APP COMPONENT
// ============================================

export default function App() {
  return (
    <AuthProvider>
      <MainNavigator />
    </AuthProvider>
  );
}

const MainNavigator = () => {
  const { user, loading } = React.useContext(AuthContext);

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#0061A8" />
        <Text style={styles.loadingText}>Loading Fixzit Souq...</Text>
      </View>
    );
  }

  return user ? <DashboardScreen /> : <LoginScreen />;
};

// ============================================
// STYLES
// ============================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#0061A8',
  },
  
  // Login Styles
  languageToggle: {
    position: 'absolute',
    top: 50,
    right: 20,
    padding: 10,
  },
  languageText: {
    fontSize: 16,
    color: '#0061A8',
    fontWeight: 'bold',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    width: 120,
    height: 120,
    backgroundColor: '#0061A8',
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  logoSubtext: {
    color: '#F6851F',
    fontSize: 14,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
    color: '#023047',
  },
  formContainer: {
    width: '100%',
  },
  loginToggle: {
    flexDirection: 'row',
    marginBottom: 20,
    borderRadius: 8,
    overflow: 'hidden',
  },
  toggleButton: {
    flex: 1,
    padding: 12,
    backgroundColor: '#e0e0e0',
    alignItems: 'center',
  },
  toggleButtonActive: {
    backgroundColor: '#0061A8',
  },
  toggleText: {
    color: '#666',
    fontWeight: '600',
  },
  toggleTextActive: {
    color: '#fff',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  phoneInputContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  countryCode: {
    paddingLeft: 15,
    fontSize: 16,
    color: '#666',
  },
  phoneInput: {
    flex: 1,
    padding: 15,
    fontSize: 16,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  forgotPasswordText: {
    color: '#0061A8',
    fontSize: 14,
  },
  loginButton: {
    backgroundColor: '#0061A8',
    borderRadius: 8,
    padding: 15,
    alignItems: 'center',
    marginBottom: 20,
  },
  loginButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  registerLink: {
    marginTop: 20,
    alignItems: 'center',
  },
  registerText: {
    color: '#666',
    fontSize: 14,
  },
  
  // Dashboard Styles
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    marginBottom: 10,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  greeting: {
    fontSize: 16,
    color: '#666',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#023047',
  },
  iconText: {
    fontSize: 24,
  },
  notificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#FF0000',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  statCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    flex: 1,
    marginHorizontal: 5,
    borderLeftWidth: 4,
    alignItems: 'center',
  },
  statIcon: {
    fontSize: 32,
    marginBottom: 5,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#023047',
    marginVertical: 5,
  },
  statTitle: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  quickActions: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#023047',
    marginBottom: 15,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    alignItems: 'center',
    padding: 10,
  },
  actionIcon: {
    fontSize: 48,
  },
  actionText: {
    fontSize: 12,
    color: '#023047',
    marginTop: 5,
  },
  notificationsSection: {
    padding: 20,
  },
  notificationItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
  },
  notificationIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 14,
    color: '#023047',
  },
  notificationTime: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  logoutButton: {
    backgroundColor: '#FF0000',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 6,
  },
  logoutText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});