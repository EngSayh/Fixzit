#!/usr/bin/env python3
"""
Navigation System Verification Script
Verifies the new navigation system is working across all pages
"""

import sys
import re
from pathlib import Path
from datetime import datetime

# Configuration
ROOT_DIR = Path(".")
PAGES_DIR = ROOT_DIR / "pages"
NAVIGATION_FILE = ROOT_DIR / "navigation.py"
REPORT_FILE = ROOT_DIR / "navigation_verification_report.md"

# Tracking
issues = []
warnings = []
successes = []
page_count = 0
pages_checked = []


def log_issue(page: str, issue: str):
    """Log an issue found in a page"""
    issues.append(f"❌ **{page}**: {issue}")
    print(f"  ❌ {page}: {issue}")


def log_warning(page: str, warning: str):
    """Log a warning for a page"""
    warnings.append(f"⚠️ **{page}**: {warning}")
    print(f"  ⚠️ {page}: {warning}")


def log_success(page: str, message: str):
    """Log a success for a page"""
    successes.append(f"✅ **{page}**: {message}")
    print(f"  ✅ {page}: {message}")


def check_navigation_import(file_path: Path) -> bool:
    """Check if page imports navigation correctly"""
    content = file_path.read_text(encoding="utf-8")

    # Check for navigation import
    if "from navigation import" not in content:
        return False

    # Check for render_sidebar call
    if "render_sidebar()" not in content:
        return False

    return True


def check_sidebar_state(file_path: Path) -> str:
    """Check sidebar state configuration"""
    content = file_path.read_text(encoding="utf-8")

    # Check for initial_sidebar_state
    if 'initial_sidebar_state="expanded"' in content:
        return "expanded"
    elif 'initial_sidebar_state="collapsed"' in content:
        return "collapsed"
    else:
        return "not_set"


def check_conflicting_sidebar(file_path: Path) -> list:
    """Check for conflicting sidebar implementations"""
    content = file_path.read_text(encoding="utf-8")
    conflicts = []

    # Check for custom sidebar implementations
    if "with st.sidebar:" in content:
        # Count occurrences and check context
        sidebar_blocks = re.findall(
            r"with st\.sidebar:.*?(?=\n(?:with|\Z))", content, re.DOTALL
        )

        for block in sidebar_blocks:
            # Check if it's navigation-related (problematic) or just additional features (ok)
            if any(
                nav in block
                for nav in [
                    "Workspace",
                    "Boards",
                    "Navigation",
                    "nav_home",
                    "nav_properties",
                    "workspace_toggle",
                ]
            ):
                conflicts.append(
                    "Custom navigation sidebar found (conflicts with new system)"
                )
            elif "render_sidebar" not in content[: content.find("with st.sidebar:")]:
                # If render_sidebar is not called before custom sidebar, it might be problematic
                if any(
                    action in block
                    for action in ["Export", "Refresh", "Actions", "download"]
                ):
                    # These are usually OK - just additional sidebar features
                    pass
                else:
                    conflicts.append("Custom sidebar implementation found")

    # Check for old navigation patterns
    old_patterns = [
        "Firebase-style navigation",
        "render_sidebar_navigation",
        "init_navigation",
        "nav_config",
        "PROJECTS[",
    ]

    for pattern in old_patterns:
        if pattern in content:
            conflicts.append(f"Old navigation pattern found: {pattern}")

    return conflicts


def check_authentication_check(file_path: Path) -> bool:
    """Check if page has proper authentication checks"""
    content = file_path.read_text(encoding="utf-8")

    # Skip login/signup pages
    if any(
        x in file_path.name.lower()
        for x in ["login", "signup", "register", "auth", "reset"]
    ):
        return True

    # Check for authentication verification
    auth_patterns = [
        'st.session_state.get("authenticated"',
        'if not st.session_state.get("authenticated"',
        "check_permissions",
        "check_admin_access",
    ]

    return any(pattern in content for pattern in auth_patterns)


def verify_page(file_path: Path):
    """Verify a single page file"""
    global page_count
    page_count += 1
    page_name = file_path.name
    pages_checked.append(page_name)

    print(f"\nChecking {page_name}...")

    try:
        # Skip backup files
        if "backup" in page_name.lower():
            log_warning(page_name, "Backup file - skipped")
            return

        # Check navigation import and usage
        has_navigation = check_navigation_import(file_path)
        if not has_navigation:
            # Login/Auth pages don't need navigation
            if any(
                x in page_name.lower()
                for x in ["login", "signup", "register", "auth", "callback"]
            ):
                log_success(page_name, "Auth page - navigation not required")
            else:
                log_issue(
                    page_name, "Missing navigation import or render_sidebar() call"
                )
        else:
            log_success(page_name, "Navigation properly imported and used")

        # Check sidebar state
        sidebar_state = check_sidebar_state(file_path)
        if sidebar_state == "expanded":
            log_issue(
                page_name, "Sidebar state set to 'expanded' (should be 'collapsed')"
            )
        elif sidebar_state == "collapsed":
            log_success(page_name, "Sidebar state correctly set to 'collapsed'")
        else:
            if not any(x in page_name.lower() for x in ["login", "signup", "register"]):
                log_warning(page_name, "No sidebar state configuration found")

        # Check for conflicting sidebar code
        conflicts = check_conflicting_sidebar(file_path)
        if conflicts:
            for conflict in conflicts:
                log_issue(page_name, conflict)

        # Check authentication
        has_auth = check_authentication_check(file_path)
        if not has_auth:
            log_warning(page_name, "No authentication check found")

    except Exception as e:
        log_issue(page_name, f"Error processing file: {str(e)}")


def verify_navigation_file():
    """Verify the main navigation.py file"""
    print("\nChecking navigation.py...")

    if not NAVIGATION_FILE.exists():
        log_issue("navigation.py", "File not found!")
        return

    content = NAVIGATION_FILE.read_text(encoding="utf-8")

    # Check for required functions
    required_functions = ["render_sidebar", "hide_sidebar_on_login", "render_mini_rail"]

    for func in required_functions:
        if f"def {func}" in content:
            log_success("navigation.py", f"Function '{func}' found")
        else:
            log_issue("navigation.py", f"Missing function '{func}'")

    # Check for old navigation code
    if "nav_config" in content.lower() or "PROJECTS" in content:
        log_issue("navigation.py", "Old navigation configuration found")

    # Check for Mini-Rail CSS
    if "mini-rail" in content:
        log_success("navigation.py", "Mini-Rail system implemented")
    else:
        log_warning("navigation.py", "Mini-Rail system not found")


def generate_report():
    """Generate the verification report"""
    report = []
    report.append("# Navigation System Verification Report")
    report.append(f"\n**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"\n**Total Pages Checked**: {page_count}")

    # Summary
    report.append("\n## Summary")
    report.append(f"- ✅ **Successes**: {len(successes)}")
    report.append(f"- ❌ **Issues**: {len(issues)}")
    report.append(f"- ⚠️ **Warnings**: {len(warnings)}")

    # Overall Status
    if len(issues) == 0:
        report.append("\n### 🎉 **VERIFICATION PASSED** - No critical issues found!")
    else:
        report.append(
            f"\n### 🚨 **VERIFICATION FAILED** - {len(issues)} issues need attention"
        )

    # Issues
    if issues:
        report.append("\n## Issues Found")
        report.append("\nThese need immediate attention:\n")
        for issue in issues:
            report.append(f"- {issue}")

    # Warnings
    if warnings:
        report.append("\n## Warnings")
        report.append("\nThese should be reviewed:\n")
        for warning in warnings:
            report.append(f"- {warning}")

    # Successes
    if successes:
        report.append("\n## Successful Checks")
        report.append("\nThese passed verification:\n")
        # Only show first 10 to keep report readable
        for success in successes[:10]:
            report.append(f"- {success}")
        if len(successes) > 10:
            report.append(f"\n... and {len(successes) - 10} more successful checks")

    # Pages List
    report.append("\n## Pages Checked")
    report.append(f"\nTotal: {len(pages_checked)} pages\n")
    pages_grouped = {}
    for page in sorted(pages_checked):
        prefix = page.split("_")[0] if "_" in page else "other"
        if prefix not in pages_grouped:
            pages_grouped[prefix] = []
        pages_grouped[prefix].append(page)

    for prefix, pages in sorted(pages_grouped.items()):
        report.append(f"\n**{prefix} pages** ({len(pages)}):")
        for page in pages[:5]:  # Show first 5
            report.append(f"- {page}")
        if len(pages) > 5:
            report.append(f"- ... and {len(pages) - 5} more")

    # Recommendations
    report.append("\n## Recommendations")
    if len(issues) > 0:
        report.append(
            '\n1. **Fix all expanded sidebar states** - Change `initial_sidebar_state="expanded"` to `"collapsed"`'
        )
        report.append(
            "2. **Remove conflicting sidebar code** - Any custom navigation in `with st.sidebar:` blocks"
        )
        report.append(
            "3. **Ensure all pages import and call `render_sidebar()`** from navigation.py"
        )
    else:
        report.append(
            "\n✅ The navigation system is properly implemented across all pages!"
        )

    # Write report
    report_content = "\n".join(report)
    REPORT_FILE.write_text(report_content, encoding="utf-8")
    print(f"\n{'='*60}")
    print(report_content)
    print(f"{'='*60}")
    print(f"\n📄 Full report saved to: {REPORT_FILE}")

    return len(issues) == 0


def main():
    """Main verification process"""
    print("=" * 60)
    print("Starting Navigation System Verification")
    print("=" * 60)

    # Check navigation.py
    verify_navigation_file()

    # Check all pages
    if PAGES_DIR.exists():
        page_files = sorted(PAGES_DIR.glob("*.py"))
        print(f"\nFound {len(page_files)} page files to check...")

        for page_file in page_files:
            verify_page(page_file)
    else:
        log_issue("pages/", "Pages directory not found!")

    # Generate report
    print("\n" + "=" * 60)
    print("Generating Report...")
    print("=" * 60)

    passed = generate_report()

    # Exit code
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
