#!/bin/bash

# ========================================================
# FIXZIT SOUQ - SYSTEMATIC COMPLETION & VERIFICATION
# This script ensures 100% completion of all fixes
# ========================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  FIXZIT SOUQ SYSTEMATIC VERIFICATION  ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
FIXES_APPLIED=0

# Function to check condition and auto-fix if possible
check_and_fix() {
    local description="$1"
    local check_command="$2"
    local fix_command="$3"
    
    ((TOTAL_CHECKS++))
    
    echo -n "Checking: $description... "
    
    if eval "$check_command" >/dev/null 2>&1; then
        echo -e "${GREEN}✅ PASS${NC}"
        ((PASSED_CHECKS++))
        return 0
    else
        echo -e "${RED}❌ FAIL${NC}"
        ((FAILED_CHECKS++))
        
        if [ -n "$fix_command" ]; then
            echo "  └─ Applying fix..."
            eval "$fix_command" >/dev/null 2>&1
            
            # Re-check after fix
            if eval "$check_command" >/dev/null 2>&1; then
                echo -e "  └─ ${GREEN}✅ Fixed successfully${NC}"
                ((FIXES_APPLIED++))
                ((FAILED_CHECKS--))
                ((PASSED_CHECKS++))
                return 0
            else
                echo -e "  └─ ${RED}⚠️  Fix failed, manual intervention needed${NC}"
                return 1
            fi
        else
            echo -e "  └─ ${YELLOW}⚠️  Manual fix required${NC}"
            return 1
        fi
    fi
}

# ========================================================
# PHASE 1: CRITICAL FILES
# ========================================================
echo -e "\n${YELLOW}PHASE 1: CRITICAL FILES${NC}"
echo "------------------------"

check_and_fix \
    ".env file exists" \
    "test -f .env" \
    "cp .env.template .env 2>/dev/null || echo 'JWT_SECRET=temp_secret_replace_immediately' > .env"

check_and_fix \
    "JWT_SECRET is secure (32+ chars)" \
    "[ \$(grep JWT_SECRET .env | cut -d= -f2 | tr -d ' ' | wc -c) -ge 32 ]" \
    "echo \"JWT_SECRET=\$(node -e 'console.log(require(\"crypto\").randomBytes(32).toString(\"hex\"))')\" > .env.tmp && grep -v JWT_SECRET .env >> .env.tmp 2>/dev/null; mv .env.tmp .env"

check_and_fix \
    "middleware/auth.js exists" \
    "test -f middleware/auth.js" \
    "mkdir -p middleware && cat > middleware/auth.js << 'EOF'
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const authenticate = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) throw new Error();
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.userId);
        if (!user) throw new Error();
        
        req.user = user;
        req.userId = user._id;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Please authenticate' });
    }
};

module.exports = { authenticate, authMiddleware: authenticate };
EOF"

check_and_fix \
    "middleware/validation.js exists" \
    "test -f middleware/validation.js" \
    "mkdir -p middleware && cat > middleware/validation.js << 'EOF'
const { validationResult } = require('express-validator');

const validate = (validations) => {
    return async (req, res, next) => {
        await Promise.all(validations.map(validation => validation.run(req)));
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    };
};

const sanitizeInput = (input) => {
    if (typeof input !== 'string') return input;
    return input.trim().replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
};

module.exports = { validate, sanitizeInput };
EOF"

# ========================================================
# PHASE 2: AUTHENTICATION SECURITY
# ========================================================
echo -e "\n${YELLOW}PHASE 2: AUTHENTICATION SECURITY${NC}"
echo "-----------------------------------"

check_and_fix \
    "No JWT fallback in auth.js" \
    "! grep -q 'JWT_SECRET.*||' middleware/auth.js" \
    "sed -i \"s/process\.env\.JWT_SECRET || '[^']*'/process.env.JWT_SECRET/g\" middleware/auth.js 2>/dev/null || sed -i '' \"s/process\.env\.JWT_SECRET || '[^']*'/process.env.JWT_SECRET/g\" middleware/auth.js"

check_and_fix \
    "Database verification in authenticate" \
    "grep -q 'User.findById' middleware/auth.js" \
    "echo '/* DB verification already in authenticate function */'"

check_and_fix \
    "No query parameter tokens" \
    "! grep -q 'req\.query\.token\|req\.params\.token' middleware/auth.js" \
    "sed -i '/req\.query\.token/d; /req\.params\.token/d' middleware/auth.js 2>/dev/null"

# ========================================================
# PHASE 3: ROUTE FILES
# ========================================================
echo -e "\n${YELLOW}PHASE 3: ROUTE FILES${NC}"
echo "----------------------"

# Fix duplicate imports in all route files
echo "Scanning route files for issues..."
for file in routes/*.js; do
    if [ -f "$file" ]; then
        basename=$(basename "$file")
        
        # Check for duplicate authenticate imports
        duplicates=$(grep -c "const.*authenticate" "$file" 2>/dev/null || echo 0)
        if [ "$duplicates" -gt 1 ]; then
            echo "  Fixing duplicate imports in $basename..."
            # Keep only first occurrence
            awk '!seen[$0]++ || !/const.*authenticate/' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
            ((FIXES_APPLIED++))
        fi
        
        # Check syntax
        if ! node -c "$file" >/dev/null 2>&1; then
            echo -e "  ${RED}Syntax error in $basename${NC}"
            ((FAILED_CHECKS++))
        fi
    fi
done

check_and_fix \
    "All route files valid syntax" \
    "! find routes -name '*.js' -exec node -c {} \; 2>&1 | grep -q 'SyntaxError'" \
    "echo 'Manual fix needed for route syntax errors'"

# ========================================================
# PHASE 4: SECURITY PACKAGES
# ========================================================
echo -e "\n${YELLOW}PHASE 4: SECURITY PACKAGES${NC}"
echo "----------------------------"

PACKAGES="helmet express-rate-limit express-validator xss express-mongo-sanitize bcryptjs jsonwebtoken"

for package in $PACKAGES; do
    check_and_fix \
        "$package installed" \
        "npm list $package >/dev/null 2>&1" \
        "npm install $package --save >/dev/null 2>&1"
done

# ========================================================
# PHASE 5: MODELS
# ========================================================
echo -e "\n${YELLOW}PHASE 5: DATA MODELS${NC}"
echo "----------------------"

check_and_fix \
    "models/User.js exists" \
    "test -f models/User.js" \
    "mkdir -p models && cat > models/User.js << 'EOF'
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, default: 'user' },
    tenantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tenant' },
    loginAttempts: { type: Number, default: 0 },
    lockUntil: Date
}, { timestamps: true });

userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
    next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
EOF"

# ========================================================
# PHASE 6: SERVER HEALTH CHECK
# ========================================================
echo -e "\n${YELLOW}PHASE 6: SERVER HEALTH CHECK${NC}"
echo "------------------------------"

# Check if server is running
if curl -s http://localhost:5000/health >/dev/null 2>&1 || curl -s http://localhost:5000 >/dev/null 2>&1; then
    echo -e "${GREEN}✅ Server is responding${NC}"
    ((PASSED_CHECKS++))
else
    echo -e "${YELLOW}⚠️  Server not responding - attempting restart${NC}"
    
    # Try to start server in background
    if command -v pm2 >/dev/null 2>&1; then
        pm2 restart fixzit-souq >/dev/null 2>&1 || pm2 start server.js --name fixzit-souq >/dev/null 2>&1
    else
        echo "  └─ Start server manually with: npm run dev"
    fi
    ((FAILED_CHECKS++))
fi

# Run comprehensive checks
echo "Running security audit..."
if command -v node >/dev/null 2>&1 && test -f security-audit.js; then
    node security-audit.js >/dev/null 2>&1
    audit_result=$?
    if [ $audit_result -eq 0 ]; then
        echo -e "${GREEN}✅ Security audit passed${NC}"
        ((PASSED_CHECKS++))
    else
        echo -e "${YELLOW}⚠️  Security audit has warnings${NC}"
        ((FAILED_CHECKS++))
    fi
fi

# ========================================================
# SUMMARY REPORT
# ========================================================
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}           COMPLETION REPORT            ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

COMPLETION_PERCENT=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))

echo "📊 STATISTICS:"
echo "  Total Checks:    $TOTAL_CHECKS"
echo "  Passed:          $PASSED_CHECKS"
echo "  Failed:          $FAILED_CHECKS"
echo "  Auto-Fixed:      $FIXES_APPLIED"
echo ""

# Progress bar
echo -n "  Completion:      ["
for i in {1..20}; do
    if [ $i -le $((COMPLETION_PERCENT / 5)) ]; then
        echo -n "█"
    else
        echo -n "░"
    fi
done
echo "] ${COMPLETION_PERCENT}%"
echo ""

if [ $FAILED_CHECKS -eq 0 ]; then
    echo -e "${GREEN}✅ VERIFICATION COMPLETE - ALL CHECKS PASSED!${NC}"
    echo ""
    echo "🚀 Your Fixzit Souq platform is:"
    echo "   • Fully secured"
    echo "   • All fixes applied"
    echo "   • Ready for production"
    echo ""
    echo "Next steps:"
    echo "  1. Restart server: npm run dev"
    echo "  2. Test login endpoint"
    echo "  3. Begin using the platform"
else
    echo -e "${YELLOW}⚠️  VERIFICATION INCOMPLETE - $FAILED_CHECKS issues remaining${NC}"
    echo ""
    echo "Manual fixes required for:"
    
    # List specific failures
    if ! test -f middleware/auth.js; then
        echo "  • Create middleware/auth.js"
    fi
    if ! grep -q 'User.findById' middleware/auth.js 2>/dev/null; then
        echo "  • Add database verification to auth.js"
    fi
    if [ $FAILED_CHECKS -gt 0 ]; then
        echo "  • Check route files for syntax errors"
        echo "  • Verify all packages installed"
    fi
    
    echo ""
    echo "Run this script again after manual fixes."
fi

echo ""
echo "========================================="

# Exit with appropriate code
if [ $FAILED_CHECKS -eq 0 ]; then
    exit 0
else
    exit 1
fi