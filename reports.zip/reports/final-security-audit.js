const fs = require('fs');
const path = require('path');

console.log('\n🔐 FINAL SECURITY AUDIT - Fixzit Souq\n');

let score = 0;
let maxScore = 0;
let issues = [];
let fixed = [];

// Test 1: JWT Security
maxScore += 20;
try {
    const authContent = fs.readFileSync('middleware/auth.js', 'utf8');
    if (authContent.includes('||') && authContent.includes('temp')) {
        issues.push('❌ JWT fallback still present');
    } else {
        score += 20;
        fixed.push('✅ JWT fallback removed');
    }
} catch (e) {
    issues.push('❌ Cannot read auth middleware');
}

// Test 2: Database Configuration
maxScore += 15;
try {
    const serverContent = fs.readFileSync('server.js', 'utf8');
    if (serverContent.match(/buffermaxentries|bufferMaxEntries/i)) {
        issues.push('❌ MongoDB deprecated options still present');
    } else {
        score += 15;
        fixed.push('✅ MongoDB configuration cleaned');
    }
} catch (e) {
    issues.push('❌ Cannot read server.js');
}

// Test 3: Environment Security
maxScore += 15;
try {
    const envContent = fs.readFileSync('.env', 'utf8');
    const jwtMatch = envContent.match(/JWT_SECRET=(.+)/);
    if (!jwtMatch || jwtMatch[1].length < 32) {
        issues.push('❌ JWT_SECRET too short or missing');
    } else {
        score += 15;
        fixed.push('✅ JWT_SECRET is secure');
    }
} catch (e) {
    issues.push('❌ Cannot read .env file');
}

// Test 4: Security Middleware
maxScore += 20;
try {
    if (fs.existsSync('middleware/security.js')) {
        score += 20;
        fixed.push('✅ Security middleware available');
    } else {
        issues.push('❌ Security middleware not found');
    }
} catch (e) {
    issues.push('❌ Cannot check security middleware');
}

// Test 5: Package Security
maxScore += 15;
try {
    const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
    const securityPackages = ['helmet', 'express-rate-limit', 'xss', 'express-mongo-sanitize'];
    const missing = securityPackages.filter(pkg => !deps[pkg]);
    
    if (missing.length > 0) {
        issues.push(`❌ Missing packages: ${missing.join(', ')}`);
    } else {
        score += 15;
        fixed.push('✅ All security packages installed');
    }
} catch (e) {
    issues.push('❌ Cannot read package.json');
}

// Test 6: User Model Security
maxScore += 15;
try {
    if (fs.existsSync('models/User.js')) {
        const userContent = fs.readFileSync('models/User.js', 'utf8');
        if (userContent.includes('bcrypt') && userContent.includes('comparePassword')) {
            score += 15;
            fixed.push('✅ User model has password security');
        } else {
            issues.push('❌ User model lacks password security');
        }
    } else {
        issues.push('❌ User model not found');
    }
} catch (e) {
    issues.push('❌ Cannot read User model');
}

// Calculate percentage
const percentage = Math.round((score / maxScore) * 100);

// Display results
console.log('📊 SECURITY AUDIT RESULTS');
console.log('════════════════════════');
console.log(`Score: ${score}/${maxScore} (${percentage}%)`);
console.log('');

if (fixed.length > 0) {
    console.log('✅ FIXED ISSUES:');
    fixed.forEach(item => console.log(`   ${item}`));
    console.log('');
}

if (issues.length > 0) {
    console.log('❌ REMAINING ISSUES:');
    issues.forEach(item => console.log(`   ${item}`));
    console.log('');
}

// Progress bar
const barLength = 40;
const filledLength = Math.round((score / maxScore) * barLength);
const bar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);
console.log(`📈 Progress: [${bar}] ${percentage}%`);

if (percentage === 100) {
    console.log('\n🎉 PERFECT SECURITY SCORE! Production ready!');
    console.log('🚀 Your Fixzit Souq platform is fully secured.');
} else if (percentage >= 90) {
    console.log('\n✅ EXCELLENT security score! Minor improvements possible.');
} else if (percentage >= 70) {
    console.log('\n⚠️ GOOD security score, but improvements needed.');
} else {
    console.log('\n🚨 SECURITY ISSUES DETECTED - immediate attention required!');
}

console.log('\n📄 Report saved to final-security-report.json');

// Save detailed report
const report = {
    timestamp: new Date().toISOString(),
    score,
    maxScore,
    percentage,
    fixed,
    issues
};

fs.writeFileSync('final-security-report.json', JSON.stringify(report, null, 2));

process.exit(percentage === 100 ? 0 : 1);
