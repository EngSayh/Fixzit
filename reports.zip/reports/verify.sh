#!/bin/bash
# Fixzit Verification Runner

set -e

echo "================================================"
echo "       FIXZIT VERIFICATION SUITE"
echo "================================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Parse arguments
AUTO_FIX=true
MAX_PASSES=3
QUICK=false

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --no-fix) AUTO_FIX=false ;;
        --quick) QUICK=true ;;
        --max-passes) MAX_PASSES="$2"; shift ;;
        -h|--help) 
            echo "Usage: $0 [options]"
            echo "Options:"
            echo "  --no-fix      Disable auto-fixing"
            echo "  --quick       Run quick verification only"
            echo "  --max-passes  Set max passes (default: 3)"
            echo "  -h, --help    Show this help"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
    shift
done

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Error: Python 3 is not installed${NC}"
    exit 1
fi

echo -e "${BLUE}Python version:${NC}"
python3 --version
echo ""

# Quick check mode
if [ "$QUICK" = true ]; then
    echo -e "${YELLOW}Running QUICK verification...${NC}"
    python3 scripts/fixzit_verify.py
    exit $?
fi

# Full verification
echo -e "${YELLOW}Running FULL verification...${NC}"
echo "Auto-fix: $([ "$AUTO_FIX" = true ] && echo -e "${GREEN}ENABLED${NC}" || echo -e "${RED}DISABLED${NC}")"
echo "Max passes: $MAX_PASSES"
echo ""

# Run the comprehensive verification
if [ "$AUTO_FIX" = true ]; then
    python3 scripts/verify_all.py --max-passes "$MAX_PASSES"
else
    python3 scripts/verify_all.py --no-fix --max-passes "$MAX_PASSES"
fi

EXIT_CODE=$?

# Show summary
echo ""
echo "================================================"
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}✅ VERIFICATION PASSED${NC}"
else
    echo -e "${RED}❌ VERIFICATION FAILED${NC}"
fi
echo "================================================"
echo ""

# Show report location
echo "Reports saved to: artifacts/"
ls -la artifacts/*.json 2>/dev/null | tail -1 || true
ls -la artifacts/*.md 2>/dev/null | tail -1 || true

exit $EXIT_CODE