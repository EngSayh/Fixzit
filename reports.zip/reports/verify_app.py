#!/usr/bin/env python3
"""Quick verification script for Fixzit app"""

import os
import glob


def verify_pages():
    """Verify all pages exist and have proper config"""
    print("\n📄 Verifying Pages...")

    pages = glob.glob("pages/*.py")
    print(f"   Found {len(pages)} pages")

    critical_pages = [
        "pages/2_Properties.py",
        "pages/3_Tickets.py",
        "pages/4_Reports.py",
        "pages/5_Payments.py",
        "pages/8_Contracts.py",
    ]

    for page in critical_pages:
        if os.path.exists(page):
            print(f"   ✓ {os.path.basename(page)}")
        else:
            print(f"   ✗ {os.path.basename(page)} - MISSING")

    return True


def verify_auth_system():
    """Verify authentication files"""
    print("\n🔐 Verifying Authentication System...")

    auth_files = [
        "auth/authentication.py",
        "auth/role_based_authentication.py",
        "utils/session_init.py",
    ]

    for file in auth_files:
        if os.path.exists(file):
            print(f"   ✓ {file}")
        else:
            print(f"   ✗ {file} - MISSING")

    return True


def verify_database_files():
    """Verify database initialization files"""
    print("\n💾 Verifying Database Files...")

    db_files = ["database/init_db.py", "utils/database.py"]

    for file in db_files:
        if os.path.exists(file):
            with open(file) as f:
                content = f.read()
                if "get_db_connection" in content or "initialize_database" in content:
                    print(f"   ✓ {file}")
                else:
                    print(f"   ⚠ {file} - May be incomplete")
        else:
            print(f"   ✗ {file} - MISSING")

    return True


def verify_utils():
    """Verify utility modules"""
    print("\n🔧 Verifying Utility Modules...")

    utils = [
        "utils/translations.py",
        "utils/navigation_menu.py",
        "utils/rtl_support.py",
    ]

    for util in utils:
        if os.path.exists(util):
            print(f"   ✓ {util}")
        else:
            print(f"   ✗ {util} - MISSING")

    return True


def main():
    print("=" * 60)
    print("FIXZIT APPLICATION VERIFICATION")
    print("=" * 60)

    verify_pages()
    verify_auth_system()
    verify_database_files()
    verify_utils()

    print("\n" + "=" * 60)
    print("✅ Verification Complete")
    print("=" * 60)


if __name__ == "__main__":
    main()
