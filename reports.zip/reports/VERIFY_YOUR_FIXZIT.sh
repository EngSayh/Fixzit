#!/bin/bash
echo "
════════════════════════════════════════════════════════
VERIFYING YOUR ACTUAL FIXZIT SYSTEM (Not Generic)
════════════════════════════════════════════════════════
"

# 1. CHECK YOUR 13 FM MODULES (from your scope)
echo "📊 Checking YOUR 13 Fixzit FM Modules:"
MODULES=(
    "dashboard:Dashboard with KPIs"
    "work-orders:Work Orders (Board, Calendar, PM, Dispatch)"
    "properties:Properties (Units, Tenants, Assets)"
    "finance:Finance (ZATCA invoices, Payments)"
    "hr:HR (Directory, Payroll, Training)"
    "administration:Admin (DoA, Policies, Fleet)"
    "crm:CRM (Customers, Leads, NPS)"
    "marketplace:Marketplace (RFQ, Vendors)"
    "support:Support (Tickets, KB, SLAs)"
    "compliance:Compliance (Permits, Audits)"
    "reports:Reports (Operational, Financial)"
    "system:System Management (Users, Roles)"
    "pm:Preventive Maintenance"
)

WORKING=0
for module in "${MODULES[@]}"; do
    IFS=':' read -r endpoint description <<< "$module"
    if curl -s http://localhost:5000/api/$endpoint | grep -q "Cannot GET\|Route not found"; then
        echo "   ❌ $description - NOT WORKING"
    else
        WORKING=$((WORKING + 1))
        echo "   ✅ $description - WORKING"
    fi
done

echo "   Result: $WORKING/13 modules working"

# 2. CHECK YOUR SPECIFIC FEATURES
echo -e "\n🔍 Checking YOUR Required Features:"

# Check ZATCA (your requirement)
if ls routes/finance.js 2>/dev/null | xargs grep -l "zatca\|qrcode" > /dev/null; then
    echo "   ✅ ZATCA E-invoicing code exists"
else
    echo "   ❌ ZATCA E-invoicing missing"
fi

# Check Arabic/RTL (your requirement)
if [ -f "public/index.html" ]; then
    if grep -q "dir=\"rtl\"\|toggleLanguage" "public/index.html"; then
        echo "   ✅ Arabic/RTL support in frontend"
    else
        echo "   ❌ Arabic/RTL missing"
    fi
fi

# Check Monday.com style (your requirement)
if grep -q "sidebar.*collapsed\|Monday" "public/index.html" 2>/dev/null; then
    echo "   ✅ Monday.com style sidebar"
else
    echo "   ❌ Monday.com style missing"
fi

# 3. THE REAL PROBLEM - Routes not mounted
echo -e "\n⚠️  THE ACTUAL PROBLEM:"
echo "   Your 47 route files exist but aren't mounted in server.js"
echo "   Checking server.js for route mounting..."

ROUTES_MOUNTED=$(grep -c "app.use('/api/" server.js 2>/dev/null || echo 0)
echo "   Currently mounted: $ROUTES_MOUNTED routes"
echo "   Need to mount: 13+ routes"

# 4. SHOW THE ACTUAL FIX
if [ $ROUTES_MOUNTED -lt 13 ]; then
    echo -e "\n🔧 THE FIX YOUR SYSTEM NEEDS:"
    echo "════════════════════════════════════════════════════════"
    echo "Add these lines to your server.js (after middleware):"
    echo ""
    cat << 'ROUTES'
// YOUR 13 FM MODULES - Mount these existing files
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/work-orders', require('./routes/workorders'));
app.use('/api/properties', require('./routes/properties'));
app.use('/api/finance', require('./routes/finance'));
app.use('/api/hr', require('./routes/hr'));
app.use('/api/administration', require('./routes/admin'));
app.use('/api/crm', require('./routes/crm'));
app.use('/api/marketplace', require('./routes/marketplace'));
app.use('/api/support', require('./routes/tickets'));
app.use('/api/compliance', require('./routes/compliance'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/system', require('./routes/system'));
app.use('/api/pm', require('./routes/pm'));

// YOUR ADDITIONAL ROUTES
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/tenants', require('./routes/tenants'));
app.use('/api/maintenance', require('./routes/maintenance'));
ROUTES
    echo "════════════════════════════════════════════════════════"
fi

# 5. CHECK YOUR FRONTEND CONNECTION
echo -e "\n🌐 Checking YOUR Frontend:"
if [ -f "public/index.html" ]; then
    echo "   ✅ Your HTML file exists"
    
    # Check if it has API calls
    if grep -q "fetch.*localhost:5000\|API_URL" "public/index.html"; then
        echo "   ✅ Frontend has API connections"
    else
        echo "   ❌ Frontend not connected to backend"
        echo "   FIX: Add this to your HTML <script> section:"
        echo '       const API_URL = "http://localhost:5000/api";'
    fi
else
    echo "   ❌ public/index.html not found"
fi

echo "
════════════════════════════════════════════════════════
YOUR SYSTEM COMPLETION STATUS:
Backend: 70% (routes need mounting)
Frontend: 90% (needs API connection)
Database: 100% ✅
════════════════════════════════════════════════════════
"
