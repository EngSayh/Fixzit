// verify-auth-routes.js
// This script verifies your auth.js file is compatible with the fixes

const fs = require('fs');
const path = require('path');

console.log('🔍 Verifying auth.js compatibility...\n');

// Read the current auth.js file
const authPath = path.join(__dirname, 'routes', 'auth.js');

if (!fs.existsSync(authPath)) {
  console.log('❌ routes/auth.js not found!');
  console.log('Creating routes directory and auth.js...');
  
  // Create routes directory if it doesn't exist
  const routesDir = path.join(__dirname, 'routes');
  if (!fs.existsSync(routesDir)) {
    fs.mkdirSync(routesDir, { recursive: true });
  }
  
  // Copy your provided auth.js content
  const authContent = fs.readFileSync('auth.js', 'utf8');
  fs.writeFileSync(authPath, authContent);
  console.log('✅ routes/auth.js created from your provided file');
} else {
  console.log('✅ routes/auth.js found');
  
  // Read and check for common issues
  const authContent = fs.readFileSync(authPath, 'utf8');
  
  // Check for required imports
  const checks = [
    {
      name: 'asyncHandler import',
      pattern: /const asyncHandler = require\(['"]\.\.\/utils\/asyncHandler['"]\)/,
      fix: "const asyncHandler = require('../utils/asyncHandler');"
    },
    {
      name: 'authMiddleware import',
      pattern: /const authMiddleware = require\(['"]\.\.\/middleware\/auth['"]\)/,
      fix: "const authMiddleware = require('../middleware/auth');"
    },
    {
      name: 'validation import',
      pattern: /const.*=.*require\(['"]\.\.\/middleware\/validation['"]\)/,
      fix: "const { checkDatabaseConnection, sanitizeInput, handleValidationErrors, authValidationRules } = require('../middleware/validation');"
    }
  ];
  
  console.log('Checking imports:');
  checks.forEach(check => {
    if (authContent.match(check.pattern)) {
      console.log(`  ✅ ${check.name} found`);
    } else {
      console.log(`  ⚠️  ${check.name} missing or incorrect`);
      console.log(`     Add: ${check.fix}`);
    }
  });
  
  // Check for asyncHandler usage on routes
  const routePattern = /router\.(post|get|put|delete|patch)\([^)]+,\s*asyncHandler\(/g;
  const routeMatches = authContent.match(routePattern);
  const totalRoutes = authContent.match(/router\.(post|get|put|delete|patch)\(/g);
  
  console.log(`\nRoute handlers:`);
  console.log(`  Total routes: ${totalRoutes ? totalRoutes.length : 0}`);
  console.log(`  Routes with asyncHandler: ${routeMatches ? routeMatches.length : 0}`);
  
  if (totalRoutes && routeMatches && routeMatches.length < totalRoutes.length) {
    console.log('  ⚠️  Some routes missing asyncHandler wrapper');
  } else if (routeMatches && totalRoutes && routeMatches.length === totalRoutes.length) {
    console.log('  ✅ All routes have asyncHandler');
  }
}

// Check other critical files
console.log('\n📁 Checking required files:');

const requiredFiles = [
  { path: 'utils/asyncHandler.js', name: 'asyncHandler' },
  { path: 'middleware/auth.js', name: 'Auth middleware' },
  { path: 'middleware/validation.js', name: 'Validation middleware' },
  { path: 'models/User.js', name: 'User model' },
  { path: 'models/Tenant.js', name: 'Tenant model' },
  { path: '.env', name: 'Environment config' }
];

requiredFiles.forEach(file => {
  const filePath = path.join(__dirname, file.path);
  if (fs.existsSync(filePath)) {
    console.log(`  ✅ ${file.name} exists`);
  } else {
    console.log(`  ❌ ${file.name} missing - run the fix script!`);
  }
});

// Quick syntax check
console.log('\n🔍 Checking for syntax errors:');
try {
  require(authPath);
  console.log('  ✅ No syntax errors detected in auth.js');
} catch (error) {
  console.log('  ❌ Syntax error in auth.js:');
  console.log('    ', error.message);
  console.log('    Line:', error.stack.split('\n')[1]);
}

console.log('\n' + '='.repeat(50));
console.log('📋 NEXT STEPS:');
console.log('1. Run the complete fix script first (from the previous artifact)');
console.log('2. Then start your server with: npm run dev');
console.log('3. If there are still issues, check the server logs');
console.log('='.repeat(50));