// verify-models.js
const mongoose = require('mongoose');

// Try to load models without connecting to database first
console.log('🔍 VERIFYING ALL MODELS...\n');

try {
  const models = require('./models');

  // Check all 15 models exist
  const requiredModels = [
    'Organization', 'User', 'Property', 'WorkOrder', 'Invoice',
    'Vendor', 'RFQ', 'Inventory', 'Contract', 'Employee',
    'Ticket', 'Notification', 'Compliance', 'ReportTemplate', 'AuditLog'
  ];

  let missingModels = [];
  let foundModels = [];

  requiredModels.forEach(modelName => {
    if (models[modelName]) {
      foundModels.push(modelName);
      console.log(`✅ ${modelName} model found`);
    } else {
      missingModels.push(modelName);
      console.log(`❌ ${modelName} model MISSING`);
    }
  });

  console.log(`\n📊 RESULTS: ${foundModels.length}/15 models implemented`);

  if (missingModels.length > 0) {
    console.log('❌ Missing models:', missingModels.join(', '));
  } else {
    console.log('🎉 All 15 models successfully implemented!');
  }
} catch (error) {
  console.error('❌ Error loading models:', error.message);
}