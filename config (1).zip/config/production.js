/**
 * Production Configuration for FIXZIT SOUQ
 * Security hardening and performance optimization for production deployment
 */

const production = {
  // Environment
  NODE_ENV: 'production',
  
  // Security Headers
  securityHeaders: {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://unpkg.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        connectSrc: ["'self'", "wss:", "ws:"],
        imgSrc: ["'self'", "data:", "https:"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'none'"]
      }
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true
    }
  },
  
  // Rate Limiting
  rateLimiting: {
    auth: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 5, // 5 attempts per window
      message: 'Too many authentication attempts, please try again later.'
    },
    general: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100, // 100 requests per window
      message: 'Too many requests, please try again later.'
    },
    strict: {
      windowMs: 60 * 1000, // 1 minute
      max: 20, // 20 requests per minute for sensitive endpoints
      message: 'Rate limit exceeded for sensitive operations.'
    }
  },
  
  // CORS Configuration
  cors: {
    origin: process.env.ALLOWED_ORIGINS?.split(',') || ['https://app.fixzit.com'],
    credentials: true,
    optionsSuccessStatus: 200
  },
  
  // MongoDB Optimization
  mongodb: {
    options: {
      maxPoolSize: 20,
      minPoolSize: 5,
      maxIdleTimeMS: 30000,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
      // bufferMaxEntries: 0, // DEPRECATED - Removed for MongoDB compatibility
      bufferCommands: false,
      retryWrites: true,
      writeConcern: {
        w: 'majority',
        j: true,
        wtimeout: 1000
      }
    }
  },
  
  // Logging
  logging: {
    level: 'info',
    format: 'combined',
    errorLogging: true,
    requestLogging: true,
    maxLogFiles: 10,
    maxLogSize: '10m'
  },
  
  // Performance
  performance: {
    compression: true,
    staticCache: {
      maxAge: '1y',
      etag: true,
      lastModified: true
    },
    jsonLimit: '10mb',
    urlLimit: '50kb'
  },
  
  // Health Monitoring
  health: {
    checkInterval: 30000, // 30 seconds
    dbTimeout: 5000,
    criticalServices: ['database', 'authentication', 'notifications']
  },
  
  // SSL/TLS
  ssl: {
    enforceHTTPS: true,
    hstsMaxAge: 31536000,
    hstsIncludeSubdomains: true
  },
  
  // Session Security
  session: {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  },
  
  // File Upload
  upload: {
    maxFileSize: '10mb',
    allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'],
    destination: '/secure/uploads',
    virusScan: true
  },
  
  // API Documentation
  apiDocs: {
    enabled: false, // Disable in production for security
    authRequired: true,
    allowedUsers: ['admin', 'super_admin']
  },
  
  // Backup Configuration
  backup: {
    enabled: true,
    schedule: '0 2 * * *', // Daily at 2 AM
    retention: '30d',
    destinations: ['s3', 'local']
  },
  
  // Notifications
  notifications: {
    email: {
      enabled: true,
      provider: 'sendgrid',
      rateLimit: 1000 // per hour
    },
    sms: {
      enabled: true,
      provider: 'twilio',
      rateLimit: 100 // per hour
    },
    slack: {
      enabled: true,
      webhookUrl: process.env.SLACK_WEBHOOK_URL
    }
  },
  
  // Monitoring
  monitoring: {
    apm: {
      enabled: true,
      provider: 'elastic'
    },
    metrics: {
      enabled: true,
      endpoint: '/metrics',
      authRequired: true
    },
    alerts: {
      enabled: true,
      thresholds: {
        errorRate: 5, // 5% error rate
        responseTime: 2000, // 2 second response time
        memoryUsage: 80, // 80% memory usage
        cpuUsage: 80 // 80% CPU usage
      }
    }
  }
};

module.exports = production;