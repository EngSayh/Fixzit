// config/redis.js
const redis = require('redis');

let client = null;

try {
  client = redis.createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379'
  });

  client.on('error', (err) => {
    console.warn('⚠️ Redis connection error (operating in fallback mode):', err.message);
  });

  client.on('connect', () => {
    console.log('✅ Redis connected successfully');
  });

  // Connect to Redis (non-blocking)
  client.connect().catch(err => {
    console.warn('⚠️ Redis connection failed (operating in fallback mode):', err.message);
    client = null;
  });
} catch (error) {
  console.warn('⚠️ Redis initialization failed (operating in fallback mode):', error.message);
  client = null;
}

// Export client (can be null if Redis is unavailable)
module.exports = client;