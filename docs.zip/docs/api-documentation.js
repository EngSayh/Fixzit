const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'FIXZIT SOUQ API Documentation',
      version: '1.0.0',
      description: 'Complete API documentation for FIXZIT facility management platform with integrated marketplace functionality',
      contact: {
        name: 'FIXZIT Support',
        email: 'support@fixzit.com'
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT'
      }
    },
    servers: [
      {
        url: 'http://localhost:5000/api',
        description: 'Development server'
      },
      {
        url: 'https://api.fixzit.com/api',
        description: 'Production server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'JWT token obtained from /auth/login endpoint'
        }
      },
      schemas: {
        Error: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: false },
            message: { type: 'string', example: 'Error message' },
            error: { type: 'string', example: 'Detailed error description' }
          }
        },
        User: {
          type: 'object',
          properties: {
            id: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k1' },
            name: { type: 'string', example: 'John Doe' },
            email: { type: 'string', example: 'john@example.com' },
            role: { 
              type: 'string', 
              enum: ['super_admin', 'admin', 'manager', 'technician', 'tenant'],
              example: 'admin'
            },
            organization: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k2' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' }
          }
        },
        Property: {
          type: 'object',
          properties: {
            id: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k3' },
            name: { type: 'string', example: 'Sunset Apartments' },
            code: { type: 'string', example: 'RES-0001' },
            type: { 
              type: 'string', 
              enum: ['residential', 'commercial', 'industrial', 'mixed', 'land'],
              example: 'residential'
            },
            address: {
              type: 'object',
              properties: {
                street: { type: 'string', example: '123 Main Street' },
                city: { type: 'string', example: 'Riyadh' },
                state: { type: 'string', example: 'Riyadh Province' },
                country: { type: 'string', example: 'Saudi Arabia' },
                postalCode: { type: 'string', example: '12345' }
              }
            },
            status: { 
              type: 'string', 
              enum: ['active', 'inactive', 'maintenance'],
              example: 'active'
            },
            organization: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k2' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' }
          }
        },
        WorkOrder: {
          type: 'object',
          properties: {
            id: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k4' },
            workOrderNumber: { type: 'string', example: 'WO-202501-00001' },
            title: { type: 'string', example: 'Fix leaking faucet' },
            description: { type: 'string', example: 'Kitchen faucet is leaking and needs repair' },
            priority: { 
              type: 'string', 
              enum: ['low', 'medium', 'high', 'urgent'],
              example: 'medium'
            },
            status: { 
              type: 'string', 
              enum: ['open', 'in_progress', 'completed', 'cancelled'],
              example: 'open'
            },
            category: { 
              type: 'string', 
              enum: ['maintenance', 'repair', 'inspection', 'cleaning'],
              example: 'repair'
            },
            propertyId: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k3' },
            assignedTo: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k5' },
            createdBy: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k1' },
            dueDate: { type: 'string', format: 'date-time' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' }
          }
        },
        Invoice: {
          type: 'object',
          properties: {
            id: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k6' },
            invoiceNumber: { type: 'string', example: 'INV-202501-00001' },
            amount: { type: 'number', example: 1500.00 },
            currency: { type: 'string', example: 'SAR' },
            status: { 
              type: 'string', 
              enum: ['draft', 'sent', 'paid', 'overdue', 'cancelled'],
              example: 'sent'
            },
            dueDate: { type: 'string', format: 'date-time' },
            propertyId: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k3' },
            items: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  description: { type: 'string', example: 'Monthly rent' },
                  quantity: { type: 'number', example: 1 },
                  unitPrice: { type: 'number', example: 1500.00 },
                  total: { type: 'number', example: 1500.00 }
                }
              }
            },
            zatca: {
              type: 'object',
              properties: {
                uuid: { type: 'string', example: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890' },
                hash: { type: 'string', example: 'abc123def456...' },
                qrCode: { type: 'string', example: 'data:image/png;base64,iVBOR...' }
              }
            },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' }
          }
        },
        Notification: {
          type: 'object',
          properties: {
            id: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k7' },
            title: { type: 'string', example: 'Work Order Assigned' },
            message: { type: 'string', example: 'You have been assigned a new work order' },
            type: { 
              type: 'string', 
              enum: ['work_order_created', 'work_order_assigned', 'invoice_generated', 'payment_received'],
              example: 'work_order_assigned'
            },
            priority: { 
              type: 'string', 
              enum: ['low', 'normal', 'high', 'urgent'],
              example: 'normal'
            },
            status: { 
              type: 'string', 
              enum: ['pending', 'sent', 'delivered', 'failed', 'read'],
              example: 'sent'
            },
            channels: {
              type: 'array',
              items: { 
                type: 'string', 
                enum: ['in_app', 'email', 'sms', 'whatsapp', 'push']
              },
              example: ['in_app', 'email']
            },
            user: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k1' },
            readAt: { type: 'string', format: 'date-time' },
            createdAt: { type: 'string', format: 'date-time' }
          }
        }
      }
    },
    security: [
      {
        bearerAuth: []
      }
    ]
  },
  apis: [
    './routes/*.js',
    './docs/api-paths.js'
  ]
};

// Generate API documentation
const specs = swaggerJsdoc(options);

// API Paths Documentation
const apiPaths = {
  '/auth/login': {
    post: {
      tags: ['Authentication'],
      summary: 'User login',
      description: 'Authenticate user and receive JWT token',
      requestBody: {
        required: true,
        content: {
          'application/json': {
            schema: {
              type: 'object',
              required: ['email', 'password'],
              properties: {
                email: { type: 'string', example: 'user@example.com' },
                password: { type: 'string', example: 'password123' }
              }
            }
          }
        }
      },
      responses: {
        200: {
          description: 'Login successful',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: true },
                  token: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' },
                  user: { $ref: '#/components/schemas/User' }
                }
              }
            }
          }
        },
        401: {
          description: 'Invalid credentials',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        }
      }
    }
  },
  '/auth/register': {
    post: {
      tags: ['Authentication'],
      summary: 'User registration',
      description: 'Register new user and organization',
      requestBody: {
        required: true,
        content: {
          'application/json': {
            schema: {
              type: 'object',
              required: ['name', 'email', 'password', 'tenantName'],
              properties: {
                name: { type: 'string', example: 'John Doe' },
                email: { type: 'string', example: 'john@example.com' },
                password: { type: 'string', example: 'SecurePass123!' },
                tenantName: { type: 'string', example: 'Acme Properties' },
                role: { type: 'string', example: 'admin' }
              }
            }
          }
        }
      },
      responses: {
        201: {
          description: 'Registration successful',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: true },
                  user: { $ref: '#/components/schemas/User' },
                  organization: { type: 'object' }
                }
              }
            }
          }
        }
      }
    }
  },
  '/properties': {
    get: {
      tags: ['Properties'],
      summary: 'Get all properties',
      description: 'Retrieve all properties for the authenticated user\'s organization',
      security: [{ bearerAuth: [] }],
      responses: {
        200: {
          description: 'Properties retrieved successfully',
          content: {
            'application/json': {
              schema: {
                type: 'array',
                items: { $ref: '#/components/schemas/Property' }
              }
            }
          }
        }
      }
    },
    post: {
      tags: ['Properties'],
      summary: 'Create new property',
      description: 'Create a new property with auto-generated property code',
      security: [{ bearerAuth: [] }],
      requestBody: {
        required: true,
        content: {
          'application/json': {
            schema: {
              type: 'object',
              required: ['name', 'type', 'address'],
              properties: {
                name: { type: 'string', example: 'Sunset Apartments' },
                type: { 
                  type: 'string', 
                  enum: ['residential', 'commercial', 'industrial', 'mixed'],
                  example: 'residential'
                },
                address: {
                  type: 'object',
                  required: ['street', 'city'],
                  properties: {
                    street: { type: 'string', example: '123 Main Street' },
                    city: { type: 'string', example: 'Riyadh' },
                    country: { type: 'string', example: 'Saudi Arabia' }
                  }
                }
              }
            }
          }
        }
      },
      responses: {
        201: {
          description: 'Property created successfully',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Property' }
            }
          }
        }
      }
    }
  },
  '/workorders': {
    get: {
      tags: ['Work Orders'],
      summary: 'Get all work orders',
      security: [{ bearerAuth: [] }],
      responses: {
        200: {
          description: 'Work orders retrieved successfully',
          content: {
            'application/json': {
              schema: {
                type: 'array',
                items: { $ref: '#/components/schemas/WorkOrder' }
              }
            }
          }
        }
      }
    },
    post: {
      tags: ['Work Orders'],
      summary: 'Create new work order',
      security: [{ bearerAuth: [] }],
      requestBody: {
        required: true,
        content: {
          'application/json': {
            schema: {
              type: 'object',
              required: ['title', 'description', 'propertyId'],
              properties: {
                title: { type: 'string', example: 'Fix leaking faucet' },
                description: { type: 'string', example: 'Kitchen faucet needs repair' },
                propertyId: { type: 'string', example: '65a1b2c3d4e5f6g7h8i9j0k3' },
                priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'], example: 'medium' },
                category: { type: 'string', enum: ['maintenance', 'repair', 'inspection'], example: 'repair' }
              }
            }
          }
        }
      },
      responses: {
        201: {
          description: 'Work order created successfully',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/WorkOrder' }
            }
          }
        }
      }
    }
  },
  '/notifications/test': {
    post: {
      tags: ['Notifications'],
      summary: 'Test notification functionality',
      description: 'Send a test notification to verify Phase 4 real-time features',
      security: [{ bearerAuth: [] }],
      responses: {
        200: {
          description: 'Test notification sent successfully',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: true },
                  message: { type: 'string', example: 'Phase 4 test notification sent' },
                  result: {
                    type: 'object',
                    properties: {
                      notificationId: { type: 'string' },
                      results: {
                        type: 'object',
                        properties: {
                          in_app: { type: 'boolean', example: true },
                          email: { type: 'boolean', example: false },
                          sms: { type: 'boolean', example: false }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
};

// Merge paths into specs
specs.paths = { ...specs.paths, ...apiPaths };

module.exports = {
  specs,
  swaggerUi,
  options
};