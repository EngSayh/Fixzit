# Performance & Reliability Integration Guide

## Overview

This guide explains how to use the new performance and reliability features in Fixzit.

## 🎯 Features Added

### 1. Performance Budgets & Testing
- **Configuration**: `perf_budgets.json` - Define performance thresholds
- **Testing Script**: `scripts/perf_budgets.py` - Automated performance testing
- **Budgets**: FCP, LCP, CLS, TBT thresholds enforced

### 2. Health Dashboard
- **Location**: Pages → Health Dashboard (955_HealthDashboard.py)
- **Features**: 
  - Core Web Vitals monitoring
  - Budget compliance status
  - UI health checks
  - Performance timeline charts
  - System health grade

### 3. Uptime Monitoring
- **Location**: Pages → Uptime Monitoring (956_UptimeMonitoring.py)
- **Features**:
  - Endpoint monitoring
  - Health checks
  - Alert management
  - Uptime statistics
  - System health scoring

### 4. Audit System
- **Service**: `services/audit_service.py`
- **Features**:
  - Track configuration changes
  - User action logging
  - System event auditing
  - Export capabilities

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements-dev.txt
playwright install --with-deps
```

### 2. Configure Performance Budgets
Edit `perf_budgets.json`:
```json
{
  "global": {
    "first_contentful_paint_ms": 1800,
    "largest_contentful_paint_ms": 2500,
    "cumulative_layout_shift": 0.10,
    "total_blocking_time_ms": 200
  }
}
```

### 3. Run Performance Tests
```bash
python scripts/perf_budgets.py
```

### 4. Access Dashboards
- **Health Dashboard**: Navigate to Pages → Health Dashboard
- **Uptime Monitoring**: Navigate to Pages → Uptime Monitoring

## 📊 Using the Health Dashboard

1. **System Status**: View overall performance grade and system health
2. **Core Web Vitals**: Monitor FCP, LCP, CLS metrics
3. **Budget Compliance**: Check if performance meets defined budgets
4. **UI Health**: View console errors and network failures
5. **Export Reports**: Download health reports for analysis

## 📡 Uptime Monitoring Setup

1. **Add Endpoints**: Click "Add Endpoint" to monitor URLs
2. **Configure Checks**: Set timeouts, intervals, and expected status codes
3. **Run Health Checks**: Use "Run Health Check" to test all endpoints
4. **Monitor Alerts**: View and acknowledge system alerts
5. **View Statistics**: Analyze uptime trends and performance

## 🔧 Integration with Existing Pages

### Add Performance Tracking
```python
from utils.performance_client import track_page, track_action

# At the start of your page
track_page("Dashboard", "/dashboard")

# Track user actions
if st.button("Submit"):
    track_action("form_submit", {"form_type": "user_data"})
```

### Enable Debug Mode
```python
from utils.performance_client import show_debug

# Add to your page for development
show_debug()
```

## 📈 Performance Testing Pipeline

### Manual Testing
```bash
# Run performance tests
python scripts/perf_budgets.py

# View results
cat artifacts/perf-budget-results.json
```

### CI/CD Integration
Add to your pipeline:
```yaml
- name: Run Performance Tests
  run: |
    python scripts/perf_budgets.py
    if [ $? -ne 0 ]; then
      echo "Performance budgets failed"
      exit 1
    fi
```

## 📝 Audit System Usage

### Track Configuration Changes
```python
from services.audit_service import audit_service

# Track feature flag changes
audit_service.audit_feature_flag("update", "dark_mode", old_value=False, new_value=True)

# Track system settings
audit_service.audit_system_setting("create", "api_timeout", new_value=30)

# Track user actions
audit_service.audit_user_action("login", "user_session", {"user_id": "123"})
```

### View Audit Logs
- Access through Config Audit page
- Search and filter logs
- Export audit data

## 🚨 Alert Management

### Uptime Alerts
- Automatic alerts for endpoint failures
- Configurable severity levels
- Acknowledgment workflow

### Performance Alerts
- Budget violation notifications
- Performance degradation warnings
- System health alerts

## 📊 Monitoring Best Practices

### Performance Budgets
1. Set realistic thresholds based on your user base
2. Regular testing in CI/CD pipeline
3. Monitor trends, not just absolute values
4. Focus on Core Web Vitals (FCP, LCP, CLS)

### Uptime Monitoring
1. Monitor critical endpoints only
2. Set appropriate check intervals
3. Use realistic timeouts
4. Monitor from user perspective

### Health Dashboard
1. Review regularly (daily/weekly)
2. Export reports for historical analysis
3. Track improvements over time
4. Share metrics with stakeholders

## 🔍 Troubleshooting

### Performance Tests Failing
1. Check if Streamlit app starts properly
2. Verify port configuration (default: 5000)
3. Review budget thresholds in `perf_budgets.json`
4. Check artifacts folder for detailed results

### Uptime Monitoring Issues
1. Verify endpoint URLs are accessible
2. Check timeout settings
3. Review expected status codes
4. Monitor network connectivity

### Dashboard Not Loading
1. Check if services are initialized
2. Verify data directory permissions
3. Review browser console for errors
4. Clear Streamlit cache if needed

## 📚 Files Structure

```
fixzit/
├── perf_budgets.json                 # Performance budget configuration
├── scripts/
│   └── perf_budgets.py              # Performance testing script
├── services/
│   ├── performance_service.py       # Performance data management
│   ├── audit_service.py            # Audit logging service
│   └── uptime_service.py           # Uptime monitoring service
├── utils/
│   └── performance_client.py       # Client-side performance tracking
├── pages/
│   ├── 955_HealthDashboard.py      # Health monitoring dashboard
│   └── 956_UptimeMonitoring.py     # Uptime monitoring dashboard
├── artifacts/                      # Generated test results
│   ├── perf-metrics.json
│   ├── perf-budget-results.json
│   └── ui-failures.json
└── .localdata/                     # Local data storage
    ├── performance/
    ├── audit/
    └── uptime/
```

## 🎯 Next Steps

1. **Configure Budgets**: Adjust performance thresholds for your needs
2. **Set Up Monitoring**: Add critical endpoints to uptime monitoring
3. **Enable Tracking**: Integrate performance tracking in key pages
4. **Schedule Tests**: Set up automated performance testing
5. **Review Dashboards**: Regularly check health and uptime status

## 📞 Support

For questions or issues with the performance and reliability features:
1. Check the troubleshooting section above
2. Review the generated artifacts for detailed information
3. Use the debug mode for development insights
4. Export audit logs for detailed analysis