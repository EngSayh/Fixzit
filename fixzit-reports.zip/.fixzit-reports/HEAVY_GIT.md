# Diagnose Large Git History (Safe)

git rev-list --objects --all | \
  git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' | \
  awk '$1=="blob" {print $3 " " $4}' | sort -nr | head -50

git reflog expire --expire=now --all
git gc --prune=now --aggressive
# If still huge: java -jar bfg.jar --strip-blobs-bigger-than 100M
