#!/usr/bin/env bash
set -euo pipefail
# DRY-RUN: remove 'echo' after review
