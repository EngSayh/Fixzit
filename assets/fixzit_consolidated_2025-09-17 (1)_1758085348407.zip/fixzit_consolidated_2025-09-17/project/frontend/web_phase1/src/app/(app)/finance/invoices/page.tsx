'use client'
import useSWR from 'swr'
import { useSearchParams } from 'next/navigation'
import { formatCurrency } from '@/lib/format'
import { useI18n } from '@/lib/i18n'
const fetcher=(url:string)=>fetch(url).then(r=>r.json())
export default function InvoicesPage(){
  const { t, locale } = useI18n() as any
  const sp=useSearchParams(); const tenantId=sp.get('tenantId')||'t_fmz'; const propertyId=sp.get('propertyId')||''
  const { data }=useSWR(`/api/invoices?tenantId=${tenantId}&propertyId=${propertyId}`, fetcher)
  return <section>
    <h1 className="text-2xl font-semibold mb-4">{t('invoices.title')}</h1>
    <div className="rounded-2xl glass p-2 overflow-x-auto">
      <table className="min-w-full divide-y">
        <thead><tr>
          <th className="px-4 py-2 text-left">ID</th>
          <th className="px-4 py-2 text-left">{t('common.property')}</th>
          <th className="px-4 py-2 text-left">{t('common.status')}</th>
          <th className="px-4 py-2 text-left">{t('common.total')}</th>
          <th className="px-4 py-2 text-left">{t('common.due')}</th>
        </tr></thead>
        <tbody className="divide-y">{data?.items?.map((i:any)=>(
          <tr key={i.id} className="hover:bg-white/40 dark:hover:bg-gray-900/40">
            <td className="px-4 py-2">{i.id}</td>
            <td className="px-4 py-2">{i.property?.name||i.propertyId}</td>
            <td className="px-4 py-2">{i.status}</td>
            <td className="px-4 py-2">{formatCurrency(i.total, locale, i.currency)}</td>
            <td className="px-4 py-2">{new Date(i.dueDate).toLocaleDateString(locale)}</td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  </section>
}
