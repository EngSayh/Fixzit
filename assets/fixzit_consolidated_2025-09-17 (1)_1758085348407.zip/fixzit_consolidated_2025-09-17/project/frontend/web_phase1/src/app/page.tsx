'use client'
import Image from 'next/image'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n'

export default function Page(){
  const { t } = useI18n()
  return (
    <main id="main" className="mx-auto max-w-6xl px-6 py-16">
      <div className="glass-card p-6 flex items-center gap-3 mb-6">
        <Image src="/logo.jpg" alt="Fixzit" width={40} height={40} className="rounded"/>
        <h1 className="text-2xl font-bold">{t('layout.welcome_title')}</h1>
      </div>
      <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl">
        {t('layout.welcome_sub')}
      </p>
      <div className="mt-8 flex gap-3">
        <Link href="/auth/login" className="rounded-xl bg-brand-500 px-5 py-3 text-white hover:bg-brand-600">{t('actions.sign_in')}</Link>
        <Link href="/app/dashboard" className="rounded-xl border px-5 py-3 hover:bg-white/40 dark:hover:bg-gray-900/40 glass">{t('nav.dashboard')}</Link>
      </div>
    </main>
  )
}
