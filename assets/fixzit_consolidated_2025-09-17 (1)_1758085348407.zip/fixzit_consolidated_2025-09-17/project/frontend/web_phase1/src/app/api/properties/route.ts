import { NextResponse } from 'next/server'
import data from '@/data/mock/properties.json'
import tenants from '@/data/mock/tenants.json'
export async function GET(req:Request){
  const { searchParams }=new URL(req.url)
  const id=searchParams.get('id'); const tenantId=searchParams.get('tenantId')||'t_fmz'
  const status=searchParams.get('status')||''; const type=searchParams.get('type')||''; const city=searchParams.get('city')||''; const q=(searchParams.get('q')||'').toLowerCase()
  const page=parseInt(searchParams.get('page')||'1'); const pageSize=10
  const items=(data as any[]).filter(p=>!id||p.id===id).filter(p=>p.tenantId===tenantId).filter(p=>!status||p.status===status).filter(p=>!type||p.type===type).filter(p=>!city||p.address.city.toLowerCase().includes(city.toLowerCase())).filter(p=>!q||(p.code.toLowerCase().includes(q)||p.name.toLowerCase().includes(q))).map(p=>({...p, tenant:(tenants as any[]).find(t=>t.id===p.tenantId)}))
  if(id){ const item=items[0]; if(!item) return NextResponse.json({error:'Not found'},{status:404}); return NextResponse.json({item}) }
  const start=(page-1)*pageSize; const paged=items.slice(start,start+pageSize)
  return NextResponse.json({ items:paged, page, pageCount:Math.ceil(items.length/pageSize), total:items.length })
}
export async function POST(req:Request){ const payload=await req.json(); return NextResponse.json({ok:true,item:{...payload,id:'p_'+Math.random().toString(36).slice(2)}},{status:201}) }
