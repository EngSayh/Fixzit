import './styles/globals.css'
import type { Metadata } from 'next'
import { cookies } from 'next/headers'
import { getDir } from '@/lib/i18n/dir'
import { I18nProvider } from '@/lib/i18n'
import { SkipLink } from '@/components/SkipLink'

export const metadata: Metadata = { title:'Fixzit — Facility Management + Marketplace', description:'RTL-ready facility management platform' }

export default function RootLayout({ children }:{ children: React.ReactNode }){
  const locale = (cookies().get('locale')?.value ?? 'en') as 'en'|'ar'
  const dir = getDir(locale)
  return (
    <html lang={locale} dir={dir} suppressHydrationWarning>
      <body className="aurora">
        <SkipLink />
        <I18nProvider initialLocale={locale}>
          {children}
        </I18nProvider>
      </body>
    </html>
  )
}
