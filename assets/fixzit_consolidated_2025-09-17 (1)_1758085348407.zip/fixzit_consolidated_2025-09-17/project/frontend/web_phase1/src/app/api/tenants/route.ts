import { NextResponse } from 'next/server'
import tenants from '@/data/mock/tenants.json'
export async function GET(){ return NextResponse.json({ items: tenants }) }