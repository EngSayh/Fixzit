'use client'
import useSWR from 'swr'
import { useSearchParams, useRouter, usePathname } from 'next/navigation'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { Pagination } from '@/components/ui/Pagination'
import { StatusPill } from '@/components/ui/StatusPill'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n'
import { Breadcrumbs } from '@/components/Breadcrumbs'

const fetcher=(url:string)=>fetch(url).then(r=>r.json())

export default function PropertiesPage(){
  const { t } = useI18n()
  const sp=useSearchParams(); const router=useRouter(); const pathname=usePathname()
  const page=Number(sp.get('page')||'1'); const tenantId=sp.get('tenantId')||'t_fmz'
  const status=sp.get('status')||''; const type=sp.get('type')||''; const city=sp.get('city')||''; const q=sp.get('q')||''
  const { data }=useSWR(`/api/properties?tenantId=${tenantId}&page=${page}&status=${status}&type=${type}&city=${city}&q=${q}`, fetcher)
  function setParam(k:string,v:string){ const params=new URLSearchParams(sp.toString()); v?params.set(k,v):params.delete(k); router.push(`${pathname}?${params.toString()}`) }
  return <section>
    <Breadcrumbs items={[{href:'/app/dashboard',label:'Dashboard'},{href:'/app/properties',label:'Properties'}]} />
    <div className="flex items-center justify-between gap-3">
      <h1 className="text-2xl font-semibold">{t('properties.title')}</h1>
      <Link href="/app/properties/new" className="rounded-xl bg-brand-500 px-4 py-2 text-white hover:bg-brand-600">{t('properties.add')}</Link>
    </div>
    <div className="mt-4 grid grid-cols-1 md:grid-cols-5 gap-3 glass-card p-4">
      <Input placeholder={t('actions.search')+'…'} value={q} onChange={e=>setParam('q', e.target.value)} />
      <Select value={status} onChange={e=>setParam('status', e.target.value)}>
        <option value="">{t('properties.all_status')}</option>
        <option>Active</option><option>Inactive</option><option>UnderConstruction</option><option>Archived</option>
      </Select>
      <Select value={type} onChange={e=>setParam('type', e.target.value)}>
        <option value="">{t('properties.all_types')}</option>
        <option>Residential</option><option>Commercial</option><option>Industrial</option><option>MixedUse</option><option>Facility</option>
      </Select>
      <Input placeholder={t('common.city')} value={city} onChange={e=>setParam('city', e.target.value)} />
      <Button variant="secondary" onClick={()=>router.push(pathname)}>{t('actions.reset')}</Button>
    </div>

    <div className="mt-4 overflow-x-auto glass-card p-2">
      <table className="min-w-full divide-y">
        <thead className="">
          <tr>
            <th className="px-4 py-2 text-left">{t('common.code')}</th>
            <th className="px-4 py-2 text-left">{t('common.name')}</th>
            <th className="px-4 py-2 text-left">{t('common.type')}</th>
            <th className="px-4 py-2 text-left">{t('common.city')}</th>
            <th className="px-4 py-2 text-left">{t('common.units')}</th>
            <th className="px-4 py-2 text-left">{t('common.area')} (m²)</th>
            <th className="px-4 py-2 text-left">{t('common.status')}</th>
            <th className="px-4 py-2 text-left">{t('common.tenant')}</th>
            <th className="px-4 py-2"></th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {data?.items?.length? data.items.map((p:any)=>(
            <tr key={p.id} className="hover:bg-white/40 dark:hover:bg-gray-900/40">
              <td className="px-4 py-2">{p.code}</td>
              <td className="px-4 py-2 font-medium">{p.name}</td>
              <td className="px-4 py-2">{p.type}</td>
              <td className="px-4 py-2">{p.address.city}</td>
              <td className="px-4 py-2">{p.units ?? '-'}</td>
              <td className="px-4 py-2">{p.areaSqm ?? '-'}</td>
              <td className="px-4 py-2"><StatusPill status={p.status} /></td>
              <td className="px-4 py-2">{p.tenant?.name ?? p.tenantId}</td>
              <td className="px-4 py-2 text-right"><Link className="underline" href={`/app/properties/${p.id}`}>{t('actions.view')}</Link></td>
            </tr>
          )) : (
            <tr><td className="px-4 py-6 text-center text-sm text-gray-600" colSpan={9}>{t('properties.list_empty')}</td></tr>
          )}
        </tbody>
      </table>
    </div>
    {data && <Pagination page={data.page} pageCount={data.pageCount} onPage={(np)=>setParam('page', String(np))} />}
  </section>
}
