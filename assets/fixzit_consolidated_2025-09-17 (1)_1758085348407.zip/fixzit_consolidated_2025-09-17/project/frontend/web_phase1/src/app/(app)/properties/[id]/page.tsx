import { notFound } from 'next/navigation'
import { Breadcrumbs } from '@/components/Breadcrumbs'
async function getData(id:string){
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/properties?id=${id}`,{ cache:'no-store' })
  if(!res.ok) return null
  return res.json()
}
export default async function PropertyDetail({ params }:{ params:{ id:string } }){
  const data = await getData(params.id)
  if(!data) notFound()
  const p = data.item
  return (
    <section className="space-y-2">
      <Breadcrumbs items={[{href:'/app/dashboard',label:'Dashboard'},{href:'/app/properties',label:'Properties'}]} />
      <h1 className="text-2xl font-semibold">{p.name} <span className="text-gray-500">({p.code})</span></h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="glass-card p-4">
          <h2 className="font-semibold">Details</h2>
          <dl className="mt-2 grid grid-cols-2 gap-2 text-sm">
            <dt>Status</dt><dd>{p.status}</dd>
            <dt>Type</dt><dd>{p.type}</dd>
            <dt>City</dt><dd>{p.address.city}</dd>
            <dt>Units</dt><dd>{p.units ?? '-'}</dd>
            <dt>Area</dt><dd>{p.areaSqm ?? '-'}</dd>
            <dt>Year built</dt><dd>{p.yearBuilt ?? '-'}</dd>
            <dt>Owner</dt><dd>{p.owner ?? '-'}</dd>
            <dt>Manager</dt><dd>{p.manager ?? '-'}</dd>
          </dl>
        </div>
        <div className="glass-card p-4">
          <h2 className="font-semibold">Links</h2>
          <ul className="mt-2 list-disc pl-6 text-sm">
            <li><a className="underline" href={`/app/work-orders?propertyId=${p.id}`}>Work Orders</a></li>
            <li><a className="underline" href={`/app/finance/invoices?propertyId=${p.id}`}>Invoices</a></li>
          </ul>
        </div>
      </div>
    </section>
  )
}
