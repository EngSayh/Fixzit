import { NextResponse } from 'next/server'
import data from '@/data/mock/invoices.json'
import props from '@/data/mock/properties.json'
export async function GET(req:Request){
  const { searchParams }=new URL(req.url)
  const tenantId=searchParams.get('tenantId')||'t_fmz'; const propertyId=searchParams.get('propertyId')||''
  const items=(data as any[]).filter(i=>i.tenantId===tenantId).filter(i=>!propertyId||i.propertyId===propertyId).map(i=>({...i, property:(props as any[]).find(p=>p.id===i.propertyId)}))
  return NextResponse.json({ items })
}