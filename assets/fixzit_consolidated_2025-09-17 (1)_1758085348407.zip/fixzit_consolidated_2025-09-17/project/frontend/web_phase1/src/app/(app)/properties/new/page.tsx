import { PropertyForm } from '../components/PropertyForm'
import { useI18n } from '@/lib/i18n'
export default function NewProperty(){ 
  // @ts-expect-error Server component using client i18n for static text is okay here
  return (<section className="space-y-4">
    {/* @ts-expect-error */}
    <Header/>
    <PropertyForm />
  </section>)
}
'use client'
function Header(){
  const { t } = useI18n()
  return <h1 className="text-2xl font-semibold">{t('properties.add')}</h1>
}
