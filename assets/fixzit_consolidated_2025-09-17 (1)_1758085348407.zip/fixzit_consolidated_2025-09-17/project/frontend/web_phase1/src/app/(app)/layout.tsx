import { AppHeader } from '@/components/AppHeader'
import { AppSidebar } from '@/components/AppSidebar'
export default function AppLayout({children}:{children:React.ReactNode}){
  return (
    <div className="min-h-screen grid grid-rows-[auto,1fr]">
      {/* @ts-expect-error Server Component */}
      <AppHeader />
      <div className="grid grid-cols-[16rem,1fr] gap-4 p-4">
        {/* @ts-expect-error Server Component */}
        <AppSidebar />
        <main id="main" className="space-y-4">{children}</main>
      </div>
    </div>
  )
}
