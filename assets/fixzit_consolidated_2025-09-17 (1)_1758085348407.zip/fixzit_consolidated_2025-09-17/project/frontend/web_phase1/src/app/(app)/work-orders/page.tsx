'use client'
import useSWR from 'swr'
import { useSearchParams } from 'next/navigation'
import { useI18n } from '@/lib/i18n'
const fetcher=(url:string)=>fetch(url).then(r=>r.json())
export default function WorkOrdersPage(){
  const { t } = useI18n()
  const sp=useSearchParams(); const tenantId=sp.get('tenantId')||'t_fmz'; const propertyId=sp.get('propertyId')||''
  const { data }=useSWR(`/api/work-orders?tenantId=${tenantId}&propertyId=${propertyId}`, fetcher)
  return <section>
    <h1 className="text-2xl font-semibold mb-4">{t('work_orders.title')}</h1>
    <div className="rounded-2xl glass p-2 overflow-x-auto">
      <table className="min-w-full divide-y">
        <thead><tr><th className="px-4 py-2 text-left">Title</th><th className="px-4 py-2 text-left">Property</th><th className="px-4 py-2 text-left">Status</th></tr></thead>
        <tbody className="divide-y">{data?.items?.map((w:any)=>(
          <tr key={w.id} className="hover:bg-white/40 dark:hover:bg-gray-900/40">
            <td className="px-4 py-2">{w.title}</td><td className="px-4 py-2">{w.property?.name||w.propertyId}</td><td className="px-4 py-2">{w.status}</td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  </section>
}
