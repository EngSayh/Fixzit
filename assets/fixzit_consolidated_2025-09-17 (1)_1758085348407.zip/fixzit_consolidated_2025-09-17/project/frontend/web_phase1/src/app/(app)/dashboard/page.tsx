'use client'
import { useI18n } from '@/lib/i18n'
export default function Dashboard(){
  const { t } = useI18n()
  return (
    <section className="space-y-6">
      <h1 className="text-2xl font-semibold">{t('nav.dashboard')}</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-card p-4">
          <div className="text-sm text-gray-600 dark:text-gray-300">{t('dashboard.open_work_orders')}</div>
          <div className="mt-2 text-3xl font-bold">12</div>
        </div>
        <div className="glass-card p-4">
          <div className="text-sm text-gray-600 dark:text-gray-300">{t('dashboard.active_properties')}</div>
          <div className="mt-2 text-3xl font-bold">48</div>
        </div>
        <div className="glass-card p-4">
          <div className="text-sm text-gray-600 dark:text-gray-300">{t('dashboard.outstanding_invoices')}</div>
          <div className="mt-2 text-3xl font-bold">SAR 126,400</div>
        </div>
      </div>
    </section>
  )
}
