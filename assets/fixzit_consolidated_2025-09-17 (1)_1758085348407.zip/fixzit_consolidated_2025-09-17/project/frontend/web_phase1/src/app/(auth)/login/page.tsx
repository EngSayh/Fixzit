'use client'
import { useState } from 'react'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n'

export default function LoginPage(){
  const { t } = useI18n()
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState<string|undefined>(undefined)
  function onSubmit(e:React.FormEvent){ e.preventDefault(); if(!email||!password){ setErr(t('validation.required')); return } window.location.href='/app/dashboard' }
  return <form onSubmit={onSubmit} aria-describedby={err?'err':undefined}>
    <div className="text-center mb-4">
      <h1 className="text-xl font-semibold">{t('login.title')}</h1>
      <p className="text-sm text-gray-600">{t('login.subtitle')}</p>
    </div>
    <div className="space-y-3">
      <Input type="email" label={t('login.email')} value={email} onChange={e=>setEmail(e.target.value)} required />
      <Input type="password" label={t('login.password')} value={password} onChange={e=>setPassword(e.target.value)} required />
    </div>
    {err&&<p id="err" className="mt-2 text-sm text-red-600">{err}</p>}
    <div className="mt-4 flex items-center justify-between">
      <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" className="rounded border-gray-300" /> {t('login.remember_me')}</label>
      <Link className="text-sm underline" href="#">{t('login.forgot')}</Link>
    </div>
    <Button className="mt-6 w-full" type="submit">{t('actions.sign_in')}</Button>
  </form>
}
