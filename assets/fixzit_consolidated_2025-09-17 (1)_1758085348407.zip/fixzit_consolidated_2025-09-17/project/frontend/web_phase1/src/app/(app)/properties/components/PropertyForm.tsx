'use client'
import { useState } from 'react'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { z } from 'zod'
import { propertySchema } from '@/lib/validators/property'
import { useI18n } from '@/lib/i18n'

export function PropertyForm({ initial }:{ initial?: z.infer<typeof propertySchema> }){
  const { t } = useI18n()
  const [model,setModel]=useState<z.infer<typeof propertySchema>>(initial ?? { tenantId:'t_fmz', code:'', name:'', type:'Residential', status:'Active', address:{ line1:'', city:'', country:'SA' }, serviceLevel:'Standard', compliance:[], attachments:[] })
  async function save(){
    const parsed = propertySchema.safeParse(model)
    if(!parsed.success){ alert(parsed.error.issues.map(i=>i.message).join('\n')); return }
    const res = await fetch('/api/properties',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(parsed.data)})
    if(res.ok) window.location.href='/app/properties'; else alert(t('toasts.failed'))
  }
  return <div className="grid grid-cols-1 md:grid-cols-2 gap-4 glass-card p-4">
    <Input label={t('common.code')} value={model.code} onChange={e=>setModel({...model, code:e.target.value})} />
    <Input label={t('common.name')} value={model.name} onChange={e=>setModel({...model, name:e.target.value})} />
    <Select label={t('common.type')} value={model.type} onChange={e=>setModel({...model, type:e.target.value as any})}>
      <option>Residential</option><option>Commercial</option><option>Industrial</option><option>MixedUse</option><option>Facility</option>
    </Select>
    <Select label={t('common.status')} value={model.status} onChange={e=>setModel({...model, status:e.target.value as any})}>
      <option>Active</option><option>Inactive</option><option>UnderConstruction</option><option>Archived</option>
    </Select>
    <Input label=f"{t('common.address')} (Line 1)" value={model.address.line1} onChange={e=>setModel({...model, address:{...model.address, line1:e.target.value}})} />
    <Input label={t('common.city')} value={model.address.city} onChange={e=>setModel({...model, address:{...model.address, city:e.target.value}})} />
    <Input label="Country" value={model.address.country} onChange={e=>setModel({...model, address:{...model.address, country:e.target.value}})} />
    <Input label={`${t('common.area')} (m²)`} type="number" value={String(model.areaSqm ?? '')} onChange={e=>setModel({...model, areaSqm:Number(e.target.value)||undefined})} />
    <Input label={t('common.units')} type="number" value={String(model.units ?? '')} onChange={e=>setModel({...model, units:Number(e.target.value)||undefined})} />
    <Input label={t('common.year_built')} type="number" value={String(model.yearBuilt ?? '')} onChange={e=>setModel({...model, yearBuilt:Number(e.target.value)||undefined})} />
    <Input label={t('common.owner')} value={model.owner ?? ''} onChange={e=>setModel({...model, owner:e.target.value})} />
    <Input label={t('common.manager')} value={model.manager ?? ''} onChange={e=>setModel({...model, manager:e.target.value})} />
    <div className="md:col-span-2 flex items-center justify-end gap-3 mt-4">
      <Button variant="secondary" onClick={()=>history.back()}>{t('actions.cancel')}</Button>
      <Button onClick={save}>{t('actions.save')}</Button>
    </div>
  </div>
}
