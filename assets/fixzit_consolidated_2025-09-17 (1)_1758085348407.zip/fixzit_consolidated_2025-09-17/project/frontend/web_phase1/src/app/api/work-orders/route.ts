import { NextResponse } from 'next/server'
import data from '@/data/mock/workOrders.json'
import props from '@/data/mock/properties.json'
export async function GET(req:Request){
  const { searchParams }=new URL(req.url)
  const tenantId=searchParams.get('tenantId')||'t_fmz'; const propertyId=searchParams.get('propertyId')||''
  const items=(data as any[]).filter(w=>w.tenantId===tenantId).filter(w=>!propertyId||w.propertyId===propertyId).map(w=>({...w, property:(props as any[]).find(p=>p.id===w.propertyId)}))
  return NextResponse.json({ items })
}