import { clsx } from 'clsx'
export function StatusPill({status}:{status:string}){
  const map:Record<string,string>={Active:'bg-green-100/70 text-green-800',Inactive:'bg-gray-100/70 text-gray-800',UnderConstruction:'bg-yellow-100/70 text-yellow-800',Archived:'bg-red-100/70 text-red-800',Draft:'bg-gray-100/70 text-gray-800',Issued:'bg-blue-100/70 text-blue-800',Paid:'bg-green-100/70 text-green-800',Overdue:'bg-red-100/70 text-red-800'}
  return <span className={clsx('inline-flex rounded-xl px-2 py-0.5 text-xs font-medium', map[status]||'bg-gray-100/70 text-gray-800')}>{status}</span>
}