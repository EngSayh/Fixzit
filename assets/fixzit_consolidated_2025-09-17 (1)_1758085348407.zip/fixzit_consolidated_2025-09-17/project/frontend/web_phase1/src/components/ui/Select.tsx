'use client'
import { forwardRef } from 'react'; import { clsx } from 'clsx'
type Props=React.SelectHTMLAttributes<HTMLSelectElement>&{label?:string}
export const Select=forwardRef<HTMLSelectElement,Props>(function Select({label,className,id,children,...rest},ref){
  const inputId=id??`sel_${Math.random().toString(36).slice(2)}`
  return <div className="space-y-1">
    {label&&<label htmlFor={inputId} className="block text-sm font-medium">{label}</label>}
    <select id={inputId} ref={ref} className={clsx('block w-full rounded-xl border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 bg-white/70 dark:bg-gray-900/40 backdrop-blur',className)} {...rest}>{children}</select>
  </div>
})