import Image from 'next/image'
import Link from 'next/link'
import { LocaleSwitcher } from './LocaleSwitcher'
import { ThemeSwitcher } from './ThemeSwitcher'
import { TenantSwitcher } from './TenantSwitcher'
import { useI18n } from '@/lib/i18n'

export function AppHeader(){
  const { t } = useI18n()
  return (
    <header className="header-glass flex items-center justify-between border-b px-4 py-2 bg-white/40 dark:bg-gray-900/40">
      <div className="flex items-center gap-3">
        <Link href="/app/dashboard" className="flex items-center gap-2">
          <Image src="/logo.jpg" alt="Fixzit" width={28} height={28} className="rounded" />
          <span className="font-semibold">{t('app.name')}</span>
        </Link>
      </div>
      <div className="flex items-center gap-4">
        <TenantSwitcher />
        <LocaleSwitcher />
        <ThemeSwitcher />
      </div>
    </header>
  )
}
