import Link from 'next/link'
import { getSession } from '@/lib/auth'
import { canSee } from '@/lib/rbac'
import { useI18n } from '@/lib/i18n'
const nav=[
  { key:'dashboard', labelKey:'nav.dashboard', href:'/app/dashboard' },
  { key:'work_orders', labelKey:'nav.work_orders', href:'/app/work-orders' },
  { key:'properties', labelKey:'nav.properties', href:'/app/properties' },
  { key:'finance', labelKey:'nav.finance', href:'/app/finance/invoices' },
  { key:'hr', labelKey:'nav.hr', href:'/app/hr' },
  { key:'crm', labelKey:'nav.crm', href:'/app/crm' },
  { key:'support', labelKey:'nav.support', href:'/app/support' },
  { key:'souq', labelKey:'nav.souq', href:'/app/souq' },
]
export async function AppSidebar(){
  const session = await getSession()
  const role = session?.role ?? 'tenant'
  return (
    <aside className="sidebar-glass w-64 border-r bg-white/40 dark:bg-gray-900/40">
      <nav className="p-3 space-y-1">
        {/* @ts-expect-error Server/Client boundary for simplicity */}
        <SidebarItems role={role} />
      </nav>
    </aside>
  )
}
'use client'
function SidebarItems({ role }:{ role:any }){
  const { t } = useI18n()
  return <>{nav.filter(n=>canSee(n.key as any, role)).map(item=>(
    <Link key={item.href} href={item.href} className="block rounded-lg px-3 py-2 hover:bg-white/60 dark:hover:bg-gray-900/60">
      {t(item.labelKey)}
    </Link>
  ))}</>
}
