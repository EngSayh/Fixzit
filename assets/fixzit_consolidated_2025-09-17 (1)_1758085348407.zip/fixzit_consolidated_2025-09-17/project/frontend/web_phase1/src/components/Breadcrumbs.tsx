import Link from 'next/link'
export function Breadcrumbs({items}:{items:{href:string;label:string}[]}){
  return (
    <nav aria-label="Breadcrumb" className="text-sm mb-3">
      <ol className="flex gap-2">
        {items.map((it,idx)=> (
          <li key={idx} className="flex items-center gap-2">
            {idx>0 && <span>/</span>}
            <Link href={it.href} className="underline hover:no-underline">{it.label}</Link>
          </li>
        ))}
      </ol>
    </nav>
  )
}
