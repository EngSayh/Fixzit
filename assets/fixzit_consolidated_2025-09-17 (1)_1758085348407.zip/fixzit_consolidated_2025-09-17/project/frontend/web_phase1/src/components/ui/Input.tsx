'use client'
import { forwardRef } from 'react'; import { clsx } from 'clsx'
type Props=React.InputHTMLAttributes<HTMLInputElement>&{label?:string,error?:string}
export const Input=forwardRef<HTMLInputElement,Props>(function Input({label,error,className,id,...rest},ref){
  const inputId=id??`in_${Math.random().toString(36).slice(2)}`
  return <div className="space-y-1">
    {label&&<label htmlFor={inputId} className="block text-sm font-medium">{label}</label>}
    <input id={inputId} ref={ref} className={clsx('block w-full rounded-xl border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 bg-white/70 dark:bg-gray-900/40 backdrop-blur',className)} {...rest} aria-invalid={!!error} aria-describedby={error?inputId+'-error':undefined}/>
    {error&&<p id={inputId+'-error'} className="text-sm text-red-600">{error}</p>}
  </div>
})