'use client'
import { builtInTenants } from '@/lib/tenants'
import { useSearchParams, useRouter, usePathname } from 'next/navigation'
export function TenantSwitcher(){
  const sp=useSearchParams(); const router=useRouter(); const pathname=usePathname()
  const tenantId=sp.get('tenantId')||'t_fmz'
  function setTenant(id:string){ const params=new URLSearchParams(sp.toString()); params.set('tenantId',id); router.push(`${pathname}?${params.toString()}`); document.cookie=`tenantId=${id};path=/;max-age=31536000` }
  return <div className="flex items-center gap-2">
    <label className="text-sm" htmlFor="tenant">🏢</label>
    <select id="tenant" className="rounded-xl border-gray-300 text-sm dark:bg-gray-900/40 glass" value={tenantId} onChange={e=>setTenant(e.target.value)} aria-label="Tenant">
      {builtInTenants.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
    </select>
  </div>
}