'use client'
import { forwardRef } from 'react'
import { clsx } from 'clsx'
type Props=React.ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'primary'|'secondary'|'ghost',size?:'sm'|'md'|'lg'}
export const Button=forwardRef<HTMLButtonElement,Props>(function Button({className,variant='primary',size='md',...rest},ref){
  return <button ref={ref} className={clsx(
    'rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-brand-500',
    variant==='primary'&&'bg-brand-500 text-white hover:bg-brand-600 active:bg-brand-700 glass',
    variant==='secondary'&&'bg-white/60 text-gray-900 hover:bg-white/80 dark:bg-gray-900/40 dark:text-gray-100 dark:hover:bg-gray-900/60 border',
    variant==='ghost'&&'bg-transparent hover:bg-white/40 dark:hover:bg-gray-900/40',
    size==='sm'&&'px-3 py-1.5 text-sm', size==='md'&&'px-4 py-2', size==='lg'&&'px-5 py-3 text-lg', className)} {...rest}/> })