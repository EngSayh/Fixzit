'use client'
import { useI18n } from '@/lib/i18n'
export function LocaleSwitcher(){
  const { locale, setLocale } = useI18n() as any
  return <div className="flex items-center gap-2">
    <label className="text-sm" htmlFor="lang">🌐</label>
    <select id="lang" className="rounded-xl border-gray-300 text-sm dark:bg-gray-900/40 glass" value={locale} onChange={e=>setLocale(e.target.value as any)} aria-label="Language">
      <option value="en">EN</option><option value="ar">AR</option>
    </select>
  </div>
}