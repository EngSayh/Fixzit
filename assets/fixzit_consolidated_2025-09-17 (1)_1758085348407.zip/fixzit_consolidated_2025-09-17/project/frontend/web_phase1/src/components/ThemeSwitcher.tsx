'use client'
import { useEffect, useState } from 'react'
export function ThemeSwitcher(){
  const [mode,setMode]=useState<'light'|'dark'>(()=>document.documentElement.classList.contains('dark')?'dark':'light')
  useEffect(()=>{ const root=document.documentElement; mode==='dark'?root.classList.add('dark'):root.classList.remove('dark') },[mode])
  return <div className="flex items-center gap-2">
    <label htmlFor="theme" className="text-sm">🌓</label>
    <select id="theme" className="rounded-xl border-gray-300 text-sm dark:bg-gray-900/40 glass" value={mode} onChange={e=>setMode(e.target.value as any)} aria-label="Theme">
      <option value="light">Light</option><option value="dark">Dark</option>
    </select>
  </div>
}