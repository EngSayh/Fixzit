'use client'
import { Button } from './Button'
export function Pagination({page,pageCount,onPage}:{page:number;pageCount:number;onPage:(p:number)=>void}){
  return <div className="flex items-center justify-between mt-4">
    <Button variant="secondary" disabled={page<=1} onClick={()=>onPage(page-1)}>Prev</Button>
    <span className="text-sm">Page {page} of {pageCount}</span>
    <Button variant="secondary" disabled={page>=pageCount} onClick={()=>onPage(page+1)}>Next</Button>
  </div>
}