import type { Role } from './auth'
export function canSee(navKey:string, role:Role){
  const map:Record<string,Role[]>={
    dashboard:['admin','fm_manager','finance','technician','tenant'],
    properties:['admin','fm_manager','finance','technician'],
    work_orders:['admin','fm_manager','technician'],
    finance:['admin','finance'], invoices:['admin','finance'], hr:['admin'], admin:['admin'],
    crm:['admin','fm_manager','finance'], support:['admin','fm_manager','finance','technician','tenant'], souq:['admin','fm_manager','tenant']
  }
  return (map[navKey]??['admin']).includes(role)
}