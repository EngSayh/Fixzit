export type Role='admin'|'fm_manager'|'technician'|'finance'|'tenant'
export type UserSession={id:string;name:string;email:string;role:Role;tenantId?:string}
export async function getSession():Promise<UserSession|null>{ return {id:'u_1',name:'Demo Admin',email:'admin@fixzit.local',role:'admin',tenantId:'t_fmz'} }