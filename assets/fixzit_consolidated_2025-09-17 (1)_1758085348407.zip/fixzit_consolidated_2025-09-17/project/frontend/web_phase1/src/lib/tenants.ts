export type Tenant={id:string;name:string}
export const builtInTenants:Tenant[]=[{id:'t_fmz',name:'FMZ Holding'},{id:'t_acme',name:'ACME Real Estate'},{id:'t_green',name:'Green Energy Campus'}]