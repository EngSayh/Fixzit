import { z } from 'zod'
export const propertySchema=z.object({
  id:z.string().optional(), tenantId:z.string(), code:z.string().min(2).max(16), name:z.string().min(2),
  type:z.enum(['Residential','Commercial','Industrial','MixedUse','Facility']),
  status:z.enum(['Active','Inactive','UnderConstruction','Archived']).default('Active'),
  address:z.object({ line1:z.string(), city:z.string(), country:z.string().default('SA'), lat:z.number().optional().nullable(), lng:z.number().optional().nullable() }),
  areaSqm:z.number().nonnegative().optional(), floors:z.number().int().nonnegative().optional(), units:z.number().int().nonnegative().optional(),
  yearBuilt:z.number().int().min(1900).max(new Date().getFullYear()).optional(), owner:z.string().optional(), manager:z.string().optional(),
  serviceLevel:z.enum(['Basic','Standard','Premium']).default('Standard'),
  compliance:z.array(z.object({ type:z.string(), id:z.string(), expiry:z.string().optional() })).optional(),
  attachments:z.array(z.object({ name:z.string(), url:z.string().url() })).optional()
})
export type PropertyInput = z.infer<typeof propertySchema>