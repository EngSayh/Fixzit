'use client'
import { createContext, useContext, useMemo, useState, useEffect } from 'react'
import en from './dictionaries/en.json'
import ar from './dictionaries/ar.json'
type Dict = Record<string, string | Record<string,string>>
type Locale = 'en'|'ar'
const dictionaries: Record<Locale, Dict> = { en, ar }
function format(template: string, params?: Record<string, any>){
  if(!params) return template
  return template.replace(/\{(\w+)\}/g, (_,k) => params[k] ?? '')
}
const Ctx = createContext<{locale:Locale;setLocale:(l:Locale)=>void;t:(key:string,params?:Record<string,any>)=>string}|null>(null)
export function I18nProvider({ initialLocale='en', children }:{initialLocale?:Locale, children:React.ReactNode}){
  const [locale,setLocale] = useState<Locale>(initialLocale)
  useEffect(()=>{
    document.cookie = `locale=${locale};path=/;max-age=31536000`
    document.documentElement.lang = locale
    document.documentElement.dir = locale==='ar'?'rtl':'ltr'
  },[locale])
  const t = (key:string, params?:Record<string,any>) => {
    const dict = dictionaries[locale] as any
    const value = key.split('.').reduce((acc:any, k)=>acc?.[k], dict)
    if(typeof value === 'string') return format(value, params)
    const fallback = key.split('.').reduce((acc:any,k)=>acc?.[k], dictionaries['en'] as any)
    return typeof fallback === 'string' ? format(fallback, params) : key
  }
  const value = useMemo(()=>({locale,setLocale,t}),[locale])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
export function useI18n(){
  const ctx = useContext(Ctx)
  if(!ctx) throw new Error('useI18n must be used inside I18nProvider')
  return ctx
}
