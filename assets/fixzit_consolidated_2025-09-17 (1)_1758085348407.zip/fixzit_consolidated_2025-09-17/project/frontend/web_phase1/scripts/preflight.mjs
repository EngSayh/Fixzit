import fs from 'node:fs'
import path from 'node:path'
const root = process.cwd()
const binNext = path.join(root, 'node_modules', '.bin', process.platform === 'win32' ? 'next.cmd' : 'next')
const pss = path.join(root, 'node_modules', 'postcss-selector-parser', 'dist', 'index.js')
let ok = true
function exists(p){ try { fs.accessSync(p, fs.constants.F_OK); return true } catch { return false } }
if(!exists(binNext)){ console.error('❌ Next.js binary missing:', binNext); ok = false } else { console.log('✅ Next.js binary found:', binNext) }
if(!exists(pss)){ console.error('❌ postcss-selector-parser/dist/index.js missing. Run `npm i` and ensure overrides are applied.'); ok = false } else { console.log('✅ postcss-selector-parser/dist/index.js present') }
if(!ok){ process.exitCode = 1; console.error('\nRun: npm i') }
