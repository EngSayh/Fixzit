#!/usr/bin/env bash
set -euo pipefail
find . -path "*/node_modules/*" -prune -o -type d   \( -name ".next" -o -name "build" -o -name "out" -o -name ".turbo" -o -name ".vercel" -o -name "coverage" \)   -exec rm -rf {} +
echo "✅ Safe clean completed (node_modules/**/dist preserved)"
