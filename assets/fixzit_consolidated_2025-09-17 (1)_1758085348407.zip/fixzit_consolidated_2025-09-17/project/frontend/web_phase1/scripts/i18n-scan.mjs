import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(process.cwd(), 'src')
const re = /\bt\(['"`]([^'"`]+)['"`]/g
const keys = new Set()
function walk(dir){ for(const f of fs.readdirSync(dir)){ const p=path.join(dir,f); const s=fs.statSync(p); if(s.isDirectory()) walk(p); else if(/\.(tsx?|jsx?)$/.test(f)){ const txt=fs.readFileSync(p,'utf8'); let m; while((m=re.exec(txt))) keys.add(m[1]) } } }
walk(root)
console.log([...keys].sort().join('\n'))
