import type { Config } from 'tailwindcss'
const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  darkMode: ['class'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: 'var(--brand-50)',100: 'var(--brand-100)',200: 'var(--brand-200)',
          300: 'var(--brand-300)',400: 'var(--brand-400)',500: 'var(--brand-500)',
          600: 'var(--brand-600)',700: 'var(--brand-700)',800: 'var(--brand-800)',900: 'var(--brand-900)',
        }
      },
      borderRadius: { 'xl':'var(--radius-xl)' },
      boxShadow: { glass: '0 10px 30px rgba(0,0,0,0.12)' }
    }
  },
  plugins: [require('@tailwindcss/forms')],
}
export default config
