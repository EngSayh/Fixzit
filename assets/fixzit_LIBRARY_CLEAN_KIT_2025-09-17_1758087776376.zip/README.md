# Fixzit Library Clean Kit — Non‑Destructive (DRY‑RUN by default)

**Purpose:** Tidy the *existing* library tree by moving obvious clutter into **existing** folders only.
- ✅ **NO new top‑level categories** are created.
- ✅ **DRY‑RUN** prints what *would* happen. Set `APPLY=1` to actually move.
- ✅ **Skips** any rule if target folder does not already exist.
- ✅ Uses **git mv** if `.git/` exists (preserves history), otherwise plain `mv -vn`.

## Quick use

```bash
# 1) Place these files at repo root
unzip fixzit_LIBRARY_CLEAN_KIT_2025-09-17.zip -d .

# 2) Preview (DRY‑RUN, no changes)
bash ./library_clean_dryrun.sh

# 3) Apply (only after you review the printed plan)
APPLY=1 bash ./library_clean_dryrun.sh
```

## What it cleans (only if target folder already exists)

- **Reports**: `audit*`, `COMPREHENSIVE_AUDIT*`, `final-security*`, `final_*`, `*_REPORT*`, `*verification*.*` → `./reports/`
- **Verification scripts**: `verify*.*`, `verification_*.*`, `VERIFY_*` → `./reports/` (no new subfolders)
- **Tools/tests**: `test_*.*`, `*_checker*.*`, `*_scanner*.*`, `usage_logger.py`, `analyzer-*.js` → `./tools/` (or stays if ./tools missing)
- **Backups**: `*.bak`, `*.bakup`, `backup_*` → `./ARCHIVE_DUPLICATES/` (only if it exists)
- **Next.js legacy routes**: if **both** `./pages/` and `./src/app/` exist → move entire `./pages/` to `./ARCHIVE_DUPLICATES/legacy_pages_20250917/`
- **Styles**: if **both** `./styles/` and `./src/styles/` exist → move files from `./styles/` into `./src/styles/`
- **UI dup**: if **both** `./ui/` and `./src/components/ui/` exist → move files from `./ui/` into `./src/components/ui/`
- **Assets**: if **both** `./attached_assets/` and `./assets/` exist → move files from `./attached_assets/` to `./assets/`

> The script never creates missing targets; it simply **skips** those actions to avoid scattering.

## Undo

All moves are tracked by git if present (via `git mv`). Otherwise, use your VCS or backups to revert.
