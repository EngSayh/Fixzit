#!/usr/bin/env bash
set -euo pipefail

DRY="${APPLY:-}"
IS_DRY=1
if [[ "${DRY:-}" == "1" ]]; then IS_DRY=0; fi

root="$(pwd)"
use_git=0
if [[ -d ".git" ]]; then use_git=1; fi

move() {
  src="$1"
  dst="$2"
  if [[ ! -e "$src" ]]; then
    echo "skip (missing src): $src"
    return
  fi
  if [[ ! -d "$dst" ]]; then
    echo "skip (missing target): $dst  ← not creating new categories"
    return
  fi
  if [[ $IS_DRY -eq 1 ]]; then
    echo "DRY: mv '$src' -> '$dst/'"
    return
  fi
  if [[ $use_git -eq 1 ]]; then
    git mv -k -v "$src" "$dst/" 2>/dev/null || mv -vn "$src" "$dst/"
  else
    mv -vn "$src" "$dst/"
  fi
}

move_glob_into() {
  pattern="$1"
  target="$2"
  shopt -s nullglob
  for f in $pattern; do
    # only move regular files at root level
    if [[ -f "$f" ]]; then
      move "$f" "$target"
    fi
  done
  shopt -u nullglob
}

echo "== Fixzit Library Clean (safe) =="
echo "Repo: $root"
echo "Mode: $([[ $IS_DRY -eq 1 ]] && echo DRY-RUN || echo APPLY)  (export APPLY=1 to apply)"
echo "---"

# 1) Reports and verification into existing ./reports
if [[ -d "./reports" ]]; then
  move_glob_into "audit*" "./reports"
  move_glob_into "COMPREHENSIVE_AUDIT*" "./reports"
  move_glob_into "final-security*" "./reports"
  move_glob_into "final_*" "./reports"
  move_glob_into "*_REPORT*" "./reports"
  move_glob_into "*verification*.*" "./reports"
  move_glob_into "verify*.*" "./reports"
  move_glob_into "VERIFY_*" "./reports"
fi

# 2) Tools/tests into existing ./tools
if [[ -d "./tools" ]]; then
  move_glob_into "test_*.*" "./tools"
  move_glob_into "*_checker*.*" "./tools"
  move_glob_into "*_scanner*.*" "./tools"
  move_glob_into "usage_logger.py" "./tools"
  move_glob_into "analyzer-*.js" "./tools"
fi

# 3) Backups into existing ARCHIVE_DUPLICATES
if [[ -d "./ARCHIVE_DUPLICATES" ]]; then
  move_glob_into "*.bak" "./ARCHIVE_DUPLICATES"
  move_glob_into "*.bakup" "./ARCHIVE_DUPLICATES"
  move_glob_into "backup_*" "./ARCHIVE_DUPLICATES"
fi

# 4) Legacy Next.js 'pages' (only if app router present)
if [[ -d "./pages" && -d "./src/app" && -d "./ARCHIVE_DUPLICATES" ]]; then
  ts="$(date +%Y%m%d)"
  legacy="./ARCHIVE_DUPLICATES/legacy_pages_${ts}"
  if [[ -d "$legacy" ]]; then
    echo "skip (target exists): $legacy"
  else
    if [[ $IS_DRY -eq 1 ]]; then
      echo "DRY: mv 'pages/' -> '$legacy/'"
    else
      mkdir -p "$legacy"
      if [[ $use_git -eq 1 ]]; then
        git mv pages "$legacy" || mv -vn pages "$legacy/"
      else
        mv -vn pages "$legacy/"
      fi
    fi
  fi
fi

# 5) styles -> src/styles (only if both exist)
if [[ -d "./styles" && -d "./src/styles" ]]; then
  shopt -s nullglob
  for f in styles/*; do
    [[ -f "$f" ]] && move "$f" "./src/styles"
  done
  shopt -u nullglob
fi

# 6) ui -> src/components/ui (only if both exist)
if [[ -d "./ui" && -d "./src/components/ui" ]]; then
  shopt -s nullglob
  for f in ui/*; do
    [[ -f "$f" ]] && move "$f" "./src/components/ui"
  done
  shopt -u nullglob
fi

# 7) attached_assets -> assets (only if both exist)
if [[ -d "./attached_assets" && -d "./assets" ]]; then
  shopt -s nullglob
  for f in attached_assets/*; do
    move "$f" "./assets"
  done
  shopt -u nullglob
fi

echo "---"
echo "Done. Review the log above. Re-run with APPLY=1 to execute moves."
