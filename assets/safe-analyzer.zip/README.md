# Fixzit SAFE Analyzer (Non-Destructive)

**Goal:** Identify **duplicate files**, **what is taking space**, and **where**, without changing your repo or scattering new folders.

- ✅ **No code changes**
- ✅ **No new duplicate folders**
- ✅ **Single output directory**: `.fixzit-reports` (hidden) or a custom path you pass
- ✅ Works on very large repos (uses streaming + hashing)

## Quick Start

```bash
# From your repo root
python3 tools/analyze.py --root .

# Or choose a custom output path
python3 tools/analyze.py --root . --out ./_reports_once

# Windows PowerShell
pwsh ./tools/analyze.ps1 -Root . -OutDir ./.fixzit-reports
```

## What you get (in the output folder)

- `file_inventory.csv` — path, size, sha256, extension, category
- `duplicates_by_hash.csv` — one row per duplicate group (hash, total_count, total_bytes)
- `duplicates_detail.csv` — each duplicate file instance with a **recommended_keep** path
- `duplicates_by_name.csv` — same-name collisions with different content
- `large_files.csv` — top 500 largest files (path, size)
- `large_dirs_*.csv` — directory sizes (depth 1..3), sorted desc
- `extensions.csv` — size by extension
- `assets_images.csv` — large image/video assets (png/jpg/webp/avif/mp4/mov etc.)
- `delete_candidates.sh` — **dry-run** shell script printing deletions for *only* safe duplicates (you review before running; it defaults to echo)
- `HEAVY_GIT.md` — how to locate large git objects safely (history bloat)

## Safety Notes

- The analyzer **never** deletes files.
- It ignores transient/build paths by default:
  `.git/ node_modules/ .next/ dist/ build/ out/ .turbo/ .vercel/ coverage/ .cache/`
- You can add more excludes with `--exclude` (repeatable).

## Why this avoids the previous mess

- It **does not** create new top-level project folders (frontend/, backend/, etc.).
- It writes **only** under the chosen output path (default: `.fixzit-reports`).

