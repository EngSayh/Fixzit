param(
  [string]$Root=".",
  [string]$OutDir=".fixzit-reports"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
python3 "$here/analyze.py" --root $Root --out $OutDir
