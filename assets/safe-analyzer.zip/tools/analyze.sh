#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
OUT="${2:-.fixzit-reports}"
python3 "$(dirname "$0")/analyze.py" --root "$ROOT" --out "$OUT"
