# nav_config.py
# One source of truth for Fixzit navigation.
# Map each module / sub-module to an actual Streamlit page under /pages.
# If a file is missing, the sidebar will warn you at runtime.

NAV = [
    {
        "group": "Operations",
        "icon": "🧭",
        "items": [
            {
                "id": "dashboard",
                "label": "Dashboard",
                "icon": "🏠",
                "page": "pages/01_Dashboard_WorkOS.py",
            },
            {
                "id": "work_orders",
                "label": "Work Orders",
                "icon": "🛠️",
                "children": [
                    {
                        "id": "wo_all",
                        "label": "All Orders",
                        "icon": "📋",
                        "page": "pages/02_Boards_WorkOS.py",
                    },
                    {
                        "id": "wo_tickets",
                        "label": "Tickets",
                        "icon": "🎫",
                        "page": "pages/07_Tickets_WorkOS.py",
                    },
                    {
                        "id": "wo_schedule",
                        "label": "Scheduling",
                        "icon": "🗓️",
                        "page": "pages/03_Automations_WorkOS.py",
                    },
                ],
            },
            {
                "id": "properties",
                "label": "Properties & Units",
                "icon": "🏢",
                "children": [
                    {
                        "id": "prop_list",
                        "label": "All Properties",
                        "icon": "📂",
                        "page": "pages/05_Properties_WorkOS.py",
                    },
                    {
                        "id": "prop_units",
                        "label": "Properties (Legacy)",
                        "icon": "🏘️",
                        "page": "pages/2_Properties.py",
                    },
                    {
                        "id": "prop_contracts",
                        "label": "Contracts",
                        "icon": "📃",
                        "page": "pages/06_Contracts_WorkOS.py",
                    },
                ],
            },
            {
                "id": "crm",
                "label": "CRM",
                "icon": "👥",
                "children": [
                    {
                        "id": "tenants",
                        "label": "Users",
                        "icon": "🧑‍💼",
                        "page": "pages/09_Users_WorkOS.py",
                    },
                    {
                        "id": "owners",
                        "label": "Owners Directory",
                        "icon": "🏷️",
                        "page": "pages/134_OwnersDirectory.py",
                    },
                    {
                        "id": "owner_statements",
                        "label": "Owner Statements",
                        "icon": "📈",
                        "page": "pages/133_OwnerStatements.py",
                    },
                    {
                        "id": "team",
                        "label": "Team Directory",
                        "icon": "🧑‍🔧",
                        "page": "pages/137_TeamDirectory.py",
                    },
                ],
            },
        ],
    },
    {
        "group": "Finance",
        "icon": "💼",
        "items": [
            {
                "id": "billing",
                "label": "Billing",
                "icon": "🧾",
                "children": [
                    {
                        "id": "payments",
                        "label": "Payments",
                        "icon": "💳",
                        "page": "pages/08_Payments_WorkOS.py",
                    },
                    {
                        "id": "financials",
                        "label": "Financials",
                        "icon": "📊",
                        "page": "pages/7_Financials.py",
                    },
                    {
                        "id": "statements",
                        "label": "Statements",
                        "icon": "📝",
                        "page": "pages/133_OwnerStatements.py",
                    },
                ],
            },
            {
                "id": "reports",
                "label": "Reports",
                "icon": "📊",
                "page": "pages/Reports.py",
            },
            {
                "id": "analytics",
                "label": "Analytics",
                "icon": "📈",
                "page": "pages/11_Analytics_WorkOS.py",
            },
        ],
    },
    {
        "group": "Account",
        "icon": "👤",
        "items": [
            {
                "id": "my_profile",
                "label": "My Profile",
                "icon": "👤",
                "page": "pages/130_MyProfile.py",
                "description": "View profile and track feedback tickets",
            },
        ],
    },
    {
        "group": "Communication",
        "icon": "💬",
        "items": [
            {
                "id": "support",
                "label": "Support",
                "icon": "🎧",
                "children": [
                    {
                        "id": "tickets",
                        "label": "Support Tickets",
                        "icon": "🎫",
                        "page": "pages/129_SupportTickets.py",
                    },
                    {
                        "id": "ticket_detail",
                        "label": "Ticket Detail",
                        "icon": "📋",
                        "page": "pages/130_TicketDetail.py",
                    },
                    {
                        "id": "support_analytics",
                        "label": "Support Analytics",
                        "icon": "📊",
                        "page": "pages/132_SupportAnalytics.py",
                    },
                ],
            },
            {
                "id": "notifications",
                "label": "Notifications",
                "icon": "🔔",
                "children": [
                    {
                        "id": "email_config",
                        "label": "Email Configuration",
                        "icon": "📧",
                        "page": "pages/131_EmailConfiguration.py",
                    },
                    {
                        "id": "email_templates",
                        "label": "Email Templates",
                        "icon": "📝",
                        "page": "pages/135_EmailTemplates.py",
                    },
                    {
                        "id": "notifications_admin",
                        "label": "Notifications Admin",
                        "icon": "⚙️",
                        "page": "pages/NotificationsAdmin.py",
                    },
                ],
            },
            {
                "id": "updates",
                "label": "Update Feed",
                "icon": "📰",
                "page": "pages/127_UpdateFeed.py",
            },
            {
                "id": "feedback",
                "label": "Feedback Analytics",
                "icon": "💭",
                "page": "pages/128_FeedbackAnalytics.py",
            },
        ],
    },
    {
        "group": "Free Services",
        "icon": "🎁",
        "items": [
            {
                "id": "fixzit_souq",
                "label": "FixzitSouq Marketplace",
                "icon": "🛒",
                "page": "pages/60_FixzitSouq.py",
            },
        ],
    },
    {
        "group": "Platform",
        "icon": "⚙️",
        "items": [
            {
                "id": "auth",
                "label": "Authentication",
                "icon": "🔐",
                "children": [
                    {
                        "id": "login",
                        "label": "Login",
                        "icon": "🔑",
                        "page": "pages/00_Login.py",
                    },
                    {
                        "id": "signup",
                        "label": "Sign Up",
                        "icon": "✍️",
                        "page": "pages/001_SignUp.py",
                    },
                    {
                        "id": "register",
                        "label": "Register",
                        "icon": "📝",
                        "page": "pages/Register.py",
                    },
                    {
                        "id": "reset_password",
                        "label": "Reset Password",
                        "icon": "🔄",
                        "page": "pages/Reset_Password.py",
                    },
                    {
                        "id": "passwordless",
                        "label": "Passwordless Login",
                        "icon": "✨",
                        "page": "pages/PasswordlessLogin.py",
                    },
                ],
            },
            {
                "id": "settings",
                "label": "Settings",
                "icon": "🧩",
                "page": "pages/10_Settings_WorkOS.py",
            },
            {
                "id": "workspace",
                "label": "Workspace Settings",
                "icon": "🏢",
                "page": "pages/12_Workspace_Settings.py",
            },
            {
                "id": "onboarding",
                "label": "Onboarding",
                "icon": "🚀",
                "page": "pages/50_Onboarding_WorkOS.py",
            },
            {
                "id": "marketplace",
                "label": "App Marketplace",
                "icon": "🛍️",
                "page": "pages/46_App_Marketplace.py",
            },
        ],
    },
    {
        "group": "Administration",
        "icon": "🛡️",
        "items": [
            {
                "id": "system",
                "label": "System",
                "icon": "💻",
                "children": [
                    {
                        "id": "verification",
                        "label": "System Verification",
                        "icon": "✅",
                        "page": "pages/900_SystemVerification.py",
                    },
                    {
                        "id": "health",
                        "label": "Health Dashboard",
                        "icon": "❤️",
                        "page": "pages/955_HealthDashboard.py",
                    },
                    {
                        "id": "uptime",
                        "label": "Uptime Monitoring",
                        "icon": "📡",
                        "page": "pages/956_UptimeMonitoring.py",
                    },
                    {
                        "id": "code_quality",
                        "label": "Code Quality",
                        "icon": "🔍",
                        "page": "pages/999_CodeQuality.py",
                    },
                ],
            },
            {
                "id": "features",
                "label": "Features",
                "icon": "🎛️",
                "children": [
                    {
                        "id": "feature_flags",
                        "label": "Feature Flags",
                        "icon": "🚦",
                        "page": "pages/998_FeatureFlags.py",
                    },
                    {
                        "id": "remote_config",
                        "label": "Remote Config",
                        "icon": "📡",
                        "page": "pages/997_RemoteConfig.py",
                    },
                    {
                        "id": "module_manager",
                        "label": "Module Manager",
                        "icon": "📦",
                        "page": "pages/996_ModuleManager.py",
                    },
                    {
                        "id": "logo_manager",
                        "label": "Logo Manager",
                        "icon": "🎨",
                        "page": "pages/995_LogoManager.py",
                    },
                ],
            },
            {
                "id": "sharing",
                "label": "Share Management",
                "icon": "🔗",
                "children": [
                    {
                        "id": "share_mgmt",
                        "label": "Share Management",
                        "icon": "🔗",
                        "page": "pages/142_ShareManagement.py",
                    },
                    {
                        "id": "share_policy",
                        "label": "Share Policy",
                        "icon": "📋",
                        "page": "pages/144_SharePolicySettings.py",
                    },
                    {
                        "id": "share_moderation",
                        "label": "Moderation Queue",
                        "icon": "👁️",
                        "page": "pages/145_ShareModerationQueue.py",
                    },
                    {
                        "id": "share_audit",
                        "label": "Audit Logs",
                        "icon": "📜",
                        "page": "pages/146_ShareAuditLogs.py",
                    },
                    {
                        "id": "share_verify",
                        "label": "Secure Verify",
                        "icon": "🔒",
                        "page": "pages/147_SecureShareVerify.py",
                    },
                ],
            },
        ],
    },
]

# Which group is open on first load
DEFAULT_OPEN_GROUP = "Operations"

# Default landing route id
DEFAULT_ROUTE = "dashboard"
