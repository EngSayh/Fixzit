"""
Test all pages in the application to check for errors
"""

from pathlib import Path
import glob

# Get all page files
pages_dir = Path("pages")
page_files = sorted(glob.glob(str(pages_dir / "*.py")))

print(f"Found {len(page_files)} pages to test\n")
print("=" * 60)

errors = []
successful = []

for page_file in page_files:
    page_name = Path(page_file).name
    print(f"Testing: {page_name}")

    try:
        # Try to import the page
        with open(page_file, "r") as f:
            content = f.read()

        # Check for basic syntax by compiling
        compile(content, page_file, "exec")

        # Check for common issues
        if "st.set_page_config" not in content:
            print("  ⚠️  Warning: No page config found")

        if "initialize_session_state()" not in content:
            print("  ⚠️  Warning: Session state not initialized")

        if "st.switch_page" not in content and page_name != "00_Login.py":
            print("  ℹ️  Info: No navigation found")

        successful.append(page_name)
        print("  ✅ OK")

    except SyntaxError as e:
        errors.append((page_name, f"Syntax error: {e}"))
        print(f"  ❌ Syntax error: {e}")
    except Exception as e:
        errors.append((page_name, str(e)))
        print(f"  ❌ Error: {e}")

    print()

print("=" * 60)
print("\nSummary:")
print(f"  ✅ Successful: {len(successful)} pages")
print(f"  ❌ Errors: {len(errors)} pages")

if errors:
    print("\nPages with errors:")
    for page, error in errors:
        print(f"  - {page}: {error}")
else:
    print("\n🎉 All pages passed basic validation!")

# Test key imports
print("\n" + "=" * 60)
print("Testing key imports:")

test_imports = [
    "from auth.multi_auth import MultiAuthManager",
    "from utils.session_init import initialize_session_state",
    "from utils.database import get_db_connection",
    "from database.init_db import initialize_database",
    "from services.automations_engine import automation_engine",
]

for import_stmt in test_imports:
    try:
        exec(import_stmt)
        print(f"  ✅ {import_stmt}")
    except Exception as e:
        print(f"  ❌ {import_stmt}: {e}")

print("\n✅ Test complete!")
