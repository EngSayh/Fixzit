// FIXZIT SOUQ Implementation Scanner - Complete Audit System
// This scanner checks EVERY element, button, and behavior against chat requirements

const fs = require('fs');
const path = require('path');

class FixzitImplementationScanner {
  constructor(projectPath) {
    this.projectPath = projectPath;
    this.requiredElements = this.loadRequirements();
    this.scanResults = {
      timestamp: new Date().toISOString(),
      totalChecks: 0,
      passed: 0,
      failed: 0,
      warnings: 0,
      notFound: 0,
      details: [],
      coverage: 0
    };
  }

  // Load all requirements from chat history
  loadRequirements() {
    const requirements = new Map();

    // LANDING PAGE REQUIREMENTS
    requirements.set('landing', [
      {
        id: 'LP001',
        category: 'Landing Page',
        element: 'Header gradient background',
        expected: 'background: linear-gradient(135deg, #0078D4 0%, #00BCF2 100%)',
        selector: '.landing-header',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP002',
        category: 'Landing Page',
        element: 'Yellow Arabic button',
        expected: 'الشاملة للاستشارات العقارية',
        selector: '.btn-arabic',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP003',
        category: 'Landing Page',
        element: 'White Souq button',
        expected: 'Fixzit Souq',
        selector: '.btn-souq',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP004',
        category: 'Landing Page',
        element: 'Green Access button',
        expected: 'Access Fixzit',
        selector: '.btn-access',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP005',
        category: 'Landing Page',
        element: 'Flip dropdown animation',
        expected: 'transform,transition',
        selector: '.dropdown-content',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP006',
        category: 'Landing Page',
        element: 'Enterprise Features section',
        expected: 'enterprise-card',
        selector: '.enterprise-card',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'LP007',
        category: 'Landing Page',
        element: 'Footer version',
        expected: 'v2.0.26',
        selector: '.footer-version',
        file: 'public/index.html',
        severity: 'low'
      }
    ]);

    // SIDEBAR REQUIREMENTS (13 MODULES)
    requirements.set('sidebar', [
      {
        id: 'SB001',
        category: 'Sidebar',
        element: 'Monday.com style sidebar',
        expected: 'sidebar,collapsible',
        selector: '.sidebar',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB002',
        category: 'Sidebar',
        element: 'Collapsed by default',
        expected: 'collapsed',
        selector: '.sidebar.collapsed',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'SB003',
        category: 'Sidebar',
        element: 'Dashboard module',
        expected: 'dashboard',
        selector: '[data-module="dashboard"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB004',
        category: 'Sidebar',
        element: 'Work Orders module',
        expected: 'work-orders',
        selector: '[data-module="work-orders"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB005',
        category: 'Sidebar',
        element: 'Properties module',
        expected: 'properties',
        selector: '[data-module="properties"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB006',
        category: 'Sidebar',
        element: 'Finance module',
        expected: 'finance',
        selector: '[data-module="finance"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB007',
        category: 'Sidebar',
        element: 'Human Resources module',
        expected: 'hr',
        selector: '[data-module="hr"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB008',
        category: 'Sidebar',
        element: 'Administration module',
        expected: 'admin',
        selector: '[data-module="admin"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB009',
        category: 'Sidebar',
        element: 'CRM module',
        expected: 'crm',
        selector: '[data-module="crm"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB010',
        category: 'Sidebar',
        element: 'Marketplace module',
        expected: 'marketplace',
        selector: '[data-module="marketplace"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB011',
        category: 'Sidebar',
        element: 'Support module',
        expected: 'support',
        selector: '[data-module="support"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB012',
        category: 'Sidebar',
        element: 'Compliance & Legal module',
        expected: 'compliance',
        selector: '[data-module="compliance"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB013',
        category: 'Sidebar',
        element: 'Reports & Analytics module',
        expected: 'reports',
        selector: '[data-module="reports"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB014',
        category: 'Sidebar',
        element: 'System Management module',
        expected: 'system',
        selector: '[data-module="system"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB015',
        category: 'Sidebar',
        element: 'Preventive Maintenance module',
        expected: 'preventive',
        selector: '[data-module="preventive"]',
        file: 'public/index.html',
        severity: 'high'
      }
    ]);

    // TOPBAR DYNAMIC TABS
    requirements.set('topbar', [
      {
        id: 'TB001',
        category: 'Topbar',
        element: 'Topbar height 60px',
        expected: 'height: 60px',
        selector: '.topbar',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'TB002',
        category: 'Topbar',
        element: 'Blue background #0061A8',
        expected: '#0061A8',
        selector: '.topbar',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'TB003',
        category: 'Topbar',
        element: 'Global search',
        expected: 'global-search',
        selector: '.global-search',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB004',
        category: 'Topbar',
        element: 'Quick create button',
        expected: 'quick-create',
        selector: '.quick-create',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB005',
        category: 'Topbar',
        element: 'Notification bell',
        expected: 'notification-bell',
        selector: '.notification-bell',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB006',
        category: 'Topbar',
        element: 'User avatar dropdown',
        expected: 'user-avatar',
        selector: '.user-avatar',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB007',
        category: 'Topbar',
        element: 'Language toggle EN/عربي',
        expected: 'lang-toggle,EN,عربي',
        selector: '.lang-toggle',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB008',
        category: 'Topbar',
        element: 'Dashboard dynamic tabs',
        expected: 'Overview,My Work,Alerts,Calendar,Reports',
        selector: '.topbar-tabs[data-module="dashboard"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB009',
        category: 'Topbar',
        element: 'Work Orders dynamic tabs',
        expected: 'All Orders,By Status,Calendar View,PM Schedule',
        selector: '.topbar-tabs[data-module="work-orders"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB010',
        category: 'Topbar',
        element: 'Properties dynamic tabs',
        expected: 'All Properties,Units & Tenants,Leases,Inspections',
        selector: '.topbar-tabs[data-module="properties"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB011',
        category: 'Topbar',
        element: 'Finance dynamic tabs',
        expected: 'Invoices,Payments,ZATCA,Budget,Reports',
        selector: '.topbar-tabs[data-module="finance"]',
        file: 'public/index.html',
        severity: 'high'
      }
    ]);

    // API ROUTES CHECK
    requirements.set('api', [
      {
        id: 'API001',
        category: 'API Routes',
        element: 'Auth routes',
        expected: 'login,register,logout,authenticate',
        file: 'routes/auth.js',
        severity: 'high'
      },
      {
        id: 'API002',
        category: 'API Routes',
        element: 'Dashboard routes',
        expected: 'dashboard,kpi,metrics,stats',
        file: 'routes/dashboard.js',
        severity: 'high'
      },
      {
        id: 'API003',
        category: 'API Routes',
        element: 'Marketplace routes',
        expected: 'marketplace,vendor,rfq,products',
        file: 'routes/marketplace.js',
        severity: 'high'
      },
      {
        id: 'API004',
        category: 'API Routes',
        element: 'Finance routes',
        expected: 'invoice,payment,zatca,budget',
        file: 'routes/finance.js',
        severity: 'high'
      },
      {
        id: 'API005',
        category: 'API Routes',
        element: 'Properties routes',
        expected: 'properties,units,tenants,lease',
        file: 'routes/properties.js',
        severity: 'high'
      },
      {
        id: 'API006',
        category: 'API Routes',
        element: 'Work Orders routes',
        expected: 'workorder,maintenance,task,schedule',
        file: 'routes/workorders.js',
        severity: 'high'
      }
    ]);

    // WORKFLOWS AND SYSTEM
    requirements.set('system', [
      {
        id: 'SYS001',
        category: 'System',
        element: 'Server running on port 5000',
        expected: '5000,PORT',
        file: 'server.js',
        severity: 'high'
      },
      {
        id: 'SYS002',
        category: 'System',
        element: 'Frontend serving',
        expected: '3000,frontend,serve',
        file: 'serve-frontend.js',
        severity: 'high'
      },
      {
        id: 'SYS003',
        category: 'System',
        element: 'Database configuration',
        expected: 'database,connection,config',
        file: 'config/database.js',
        severity: 'high'
      },
      {
        id: 'SYS004',
        category: 'System',
        element: 'Package.json dependencies',
        expected: 'express,cors,bcryptjs,jsonwebtoken',
        file: 'package.json',
        severity: 'medium'
      }
    ]);

    return requirements;
  }

  // Simple regex-based HTML parsing
  parseHTML(content) {
    const elements = [];
    
    // Find elements with classes
    const classMatches = content.match(/class\s*=\s*["']([^"']+)["']/g);
    if (classMatches) {
      classMatches.forEach(match => {
        const classes = match.match(/["']([^"']+)["']/)[1].split(' ');
        classes.forEach(cls => {
          elements.push({ type: 'class', name: cls });
        });
      });
    }
    
    // Find elements with data attributes
    const dataMatches = content.match(/data-[a-zA-Z0-9-]+\s*=\s*["']([^"']+)["']/g);
    if (dataMatches) {
      dataMatches.forEach(match => {
        const attr = match.match(/data-([a-zA-Z0-9-]+)\s*=\s*["']([^"']+)["']/);
        if (attr) {
          elements.push({ type: 'data', name: attr[1], value: attr[2] });
        }
      });
    }
    
    return elements;
  }

  // Check file for requirements
  async scanFile(filePath, checks) {
    const results = [];
    
    try {
      const fullPath = path.join(this.projectPath, filePath);
      
      if (!fs.existsSync(fullPath)) {
        checks.forEach(check => {
          results.push({
            ...check,
            status: 'not_found',
            actual: `File not found: ${filePath}`
          });
        });
        return results;
      }

      const content = fs.readFileSync(fullPath, 'utf-8');
      
      checks.forEach(check => {
        const result = this.checkContent(content, check, filePath);
        results.push(result);
      });
      
    } catch (error) {
      checks.forEach(check => {
        results.push({
          ...check,
          status: 'fail',
          actual: `Error scanning file: ${error.message}`
        });
      });
    }
    
    return results;
  }

  // Check content for specific requirements
  checkContent(content, check, filePath) {
    const lines = content.split('\n');
    let found = false;
    let lineNumber = 0;
    let actual = '';
    
    // Check for expected keywords or patterns
    const expectedKeywords = check.expected.split(',').map(k => k.trim().toLowerCase());
    
    // Search through content
    expectedKeywords.forEach(keyword => {
      lines.forEach((line, index) => {
        if (line.toLowerCase().includes(keyword)) {
          found = true;
          lineNumber = index + 1;
          actual = line.trim();
        }
      });
    });

    // Check for selector-based elements
    if (check.selector && !found) {
      const selector = check.selector;
      
      // Class selector
      if (selector.startsWith('.')) {
        const className = selector.substring(1);
        if (content.includes(className)) {
          found = true;
          actual = `Found class: ${className}`;
        }
      }
      
      // Data attribute selector
      if (selector.includes('[data-module=')) {
        const moduleMatch = selector.match(/\[data-module="([^"]+)"\]/);
        if (moduleMatch) {
          const module = moduleMatch[1];
          if (content.includes(`data-module="${module}`) || content.includes(`data-module='${module}`)) {
            found = true;
            actual = `Found data-module: ${module}`;
          }
        }
      }
    }

    // Special checks for specific file types
    if (filePath.endsWith('.js')) {
      // Check for port configurations
      if (check.element.includes('port 5000')) {
        found = content.includes('5000') || content.includes('PORT');
        actual = found ? 'Port 5000 configuration found' : 'Port 5000 not found';
      }
      
      if (check.element.includes('port 3000')) {
        found = content.includes('3000');
        actual = found ? 'Port 3000 configuration found' : 'Port 3000 not found';
      }
    }

    // Status determination
    let status = 'fail';
    if (found) {
      status = 'pass';
    } else if (check.severity === 'low') {
      status = 'warning';
    }

    return {
      ...check,
      status: status,
      actual: found ? actual : 'Expected content not found in file',
      line: lineNumber
    };
  }

  // Run complete scan
  async runCompleteScan() {
    console.log('🔍 Starting FIXZIT SOUQ Implementation Scan...\n');
    
    const allChecks = [];
    
    // Group checks by file
    const fileChecks = new Map();
    
    this.requiredElements.forEach((checks, category) => {
      console.log(`📋 Loading ${category} requirements (${checks.length} checks)`);
      checks.forEach(check => {
        if (check.file) {
          if (!fileChecks.has(check.file)) {
            fileChecks.set(check.file, []);
          }
          fileChecks.get(check.file).push(check);
        }
        allChecks.push(check);
      });
    });

    console.log(`\n📊 Total checks: ${allChecks.length}`);
    console.log(`📁 Files to scan: ${fileChecks.size}\n`);
    
    // Scan each file
    const results = [];
    for (const [file, checks] of fileChecks) {
      console.log(`🔎 Scanning ${file}...`);
      const fileResults = await this.scanFile(file, checks);
      results.push(...fileResults);
    }
    
    // Calculate results
    const passed = results.filter(r => r.status === 'pass').length;
    const failed = results.filter(r => r.status === 'fail').length;
    const warnings = results.filter(r => r.status === 'warning').length;
    const notFound = results.filter(r => r.status === 'not_found').length;
    
    this.scanResults = {
      timestamp: new Date().toISOString(),
      totalChecks: results.length,
      passed,
      failed,
      warnings,
      notFound,
      details: results,
      coverage: (passed / results.length) * 100
    };
    
    return this.scanResults;
  }

  // Generate detailed report
  generateReport() {
    const results = this.scanResults;
    
    console.log('\n' + '='.repeat(80));
    console.log('🏗️  FIXZIT SOUQ IMPLEMENTATION AUDIT REPORT');
    console.log('='.repeat(80));
    console.log(`📅 Generated: ${new Date(results.timestamp).toLocaleString()}`);
    console.log(`📊 Coverage: ${results.coverage.toFixed(1)}%`);
    console.log('');
    
    // Summary
    console.log('📈 SUMMARY:');
    console.log(`   ✅ Passed:    ${results.passed.toString().padStart(3)} (${((results.passed/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   ❌ Failed:    ${results.failed.toString().padStart(3)} (${((results.failed/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   ⚠️  Warnings: ${results.warnings.toString().padStart(3)} (${((results.warnings/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   🔍 Not Found: ${results.notFound.toString().padStart(3)} (${((results.notFound/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   📋 Total:     ${results.totalChecks.toString().padStart(3)}`);
    console.log('');

    // Group by category
    const categories = new Map();
    results.details.forEach(check => {
      if (!categories.has(check.category)) {
        categories.set(check.category, []);
      }
      categories.get(check.category).push(check);
    });

    // Category breakdown
    console.log('📊 CATEGORY BREAKDOWN:');
    categories.forEach((checks, category) => {
      const passed = checks.filter(c => c.status === 'pass').length;
      const total = checks.length;
      const percentage = (passed / total) * 100;
      
      const status = percentage >= 80 ? '✅' : percentage >= 50 ? '⚠️' : '❌';
      console.log(`   ${status} ${category.padEnd(20)} ${passed.toString().padStart(2)}/${total.toString().padStart(2)} (${percentage.toFixed(0)}%)`);
    });
    console.log('');

    // Failed checks (High priority)
    const highFailures = results.details.filter(c => c.status === 'fail' && c.severity === 'high');
    if (highFailures.length > 0) {
      console.log('🔴 HIGH PRIORITY FAILURES:');
      highFailures.slice(0, 10).forEach(check => {
        console.log(`   ❌ ${check.id}: ${check.element}`);
        console.log(`      Expected: ${check.expected}`);
        console.log(`      Actual: ${check.actual}`);
        console.log(`      File: ${check.file} ${check.line ? `(line ${check.line})` : ''}`);
        console.log('');
      });
    }

    // Medium priority failures
    const mediumFailures = results.details.filter(c => c.status === 'fail' && c.severity === 'medium');
    if (mediumFailures.length > 0) {
      console.log('🟡 MEDIUM PRIORITY FAILURES:');
      mediumFailures.slice(0, 5).forEach(check => {
        console.log(`   ❌ ${check.id}: ${check.element}`);
        console.log(`      Expected: ${check.expected}`);
        console.log(`      File: ${check.file}`);
        console.log('');
      });
    }

    // Not Found Files
    const notFoundFiles = [...new Set(results.details.filter(c => c.status === 'not_found').map(c => c.file))];
    if (notFoundFiles.length > 0) {
      console.log('📁 MISSING FILES:');
      notFoundFiles.forEach(file => {
        console.log(`   🔍 ${file}`);
      });
      console.log('');
    }

    // Recommendations
    console.log('💡 RECOMMENDATIONS:');
    if (results.coverage >= 80) {
      console.log('   ✅ Excellent implementation coverage! Minor fixes needed.');
    } else if (results.coverage >= 60) {
      console.log('   ⚠️  Good progress. Focus on high priority failures.');
    } else if (results.coverage >= 40) {
      console.log('   🟡 Moderate implementation. Core components need work.');
    } else {
      console.log('   ❌ Low implementation coverage. Major development needed.');
    }

    // Save JSON report
    const jsonReport = {
      ...results,
      generatedAt: new Date().toISOString(),
      categoryBreakdown: Array.from(categories.entries()).map(([category, checks]) => ({
        category,
        total: checks.length,
        passed: checks.filter(c => c.status === 'pass').length,
        failed: checks.filter(c => c.status === 'fail').length,
        warnings: checks.filter(c => c.status === 'warning').length,
        notFound: checks.filter(c => c.status === 'not_found').length,
        coverage: (checks.filter(c => c.status === 'pass').length / checks.length) * 100
      }))
    };

    fs.writeFileSync('fixzit-audit-results.json', JSON.stringify(jsonReport, null, 2));
    console.log('\n💾 Detailed JSON report saved: fixzit-audit-results.json');
    
    console.log('='.repeat(80));
  }
}

// Main execution
async function main() {
  const projectPath = process.argv[2] || '.';
  console.log(`🚀 FIXZIT SOUQ Implementation Scanner v1.0`);
  console.log(`📁 Scanning project: ${path.resolve(projectPath)}\n`);
  
  const scanner = new FixzitImplementationScanner(projectPath);
  
  try {
    await scanner.runCompleteScan();
    scanner.generateReport();
  } catch (error) {
    console.error('❌ Scanner failed:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}