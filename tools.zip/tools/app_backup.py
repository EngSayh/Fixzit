"""
FIXZIT - Main Application Entry Point
Clean routing to login page
"""

import streamlit as st

# Page configuration MUST be first
st.set_page_config(
    page_title="Fixzit - شركة خدماتي الشاملة",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Initialize session state - AUTO-AUTHENTICATE FOR TESTING
if "authenticated" not in st.session_state:
    st.session_state.authenticated = True  # BYPASS LOGIN FOR TESTING
if "user_name" not in st.session_state:
    st.session_state.user_name = "Test User"
if "user_role" not in st.session_state:
    st.session_state.user_role = "admin"
if "username" not in st.session_state:
    st.session_state.username = "Test User"

# Show brief message and go directly to dashboard
st.markdown("# 🔧 Fixzit")
st.markdown("### Testing Mode - Going to Dashboard...")

# Skip login and go directly to dashboard for testing
st.switch_page("pages/01_Dashboard_WorkOS.py")


def apply_fixzit_branding():
    """Apply FIXZIT branding and styles - ONLY for authenticated pages"""
    # Don't apply branding if not authenticated (login page)
    if not st.session_state.get("authenticated", False):
        return

    st.markdown(
        """
    <style>
    /* FIXZIT Brand Colors */
    :root {
        --fixzit-orange: #F6851F;
        --fixzit-blue: #023047;
        --fixzit-white: #FFFFFF;
        --fixzit-gray: #f5f5f5;
    }
    
    /* Brand header for authenticated pages only */
    .fixzit-header {
        background: linear-gradient(135deg, var(--fixzit-orange) 0%, var(--fixzit-blue) 100%);
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        color: white;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .fixzit-title {
        font-size: 3rem;
        font-weight: bold;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .fixzit-subtitle {
        font-size: 1.2rem;
        opacity: 0.95;
        margin-top: 0.5rem;
    }
    
    .branding-content {
        text-align: center;
        z-index: 2;
    }
    
    .branding-logo {
        font-size: 4rem;
        margin-bottom: 1rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .branding-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    
    .branding-subtitle {
        font-size: 1.2rem;
        opacity: 0.9;
        line-height: 1.6;
        margin-bottom: 2rem;
    }
    
    .branding-features {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .branding-features li {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
        font-size: 1.1rem;
    }
    
    .branding-features li::before {
        content: "✓";
        margin-right: 1rem;
        font-weight: bold;
        color: #fff;
        background: rgba(255,255,255,0.2);
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.9rem;
    }
    
    .login-section {
        flex: 1;
        background: white;
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 3rem;
        position: relative;
    }
    
    .login-form-container {
        max-width: 400px;
        margin: 0 auto;
        width: 100%;
    }
    
    .login-header {
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .login-title {
        font-size: 2rem;
        font-weight: 700;
        color: var(--fixzit-blue);
        margin-bottom: 0.5rem;
    }
    
    .login-description {
        color: #666;
        font-size: 1rem;
        line-height: 1.5;
    }
    
    /* Modern form styling */
    .modern-input {
        position: relative;
        margin-bottom: 1.5rem;
    }
    
    .modern-input input {
        width: 100%;
        padding: 1rem 1rem 1rem 3rem !important;
        border: 2px solid #e1e5e9 !important;
        border-radius: 12px !important;
        font-size: 1rem !important;
        transition: all 0.3s ease !important;
        background: #fff !important;
    }
    
    .modern-input input:focus {
        border-color: var(--fixzit-orange) !important;
        box-shadow: 0 0 0 3px rgba(246, 133, 31, 0.1) !important;
        outline: none !important;
    }
    
    .modern-input .input-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
        font-size: 1.2rem;
        z-index: 2;
    }
    
    .modern-button {
        width: 100%;
        padding: 1rem 2rem;
        background: linear-gradient(135deg, var(--fixzit-orange), #e67c00);
        color: white;
        border: none;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(246, 133, 31, 0.3);
        margin-bottom: 1.5rem;
    }
    
    .modern-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(246, 133, 31, 0.4);
    }
    
    .modern-button:active {
        transform: translateY(0);
    }
    
    .secondary-links {
        text-align: center;
        margin-top: 2rem;
    }
    
    .secondary-links a {
        color: var(--fixzit-blue);
        text-decoration: none;
        margin: 0 1rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .secondary-links a:hover {
        color: var(--fixzit-orange);
        text-decoration: underline;
    }
    
    .language-selector {
        position: absolute;
        top: 2rem;
        right: 2rem;
        z-index: 10;
    }
    
    .security-badge {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 1rem;
        color: #666;
        font-size: 0.9rem;
    }
    
    .security-badge::before {
        content: "🔒";
        margin-right: 0.5rem;
    }
    
    /* Mobile responsiveness */
    @media (max-width: 768px) {
        .login-container {
            flex-direction: column;
        }
        
        .branding-section {
            min-height: 40vh;
            padding: 2rem;
        }
        
        .branding-title {
            font-size: 2rem;
        }
        
        .login-section {
            padding: 2rem;
        }
        
        .modern-input input {
            padding: 0.875rem 0.875rem 0.875rem 2.5rem !important;
        }
    }
    
    .login-type-desc {
        font-size: 0.9rem;
        color: #666;
    }
    
    /* Custom button styles */
    .stButton > button {
        background: linear-gradient(135deg, var(--fixzit-orange), #e57517);
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 10px;
        font-weight: bold;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(246, 133, 31, 0.3);
    }
    
    /* Input fields */
    .stTextInput > div > div > input,
    .stSelectbox > div > div > div {
        border-radius: 10px;
        border: 2px solid #e0e0e0;
        padding: 0.75rem;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: var(--fixzit-orange);
        box-shadow: 0 0 0 2px rgba(246, 133, 31, 0.2);
    }
    
    /* Subscription info */
    .subscription-info {
        background: var(--fixzit-gray);
        border-left: 4px solid var(--fixzit-orange);
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .subscription-expiry {
        color: #d32f2f;
        font-weight: bold;
    }
    
    /* Module access table */
    .module-access-table {
        width: 100%;
        border-collapse: collapse;
        margin: 1rem 0;
    }
    
    .module-access-table th {
        background: var(--fixzit-blue);
        color: white;
        padding: 0.75rem;
        text-align: left;
    }
    
    .module-access-table td {
        padding: 0.5rem 0.75rem;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .module-access-table tr:hover {
        background: var(--fixzit-gray);
    }
    
    /* RTL support for Arabic */
    .rtl {
        direction: rtl;
        text-align: right;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )


def show_login_page():
    """Display the modern unified login page"""
    # Hide sidebar
    st.markdown(
        """
    <style>
        [data-testid="stSidebar"] {
            display: none !important;
        }
        
        /* Enhanced styling for modern look */
        .stApp {
            background: linear-gradient(135deg, #F6851F 0%, #023047 100%);
        }
        
        .login-container {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: 2rem auto;
        }
        
        /* Override the gradient background for the right column form area */
        .main .block-container {
            background: transparent;
        }
        
        .stTextInput > div > div > input {
            border-radius: 12px !important;
            border: 2px solid #e1e5e9 !important;
            padding: 1rem !important;
            font-size: 1rem !important;
            transition: all 0.3s ease !important;
        }
        
        .stTextInput > div > div > input:focus {
            border-color: #F6851F !important;
            box-shadow: 0 0 0 3px rgba(246, 133, 31, 0.1) !important;
        }
        
        .stButton > button {
            background: #F6851F !important;
            color: white !important;
            border: none !important;
            border-radius: 12px !important;
            font-size: 1.1rem !important;
            font-weight: 600 !important;
            padding: 1rem 2rem !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 15px rgba(246, 133, 31, 0.3) !important;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 6px 20px rgba(246, 133, 31, 0.4) !important;
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    # Language selector at top
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        language = st.selectbox(
            "Language",
            options=["en", "ar"],
            format_func=lambda x: "🇺🇸 English" if x == "en" else "🇸🇦 العربية",
            index=0 if st.session_state.get("language", "en") == "en" else 1,
            label_visibility="collapsed",
        )
        if language != st.session_state.get("language", "en"):
            st.session_state.language = language
            st.rerun()

    # Two-column layout using Streamlit columns
    left_col, right_col = st.columns([1, 1])

    # Left column - Branding (keep gradient background)
    with left_col:
        st.markdown(
            """
        <div style="padding: 2rem; text-align: center; color: white;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">🔧</div>
            <div style="font-size: 2.5rem; font-weight: 700; margin-bottom: 1rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">FIXZIT</div>
            <div style="font-size: 1.2rem; opacity: 0.9; line-height: 1.6; margin-bottom: 2rem;">
                Comprehensive Service Company<br>
                شركة خدماتي الشاملة للمقاولات العامة
            </div>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Feature list with better spacing and improved readability
        st.markdown(
            """
        <div style="color: white; padding: 0 2rem;">
            <h3 style="color: white; margin-bottom: 1.5rem;">🌟 Platform Features</h3>
            <div style="line-height: 1.8; font-size: 1.1rem;">
                ✅ Property & Facility Management<br>
                ✅ Multi-Vendor Service Platform<br>
                ✅ HR Services & Automation<br>
                ✅ Enterprise-Grade Security<br>
                ✅ Multi-Language Support
            </div>
        </div>
        """,
            unsafe_allow_html=True,
        )

    # Right column - Login form with clean white background
    with right_col:
        st.markdown(
            """
        <div style="
            background: white;
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            margin: 2rem auto;
        ">
        """,
            unsafe_allow_html=True,
        )

        # Header - cleaned up and better spaced
        st.markdown(
            """
        <div style="text-align: center; margin-bottom: 2.5rem;">
            <h1 style="color: #023047; font-size: 2.2rem; font-weight: 700; margin-bottom: 0.8rem;">Welcome Back</h1>
            <p style="color: #666; font-size: 1rem; line-height: 1.5;">Enter your credentials to access your account</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # auth_manager = MultiAuthManager()  # TODO: Class to be implemented

        # Unified login form with better spacing
        with st.form("unified_login_form", clear_on_submit=False):
            st.markdown(
                """
            <div style="margin-bottom: 1rem;">
                <label style="color: #023047; font-weight: 600; font-size: 1rem; margin-bottom: 0.5rem; display: block;">
                    📧 Email Address
                </label>
            </div>
            """,
                unsafe_allow_html=True,
            )
            email = st.text_input(
                "Email",
                placeholder="Enter your email address",
                label_visibility="collapsed",
            )

            st.markdown(
                """
            <div style="margin: 1.5rem 0 1rem 0;">
                <label style="color: #023047; font-weight: 600; font-size: 1rem; margin-bottom: 0.5rem; display: block;">
                    🔒 Password
                </label>
            </div>
            """,
                unsafe_allow_html=True,
            )
            password = st.text_input(
                "Password",
                type="password",
                placeholder="Enter your password",
                label_visibility="collapsed",
            )

            # Options with better spacing
            st.markdown("<div style='margin: 1.5rem 0;'></div>", unsafe_allow_html=True)
            col1, col2 = st.columns(2)
            with col1:
                remember = st.checkbox("Remember me")
            with col2:
                show_password = st.checkbox("Show password")
                if show_password and password:
                    st.caption(f"Password: {password}")

            # Login button with more spacing
            st.markdown("<div style='margin: 1.5rem 0;'></div>", unsafe_allow_html=True)
            login_submitted = st.form_submit_button(
                "🔓 Sign In", use_container_width=True, type="primary"
            )

            if login_submitted:
                if email and password:
                    with st.spinner("🔍 Authenticating..."):
                        # Use auto-detection
                        # user = auth_manager.authenticate_user_auto_detect(
                        #     email, password
                        # )
                        user = None  # TODO: Implement authentication

                        if user:
                            # Store user session
                            st.session_state.authenticated = True
                            st.session_state.user_id = user["id"]
                            st.session_state.user_name = user["full_name"]
                            st.session_state.user_email = user["email"]
                            st.session_state.user_role = user["role"]
                            st.session_state.login_type = user["login_type"]
                            st.session_state.subscription_status = user[
                                "subscription_status"
                            ]
                            st.session_state.subscription_expiry = user[
                                "subscription_expiry"
                            ]
                            st.session_state.user_modules = user["modules"]

                            # Success message with user type
                            login_type_display = {
                                "admin": "👑 Administrator",
                                "corporate": "🏢 Corporate Manager",
                                "individual": "👤 Individual User",
                                "employee": "👥 Employee",
                            }.get(user["login_type"], user["login_type"].title())

                            st.success(f"✅ Welcome back, {user['full_name']}!")
                            st.info(f"🎯 Logged in as {login_type_display}")

                            if remember:
                                st.info("🔄 Login credentials will be remembered")

                            # Auto-redirect after success
                            st.rerun()
                        else:
                            st.error("❌ Invalid credentials")
                            st.info("💡 Please check your email and password")
                else:
                    st.error("⚠️ Please fill in both email and password")

        # Security badge
        st.markdown(
            """
        <div style="text-align: center; margin-top: 1rem; color: #666; font-size: 0.9rem;">
            🔒 Secure Login Protected by SSL Encryption
        </div>
        """,
            unsafe_allow_html=True,
        )

        st.markdown("</div>", unsafe_allow_html=True)

        # Demo credentials section - clean and integrated
        st.markdown("---")
        with st.expander("🧪 Demo Credentials (Click to expand)", expanded=False):
            st.markdown(
                """
            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 8px; margin: 1rem 0;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div>
                        <h4 style="color: #023047; margin-bottom: 0.5rem;">Admin Access</h4>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block;">
                            admin@fixzit.com<br>test123
                        </code>
                        <h4 style="color: #023047; margin: 1rem 0 0.5rem 0;">Corporate Manager</h4>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block;">
                            manager@fixzit.com<br>test123
                        </code>
                    </div>
                    <div>
                        <h4 style="color: #023047; margin-bottom: 0.5rem;">Individual User</h4>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block;">
                            tenant@fixzit.com<br>test123
                        </code>
                        <h4 style="color: #023047; margin: 1rem 0 0.5rem 0;">Employee</h4>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block;">
                            employee@fixzit.com<br>test123
                        </code>
                    </div>
                </div>
            </div>
            """,
                unsafe_allow_html=True,
            )

        # Additional options tabs (without redundant login tab)
        st.markdown("---")
        tab1, tab2 = st.tabs(
            ["Register", "Reset Password"]  # TODO: Add translation support
        )

        with tab1:
            st.markdown(
                """
            <div style="padding: 2rem;">
                <h3 style="color: #023047; text-align: center; margin-bottom: 2rem;">🏢 Create Your FIXZIT Account</h3>
            </div>
            """,
                unsafe_allow_html=True,
            )

            # Registration workflow
            reg_step = st.session_state.get("registration_step", 1)

            if reg_step == 1:
                # Step 1: Basic Information
                st.markdown("### 📝 Step 1: Basic Information")

                with st.form("registration_basic_info"):
                    col1, col2 = st.columns(2)
                    with col1:
                        company_name = st.text_input(
                            "Company Name *", placeholder="Your Company Ltd."
                        )
                        contact_person = st.text_input(
                            "Contact Person *", placeholder="John Smith"
                        )
                        email = st.text_input(
                            "Business Email *", placeholder="john@company.com"
                        )

                    with col2:
                        phone = st.text_input(
                            "Phone Number *", placeholder="+966 50 123 4567"
                        )
                        industry = st.selectbox(
                            "Industry",
                            [
                                "Real Estate",
                                "Construction",
                                "Property Management",
                                "Facilities Management",
                                "General Contracting",
                                "Other",
                            ],
                        )
                        company_size = st.selectbox(
                            "Company Size",
                            [
                                "1-10 employees",
                                "11-50 employees",
                                "51-200 employees",
                                "201-500 employees",
                                "500+ employees",
                            ],
                        )

                    if st.form_submit_button(
                        "Continue to Module Selection →", use_container_width=True
                    ):
                        if company_name and contact_person and email and phone:
                            st.session_state.registration_data = {
                                "company_name": company_name,
                                "contact_person": contact_person,
                                "email": email,
                                "phone": phone,
                                "industry": industry,
                                "company_size": company_size,
                            }
                            st.session_state.registration_step = 2
                            st.rerun()
                        else:
                            st.error("Please fill in all required fields (*)")

            elif reg_step == 2:
                # Step 2: Module Selection & Pricing
                st.markdown("### 🛒 Step 2: Select Your Modules")
                st.write(
                    f"**Company:** {st.session_state.registration_data['company_name']}"
                )

                # Module selection with pricing
                modules_pricing = {
                    "Core Shell": {
                        "price": 299,
                        "description": "Dashboard, basic user management",
                    },
                    "Real Estate Portfolio": {
                        "price": 499,
                        "description": "Property management, units, contracts",
                    },
                    "Operations & Maintenance": {
                        "price": 399,
                        "description": "Ticket system, maintenance tracking",
                    },
                    "Service Providers & Marketplace": {
                        "price": 599,
                        "description": "Vendor management, bidding system",
                    },
                    "Financials & Billing": {
                        "price": 349,
                        "description": "Payment tracking, invoicing",
                    },
                    "HR & Organization": {
                        "price": 449,
                        "description": "Employee management, HR services",
                    },
                    "Reporting & Analytics": {
                        "price": 249,
                        "description": "Reports, dashboards, analytics",
                    },
                }

                selected_modules = []
                total_price = 0

                st.markdown("**Select the modules you need:**")
                for module, details in modules_pricing.items():
                    col1, col2, col3 = st.columns([1, 2, 1])
                    with col1:
                        selected = st.checkbox(module, key=f"module_{module}")
                        if selected:
                            selected_modules.append(module)
                            total_price += details["price"]
                    with col2:
                        st.write(details["description"])
                    with col3:
                        st.write(f"${details['price']}/month")

                if selected_modules:
                    st.markdown("---")
                    st.markdown(f"**Selected Modules:** {', '.join(selected_modules)}")
                    st.markdown(f"**Monthly Total:** ${total_price}")
                    st.markdown(
                        f"**Annual Total (20% discount):** ${int(total_price * 12 * 0.8)}"
                    )

                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("← Back to Basic Info"):
                            st.session_state.registration_step = 1
                            st.rerun()
                    with col2:
                        if st.button("Continue to Payment →", type="primary"):
                            st.session_state.registration_data.update(
                                {
                                    "selected_modules": selected_modules,
                                    "monthly_price": total_price,
                                    "annual_price": int(total_price * 12 * 0.8),
                                }
                            )
                            st.session_state.registration_step = 3
                            st.rerun()
                else:
                    st.info("Please select at least one module to continue")
                    if st.button("← Back to Basic Info"):
                        st.session_state.registration_step = 1
                        st.rerun()

            elif reg_step == 3:
                # Step 3: Payment & Account Creation
                st.markdown("### 💳 Step 3: Complete Your Subscription")

                data = st.session_state.registration_data
                st.markdown(f"**Company:** {data['company_name']}")
                st.markdown(f"**Modules:** {', '.join(data['selected_modules'])}")
                st.markdown(f"**Monthly Price:** ${data['monthly_price']}")

                # Billing preference
                billing_cycle = st.radio(
                    "Billing Cycle", ["Monthly", "Annual (20% discount)"]
                )
                final_price = (
                    data["annual_price"]
                    if billing_cycle == "Annual (20% discount)"
                    else data["monthly_price"]
                )

                # Payment simulation
                st.markdown("#### Payment Information")
                with st.form("payment_form"):
                    col1, col2 = st.columns(2)
                    with col1:
                        card_number = st.text_input(
                            "Card Number", placeholder="1234 5678 9012 3456"
                        )
                        expiry = st.text_input("Expiry Date", placeholder="MM/YY")
                    with col2:
                        cvv = st.text_input("CVV", placeholder="123", type="password")
                        cardholder = st.text_input(
                            "Cardholder Name", placeholder="John Smith"
                        )

                    st.markdown(f"**Total Amount:** ${final_price}")

                    col1, col2 = st.columns(2)
                    with col1:
                        if st.form_submit_button("← Back to Modules"):
                            st.session_state.registration_step = 2
                            st.rerun()
                    with col2:
                        if st.form_submit_button(
                            "🚀 Complete Registration", type="primary"
                        ):
                            if card_number and expiry and cvv and cardholder:
                                # Simulate account creation
                                st.success("🎉 Registration Successful!")
                                st.info(
                                    f"✅ Account created for {data['company_name']}"
                                )
                                st.info(f"📧 Login credentials sent to {data['email']}")
                                st.info(f"🔑 Username: {data['email']}")
                                st.info("🔑 Temporary password: FixzitTemp123")
                                st.info("💡 Please login and change your password")

                                # Reset registration
                                if st.button("Continue to Login"):
                                    st.session_state.registration_step = 1
                                    if "registration_data" in st.session_state:
                                        del st.session_state.registration_data
                                    st.rerun()
                            else:
                                st.error("Please fill in all payment fields")

        with tab2:
            st.markdown(
                """
            <div style="padding: 2rem;">
                <h3 style="color: #023047; text-align: center; margin-bottom: 2rem;">🔑 Reset Your Password</h3>
            </div>
            """,
                unsafe_allow_html=True,
            )

            # Password reset workflow
            reset_step = st.session_state.get("reset_step", 1)

            if reset_step == 1:
                # Step 1: Enter email
                st.markdown("### 📧 Step 1: Enter Your Email")
                st.write("We'll send you a secure reset link to verify your identity.")

                with st.form("password_reset_email"):
                    email = st.text_input(
                        "Email Address",
                        placeholder="Enter your registered email address",
                        help="This should be the email you used to register your account",
                    )

                    if st.form_submit_button(
                        "Send Reset Link", use_container_width=True, type="primary"
                    ):
                        if email:
                            if "@" in email:  # Basic email validation
                                st.session_state.reset_email = email
                                st.session_state.reset_step = 2
                                st.rerun()
                            else:
                                st.error("Please enter a valid email address")
                        else:
                            st.error("Please enter your email address")

                st.markdown("---")
                st.info(
                    "💡 **Security Note:** We'll only send reset links to registered email addresses."
                )

            elif reset_step == 2:
                # Step 2: Email sent confirmation
                st.markdown("### ✅ Reset Link Sent")

                st.success(
                    f"📧 We've sent a password reset link to **{st.session_state.reset_email}**"
                )

                st.markdown(
                    """
                **Next Steps:**
                1. Check your email inbox (and spam folder)
                2. Click the secure reset link in the email
                3. Create your new password
                4. Login with your new credentials
                """
                )

                # Simulate the verification code entry
                st.markdown("---")
                st.markdown("### 🔐 Enter Verification Code")
                st.write("Enter the 6-digit code from your email:")

                with st.form("verification_code"):
                    code = st.text_input(
                        "Verification Code",
                        placeholder="123456",
                        max_chars=6,
                        help="Check your email for the 6-digit verification code",
                    )

                    col1, col2 = st.columns(2)
                    with col1:
                        if st.form_submit_button("Resend Code"):
                            st.info("🔄 New verification code sent!")

                    with col2:
                        if st.form_submit_button("Verify Code", type="primary"):
                            if code == "123456":  # Simulate correct code
                                st.session_state.reset_step = 3
                                st.rerun()
                            else:
                                st.error("Invalid verification code. Please try again.")

                if st.button("← Back to Email Entry"):
                    st.session_state.reset_step = 1
                    st.rerun()

            elif reset_step == 3:
                # Step 3: Create new password
                st.markdown("### 🔒 Create New Password")
                st.success(f"✅ Email verified for {st.session_state.reset_email}")

                with st.form("new_password"):
                    new_password = st.text_input(
                        "New Password",
                        type="password",
                        help="Password must be at least 8 characters long",
                    )
                    confirm_password = st.text_input(
                        "Confirm New Password", type="password"
                    )

                    # Password strength indicator
                    if new_password:
                        strength = 0
                        if len(new_password) >= 8:
                            strength += 1
                        if any(c.isupper() for c in new_password):
                            strength += 1
                        if any(c.islower() for c in new_password):
                            strength += 1
                        if any(c.isdigit() for c in new_password):
                            strength += 1
                        if any(c in "!@#$%^&*" for c in new_password):
                            strength += 1

                        strength_text = ["Very Weak", "Weak", "Fair", "Good", "Strong"][
                            min(strength, 4)
                        ]
                        strength_color = [
                            "#ff4444",
                            "#ff8800",
                            "#ffaa00",
                            "#88cc00",
                            "#00cc44",
                        ][min(strength, 4)]

                        st.markdown(
                            f"**Password Strength:** <span style='color: {strength_color}'>{strength_text}</span>",
                            unsafe_allow_html=True,
                        )

                    if st.form_submit_button(
                        "Reset Password", use_container_width=True, type="primary"
                    ):
                        if new_password and confirm_password:
                            if new_password == confirm_password:
                                if len(new_password) >= 8:
                                    st.success("🎉 Password reset successful!")
                                    st.info(
                                        f"✅ New password set for {st.session_state.reset_email}"
                                    )
                                    st.info(
                                        "💡 You can now login with your new password"
                                    )

                                    # Reset the process
                                    if st.button("Continue to Login"):
                                        st.session_state.reset_step = 1
                                        if "reset_email" in st.session_state:
                                            del st.session_state.reset_email
                                        st.rerun()
                                else:
                                    st.error(
                                        "Password must be at least 8 characters long"
                                    )
                            else:
                                st.error("Passwords do not match")
                        else:
                            st.error("Please fill in both password fields")

                if st.button("← Back to Verification"):
                    st.session_state.reset_step = 2
                    st.rerun()

        st.markdown("</div>", unsafe_allow_html=True)


def show_admin_access_control():
    """Display admin panel for module access control"""
    st.title("🔒 Module Access Control")

    # auth_manager = MultiAuthManager()  # Will be used when implementing access control

    # User type selector
    st.selectbox(
        "Select User Type to Configure",
        ["corporate", "individual", "employee"],
        index=0,
    )

    st.info("🚧 Module access control functionality will be implemented here")


def show_subscription_management():
    """Display subscription management interface"""
    st.title("💳 Subscription Management")
    st.info("🚧 Subscription management functionality will be implemented here")


def get_dashboard_metrics():
    """Get key dashboard metrics from database"""

    metrics = {
        "properties": 0,
        "contracts": 0,
        "users": 0,
        "pending_payments": 0,
        "recent_activity": [],
    }

    try:
        # conn = get_db_connection()  # TODO: Database connection to be implemented
        conn = None
        if conn:
            cur = conn.cursor()
            # Get basic counts
            cur.execute(
                """
                SELECT 
                    (SELECT COUNT(*) FROM properties) as total_properties,
                    (SELECT COUNT(*) FROM contracts) as total_contracts,
                    (SELECT COUNT(*) FROM users) as total_users,
                    (SELECT COUNT(*) FROM payments WHERE status = 'pending') as pending_payments
            """
            )
            result = cur.fetchone()
            if result:
                metrics["properties"] = result[0] or 0
                metrics["contracts"] = result[1] or 0
                metrics["users"] = result[2] or 0
                metrics["pending_payments"] = result[3] or 0

            # Get recent properties for activity
            cur.execute(
                """
                SELECT name, created_at FROM properties 
                ORDER BY created_at DESC LIMIT 3
            """
            )
            recent_props = cur.fetchall()
            metrics["recent_activity"] = [
                {"type": "Property Added", "name": prop[0], "date": prop[1]}
                for prop in recent_props
            ]

            conn.close()
    except Exception as e:
        st.error(f"Error loading dashboard metrics: {str(e)}")

    return metrics


def show_dashboard():
    """Display the main dashboard with metrics and quick actions"""

    # Custom CSS for dashboard styling
    st.markdown(
        """
    <style>
    .dashboard-header {
        background: linear-gradient(90deg, #F6851F 0%, #023047 100%);
        padding: 1rem 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
    }
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #F6851F;
        margin-bottom: 1rem;
    }
    .metric-number {
        font-size: 2.5rem;
        font-weight: bold;
        color: #023047;
        margin: 0;
    }
    .metric-label {
        color: #666;
        font-size: 0.9rem;
        margin: 0;
    }
    .quick-action-btn {
        background: #F6851F;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        margin: 0.25rem;
        font-weight: 500;
    }
    .activity-item {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 0.5rem;
        border-left: 3px solid #F6851F;
    }
    .sidebar-nav {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 10px;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )

    # Dashboard Header with User Menu
    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown(
            f"""
        <div class="dashboard-header">
            <h1 style="margin:0; font-size:2rem;">🏠 FIXZIT Dashboard</h1>
            <p style="margin:0; opacity:0.9;">Welcome back, {st.session_state.get('user_name', 'User')}! • {st.session_state.get('login_type', 'User').title()} Access</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        with st.popover("👤 User Menu"):
            st.write(f"**{st.session_state.get('user_name', 'User')}**")
            st.write(f"Role: {st.session_state.get('login_type', 'User').title()}")
            st.write(f"Email: {st.session_state.get('user_email', 'N/A')}")
            st.divider()
            if st.button("⚙️ Settings", use_container_width=True):
                st.info("Settings panel coming soon!")
            if st.button("🚪 Logout", use_container_width=True):
                for key in st.session_state.keys():
                    del st.session_state[key]
                st.rerun()

    # Get dashboard metrics
    metrics = get_dashboard_metrics()

    # Key Metrics Cards
    st.subheader("📊 Key Metrics")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(
            f"""
        <div class="metric-card">
            <p class="metric-number">{metrics['properties']}</p>
            <p class="metric-label">🏢 Active Properties</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

    with col2:
        st.markdown(
            f"""
        <div class="metric-card">
            <p class="metric-number">{metrics['contracts']}</p>
            <p class="metric-label">📄 Total Contracts</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

    with col3:
        st.markdown(
            f"""
        <div class="metric-card">
            <p class="metric-number">{metrics['users']}</p>
            <p class="metric-label">👥 System Users</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

    with col4:
        st.markdown(
            f"""
        <div class="metric-card">
            <p class="metric-number">{metrics['pending_payments']}</p>
            <p class="metric-label">💰 Pending Payments</p>
        </div>
        """,
            unsafe_allow_html=True,
        )

    # Quick Actions Section
    st.subheader("⚡ Quick Actions")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        if st.button("➕ Add Property", use_container_width=True):
            st.switch_page("pages/02_Properties.py")

    with col2:
        if st.button("📋 Create Contract", use_container_width=True):
            st.switch_page("pages/03_Contracts.py")

    with col3:
        if st.button("🎫 New Ticket", use_container_width=True):
            st.switch_page("pages/04_Tickets.py")

    with col4:
        if st.button("👤 Add User", use_container_width=True):
            st.switch_page("pages/06_Users.py")

    # Recent Activity and Important Info
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🔔 Recent Activity")
        if metrics["recent_activity"]:
            for activity in metrics["recent_activity"]:
                st.markdown(
                    f"""
                <div class="activity-item">
                    <strong>{activity['type']}</strong><br>
                    {activity['name']}<br>
                    <small>{activity['date'].strftime('%Y-%m-%d') if activity['date'] else 'Recently'}</small>
                </div>
                """,
                    unsafe_allow_html=True,
                )
        else:
            st.info("No recent activity to display")

    with col2:
        st.subheader("⚠️ Alerts & Notifications")
        if metrics["pending_payments"] > 0:
            st.warning(
                f"You have {metrics['pending_payments']} pending payment(s) that need attention"
            )

        # Simulate some alerts for demo
        st.info("💡 Tip: Use the Quick Actions above to streamline your workflow")
        st.success("✅ System Status: All services operational")


def main():
    """Main application entry point"""
    # Load Monday.com-style theme
    # load_monday_theme()  # TODO: Function to be implemented

    # Apply dark mode if enabled
    # apply_dark_mode()  # TODO: Function to be implemented

    # Apply RTL mode for Arabic
    # apply_rtl_mode()  # TODO: Function to be implemented

    # Check authentication status properly
    if not st.session_state.get("authenticated", False):
        # Hide all content and redirect to login page immediately
        st.markdown(
            "<style>div.block-container{display:none !important;}</style>",
            unsafe_allow_html=True,
        )
        st.switch_page("pages/00_Login.py")
        st.stop()
    else:
        # Show authenticated dashboard
        show_dashboard()


if __name__ == "__main__":
    main()
