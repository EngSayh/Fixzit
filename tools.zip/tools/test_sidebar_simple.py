"""
Minimal sidebar test
"""
import streamlit as st

# Basic config
st.set_page_config(
    page_title="Test Sidebar",
    layout="wide", 
    initial_sidebar_state="expanded"
)

# Simple sidebar content
st.sidebar.title("🔧 FIXZIT SIDEBAR TEST")
st.sidebar.button("Dashboard")
st.sidebar.button("Properties") 
st.sidebar.button("Finance")
st.sidebar.markdown("---")
st.sidebar.markdown("This is the sidebar!")

# Main content
st.title("Sidebar Test Page")
st.write("Look to the left - do you see the sidebar?")
st.write("The sidebar should show: FIXZIT SIDEBAR TEST with buttons")