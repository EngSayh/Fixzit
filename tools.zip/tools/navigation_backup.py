# navigation.py — Final deduplicated universal navigation with Mini-Rail
import os
import streamlit as st
from typing import Tuple
from nav_config import NAV, DEFAULT_OPEN_GROUP, DEFAULT_ROUTE

# ───────────────────────── CSS (sanitize + base + mini rail) ──────────────────
SANITIZE_CSS = """
<style id="fxz-sanitize">
/* 1) Kill any legacy custom sidebars left in pages */
.fxz-layout, .fxz-sb, .legacy-sidebar, [data-legacy-sidebar="1"] { display:none !important; }
/* 2) Inside Streamlit's sidebar, keep only our root container */
section[data-testid="stSidebar"] > div > :not(#fxz-sidebar-root) { display:none !important; }
/* 3) Make Streamlit sidebar sticky + dark */
section[data-testid="stSidebar"] {
  display: block !important;
  visibility: visible !important;
}
section[data-testid="stSidebar"] > div {
  position: sticky; top: 0; height: 100vh; overflow-y: auto;
  background: #121212 !important; padding-top:.6rem; padding-left:.4rem; padding-right:.4rem;
  display: block !important;
  visibility: visible !important;
}
/* 4) Hide Streamlit's default collapse chevron to prevent full hide */
div[data-testid="collapsedControl"] { display:none !important; }
</style>
"""

BASE_CSS = """
<style id="fxz-base">
.fxz-group{
  user-select:none; display:flex; align-items:center; justify-content:space-between;
  font-weight:600; font-size:.95rem; padding:10px 12px; margin:6px 4px 0 4px;
  background:#1b1b1b; border-radius:10px; color:#e6e6e6; cursor:pointer; border:1px solid #2a2a2a;
}
.fxz-group:hover{ background:#212121; }
.fxz-ch{ transition: transform .18s ease; } .fxz-ch.open{ transform: rotate(90deg); }
.fxz-items{ margin:4px 6px 10px 6px; }
.fxz-item,.fxz-child{
  display:flex; align-items:center; gap:.6rem; padding:9px 12px; margin:4px 0;
  background:#181818; border:1px solid #262626; border-radius:10px; color:#cdcdcd; text-decoration:none;
}
.fxz-item:hover,.fxz-child:hover{ background:#202020; color:#fff; }
.fxz-item.active,.fxz-child.active{ 
  background: linear-gradient(90deg, rgba(246, 133, 31, 0.15) 0%, rgba(246, 133, 31, 0.05) 100%);
  border-left: 3px solid #F6851F;
  color: #F6851F;
}
.fxz-children{ margin-left:10px; }
.fxz-warn{ color:#ffb3b3; font-size:.82rem; padding:4px 8px; }

/* Mini rail container */
#fxz-mini-rail{
  position:fixed; left:10px; top:68px; width:56px; z-index:9999;
  display:flex; flex-direction:column; gap:8px; background:#121212;
  border:1px solid #2a2a2a; border-radius:16px; padding:8px 6px;
  box-shadow: 0 6px 20px rgba(0,0,0,.35);
}
.fxz-rail-btn{
  display:flex; align-items:center; justify-content:center;
  width:44px; height:44px; border-radius:12px; border:1px solid #2a2a2a;
  background:#1b1b1b; color:#e6e6e6; font-size:18px; cursor:pointer;
}
.fxz-rail-btn:hover{ background:#202020; }

/* Shift main content when rail is visible */
body.fxz-mini main .block-container{ margin-left:72px !important; }
section[data-testid="stSidebar"][aria-expanded="false"] ~ main .block-container { margin-left:72px !important; }
@media (max-width: 820px){
  #fxz-mini-rail{ left:6px; top:56px; transform:scale(.92); }
  body.fxz-mini main .block-container{ margin-left:64px !important; }
}

/* Brand header */
.fxz-brand {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 0.75rem;
    margin-bottom: 0.5rem;
    border-bottom: 1px solid #2a2a2a;
}

.fxz-brand-logo {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.fxz-brand-text {
    color: #F6851F;
    font-weight: 900;
    font-size: 1.2rem;
}

/* Collapse button */
.fxz-collapse-btn {
    width: 100%;
    padding: 8px 12px;
    margin: 8px 4px;
    background: #1b1b1b;
    border: 1px solid #2a2a2a;
    border-radius: 8px;
    color: #e6e6e6;
    font-size: 0.9rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.fxz-collapse-btn:hover {
    background: #212121;
}

/* Footer */
.fxz-footer {
    padding: 1rem 0.75rem;
    border-top: 1px solid #2a2a2a;
    margin-top: auto;
    color: #999;
    font-size: 0.85rem;
}
</style>
"""

# Rail routes mapping
RAIL_ROUTES = {
    "home": "dashboard",
    "settings": "settings",
    "profile": "tenants",  # Maps to users page
    "help": "support",  # Maps to support page
    "feedback": "feedback",  # Maps to feedback analytics page
}


# ───────────────────────── Helpers ─────────────────────────
def _page_exists(path: str) -> bool:
    """Check if a page file exists"""
    if not path:
        return False
    p = path.replace("\\", "/")
    return os.path.isfile(p) or os.path.isfile(os.path.join(".", p))


def _switch_to(page_path: str):
    """Switch to a different page"""
    try:
        st.switch_page(page_path)
    except Exception:
        pass


def _qp_get(name: str, default=None):
    """Get query parameter"""
    try:
        return st.query_params.get(name, default)
    except Exception:
        try:
            return st.experimental_get_query_params().get(name, [default])[0]
        except Exception:
            return default


def _qp_set(**kwargs):
    """Set query parameters"""
    try:
        st.query_params.update(kwargs)
    except Exception:
        st.experimental_set_query_params(**kwargs)


def _init_state():
    """Initialize session state"""
    # Navigation mode: 'full' or 'mini'
    st.session_state.setdefault("fxz_nav_mode", "full")

    # Navigation state
    st.session_state.setdefault("fxz_route", DEFAULT_ROUTE)
    st.session_state.setdefault("fxz_open_group", DEFAULT_OPEN_GROUP)
    st.session_state.setdefault("fxz_open_item", None)

    # Check for route in query params
    qp_route = _qp_get("route")
    if qp_route:
        st.session_state.fxz_route = qp_route


def hide_sidebar_on_login():
    """Hide sidebar completely on login page"""
    st.markdown(
        "<style>section[data-testid='stSidebar']{display:none!important}</style>",
        unsafe_allow_html=True,
    )


# ───────────────────────── Mini Rail ───────────────────
def _render_mini_rail():
    """Render the mini rail navigation"""
    # CSS for mini rail
    st.markdown(
        """
        <style>
        /* Hide full sidebar when in mini mode */
        section[data-testid="stSidebar"] {
            display: none !important;
        }
        
        /* Shift main content for rail */
        .main .block-container {
            margin-left: 80px !important;
        }
        </style>
    """,
        unsafe_allow_html=True,
    )

    # Create mini rail container
    rail_html = """
    <div id='fxz-mini-rail'>
        <div style='display: flex; flex-direction: column; gap: 8px;'>
    """

    # Expand button
    rail_html += """
        <button class='fxz-rail-btn' title='Expand navigation' 
                onclick='window.parent.postMessage({type: "expand"}, "*")'>
            »
        </button>
    """

    # Rail buttons with emojis
    rail_items = [
        ("🏠", "Home", "home"),
        ("⚙️", "Settings", "settings"),
        ("👤", "Profile", "profile"),
        ("❓", "Help", "help"),
        ("💬", "Feedback", "feedback"),
    ]

    for emoji, label, key in rail_items:
        rail_html += f"""
            <button class='fxz-rail-btn' title='{label}' 
                    onclick='window.parent.postMessage({{type: "navigate", route: "{key}"}}, "*")'>
                {emoji}
            </button>
        """

    rail_html += """
        </div>
    </div>
    """

    st.markdown(rail_html, unsafe_allow_html=True)

    # Handle navigation from mini rail using placeholder buttons
    col1 = st.columns(1)[0]
    with col1:
        # Invisible buttons to handle clicks
        if st.button(
            "Expand",
            key="rail_expand",
            help="Expand navigation",
            use_container_width=False,
        ):
            st.session_state.fxz_nav_mode = "full"
            st.rerun()

        for _, label, key in rail_items:
            if st.button(
                label, key=f"rail_{key}", help=label, use_container_width=False
            ):
                route_id = RAIL_ROUTES.get(key)
                if route_id:
                    st.session_state.fxz_route = route_id
                    _qp_set(route=route_id)
                    # Find and switch to the page
                    for group in NAV:
                        for item in group["items"]:
                            if item.get("id") == route_id:
                                if _page_exists(item.get("page", "")):
                                    _switch_to(item["page"])
                                break
                            # Check children
                            if "children" in item:
                                for child in item["children"]:
                                    if child.get("id") == route_id:
                                        if _page_exists(child.get("page", "")):
                                            _switch_to(child["page"])
                                        break
                    st.rerun()


def _warn_missing(page_path: str):
    """Show warning for missing page"""
    st.markdown(
        f"<div class='fxz-warn'>⚠️ Missing page: <code>{page_path}</code></div>",
        unsafe_allow_html=True,
    )


# ───────────────────────── Main Renderer ─────────────────
def render_sidebar(auth_ok: bool = True) -> Tuple[str, str]:
    """
    Renders the universal sidebar with mini-rail support.
    Returns (project_key, active_route_id).
    For login pages, pass auth_ok=False or call hide_sidebar_on_login().
    """
    if not auth_ok:
        hide_sidebar_on_login()
        return None, None

    # Initialize state
    _init_state()

    # Apply base CSS
    st.markdown(SANITIZE_CSS + BASE_CSS, unsafe_allow_html=True)

    # MINI MODE → render rail and skip sidebar
    if st.session_state.fxz_nav_mode == "mini":
        _render_mini_rail()
        return "console", st.session_state.fxz_route

    # FULL MODE → normal sidebar
    with st.sidebar:
        st.markdown("<div id='fxz-sidebar-root'>", unsafe_allow_html=True)

        # Brand header
        st.markdown(
            """
            <div class='fxz-brand'>
                <div class='fxz-brand-logo'>🔧</div>
                <div class='fxz-brand-text'>FIXZIT</div>
            </div>
        """,
            unsafe_allow_html=True,
        )

        # Collapse button
        if st.button(
            "« Collapse",
            key="collapse_nav",
            help="Collapse to mini rail",
            use_container_width=True,
        ):
            st.session_state.fxz_nav_mode = "mini"
            st.rerun()

        st.caption("Navigation")

        # Render navigation groups
        for g in NAV:
            gname = g["group"]
            is_open = st.session_state.fxz_open_group == gname

            # Group header
            c1, c2 = st.columns([1, 0.12])
            with c1:
                if st.button(
                    f"{g.get('icon','📂')}  {gname}",
                    key=f"grp_{gname}",
                    use_container_width=True,
                ):
                    st.session_state.fxz_open_group = gname if not is_open else None
                    st.session_state.fxz_open_item = None
                    st.rerun()
            with c2:
                st.markdown(
                    f"<div class='fxz-ch {'open' if is_open else ''}'>▶</div>",
                    unsafe_allow_html=True,
                )

            # Show items if group is open
            if is_open:
                for item in g["items"]:
                    has_children = "children" in item and item["children"]
                    st.session_state.fxz_route == item.get("id")
                    is_item_open = st.session_state.fxz_open_item == item.get("id")

                    # Style active items
                    # active_class = "active" if is_active else ""  # Not used

                    # Item button
                    btn = st.button(
                        f"{item.get('icon','•')}  {item['label']}",
                        key=f"itm_{item['id']}",
                        use_container_width=True,
                    )

                    if btn:
                        if has_children:
                            # Toggle children
                            st.session_state.fxz_open_item = (
                                item["id"] if not is_item_open else None
                            )
                            st.rerun()
                        else:
                            # Navigate to page
                            st.session_state.fxz_route = item["id"]
                            st.session_state.fxz_open_item = None
                            _qp_set(route=item["id"])
                            if _page_exists(item.get("page", "")):
                                _switch_to(item["page"])
                            st.rerun()

                    # Show children if item is open
                    if has_children and is_item_open:
                        st.markdown(
                            "<div class='fxz-children'>", unsafe_allow_html=True
                        )
                        for ch in item["children"]:
                            # ch_active = st.session_state.fxz_route == ch["id"]  # Not used

                            ch_btn = st.button(
                                f"   {ch.get('icon','›')}  {ch['label']}",
                                key=f"ch_{ch['id']}",
                                use_container_width=True,
                            )

                            if ch_btn:
                                st.session_state.fxz_route = ch["id"]
                                _qp_set(route=ch["id"])
                                if _page_exists(ch.get("page", "")):
                                    _switch_to(ch["page"])
                                st.rerun()

                            # Warn if page missing
                            if not _page_exists(ch.get("page", "")):
                                _warn_missing(ch["page"])

                        st.markdown("</div>", unsafe_allow_html=True)

                    # Warn if page missing (for non-parent items)
                    if not has_children and not _page_exists(item.get("page", "")):
                        _warn_missing(item["page"])

        # Footer
        st.markdown(
            """
            <div class='fxz-footer'>
                Fixzit Platform<br>
                v2.0.0
            </div>
        """,
            unsafe_allow_html=True,
        )

        st.markdown("</div>", unsafe_allow_html=True)

    return "console", st.session_state.fxz_route


# Alias for backward compatibility
def render_firebase_sidebar(*args, **kwargs):
    """Alias for render_sidebar for backward compatibility"""
    return render_sidebar(*args, **kwargs)
