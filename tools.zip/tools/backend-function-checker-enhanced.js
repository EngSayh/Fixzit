#!/usr/bin/env node

/**
 * FIXZIT SOUQ Backend Function Checker - Enhanced Version
 * Based on Phase 1 Scope: 13 Modules + Event System + Portals
 * Scans backend codebase for missing functions based on complete scope requirements
 */

const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
  scanDirs: ['./routes', './models', './middleware', './services', './utils', './controllers', './api', './src'],
  fileExtensions: ['.js', '.ts', '.jsx', '.tsx'],
  ignorePatterns: ['node_modules', 'dist', 'build', '.git', 'test', 'tests', '__tests__', 'coverage', '.next']
};

// Complete Required Backend Functions based on FIXZIT SOUQ Phase 1 Scope
const REQUIRED_FUNCTIONS = {
  // 1. Dashboard Module Functions
  dashboard: [
    'getDashboardMetrics', 'getKPICards', 'getActivityFeed', 'getCalendarEvents',
    'getRoleBasedDashboard', 'getMyWork', 'getAlerts', 'getCalendarTab',
    'updateKPICard', 'refreshDashboard', 'exportDashboard', 'customizeDashboard'
  ],
  
  // 2. Work Orders Module Functions
  workOrders: [
    'createWorkOrder', 'updateWorkOrderStatus', 'assignTechnician', 'autoAssignWorkOrder',
    'trackSLA', 'getServiceHistory', 'dispatchWorkOrder', 'generatePreventiveMaintenance',
    'updateWorkOrderState', 'getKanbanView', 'getCalendarView', 'getGanttView',
    'calculateRoute', 'getMapDispatch', 'moveWorkOrderState', 'bulkAssignWorkOrders',
    'getWorkOrdersByStatus', 'getOverdueWorkOrders', 'calculatePriority'
  ],
  
  // 3. Properties Module Functions
  properties: [
    'getProperties', 'createProperty', 'updateProperty', 'deleteProperty',
    'getUnits', 'createUnit', 'updateUnit', 'deleteUnit',
    'getTenants', 'createTenant', 'updateTenant', 'deleteTenant',
    'createLease', 'updateLease', 'terminateLease', 'renewLease',
    'getAssetRegister', 'addAsset', 'updateAsset', 'removeAsset',
    'createInspection', 'getInspectionTemplates', 'submitInspection',
    'uploadDocument', 'getDocuments', 'deleteDocument',
    'getPropertyLocation', 'updatePropertyLocation', 'generatePropertyReport'
  ],
  
  // 4. Finance Module Functions (ZATCA Compliance Critical)
  finance: [
    'createInvoice', 'generateZATCAQRCode', 'submitToZATCA', 'validateZATCACompliance',
    'processPayment', 'recordExpense', 'getBudgetVsActual', 'calculateVAT',
    'generateTaxReport', 'reconcilePayments', 'processBulkPayments',
    'generateStatement', 'trackOverduePayments', 'applyLateFees',
    'createPriceBook', 'updatePricing', 'generateFinancialReports',
    'exportToAccounting', 'handleRefund', 'processRecurringInvoices'
  ],
  
  // 5. Human Resources Module Functions
  hr: [
    'getEmployeeDirectory', 'createEmployee', 'updateEmployee', 'deactivateEmployee',
    'recordAttendance', 'trackLeave', 'approveLeave', 'rejectLeave',
    'processPayroll', 'generatePayslips', 'calculateDeductions',
    'createJobPosting', 'processApplication', 'scheduleInterview',
    'createTrainingProgram', 'trackTrainingProgress', 'generateCertificate',
    'createPerformanceReview', 'submitReview', 'generateHRReports'
  ],
  
  // 6. Administration Module Functions
  administration: [
    'manageDelegationOfAuthority', 'getApprovalMatrix', 'updateApprovalLevels',
    'createPolicy', 'updatePolicy', 'publishPolicy', 'archivePolicy',
    'manageAssets', 'trackInventory', 'createPurchaseRequest',
    'manageFacilities', 'scheduleFleetMaintenance', 'trackFleetUsage',
    'createVendor', 'evaluateVendor', 'manageVendorContracts',
    'generateAdminReports', 'auditTrail'
  ],
  
  // 7. CRM Module Functions
  crm: [
    'createCustomer', 'updateCustomer', 'getCustomerHistory',
    'createLead', 'convertLead', 'trackLeadStatus',
    'createOpportunity', 'updateOpportunityStage', 'calculatePipeline',
    'createContract', 'renewContract', 'trackContractMilestones',
    'recordFeedback', 'processComplaint', 'escalateComplaint',
    'calculateNPS', 'calculateCSAT', 'generateCRMReports',
    'sendCustomerCommunication', 'trackInteractions'
  ],
  
  // 8. Marketplace Module Functions (Amazon-style)
  marketplace: [
    'createVendor', 'updateVendor', 'verifyVendor', 'suspendVendor',
    'createService', 'updateService', 'categorizeService',
    'createProcurementRequest', 'approveProcurementRequest',
    'createRFQ', 'submitBid', 'evaluateBids', 'awardBid',
    'createPurchaseOrder', 'trackDelivery', 'confirmReceipt',
    'rateVendor', 'searchMarketplace', 'filterServices',
    'compareVendors', 'generateMarketplaceReports'
  ],
  
  // 9. Support Module Functions
  support: [
    'createTicket', 'assignTicket', 'updateTicketStatus', 'escalateTicket',
    'createKnowledgeArticle', 'updateArticle', 'searchKnowledgeBase',
    'trackSLA', 'calculateResponseTime', 'calculateResolutionTime',
    'createSurvey', 'collectSurveyResponses', 'analyzeSurveyResults',
    'generateSupportReports', 'trackAgentPerformance'
  ],
  
  // 10. Compliance & Legal Module Functions
  compliance: [
    'createPermit', 'renewPermit', 'trackPermitExpiry',
    'scheduleInspection', 'recordInspectionResults', 'generateComplianceReport',
    'recordFine', 'trackFinePayment', 'appealFine',
    'createContract', 'reviewContract', 'approveContract', 'archiveContract',
    'maintainAuditLog', 'generateAuditReport',
    'integrateDocuSign', 'sendForSignature', 'trackSignatureStatus'
  ],
  
  // 11. Reports & Analytics Module Functions
  reports: [
    'generateOperationalReport', 'generateFinancialReport', 'generateWorkforceReport',
    'createCustomReport', 'scheduleReport', 'exportReport',
    'createDashboard', 'updateDashboard', 'shareDashboard',
    'trackKPIs', 'generateTrendAnalysis', 'performDataAnalysis',
    'createDataVisualization', 'exportToBI'
  ],
  
  // 12. System Management Module Functions
  system: [
    'createUser', 'updateUser', 'deactivateUser', 'resetPassword',
    'createRole', 'updateRole', 'assignPermissions',
    'configureTenant', 'updateTenantSettings', 'manageTenantLimits',
    'configureIntegration', 'testIntegration', 'monitorIntegration',
    'importData', 'exportData', 'validateDataFormat',
    'configureWebhook', 'testWebhook', 'logWebhookActivity',
    'customizeBranding', 'updateTheme', 'manageAuditLog'
  ],
  
  // 13. Preventive Maintenance Module Functions
  preventiveMaintenance: [
    'createMaintenanceSchedule', 'updateSchedule', 'pauseSchedule',
    'generateRecurringWorkOrder', 'calculateNextMaintenance',
    'trackAssetMaintenance', 'predictMaintenance', 'generateMaintenanceAlert',
    'recordServiceHistory', 'analyzeMaintenancePatterns',
    'optimizeMaintenanceSchedule', 'generateMaintenanceReports'
  ],
  
  // Authentication & Security Functions (CRITICAL)
  auth: [
    'login', 'logout', 'refreshToken', 'validateJWT', 'checkPermissions',
    'enforceRBAC', 'logSecurityEvent', 'detectAnomalies', 'rateLimitCheck',
    'validateSession', 'handleMFA', 'validateOTP', 'generateAPIKey',
    'revokeAccess', 'auditAccess'
  ],
  
  // Portal-specific Functions (5 Portals - CRITICAL)
  portals: [
    'getTenantPortalData', 'submitTenantRequest', 'viewTenantBills',
    'getTechnicianPortalData', 'updateTechnicianStatus', 'viewTechnicianSchedule',
    'getOwnerPortalData', 'approveOwnerRequest', 'viewOwnerReports',
    'getCorporateManagerData', 'manageCorporateSettings', 'viewCorporateDashboard',
    'getVendorPortalData', 'submitVendorBid', 'viewVendorOrders',
    'authenticatePortalUser', 'getPortalNotifications', 'updatePortalPreferences'
  ],
  
  // Critical Workflow Functions (3 Golden Paths)
  workflows: [
    'processTenantMaintenanceRequest', 'routeMaintenanceRequest', 'assignMaintenanceTechnician',
    'processRFQToPurchaseOrder', 'evaluateRFQResponses', 'convertRFQToPO',
    'processOwnerApproval', 'escalateApproval', 'trackApprovalStatus',
    'getWorkflowStatus', 'moveToNextStep', 'rollbackWorkflow', 'validateWorkflowRules'
  ],
  
  // Event System Functions (11 Events from Catalog)
  events: [
    'publishWorkOrderCreated', 'publishWorkOrderUpdated', 'publishWorkOrderCompleted',
    'publishPaymentProcessed', 'publishInvoiceGenerated',
    'publishMaintenanceScheduled', 'publishAssetUpdated',
    'publishTenantRequest', 'publishOwnerApproval',
    'publishVendorBidReceived', 'publishSystemAlert',
    'subscribeToEvent', 'unsubscribeFromEvent', 'processEventQueue',
    'handleEventError', 'retryFailedEvent'
  ],
  
  // Real-time Functions (WebSocket - CRITICAL)
  realtime: [
    'establishWebSocket', 'broadcastUpdate', 'sendNotification',
    'syncData', 'handleRealtimeEvent', 'manageSocketRooms',
    'handleDisconnect', 'handleReconnect', 'broadcastToRole',
    'broadcastToUser', 'trackActiveConnections'
  ],
  
  // Integration Functions (External Services)
  integrations: [
    'sendSMS', 'sendEmail', 'sendWhatsApp',
    'getMapData', 'calculateRoute', 'geocodeAddress',
    'processPaymentGateway', 'verifyPayment', 'handlePaymentWebhook',
    'syncWithAccounting', 'syncWithERP', 'syncWithCRM',
    'uploadToCloudStorage', 'generateSignedURL'
  ]
};

// Function to recursively scan directories
function scanDirectory(dirPath, results = []) {
  if (!fs.existsSync(dirPath)) return results;
  
  try {
    const items = fs.readdirSync(dirPath);
    
    for (const item of items) {
      const fullPath = path.join(dirPath, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        // Skip ignored directories
        if (!CONFIG.ignorePatterns.some(pattern => item.includes(pattern))) {
          scanDirectory(fullPath, results);
        }
      } else if (stat.isFile()) {
        // Check if file has valid extension
        if (CONFIG.fileExtensions.some(ext => fullPath.endsWith(ext))) {
          results.push(fullPath);
        }
      }
    }
  } catch (error) {
    console.error(`Error scanning directory ${dirPath}:`, error.message);
  }
  
  return results;
}

// Enhanced function scanner with better pattern matching
function scanForFunctions(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const functions = new Set();
    
    // Enhanced regex patterns for better function detection
    const patterns = [
      // Regular functions
      /function\s+(\w+)\s*\(/g,
      // Arrow functions assigned to const/let/var
      /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Methods in objects
      /(\w+)\s*:\s*(?:async\s*)?function\s*\(/g,
      /(\w+)\s*:\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Express route handlers with function name extraction
      /router\.(get|post|put|delete|patch)\s*\(\s*['"`]\/(\w+)/g,
      /app\.(get|post|put|delete|patch)\s*\(\s*['"`]\/api\/(\w+)/g,
      // Controller methods
      /exports\.(\w+)\s*=/g,
      /module\.exports\.(\w+)\s*=/g,
      // ES6 exports
      /export\s+(?:async\s+)?function\s+(\w+)/g,
      /export\s+const\s+(\w+)\s*=/g,
      /export\s+{\s*(\w+)/g,
      // Class methods
      /(?:async\s+)?(\w+)\s*\([^)]*\)\s*{/g,
      // MongoDB/Mongoose operations
      /\.(?:find|findOne|findById|create|update|delete|save|remove)\w*\(/g,
      // API endpoint definitions
      /\/api\/(\w+)/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        // Extract function names from matches
        for (let i = 1; i < match.length; i++) {
          if (match[i] && typeof match[i] === 'string') {
            const fnName = match[i];
            // Filter out common non-function words
            if (!['use', 'return', 'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'break', 'continue', 'try', 'catch', 'finally', 'throw', 'new', 'this', 'super', 'class', 'extends', 'static', 'get', 'set', 'const', 'let', 'var', 'function', 'async', 'await', 'import', 'export', 'default', 'from', 'as'].includes(fnName) && 
                !fnName.startsWith('_') && 
                fnName.length > 2) {
              functions.add(fnName);
            }
          }
        }
      }
    });
    
    return functions;
  } catch (error) {
    console.error(`Error reading file ${filePath}:`, error.message);
    return new Set();
  }
}

// Enhanced missing function finder with fuzzy matching
function findMissingFunctions(implementedFunctions) {
  const missing = {};
  const found = {};
  const partial = {};
  
  for (const [module, functions] of Object.entries(REQUIRED_FUNCTIONS)) {
    missing[module] = [];
    found[module] = [];
    partial[module] = [];
    
    for (const fn of functions) {
      let isFound = false;
      
      // Check exact match
      if (implementedFunctions.has(fn)) {
        found[module].push(fn);
        isFound = true;
      } else {
        // Enhanced partial matching with fuzzy logic
        const lowerFn = fn.toLowerCase();
        const fnWords = fn.replace(/([A-Z])/g, ' $1').toLowerCase().split(' ').filter(w => w.length > 2);
        
        for (const implFn of implementedFunctions) {
          const lowerImpl = implFn.toLowerCase();
          
          // Direct substring match
          if (lowerImpl.includes(lowerFn) || lowerFn.includes(lowerImpl)) {
            partial[module].push({ required: fn, found: implFn, confidence: 'high' });
            isFound = true;
            break;
          }
          
          // Word-based matching for camelCase functions
          const matchingWords = fnWords.filter(word => lowerImpl.includes(word));
          if (matchingWords.length >= Math.min(2, fnWords.length)) {
            partial[module].push({ required: fn, found: implFn, confidence: 'medium' });
            isFound = true;
            break;
          }
          
          // Snake_case to camelCase matching
          const snakeCaseFn = fn.replace(/([A-Z])/g, '_$1').toLowerCase().substring(1);
          if (lowerImpl.includes(snakeCaseFn) || snakeCaseFn.includes(lowerImpl)) {
            partial[module].push({ required: fn, found: implFn, confidence: 'medium' });
            isFound = true;
            break;
          }
        }
      }
      
      if (!isFound) {
        missing[module].push(fn);
      }
    }
  }
  
  return { missing, found, partial };
}

// Function to scan entire backend
function scanBackend() {
  console.log('📁 Scanning directories:', CONFIG.scanDirs.join(', '));
  
  const implementedFunctions = new Set();
  const scannedFiles = [];
  
  for (const dir of CONFIG.scanDirs) {
    const files = scanDirectory(dir);
    
    for (const file of files) {
      const functions = scanForFunctions(file);
      functions.forEach(fn => implementedFunctions.add(fn));
      if (functions.size > 0) {
        scannedFiles.push({ file, functions: Array.from(functions) });
      }
    }
  }
  
  return { implementedFunctions, scannedFiles };
}

// Enhanced report generation with priority analysis
function generateReport() {
  console.log('\n🔍 FIXZIT SOUQ Backend Function Checker - Enhanced Version\n');
  console.log('='.repeat(80));
  
  const { implementedFunctions, scannedFiles } = scanBackend();
  
  console.log(`\n✅ Found ${implementedFunctions.size} implemented functions`);
  console.log(`📄 Scanned ${scannedFiles.length} files\n`);
  
  const { missing, found, partial } = findMissingFunctions(implementedFunctions);
  
  // Calculate comprehensive statistics
  let totalRequired = 0;
  let totalFound = 0;
  let totalMissing = 0;
  let totalPartial = 0;
  
  for (const module of Object.keys(REQUIRED_FUNCTIONS)) {
    totalRequired += REQUIRED_FUNCTIONS[module].length;
    totalFound += found[module].length;
    totalMissing += missing[module].length;
    totalPartial += partial[module].length;
  }
  
  // Priority analysis for different function categories
  const criticalModules = ['auth', 'finance', 'portals', 'workflows', 'realtime'];
  const coreModules = ['dashboard', 'workOrders', 'properties', 'hr', 'administration'];
  const enhancementModules = ['crm', 'marketplace', 'support', 'compliance', 'reports', 'system', 'preventiveMaintenance', 'events', 'integrations'];
  
  function calculateModuleStats(modules) {
    let total = 0, foundCount = 0, missingCount = 0, partialCount = 0;
    
    for (const module of modules) {
      if (REQUIRED_FUNCTIONS[module]) {
        total += REQUIRED_FUNCTIONS[module].length;
        foundCount += found[module] ? found[module].length : 0;
        missingCount += missing[module] ? missing[module].length : 0;
        partialCount += partial[module] ? partial[module].length : 0;
      }
    }
    
    return { total, foundCount, missingCount, partialCount };
  }
  
  const criticalStats = calculateModuleStats(criticalModules);
  const coreStats = calculateModuleStats(coreModules);
  const enhancementStats = calculateModuleStats(enhancementModules);
  
  // Print comprehensive summary
  console.log('='.repeat(80));
  console.log('📊 COMPREHENSIVE SUMMARY - FIXZIT SOUQ Phase 1 Scope');
  console.log('='.repeat(80));
  console.log(`Total Required Functions: ${totalRequired} (Complete Phase 1 Scope)`);
  console.log(`✅ Exact Matches: ${totalFound} (${((totalFound/totalRequired)*100).toFixed(1)}%)`);
  console.log(`⚠️  Partial Matches: ${totalPartial} (${((totalPartial/totalRequired)*100).toFixed(1)}%)`);
  console.log(`❌ Missing Functions: ${totalMissing} (${((totalMissing/totalRequired)*100).toFixed(1)}%)`);
  console.log('='.repeat(80));
  
  // Priority-based analysis
  console.log('\n🚨 PRIORITY ANALYSIS');
  console.log('='.repeat(80));
  console.log(`🔴 CRITICAL MODULES (${criticalStats.total} functions):`);
  console.log(`   ✅ Found: ${criticalStats.foundCount} (${((criticalStats.foundCount/criticalStats.total)*100).toFixed(1)}%)`);
  console.log(`   ⚠️  Partial: ${criticalStats.partialCount} (${((criticalStats.partialCount/criticalStats.total)*100).toFixed(1)}%)`);
  console.log(`   ❌ Missing: ${criticalStats.missingCount} (${((criticalStats.missingCount/criticalStats.total)*100).toFixed(1)}%)`);
  
  console.log(`\n🟡 CORE MODULES (${coreStats.total} functions):`);
  console.log(`   ✅ Found: ${coreStats.foundCount} (${((coreStats.foundCount/coreStats.total)*100).toFixed(1)}%)`);
  console.log(`   ⚠️  Partial: ${coreStats.partialCount} (${((coreStats.partialCount/coreStats.total)*100).toFixed(1)}%)`);
  console.log(`   ❌ Missing: ${coreStats.missingCount} (${((coreStats.missingCount/coreStats.total)*100).toFixed(1)}%)`);
  
  console.log(`\n🟢 ENHANCEMENT MODULES (${enhancementStats.total} functions):`);
  console.log(`   ✅ Found: ${enhancementStats.foundCount} (${((enhancementStats.foundCount/enhancementStats.total)*100).toFixed(1)}%)`);
  console.log(`   ⚠️  Partial: ${enhancementStats.partialCount} (${((enhancementStats.partialCount/enhancementStats.total)*100).toFixed(1)}%)`);
  console.log(`   ❌ Missing: ${enhancementStats.missingCount} (${((enhancementStats.missingCount/enhancementStats.total)*100).toFixed(1)}%)`);
  
  // Print missing functions by priority
  console.log('\n❌ MISSING FUNCTIONS BY PRIORITY\n');
  console.log('='.repeat(80));
  
  // Critical modules first
  for (const module of criticalModules) {
    if (missing[module] && missing[module].length > 0) {
      console.log(`\n🚨 ${module.toUpperCase()} MODULE - CRITICAL (${missing[module].length} missing):`);
      missing[module].forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
    }
  }
  
  // Core modules
  for (const module of coreModules) {
    if (missing[module] && missing[module].length > 0) {
      console.log(`\n🟡 ${module.toUpperCase()} MODULE - CORE (${missing[module].length} missing):`);
      missing[module].forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
    }
  }
  
  // Enhancement modules (only show if significant missing functions)
  for (const module of enhancementModules) {
    if (missing[module] && missing[module].length > 5) {
      console.log(`\n🟢 ${module.toUpperCase()} MODULE - ENHANCEMENT (${missing[module].length} missing):`);
      missing[module].slice(0, 5).forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
      if (missing[module].length > 5) {
        console.log(`   ... and ${missing[module].length - 5} more`);
      }
    }
  }
  
  // High-confidence partial matches
  console.log('\n⚠️  HIGH-CONFIDENCE PARTIAL MATCHES (likely implemented)\n');
  console.log('='.repeat(80));
  
  for (const [module, matches] of Object.entries(partial)) {
    const highConfMatches = matches.filter(m => m.confidence === 'high');
    if (highConfMatches.length > 0) {
      console.log(`\n📦 ${module.toUpperCase()} MODULE:`);
      highConfMatches.forEach(({ required, found }) => {
        console.log(`   ⚠️  ${required} → likely: ${found}`);
      });
    }
  }
  
  // Generate comprehensive JSON report
  const report = {
    timestamp: new Date().toISOString(),
    scope: 'FIXZIT SOUQ Phase 1 Complete',
    summary: {
      totalRequired,
      totalFound,
      totalPartial,
      totalMissing,
      completionPercentage: ((totalFound/totalRequired)*100).toFixed(1),
      criticalModules: criticalStats,
      coreModules: coreStats,
      enhancementModules: enhancementStats
    },
    missing,
    found,
    partial,
    scannedFiles: scannedFiles.map(f => f.file),
    implementedFunctions: Array.from(implementedFunctions).sort()
  };
  
  // Save enhanced report
  try {
    fs.writeFileSync('./backend-functions-enhanced-report.json', JSON.stringify(report, null, 2));
    console.log('\n💾 Enhanced Report saved to: backend-functions-enhanced-report.json');
    
    // Generate implementation roadmap
    const roadmap = generateImplementationRoadmap(missing, partial);
    fs.writeFileSync('./implementation-roadmap.md', roadmap);
    console.log('🗺️  Implementation Roadmap saved to: implementation-roadmap.md');
  } catch (error) {
    console.error('Error saving report:', error.message);
  }
  
  return report;
}

// Generate implementation roadmap
function generateImplementationRoadmap(missing, partial) {
  let roadmap = '# FIXZIT SOUQ Phase 1 Implementation Roadmap\n\n';
  roadmap += `Generated: ${new Date().toISOString()}\n\n`;
  
  const criticalModules = ['auth', 'finance', 'portals', 'workflows', 'realtime'];
  const coreModules = ['dashboard', 'workOrders', 'properties', 'hr', 'administration'];
  
  roadmap += '## 🚨 CRITICAL PHASE (Week 1-2)\n\n';
  for (const module of criticalModules) {
    if (missing[module] && missing[module].length > 0) {
      roadmap += `### ${module.toUpperCase()} Module\n`;
      missing[module].forEach(fn => {
        roadmap += `- [ ] ${fn}\n`;
      });
      roadmap += '\n';
    }
  }
  
  roadmap += '## 🟡 CORE PHASE (Week 3-4)\n\n';
  for (const module of coreModules) {
    if (missing[module] && missing[module].length > 0) {
      roadmap += `### ${module.toUpperCase()} Module\n`;
      missing[module].forEach(fn => {
        roadmap += `- [ ] ${fn}\n`;
      });
      roadmap += '\n';
    }
  }
  
  return roadmap;
}

// Run the enhanced checker
if (require.main === module) {
  generateReport();
}

module.exports = { generateReport, scanBackend, findMissingFunctions };