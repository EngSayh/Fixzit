// FIXZIT SOUQ Implementation Scanner - Complete Audit System
// This scanner checks EVERY element, button, and behavior against chat requirements

import * as fs from 'fs';
import * as path from 'path';
import { JSDOM } from 'jsdom';
import * as cheerio from 'cheerio';

interface AuditCheck {
  id: string;
  category: string;
  element: string;
  expected: string;
  selector?: string;
  file?: string;
  status?: 'pass' | 'fail' | 'warning' | 'not_found';
  actual?: string;
  severity: 'high' | 'medium' | 'low';
  line?: number;
}

interface AuditResult {
  timestamp: string;
  totalChecks: number;
  passed: number;
  failed: number;
  warnings: number;
  notFound: number;
  details: AuditCheck[];
  coverage: number;
}

class FixzitImplementationScanner {
  private projectPath: string;
  private requiredElements: Map<string, AuditCheck[]>;
  private scanResults: AuditResult;

  constructor(projectPath: string) {
    this.projectPath = projectPath;
    this.requiredElements = this.loadRequirements();
    this.scanResults = {
      timestamp: new Date().toISOString(),
      totalChecks: 0,
      passed: 0,
      failed: 0,
      warnings: 0,
      notFound: 0,
      details: [],
      coverage: 0
    };
  }

  // Load all requirements from chat history
  private loadRequirements(): Map<string, AuditCheck[]> {
    const requirements = new Map<string, AuditCheck[]>();

    // LANDING PAGE REQUIREMENTS
    requirements.set('landing', [
      {
        id: 'LP001',
        category: 'Landing Page',
        element: 'Header gradient background',
        expected: 'background: linear-gradient(135deg, #0078D4 0%, #00BCF2 100%)',
        selector: '.landing-header',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP002',
        category: 'Landing Page',
        element: 'Yellow Arabic button',
        expected: 'الشاملة للاستشارات العقارية with background #FFB400',
        selector: '.btn-arabic',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP003',
        category: 'Landing Page',
        element: 'White Souq button',
        expected: 'Fixzit Souq with white background',
        selector: '.btn-souq',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP004',
        category: 'Landing Page',
        element: 'Green Access button',
        expected: 'Access Fixzit with background #00A859',
        selector: '.btn-access',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP005',
        category: 'Landing Page',
        element: 'Flip dropdown animation',
        expected: '3D flip transform with transition',
        selector: '.dropdown-content',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'LP006',
        category: 'Landing Page',
        element: 'Enterprise Features section',
        expected: '6 feature cards',
        selector: '.enterprise-card',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'LP007',
        category: 'Landing Page',
        element: 'Footer version',
        expected: 'v2.0.26',
        selector: '.footer-version',
        file: 'public/index.html',
        severity: 'low'
      }
    ]);

    // SIDEBAR REQUIREMENTS (13 MODULES)
    requirements.set('sidebar', [
      {
        id: 'SB001',
        category: 'Sidebar',
        element: 'Monday.com style',
        expected: 'Collapsible sidebar with icons',
        selector: '.sidebar',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB002',
        category: 'Sidebar',
        element: 'Collapsed by default',
        expected: 'sidebar collapsed class on load',
        selector: '.sidebar.collapsed',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'SB003',
        category: 'Sidebar',
        element: 'Dashboard module',
        expected: 'Dashboard menu item with icon',
        selector: '[data-module="dashboard"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB004',
        category: 'Sidebar',
        element: 'Work Orders module',
        expected: 'Work Orders menu item',
        selector: '[data-module="work-orders"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB005',
        category: 'Sidebar',
        element: 'Properties module',
        expected: 'Properties menu item',
        selector: '[data-module="properties"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB006',
        category: 'Sidebar',
        element: 'Finance module',
        expected: 'Finance menu item',
        selector: '[data-module="finance"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB007',
        category: 'Sidebar',
        element: 'Human Resources module',
        expected: 'Human Resources menu item',
        selector: '[data-module="hr"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB008',
        category: 'Sidebar',
        element: 'Administration module',
        expected: 'Administration menu item',
        selector: '[data-module="admin"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB009',
        category: 'Sidebar',
        element: 'CRM module',
        expected: 'CRM menu item',
        selector: '[data-module="crm"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB010',
        category: 'Sidebar',
        element: 'Marketplace module',
        expected: 'Marketplace menu item',
        selector: '[data-module="marketplace"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB011',
        category: 'Sidebar',
        element: 'Support module',
        expected: 'Support menu item',
        selector: '[data-module="support"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB012',
        category: 'Sidebar',
        element: 'Compliance & Legal module',
        expected: 'Compliance & Legal menu item',
        selector: '[data-module="compliance"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB013',
        category: 'Sidebar',
        element: 'Reports & Analytics module',
        expected: 'Reports & Analytics menu item',
        selector: '[data-module="reports"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB014',
        category: 'Sidebar',
        element: 'System Management module',
        expected: 'System Management menu item',
        selector: '[data-module="system"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'SB015',
        category: 'Sidebar',
        element: 'Preventive Maintenance module',
        expected: 'Preventive Maintenance menu item',
        selector: '[data-module="preventive"]',
        file: 'public/index.html',
        severity: 'high'
      }
    ]);

    // TOPBAR DYNAMIC TABS
    requirements.set('topbar', [
      {
        id: 'TB001',
        category: 'Topbar',
        element: 'Topbar height',
        expected: 'height: 60px',
        selector: '.topbar',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'TB002',
        category: 'Topbar',
        element: 'Background color',
        expected: 'background: #0061A8',
        selector: '.topbar',
        file: 'public/index.html',
        severity: 'medium'
      },
      {
        id: 'TB003',
        category: 'Topbar',
        element: 'Global search',
        expected: 'Search input with Command+K',
        selector: '.global-search',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB004',
        category: 'Topbar',
        element: 'Quick create button',
        expected: 'Plus button for quick actions',
        selector: '.quick-create',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB005',
        category: 'Topbar',
        element: 'Notification bell',
        expected: 'Bell icon with badge count',
        selector: '.notification-bell',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB006',
        category: 'Topbar',
        element: 'User avatar dropdown',
        expected: 'Profile menu with logout',
        selector: '.user-avatar',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB007',
        category: 'Topbar',
        element: 'Language toggle',
        expected: 'EN/عربي switcher',
        selector: '.lang-toggle',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB008',
        category: 'Topbar',
        element: 'Dashboard dynamic tabs',
        expected: 'Overview, My Work, Alerts, Calendar, Reports',
        selector: '.topbar-tabs[data-module="dashboard"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB009',
        category: 'Topbar',
        element: 'Work Orders dynamic tabs',
        expected: 'All Orders, By Status, Calendar View, PM Schedule',
        selector: '.topbar-tabs[data-module="work-orders"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB010',
        category: 'Topbar',
        element: 'Properties dynamic tabs',
        expected: 'All Properties, Units & Tenants, Leases, Inspections',
        selector: '.topbar-tabs[data-module="properties"]',
        file: 'public/index.html',
        severity: 'high'
      },
      {
        id: 'TB011',
        category: 'Topbar',
        element: 'Finance dynamic tabs',
        expected: 'Invoices, Payments, ZATCA, Budget, Reports',
        selector: '.topbar-tabs[data-module="finance"]',
        file: 'public/index.html',
        severity: 'high'
      }
    ]);

    // API ROUTES CHECK
    requirements.set('api', [
      {
        id: 'API001',
        category: 'API Routes',
        element: 'Auth routes',
        expected: 'Authentication endpoints available',
        file: 'routes/auth.js',
        severity: 'high'
      },
      {
        id: 'API002',
        category: 'API Routes',
        element: 'Dashboard routes',
        expected: 'Dashboard API endpoints',
        file: 'routes/dashboard.js',
        severity: 'high'
      },
      {
        id: 'API003',
        category: 'API Routes',
        element: 'Marketplace routes',
        expected: 'Marketplace API endpoints',
        file: 'routes/marketplace.js',
        severity: 'high'
      },
      {
        id: 'API004',
        category: 'API Routes',
        element: 'Finance routes',
        expected: 'Finance API endpoints',
        file: 'routes/finance.js',
        severity: 'high'
      },
      {
        id: 'API005',
        category: 'API Routes',
        element: 'Properties routes',
        expected: 'Properties API endpoints',
        file: 'routes/properties.js',
        severity: 'high'
      },
      {
        id: 'API006',
        category: 'API Routes',
        element: 'Work Orders routes',
        expected: 'Work Orders API endpoints',
        file: 'routes/workorders.js',
        severity: 'high'
      }
    ]);

    // WORKFLOWS
    requirements.set('workflows', [
      {
        id: 'WF001',
        category: 'Workflows',
        element: 'Server running on port 5000',
        expected: 'Server listens on port 5000',
        file: 'server.js',
        severity: 'high'
      },
      {
        id: 'WF002',
        category: 'Workflows',
        element: 'Frontend serving',
        expected: 'Frontend serves on port 3000',
        file: 'serve-frontend.js',
        severity: 'high'
      },
      {
        id: 'WF003',
        category: 'Workflows',
        element: 'Database connection',
        expected: 'Database connection established',
        file: 'config/database.js',
        severity: 'high'
      }
    ]);

    return requirements;
  }

  // Scan HTML/TSX file for elements
  private async scanFile(filePath: string, checks: AuditCheck[]): Promise<AuditCheck[]> {
    const results: AuditCheck[] = [];
    
    try {
      const fullPath = path.join(this.projectPath, filePath);
      
      if (!fs.existsSync(fullPath)) {
        checks.forEach(check => {
          results.push({
            ...check,
            status: 'not_found',
            actual: `File not found: ${filePath}`
          });
        });
        return results;
      }

      const content = fs.readFileSync(fullPath, 'utf-8');
      
      // For HTML files
      if (filePath.endsWith('.html')) {
        const $ = cheerio.load(content);
        checks.forEach(check => {
          const result = this.checkHTMLElement($, check, content);
          results.push(result);
        });
      }
      
      // For JavaScript files
      if (filePath.endsWith('.js')) {
        checks.forEach(check => {
          const result = this.checkJavaScriptFile(content, check);
          results.push(result);
        });
      }
      
    } catch (error) {
      checks.forEach(check => {
        results.push({
          ...check,
          status: 'fail',
          actual: `Error scanning file: ${error.message}`
        });
      });
    }
    
    return results;
  }

  // Check HTML element
  private checkHTMLElement($: any, check: AuditCheck, content: string): AuditCheck {
    if (!check.selector) {
      return {
        ...check,
        status: 'warning',
        actual: 'No selector provided for HTML check'
      };
    }
    
    const element = $(check.selector);
    
    if (element.length === 0) {
      return {
        ...check,
        status: 'fail',
        actual: 'Element not found'
      };
    }
    
    // Check specific properties
    if (check.expected.includes('background')) {
      const style = element.attr('style') || '';
      const hasExpectedBg = style.includes('#0078D4') || style.includes('#00BCF2') || 
                          style.includes('#FFB400') || style.includes('#00A859');
      return {
        ...check,
        status: hasExpectedBg ? 'pass' : 'warning',
        actual: `Background: ${style}`
      };
    }
    
    if (check.expected.includes('height')) {
      const style = element.attr('style') || '';
      const hasHeight = style.includes('60px');
      return {
        ...check,
        status: hasHeight ? 'pass' : 'fail',
        actual: `Style: ${style}`
      };
    }
    
    // Check text content
    const text = element.text().trim();
    const expectedTexts = check.expected.split(',').map(t => t.trim());
    const hasExpectedText = expectedTexts.some(expectedText => 
      text.toLowerCase().includes(expectedText.toLowerCase()) ||
      content.toLowerCase().includes(expectedText.toLowerCase())
    );
    
    return {
      ...check,
      status: hasExpectedText ? 'pass' : 'warning',
      actual: `Found: ${element.length} elements, text: ${text.substring(0, 50)}...`
    };
  }

  // Check JavaScript file
  private checkJavaScriptFile(content: string, check: AuditCheck): AuditCheck {
    const lines = content.split('\n');
    let found = false;
    let lineNumber = 0;
    let actual = '';
    
    // Check for expected keywords or patterns
    const expectedKeywords = check.expected.split(',').map(k => k.trim().toLowerCase());
    
    expectedKeywords.forEach(keyword => {
      lines.forEach((line, index) => {
        if (line.toLowerCase().includes(keyword)) {
          found = true;
          lineNumber = index + 1;
          actual = line.trim();
        }
      });
    });

    // Special checks for specific elements
    if (check.element.includes('port 5000')) {
      found = content.includes('5000') || content.includes('PORT');
      actual = found ? 'Port 5000 configuration found' : 'Port 5000 not found';
    }

    if (check.element.includes('port 3000')) {
      found = content.includes('3000');
      actual = found ? 'Port 3000 configuration found' : 'Port 3000 not found';
    }

    return {
      ...check,
      status: found ? 'pass' : 'fail',
      actual: found ? actual : 'Expected content not found in file',
      line: lineNumber
    };
  }

  // Run complete scan
  public async runCompleteScan(): Promise<AuditResult> {
    console.log('🔍 Starting FIXZIT SOUQ Implementation Scan...\n');
    
    const allChecks: AuditCheck[] = [];
    
    // Group checks by file
    const fileChecks = new Map<string, AuditCheck[]>();
    
    this.requiredElements.forEach((checks, category) => {
      console.log(`📋 Scanning ${category} (${checks.length} checks)`);
      checks.forEach(check => {
        if (check.file) {
          if (!fileChecks.has(check.file)) {
            fileChecks.set(check.file, []);
          }
          fileChecks.get(check.file)!.push(check);
        }
        allChecks.push(check);
      });
    });

    console.log(`\n📊 Total checks: ${allChecks.length}`);
    console.log(`📁 Files to scan: ${fileChecks.size}\n`);
    
    // Scan each file
    const results: AuditCheck[] = [];
    for (const [file, checks] of fileChecks) {
      console.log(`🔎 Scanning ${file}...`);
      const fileResults = await this.scanFile(file, checks);
      results.push(...fileResults);
    }
    
    // Calculate results
    const passed = results.filter(r => r.status === 'pass').length;
    const failed = results.filter(r => r.status === 'fail').length;
    const warnings = results.filter(r => r.status === 'warning').length;
    const notFound = results.filter(r => r.status === 'not_found').length;
    
    this.scanResults = {
      timestamp: new Date().toISOString(),
      totalChecks: results.length,
      passed,
      failed,
      warnings,
      notFound,
      details: results,
      coverage: (passed / results.length) * 100
    };
    
    return this.scanResults;
  }

  // Generate detailed report
  public generateReport(): void {
    const results = this.scanResults;
    
    console.log('\n' + '='.repeat(80));
    console.log('🏗️  FIXZIT SOUQ IMPLEMENTATION AUDIT REPORT');
    console.log('='.repeat(80));
    console.log(`📅 Generated: ${new Date(results.timestamp).toLocaleString()}`);
    console.log(`📊 Coverage: ${results.coverage.toFixed(1)}%`);
    console.log('');
    
    // Summary
    console.log('📈 SUMMARY:');
    console.log(`   ✅ Passed:    ${results.passed.toString().padStart(3)} (${((results.passed/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   ❌ Failed:    ${results.failed.toString().padStart(3)} (${((results.failed/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   ⚠️  Warnings: ${results.warnings.toString().padStart(3)} (${((results.warnings/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   🔍 Not Found: ${results.notFound.toString().padStart(3)} (${((results.notFound/results.totalChecks)*100).toFixed(1)}%)`);
    console.log(`   📋 Total:     ${results.totalChecks.toString().padStart(3)}`);
    console.log('');

    // Group by category
    const categories = new Map<string, AuditCheck[]>();
    results.details.forEach(check => {
      if (!categories.has(check.category)) {
        categories.set(check.category, []);
      }
      categories.get(check.category)!.push(check);
    });

    // Category breakdown
    console.log('📊 CATEGORY BREAKDOWN:');
    categories.forEach((checks, category) => {
      const passed = checks.filter(c => c.status === 'pass').length;
      const total = checks.length;
      const percentage = (passed / total) * 100;
      
      const status = percentage >= 80 ? '✅' : percentage >= 50 ? '⚠️' : '❌';
      console.log(`   ${status} ${category.padEnd(20)} ${passed.toString().padStart(2)}/${total.toString().padStart(2)} (${percentage.toFixed(0)}%)`);
    });
    console.log('');

    // Failed checks (High priority)
    const highFailures = results.details.filter(c => c.status === 'fail' && c.severity === 'high');
    if (highFailures.length > 0) {
      console.log('🔴 HIGH PRIORITY FAILURES:');
      highFailures.forEach(check => {
        console.log(`   ❌ ${check.id}: ${check.element}`);
        console.log(`      Expected: ${check.expected}`);
        console.log(`      Actual: ${check.actual}`);
        console.log(`      File: ${check.file} ${check.line ? `(line ${check.line})` : ''}`);
        console.log('');
      });
    }

    // Medium priority failures
    const mediumFailures = results.details.filter(c => c.status === 'fail' && c.severity === 'medium');
    if (mediumFailures.length > 0) {
      console.log('🟡 MEDIUM PRIORITY FAILURES:');
      mediumFailures.forEach(check => {
        console.log(`   ❌ ${check.id}: ${check.element}`);
        console.log(`      Expected: ${check.expected}`);
        console.log(`      Actual: ${check.actual}`);
        console.log(`      File: ${check.file}`);
        console.log('');
      });
    }

    // Warnings
    const criticalWarnings = results.details.filter(c => c.status === 'warning' && c.severity === 'high');
    if (criticalWarnings.length > 0) {
      console.log('⚠️  CRITICAL WARNINGS:');
      criticalWarnings.forEach(check => {
        console.log(`   ⚠️  ${check.id}: ${check.element}`);
        console.log(`      Expected: ${check.expected}`);
        console.log(`      Actual: ${check.actual}`);
        console.log('');
      });
    }

    // Save detailed JSON report
    const jsonReport = {
      ...results,
      generatedAt: new Date().toISOString(),
      summary: {
        totalChecks: results.totalChecks,
        passed: results.passed,
        failed: results.failed,
        warnings: results.warnings,
        notFound: results.notFound,
        coverage: results.coverage
      },
      categoryBreakdown: Array.from(categories.entries()).map(([category, checks]) => ({
        category,
        total: checks.length,
        passed: checks.filter(c => c.status === 'pass').length,
        failed: checks.filter(c => c.status === 'fail').length,
        warnings: checks.filter(c => c.status === 'warning').length,
        notFound: checks.filter(c => c.status === 'not_found').length,
        coverage: (checks.filter(c => c.status === 'pass').length / checks.length) * 100
      }))
    };

    fs.writeFileSync('fixzit-audit-results.json', JSON.stringify(jsonReport, null, 2));
    console.log('💾 Detailed JSON report saved: fixzit-audit-results.json');
    
    // Generate HTML report
    this.generateHTMLReport(jsonReport);
    console.log('💾 Interactive HTML report saved: fixzit-audit-report.html');
    console.log('');
    console.log('🎯 RECOMMENDATION:');
    if (results.coverage >= 80) {
      console.log('   ✅ Good implementation coverage! Focus on fixing high priority failures.');
    } else if (results.coverage >= 50) {
      console.log('   ⚠️  Moderate implementation. Address high priority issues first.');
    } else {
      console.log('   ❌ Low implementation coverage. Major components are missing.');
    }
    console.log('='.repeat(80));
  }

  // Generate HTML report
  private generateHTMLReport(jsonReport: any): void {
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIXZIT SOUQ Implementation Audit Report</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #0061A8 0%, #023047 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .header h1 { font-size: 2.5em; margin-bottom: 10px; }
        .header .subtitle { opacity: 0.9; font-size: 1.1em; }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
        }
        .summary-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            text-align: center;
        }
        .summary-card .value {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .summary-card .label {
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .summary-card.passed .value { color: #00A859; }
        .summary-card.failed .value { color: #dc3545; }
        .summary-card.warnings .value { color: #F6851F; }
        .summary-card.coverage .value { color: #0061A8; }
        
        .content { padding: 40px; }
        .section { margin-bottom: 40px; }
        .section h2 { color: #023047; margin-bottom: 20px; font-size: 1.8em; }
        
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .category-card {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
        }
        .category-card h3 { color: #0061A8; margin-bottom: 15px; }
        .category-progress {
            background: #e9ecef;
            border-radius: 10px;
            height: 20px;
            overflow: hidden;
            margin: 10px 0;
        }
        .category-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #00A859, #00BCF2);
            transition: width 0.3s ease;
        }
        
        .failure-item {
            background: #fff5f5;
            border-left: 4px solid #dc3545;
            padding: 15px;
            margin: 10px 0;
            border-radius: 0 8px 8px 0;
        }
        .failure-item h4 { color: #dc3545; margin-bottom: 8px; }
        .failure-item .expected { color: #666; font-size: 0.9em; margin: 5px 0; }
        .failure-item .actual { color: #333; font-size: 0.9em; margin: 5px 0; }
        .failure-item .file { color: #0061A8; font-size: 0.8em; font-family: monospace; }
        
        .warning-item {
            background: #fff8e1;
            border-left: 4px solid #F6851F;
            padding: 15px;
            margin: 10px 0;
            border-radius: 0 8px 8px 0;
        }
        .warning-item h4 { color: #F6851F; margin-bottom: 8px; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        th {
            background: #f8f9fa;
            color: #023047;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
        }
        tr:hover { background: #f8f9fa; }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
        }
        .status-pass { background: #d4edda; color: #155724; }
        .status-fail { background: #f8d7da; color: #721c24; }
        .status-warning { background: #fff3cd; color: #856404; }
        .status-not-found { background: #e2e3e5; color: #383d41; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏗️ FIXZIT SOUQ Implementation Audit</h1>
            <p class="subtitle">Complete verification of all requirements</p>
            <p style="margin-top: 10px; opacity: 0.8;">Generated on ${new Date().toLocaleString()}</p>
        </div>

        <div class="summary-grid">
            <div class="summary-card coverage">
                <div class="value">${jsonReport.coverage.toFixed(1)}%</div>
                <div class="label">Coverage</div>
            </div>
            <div class="summary-card passed">
                <div class="value">${jsonReport.passed}</div>
                <div class="label">Passed</div>
            </div>
            <div class="summary-card failed">
                <div class="value">${jsonReport.failed}</div>
                <div class="label">Failed</div>
            </div>
            <div class="summary-card warnings">
                <div class="value">${jsonReport.warnings}</div>
                <div class="label">Warnings</div>
            </div>
        </div>

        <div class="content">
            <div class="section">
                <h2>📊 Category Breakdown</h2>
                <div class="category-grid">
                    ${jsonReport.categoryBreakdown.map(cat => `
                    <div class="category-card">
                        <h3>${cat.category}</h3>
                        <div style="display: flex; justify-content: space-between; margin: 10px 0;">
                            <span>Passed: ${cat.passed}/${cat.total}</span>
                            <span>${cat.coverage.toFixed(0)}%</span>
                        </div>
                        <div class="category-progress">
                            <div class="category-progress-fill" style="width: ${cat.coverage}%"></div>
                        </div>
                    </div>
                    `).join('')}
                </div>
            </div>

            ${jsonReport.details.filter(d => d.status === 'fail' && d.severity === 'high').length > 0 ? `
            <div class="section">
                <h2>🔴 High Priority Failures</h2>
                ${jsonReport.details.filter(d => d.status === 'fail' && d.severity === 'high').map(item => `
                <div class="failure-item">
                    <h4>${item.id}: ${item.element}</h4>
                    <div class="expected"><strong>Expected:</strong> ${item.expected}</div>
                    <div class="actual"><strong>Actual:</strong> ${item.actual}</div>
                    <div class="file">${item.file} ${item.line ? `(line ${item.line})` : ''}</div>
                </div>
                `).join('')}
            </div>
            ` : ''}

            <div class="section">
                <h2>📋 All Results</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Element</th>
                            <th>Status</th>
                            <th>File</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${jsonReport.details.map(item => `
                        <tr>
                            <td>${item.id}</td>
                            <td>${item.category}</td>
                            <td>${item.element}</td>
                            <td><span class="status-badge status-${item.status}">${item.status.toUpperCase()}</span></td>
                            <td style="font-family: monospace; font-size: 0.9em;">${item.file}</td>
                        </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>`;
    
    fs.writeFileSync('fixzit-audit-report.html', html);
  }
}

// Main execution
async function main() {
  const projectPath = process.argv[2] || '.';
  console.log(`🚀 FIXZIT SOUQ Implementation Scanner v1.0`);
  console.log(`📁 Scanning project: ${path.resolve(projectPath)}\n`);
  
  const scanner = new FixzitImplementationScanner(projectPath);
  
  try {
    await scanner.runCompleteScan();
    scanner.generateReport();
  } catch (error) {
    console.error('❌ Scanner failed:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}