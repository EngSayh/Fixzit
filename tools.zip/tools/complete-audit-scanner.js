#!/usr/bin/env node

/**
 * FIXZIT COMPLETE AUDIT SCANNER
 * Comprehensive audit to find ALL errors, bugs, issues, and problems
 */

const fs = require('fs').promises;
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Audit configuration
const auditConfig = {
  projectRoot: process.cwd(),
  excludeDirs: ['node_modules', '.git', '.cache', '.pythonlibs', 'dist', 'build', '.next', 'coverage', '.replit'],
  fileExtensions: ['.js', '.jsx', '.ts', '.tsx', '.json', '.env', '.sql', '.py', '.html', '.css'],
  issues: [],
  stats: {
    filesScanned: 0,
    totalIssues: 0,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    warnings: 0
  }
};

class CompleteAuditScanner {
  constructor() {
    this.issues = [];
    this.fileCache = new Map();
  }

  // Main audit function
  async runCompleteAudit() {
    console.log(`\n🔍 COMPLETE FIXZIT AUDIT SCANNER\n`);
    console.log(`Starting comprehensive audit...\n`);

    try {
      // 1. File System Scan
      console.log('📁 Scanning project files...');
      await this.scanProjectFiles();
      
      // 2. Runtime Issues Analysis
      console.log('⚡ Analyzing runtime issues...');
      await this.analyzeRuntimeIssues();
      
      // 3. Code Quality Issues
      console.log('📝 Checking code quality...');
      await this.analyzeCodeQuality();
      
      // 4. Configuration Issues
      console.log('⚙️ Validating configuration...');
      await this.analyzeConfiguration();
      
      // 5. Dependencies Issues
      console.log('📦 Checking dependencies...');
      await this.analyzeDependencies();
      
      // 6. Security Vulnerabilities
      console.log('🔒 Security analysis...');
      await this.analyzeSecurityIssues();
      
      // 7. Performance Issues
      console.log('🚀 Performance analysis...');
      await this.analyzePerformance();
      
      // 8. Database Issues
      console.log('🗄️ Database analysis...');
      await this.analyzeDatabaseIssues();
      
      // 9. API and Routes Issues
      console.log('🔌 API routes analysis...');
      await this.analyzeAPIIssues();
      
      // 10. Frontend Issues
      console.log('🎨 Frontend analysis...');
      await this.analyzeFrontendIssues();
      
      // Generate comprehensive report
      await this.generateCompleteReport();
      
    } catch (error) {
      console.error(`❌ Audit Error: ${error.message}`);
    }
  }

  async scanProjectFiles() {
    const scanDir = async (dir) => {
      try {
        const items = await fs.readdir(dir, { withFileTypes: true });
        
        for (const item of items) {
          const fullPath = path.join(dir, item.name);
          
          if (item.isDirectory()) {
            if (!auditConfig.excludeDirs.includes(item.name) && !item.name.startsWith('.')) {
              await scanDir(fullPath);
            }
          } else if (item.isFile()) {
            const ext = path.extname(item.name);
            if (auditConfig.fileExtensions.includes(ext)) {
              await this.analyzeFile(fullPath);
              auditConfig.stats.filesScanned++;
            }
          }
        }
      } catch (err) {
        // Skip directories we can't access
      }
    };
    
    await scanDir(auditConfig.projectRoot);
    console.log(`  ✓ Scanned ${auditConfig.stats.filesScanned} files`);
  }

  async analyzeFile(filePath) {
    try {
      const content = await fs.readFile(filePath, 'utf-8');
      this.fileCache.set(filePath, content);
      
      // Look for common issues in each file
      await this.findCommonIssues(filePath, content);
      
    } catch (error) {
      this.addIssue({
        type: 'File System',
        severity: 'low',
        file: filePath,
        issue: `Cannot read file: ${error.message}`,
        line: 0
      });
    }
  }

  async findCommonIssues(filePath, content) {
    const lines = content.split('\n');
    
    lines.forEach((line, index) => {
      const lineNum = index + 1;
      
      // JavaScript/TypeScript specific issues
      if (filePath.match(/\.(js|jsx|ts|tsx)$/)) {
        // Console statements
        if (line.match(/console\.(log|error|warn|info|debug)/)) {
          this.addIssue({
            type: 'Code Quality',
            severity: 'low',
            file: filePath,
            issue: 'Console statement in code',
            line: lineNum,
            context: line.trim()
          });
        }
        
        // Debugger statements
        if (line.match(/\bdebugger\b/)) {
          this.addIssue({
            type: 'Code Quality',
            severity: 'high',
            file: filePath,
            issue: 'Debugger statement left in code',
            line: lineNum,
            context: line.trim()
          });
        }
        
        // TODO/FIXME comments
        if (line.match(/(TODO|FIXME|HACK|XXX)/i)) {
          this.addIssue({
            type: 'Code Quality',
            severity: 'low',
            file: filePath,
            issue: 'Unresolved TODO/FIXME comment',
            line: lineNum,
            context: line.trim()
          });
        }
        
        // Error handling issues
        if (line.match(/catch\s*\([^)]*\)\s*\{\s*\}/)) {
          this.addIssue({
            type: 'Error Handling',
            severity: 'medium',
            file: filePath,
            issue: 'Empty catch block',
            line: lineNum,
            context: line.trim()
          });
        }
        
        // Hardcoded values that should be configurable
        if (line.match(/(localhost|127\.0\.0\.1|password.*=.*['"]\w+['"])/)) {
          this.addIssue({
            type: 'Configuration',
            severity: 'medium',
            file: filePath,
            issue: 'Hardcoded configuration value',
            line: lineNum,
            context: line.trim()
          });
        }
      }
      
      // HTML specific issues
      if (filePath.endsWith('.html')) {
        // Missing alt attributes
        if (line.match(/<img(?![^>]*alt=)/i)) {
          this.addIssue({
            type: 'Accessibility',
            severity: 'medium',
            file: filePath,
            issue: 'Image missing alt attribute',
            line: lineNum,
            context: line.trim()
          });
        }
        
        // Inline styles
        if (line.match(/style\s*=\s*['"]/)) {
          this.addIssue({
            type: 'Code Quality',
            severity: 'low',
            file: filePath,
            issue: 'Inline styles detected',
            line: lineNum,
            context: line.trim()
          });
        }
      }
    });
  }

  async analyzeRuntimeIssues() {
    // Check workflow logs for errors
    const logFiles = [
      '/tmp/logs/Fixzit_Platform_20250914_153601_990.log',
      '/tmp/logs/Fixzit_Souq_Server_20250914_153211_850.log'
    ];
    
    for (const logFile of logFiles) {
      try {
        const content = await fs.readFile(logFile, 'utf-8');
        const lines = content.split('\n');
        
        lines.forEach((line, index) => {
          if (line.includes('error:') || line.includes('Error:') || line.includes('ERROR')) {
            this.addIssue({
              type: 'Runtime Error',
              severity: 'high',
              file: logFile,
              issue: 'Runtime error in logs',
              line: index + 1,
              context: line.trim()
            });
          }
          
          if (line.includes('⚠️') || line.includes('warning:') || line.includes('Warning:')) {
            this.addIssue({
              type: 'Runtime Warning',
              severity: 'medium',
              file: logFile,
              issue: 'Runtime warning in logs',
              line: index + 1,
              context: line.trim()
            });
          }
          
          if (line.includes('ECONNREFUSED') || line.includes('connection refused')) {
            this.addIssue({
              type: 'Connection Issue',
              severity: 'high',
              file: logFile,
              issue: 'Service connection refused',
              line: index + 1,
              context: line.trim()
            });
          }
        });
        
      } catch (err) {
        // Log file might not exist
      }
    }
    
    console.log(`  ✓ Analyzed runtime logs`);
  }

  async analyzeCodeQuality() {
    // Check for TypeScript errors if available
    try {
      const { stdout, stderr } = await execPromise('npx tsc --noEmit --pretty false 2>&1 || true', { timeout: 10000 });
      const output = stderr || stdout;
      
      if (output && output.includes('error TS')) {
        const errors = output.split('\n').filter(line => line.includes('error TS'));
        errors.forEach(error => {
          this.addIssue({
            type: 'TypeScript Error',
            severity: 'high',
            file: 'TypeScript Compiler',
            issue: error.trim(),
            line: 0
          });
        });
      }
    } catch (err) {
      // TypeScript might not be available
    }
    
    console.log(`  ✓ Code quality analysis complete`);
  }

  async analyzeConfiguration() {
    // Check for missing environment files
    const requiredFiles = ['.env', 'package.json', 'server.js'];
    
    for (const file of requiredFiles) {
      try {
        await fs.access(file);
      } catch (err) {
        this.addIssue({
          type: 'Configuration',
          severity: 'critical',
          file: 'Project Root',
          issue: `Missing required file: ${file}`,
          line: 0
        });
      }
    }
    
    // Check package.json for issues
    try {
      const packageJson = JSON.parse(await fs.readFile('package.json', 'utf-8'));
      
      if (!packageJson.scripts || !packageJson.scripts.start) {
        this.addIssue({
          type: 'Configuration',
          severity: 'medium',
          file: 'package.json',
          issue: 'Missing start script',
          line: 0
        });
      }
      
      if (!packageJson.dependencies || Object.keys(packageJson.dependencies).length === 0) {
        this.addIssue({
          type: 'Configuration',
          severity: 'medium',
          file: 'package.json',
          issue: 'No dependencies defined',
          line: 0
        });
      }
      
    } catch (err) {
      this.addIssue({
        type: 'Configuration',
        severity: 'high',
        file: 'package.json',
        issue: `Invalid package.json: ${err.message}`,
        line: 0
      });
    }
    
    console.log(`  ✓ Configuration analysis complete`);
  }

  async analyzeDependencies() {
    try {
      // Check for vulnerabilities
      const { stdout } = await execPromise('npm audit --json 2>&1 || echo "{}"', { timeout: 15000 });
      const audit = JSON.parse(stdout);
      
      if (audit.metadata && audit.metadata.vulnerabilities) {
        const vulns = audit.metadata.vulnerabilities;
        
        Object.keys(vulns).forEach(severity => {
          const count = vulns[severity];
          if (count > 0) {
            this.addIssue({
              type: 'Dependencies',
              severity: severity,
              file: 'npm packages',
              issue: `${count} ${severity} vulnerabilities in dependencies`,
              line: 0
            });
          }
        });
      }
    } catch (err) {
      this.addIssue({
        type: 'Dependencies',
        severity: 'medium',
        file: 'npm audit',
        issue: `Cannot run npm audit: ${err.message}`,
        line: 0
      });
    }
    
    console.log(`  ✓ Dependencies analysis complete`);
  }

  async analyzeSecurityIssues() {
    // This is covered in the main scanner, just add summary
    console.log(`  ✓ Security analysis complete (see main security scanner)`);
  }

  async analyzePerformance() {
    // Check for performance issues
    for (const [filePath, content] of this.fileCache) {
      if (filePath.match(/\.(js|jsx|ts|tsx)$/)) {
        // Large files
        const lines = content.split('\n');
        if (lines.length > 1000) {
          this.addIssue({
            type: 'Performance',
            severity: 'medium',
            file: filePath,
            issue: `Large file (${lines.length} lines) - consider splitting`,
            line: 0
          });
        }
        
        // Potential memory leaks
        if (content.match(/addEventListener(?![\s\S]*removeEventListener)/)) {
          this.addIssue({
            type: 'Performance',
            severity: 'medium',
            file: filePath,
            issue: 'Event listener without removal (potential memory leak)',
            line: 0
          });
        }
      }
    }
    
    console.log(`  ✓ Performance analysis complete`);
  }

  async analyzeDatabaseIssues() {
    // Check for database-related issues
    for (const [filePath, content] of this.fileCache) {
      if (content.includes('SELECT') || content.includes('INSERT') || content.includes('UPDATE') || content.includes('DELETE')) {
        // SQL injection patterns
        if (content.match(/\$\{[^}]*\}.*(?:SELECT|INSERT|UPDATE|DELETE)/gi)) {
          this.addIssue({
            type: 'Database Security',
            severity: 'critical',
            file: filePath,
            issue: 'Potential SQL injection vulnerability',
            line: 0
          });
        }
      }
    }
    
    console.log(`  ✓ Database analysis complete`);
  }

  async analyzeAPIIssues() {
    // Check API routes for common issues
    const apiFiles = ['server.js', 'routes/auth.js', 'routes/dashboard.js'];
    
    for (const apiFile of apiFiles) {
      try {
        const content = await fs.readFile(apiFile, 'utf-8');
        
        // Missing error handling
        if (content.includes('async') && !content.includes('catch')) {
          this.addIssue({
            type: 'API Error Handling',
            severity: 'high',
            file: apiFile,
            issue: 'Async operations without proper error handling',
            line: 0
          });
        }
        
        // Missing rate limiting
        if (content.includes('app.post') && !content.includes('rateLimit')) {
          this.addIssue({
            type: 'API Security',
            severity: 'medium',
            file: apiFile,
            issue: 'POST endpoints without rate limiting',
            line: 0
          });
        }
        
      } catch (err) {
        // File might not exist
      }
    }
    
    console.log(`  ✓ API analysis complete`);
  }

  async analyzeFrontendIssues() {
    // Check frontend files for issues
    const frontendFile = 'public/index.html';
    
    try {
      const content = await fs.readFile(frontendFile, 'utf-8');
      
      // Missing security headers
      if (!content.includes('Content-Security-Policy')) {
        this.addIssue({
          type: 'Frontend Security',
          severity: 'medium',
          file: frontendFile,
          issue: 'Missing Content Security Policy',
          line: 0
        });
      }
      
      // Accessibility issues
      if (!content.includes('lang=')) {
        this.addIssue({
          type: 'Accessibility',
          severity: 'medium',
          file: frontendFile,
          issue: 'Missing language attribute on HTML element',
          line: 0
        });
      }
      
    } catch (err) {
      this.addIssue({
        type: 'Frontend',
        severity: 'medium',
        file: 'Frontend Analysis',
        issue: 'Cannot analyze frontend files',
        line: 0
      });
    }
    
    console.log(`  ✓ Frontend analysis complete`);
  }

  addIssue(issue) {
    this.issues.push(issue);
    auditConfig.stats.totalIssues++;
    
    switch(issue.severity) {
      case 'critical': auditConfig.stats.critical++; break;
      case 'high': auditConfig.stats.high++; break;
      case 'medium': auditConfig.stats.medium++; break;
      case 'low': auditConfig.stats.low++; break;
      default: auditConfig.stats.warnings++; break;
    }
  }

  async generateCompleteReport() {
    console.log(`\n📊 COMPLETE AUDIT RESULTS\n`);
    
    console.log(`Files Scanned: ${auditConfig.stats.filesScanned}`);
    console.log(`Total Issues Found: ${auditConfig.stats.totalIssues}`);
    console.log(``);
    
    console.log(`Issues by Severity:`);
    console.log(`  🔴 Critical: ${auditConfig.stats.critical}`);
    console.log(`  🟠 High: ${auditConfig.stats.high}`);
    console.log(`  🟡 Medium: ${auditConfig.stats.medium}`);
    console.log(`  🟢 Low: ${auditConfig.stats.low}`);
    console.log(`  ⚠️ Warnings: ${auditConfig.stats.warnings}`);
    console.log(``);
    
    // Group issues by type for summary
    const issuesByType = {};
    this.issues.forEach(issue => {
      if (!issuesByType[issue.type]) {
        issuesByType[issue.type] = [];
      }
      issuesByType[issue.type].push(issue);
    });
    
    console.log(`Issues by Category:`);
    Object.keys(issuesByType).forEach(type => {
      console.log(`  📁 ${type}: ${issuesByType[type].length} issues`);
    });
    console.log(``);
    
    // Show critical and high issues first
    const criticalAndHigh = this.issues.filter(issue => 
      issue.severity === 'critical' || issue.severity === 'high'
    );
    
    if (criticalAndHigh.length > 0) {
      console.log(`🚨 CRITICAL & HIGH PRIORITY ISSUES (showing first 10):`);
      criticalAndHigh.slice(0, 10).forEach((issue, index) => {
        console.log(`  ${index + 1}. [${issue.severity.toUpperCase()}] ${issue.type}: ${issue.issue}`);
        console.log(`     📁 ${issue.file}${issue.line > 0 ? ` (line ${issue.line})` : ''}`);
        if (issue.context) {
          console.log(`     💡 ${issue.context}`);
        }
        console.log(``);
      });
    }
    
    // Save detailed report
    const detailedReport = {
      timestamp: new Date().toISOString(),
      summary: auditConfig.stats,
      issuesByType,
      allIssues: this.issues.map(issue => ({
        ...issue,
        timestamp: new Date().toISOString()
      }))
    };
    
    await fs.writeFile('fixzit-complete-audit-report.json', JSON.stringify(detailedReport, null, 2));
    console.log(`✅ Complete audit report saved to: fixzit-complete-audit-report.json`);
    
    // Calculate health score
    const totalPossibleIssues = auditConfig.stats.filesScanned * 10; // Rough estimate
    const healthScore = Math.max(0, Math.min(100, 100 - (auditConfig.stats.totalIssues / totalPossibleIssues) * 100));
    console.log(`\n🏥 Overall System Health Score: ${Math.round(healthScore)}/100`);
  }
}

// Run the complete audit
const auditScanner = new CompleteAuditScanner();
auditScanner.runCompleteAudit().catch(console.error);