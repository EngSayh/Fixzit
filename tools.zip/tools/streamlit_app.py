"""
FIXZIT - Main Entry Point
Simple clean routing
"""

import streamlit as st

# Page config MUST be first
st.set_page_config(
    page_title="Fixzit - شركة خدماتي الشاملة",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Simple routing logic
st.markdown("# Welcome to Fixzit")
st.markdown("Redirecting to login...")

# Always go to login page
st.switch_page("pages/00_Login.py")
