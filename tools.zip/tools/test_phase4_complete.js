// PHASE 4 COMPLETE - COMPREHENSIVE INTEGRATION TEST
// File: test_phase4_complete.js

const axios = require('axios');

class Phase4IntegrationTester {
  constructor() {
    this.baseUrl = 'http://localhost:5000';
    this.authToken = null;
    this.testResults = [];
  }

  // Helper method to add test results
  addResult(testName, success, message, data = null) {
    this.testResults.push({
      test: testName,
      success,
      message,
      data,
      timestamp: new Date()
    });
    
    const status = success ? '✅' : '❌';
    console.log(`${status} ${testName}: ${message}`);
  }

  // Authenticate to get access token
  async authenticate() {
    try {
      const response = await axios.post(`${this.baseUrl}/api/auth/login`, {
        email: 'admin@fixzit.com',
        password: 'Admin@1234'
      });

      if (response.data.success) {
        this.authToken = response.data.token;
        this.addResult('Authentication', true, 'Admin login successful');
        return true;
      } else {
        this.addResult('Authentication', false, 'Login failed: ' + response.data.message);
        return false;
      }
    } catch (error) {
      this.addResult('Authentication', false, 'Login error: ' + error.message);
      return false;
    }
  }

  // Get authorization headers
  getAuthHeaders() {
    return {
      'Authorization': `Bearer ${this.authToken}`,
      'Content-Type': 'application/json'
    };
  }

  // Test System Health
  async testSystemHealth() {
    try {
      const response = await axios.get(`${this.baseUrl}/health`);
      
      if (response.data.status === 'ok') {
        this.addResult('System Health', true, 'System health check passed', response.data);
        
        // Check integration services
        const integrations = response.data.integrations;
        if (integrations) {
          this.addResult('SMS Service Health', integrations.sms?.enabled || false, 
            `SMS ${integrations.sms?.provider || 'not configured'}`);
          this.addResult('Email Service Health', integrations.email?.enabled || false, 
            `Email ${integrations.email?.provider || 'not configured'}`);
          this.addResult('Maps Service Health', integrations.maps?.configured || false, 
            `Maps ${integrations.maps?.enabled ? 'enabled' : 'disabled'}`);
          this.addResult('WebSocket Service Health', integrations.websocket?.enabled || false, 
            `WebSocket with ${integrations.websocket?.connectedUsers || 0} users`);
        }
        
        return true;
      } else {
        this.addResult('System Health', false, 'Health check failed');
        return false;
      }
    } catch (error) {
      this.addResult('System Health', false, 'Health check error: ' + error.message);
      return false;
    }
  }

  // Test Integration Health Endpoint
  async testIntegrationHealth() {
    try {
      const response = await axios.get(`${this.baseUrl}/api/integrations/health`, {
        headers: this.getAuthHeaders()
      });

      if (response.data.success) {
        const health = response.data.health;
        this.addResult('Integration Health Endpoint', true, `Overall status: ${health.overall}`, health);
        
        // Test individual services
        const services = health.services;
        this.addResult('SMS Integration Health', 
          services.sms?.valid !== false, 
          services.sms?.errors ? services.sms.errors.join(', ') : 'SMS service ready');
        
        this.addResult('Email Integration Health', 
          services.email?.success !== false, 
          services.email?.message || 'Email service ready');
        
        this.addResult('Maps Integration Health', 
          services.maps?.enabled || false, 
          services.maps?.message || 'Maps service status unknown');
        
        this.addResult('WebSocket Integration Health', 
          services.websocket?.enabled || false, 
          `WebSocket ${services.websocket?.connected ? 'connected' : 'not connected'}`);
        
        return true;
      } else {
        this.addResult('Integration Health Endpoint', false, 'Health endpoint failed');
        return false;
      }
    } catch (error) {
      this.addResult('Integration Health Endpoint', false, 'Health endpoint error: ' + error.message);
      return false;
    }
  }

  // Test SMS Service
  async testSMSService() {
    try {
      // Test SMS configuration
      const testResponse = await axios.get(`${this.baseUrl}/api/integrations/sms/test`, {
        headers: this.getAuthHeaders()
      });

      if (testResponse.data.success !== false) {
        this.addResult('SMS Configuration Test', true, 'SMS service configured');
        
        // Test SMS send (local mode)
        const sendResponse = await axios.post(`${this.baseUrl}/api/integrations/sms/send`, {
          to: '+966501234567',
          message: 'FIXZIT Phase 4 SMS integration test',
          type: 'test'
        }, {
          headers: this.getAuthHeaders()
        });

        if (sendResponse.data.success) {
          this.addResult('SMS Send Test', true, 'SMS sent successfully', sendResponse.data.result);
        } else {
          this.addResult('SMS Send Test', false, 'SMS send failed: ' + sendResponse.data.message);
        }
      } else {
        this.addResult('SMS Configuration Test', false, 'SMS not configured: ' + testResponse.data.message);
      }
    } catch (error) {
      this.addResult('SMS Service Test', false, 'SMS test error: ' + error.message);
    }
  }

  // Test Email Service
  async testEmailService() {
    try {
      // Test email configuration
      const testResponse = await axios.get(`${this.baseUrl}/api/integrations/email/test`, {
        headers: this.getAuthHeaders()
      });

      if (testResponse.data.success !== false) {
        this.addResult('Email Configuration Test', true, 'Email service configured');
        
        // Test email send (local mode)
        const sendResponse = await axios.post(`${this.baseUrl}/api/integrations/email/send`, {
          to: 'test@fixzit.com',
          subject: 'FIXZIT Phase 4 Email Integration Test',
          html: '<h3>Email Integration Test</h3><p>Phase 4 email service is working correctly!</p>',
          text: 'Email Integration Test - Phase 4 email service is working correctly!'
        }, {
          headers: this.getAuthHeaders()
        });

        if (sendResponse.data.success) {
          this.addResult('Email Send Test', true, 'Email sent successfully', sendResponse.data.result);
        } else {
          this.addResult('Email Send Test', false, 'Email send failed: ' + sendResponse.data.message);
        }
      } else {
        this.addResult('Email Configuration Test', false, 'Email not configured: ' + testResponse.data.message);
      }
    } catch (error) {
      this.addResult('Email Service Test', false, 'Email test error: ' + error.message);
    }
  }

  // Test Maps Service
  async testMapsService() {
    try {
      // Test maps health
      const healthResponse = await axios.get(`${this.baseUrl}/api/integrations/maps/test`, {
        headers: this.getAuthHeaders()
      });

      if (healthResponse.data.enabled !== false) {
        this.addResult('Maps Configuration Test', true, 'Maps service available');
        
        // Test geocoding
        const geocodeResponse = await axios.post(`${this.baseUrl}/api/integrations/maps/geocode`, {
          address: 'Riyadh, Saudi Arabia'
        }, {
          headers: this.getAuthHeaders()
        });

        if (geocodeResponse.data.success) {
          this.addResult('Maps Geocoding Test', true, 'Geocoding successful', geocodeResponse.data.coordinates);
          
          // Test distance calculation
          const distanceResponse = await axios.post(`${this.baseUrl}/api/integrations/maps/distance`, {
            origin: { lat: 24.7136, lng: 46.6753 },
            destination: { lat: 24.7500, lng: 46.7000 }
          }, {
            headers: this.getAuthHeaders()
          });

          if (distanceResponse.data.success) {
            this.addResult('Maps Distance Test', true, 'Distance calculation successful', distanceResponse.data.distance);
          } else {
            this.addResult('Maps Distance Test', false, 'Distance calculation failed');
          }
        } else {
          this.addResult('Maps Geocoding Test', false, 'Geocoding failed');
        }
      } else {
        this.addResult('Maps Configuration Test', false, 'Maps service not configured');
      }
    } catch (error) {
      this.addResult('Maps Service Test', false, 'Maps test error: ' + error.message);
    }
  }

  // Test WebSocket Service
  async testWebSocketService() {
    try {
      // Test WebSocket status
      const statusResponse = await axios.get(`${this.baseUrl}/api/integrations/websocket/status`, {
        headers: this.getAuthHeaders()
      });

      if (statusResponse.data.success) {
        const wsStatus = statusResponse.data.websocket;
        this.addResult('WebSocket Status Test', wsStatus.enabled, 
          `WebSocket ${wsStatus.connected ? 'connected' : 'not connected'} with ${wsStatus.connectedUsers} users`);
        
        // Test broadcast functionality
        const broadcastResponse = await axios.post(`${this.baseUrl}/api/integrations/websocket/broadcast`, {
          organizationId: 'test-org',
          event: 'phase4_test',
          data: { message: 'Phase 4 WebSocket test broadcast', timestamp: new Date() }
        }, {
          headers: this.getAuthHeaders()
        });

        if (broadcastResponse.data.success) {
          this.addResult('WebSocket Broadcast Test', true, 'Broadcast sent successfully');
        } else {
          this.addResult('WebSocket Broadcast Test', false, 'Broadcast failed');
        }
      } else {
        this.addResult('WebSocket Status Test', false, 'WebSocket status check failed');
      }
    } catch (error) {
      this.addResult('WebSocket Service Test', false, 'WebSocket test error: ' + error.message);
    }
  }

  // Test Database Connectivity and Core Features
  async testDatabaseConnectivity() {
    try {
      // Test property listing (core feature)
      const propertiesResponse = await axios.get(`${this.baseUrl}/api/properties`, {
        headers: this.getAuthHeaders()
      });

      if (propertiesResponse.status === 200) {
        this.addResult('Database Connectivity', true, 'Database connection and property API working');
        
        // Test marketplace vendor listing
        const vendorsResponse = await axios.get(`${this.baseUrl}/api/vendors`, {
          headers: this.getAuthHeaders()
        });

        if (vendorsResponse.status === 200) {
          this.addResult('Marketplace Database', true, 'Marketplace vendor API working');
        } else {
          this.addResult('Marketplace Database', false, 'Marketplace vendor API failed');
        }
      } else {
        this.addResult('Database Connectivity', false, 'Database connection failed');
      }
    } catch (error) {
      this.addResult('Database Connectivity', false, 'Database test error: ' + error.message);
    }
  }

  // Run complete Phase 4 test suite
  async runCompleteTest() {
    console.log('🚀 STARTING PHASE 4 COMPLETE INTEGRATION TEST');
    console.log('='.repeat(60));
    
    // Authenticate first
    const authSuccess = await this.authenticate();
    if (!authSuccess) {
      console.log('❌ Authentication failed - stopping tests');
      return this.getTestSummary();
    }

    // Run all tests
    await this.testSystemHealth();
    await this.testIntegrationHealth();
    await this.testDatabaseConnectivity();
    await this.testSMSService();
    await this.testEmailService();
    await this.testMapsService();
    await this.testWebSocketService();

    console.log('\n' + '='.repeat(60));
    console.log('🏁 PHASE 4 TEST COMPLETE');
    
    return this.getTestSummary();
  }

  // Get test summary
  getTestSummary() {
    const totalTests = this.testResults.length;
    const passedTests = this.testResults.filter(r => r.success).length;
    const failedTests = totalTests - passedTests;
    const successRate = ((passedTests / totalTests) * 100).toFixed(1);

    const summary = {
      totalTests,
      passedTests,
      failedTests,
      successRate: `${successRate}%`,
      overallStatus: failedTests === 0 ? 'ALL TESTS PASSED ✅' : 
                    successRate >= 80 ? 'MOSTLY SUCCESSFUL ⚡' : 'NEEDS ATTENTION ⚠️',
      details: this.testResults,
      completionTimestamp: new Date()
    };

    console.log('\n📊 TEST SUMMARY:');
    console.log(`✅ Passed: ${passedTests}`);
    console.log(`❌ Failed: ${failedTests}`);
    console.log(`📈 Success Rate: ${successRate}%`);
    console.log(`🎯 Status: ${summary.overallStatus}`);

    if (failedTests > 0) {
      console.log('\n❌ FAILED TESTS:');
      this.testResults.filter(r => !r.success).forEach(test => {
        console.log(`   - ${test.test}: ${test.message}`);
      });
    }

    return summary;
  }
}

// Run the test if this file is executed directly
async function runPhase4Test() {
  const tester = new Phase4IntegrationTester();
  const results = await tester.runCompleteTest();
  
  // Save results to file
  const fs = require('fs');
  fs.writeFileSync('phase4_test_results.json', JSON.stringify(results, null, 2));
  console.log('\n💾 Results saved to phase4_test_results.json');
  
  return results;
}

// Export for use in other files
module.exports = { Phase4IntegrationTester, runPhase4Test };

// Run if executed directly
if (require.main === module) {
  runPhase4Test().catch(console.error);
}