"""
FIXZIT - Home Page
Redirects to appropriate page based on authentication
"""

import streamlit as st
from utils.session_init import initialize_session_state

# Page configuration
st.set_page_config(
    page_title="Fixzit - شركة خدماتي الشاملة",
    page_icon="🔧",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# Initialize session
initialize_session_state()

# Check authentication and redirect
if not st.session_state.get("authenticated", False):
    # Redirect to login
    st.switch_page("pages/00_Login.py")
else:
    # Redirect to dashboard
    st.switch_page("pages/01_Dashboard_WorkOS.py")
