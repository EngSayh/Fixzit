from __future__ import annotations
import time
import json
from pathlib import Path

ART = Path("artifacts")
ART.mkdir(exist_ok=True)


def log_event(event: str, **kw):
    row = {"ts": time.time(), "event": event}
    row.update(kw)
    with (ART / "metrics.log").open("a", encoding="utf-8") as f:
        f.write(json.dumps(row) + "\n")
