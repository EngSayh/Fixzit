#!/usr/bin/env python3
"""
Simple verification runner for Fixzit
Run with: python3 run_verify.py
"""

import subprocess
import sys


def main():
    """Run verification suite"""
    print("=" * 60)
    print("FIXZIT VERIFICATION LAUNCHER")
    print("=" * 60)
    print("\nSelect verification mode:")
    print("1. Quick check (existing script)")
    print("2. Full verification with auto-fix")
    print("3. Full verification without auto-fix")
    print("4. Run tests only")
    print("5. Exit")

    choice = input("\nEnter choice (1-5): ").strip()

    if choice == "1":
        print("\n🚀 Running quick verification...")
        result = subprocess.run([sys.executable, "scripts/fixzit_verify.py"])
        sys.exit(result.returncode)

    elif choice == "2":
        print("\n🚀 Running full verification with auto-fix...")
        result = subprocess.run([sys.executable, "scripts/verify_all.py"])
        sys.exit(result.returncode)

    elif choice == "3":
        print("\n🚀 Running full verification without auto-fix...")
        result = subprocess.run([sys.executable, "scripts/verify_all.py", "--no-fix"])
        sys.exit(result.returncode)

    elif choice == "4":
        print("\n🧪 Running tests...")
        # Install pytest if needed
        try:
            import importlib.util

            if importlib.util.find_spec("pytest") is None:
                print("Installing pytest...")
                subprocess.run([sys.executable, "-m", "pip", "install", "pytest"])
        except ImportError:
            print("Installing pytest...")
            subprocess.run([sys.executable, "-m", "pip", "install", "pytest"])

        result = subprocess.run([sys.executable, "-m", "pytest", "-v", "tests/"])
        sys.exit(result.returncode)

    elif choice == "5":
        print("\n👋 Goodbye!")
        sys.exit(0)

    else:
        print("\n❌ Invalid choice")
        sys.exit(1)


if __name__ == "__main__":
    main()
