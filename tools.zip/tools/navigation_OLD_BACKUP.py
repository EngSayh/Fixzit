"""
Fixzit Navigation - Ultra Simple Clean Lines Only
"""

import streamlit as st
from typing import Optional, Tuple
from nav_config import APP_NAME, BRAND, NAVIGATION


def init_navigation_state():
    if "current_page" not in st.session_state:
        st.session_state.current_page = "dashboard"
    if "expanded_groups" not in st.session_state:
        st.session_state.expanded_groups = set()
    if "sidebar_collapsed" not in st.session_state:
        st.session_state.sidebar_collapsed = False


def render_sidebar(
    auth_ok: bool = True, user_roles: Optional[set] = None
) -> Tuple[Optional[str], Optional[str]]:
    """Universal cross-platform sidebar with comprehensive device support"""
    init_navigation_state()

    # Cross-platform styles will be applied via CSS below

    if not auth_ok:
        st.markdown(
            '<style>section[data-testid="stSidebar"] {display: none !important;}</style>',
            unsafe_allow_html=True,
        )
        return None, None

    # Check language for RTL support
    is_rtl = st.session_state.get("language", "en") == "ar"

    # Get collapsed state
    is_collapsed = st.session_state.get("sidebar_collapsed", False)

    # Ultra-simple CSS with RTL support
    rtl_styles = ""
    if is_rtl:
        # RTL specific styles - move sidebar to right
        rtl_styles = """
        /* RTL Layout - Move sidebar to right */
        section[data-testid="stSidebar"] {
            right: 0 !important;
            left: auto !important;
            direction: rtl !important;
        }
        
        /* RTL Responsive Adjustments - handled by main CSS */
        
        @media (max-width: 767px) {
            section[data-testid="stSidebar"] {
                right: -100% !important;
                left: auto !important;
            }
            section[data-testid="stSidebar"].mobile-open {
                right: 0 !important;
            }
        }
        
        /* RTL text alignment */
        section[data-testid="stSidebar"] .stButton > button {
            text-align: right !important;
        }
        """

    st.markdown(
        f"""
    <style>
    /* Simple Sidebar System */
    section[data-testid="stSidebar"] {{
        background: {BRAND['white']} !important;
        min-height: 100vh !important;
        box-shadow: 2px 0 8px rgba(0,0,0,0.1) !important;
        z-index: 999 !important;
    }}
    
    section[data-testid="stSidebar"] > div {{
        background: {BRAND['white']} !important;
        padding: 0 !important;
        height: 100% !important;
    }}
    
    /* Hide Streamlit defaults */
    section[data-testid="stSidebar"] [data-testid="stSidebarNav"] {{ display: none !important; }}
    button[data-testid="collapsedControl"] {{ display: none !important; }}
    
    /* Main content margin */
    .main .block-container {{
        margin-{("right" if is_rtl else "left")}: {("80px" if is_collapsed else "260px")} !important;
        padding: 2rem 3rem !important;
        max-width: calc(100vw - {("80px" if is_collapsed else "260px")}) !important;
    }}
    
    /* Platform-Specific Optimizations */
    
    /* iOS Safari */
    @supports (-webkit-appearance: none) {{
        section[data-testid="stSidebar"] {{
            -webkit-overflow-scrolling: touch !important;
        }}
        
        @media (max-width: 767px) {{
            section[data-testid="stSidebar"] {{
                height: 100vh !important;
                height: -webkit-fill-available !important;
            }}
            
            .main .block-container {{
                padding-top: max(4rem, env(safe-area-inset-top) + 1rem) !important;
                padding-bottom: max(1rem, env(safe-area-inset-bottom)) !important;
            }}
        }}
    }}
    
    /* Android Chrome & Others */
    @media (hover: none) and (pointer: coarse) {{
        section[data-testid="stSidebar"] .stButton > button {{
            min-height: 48px !important;
            touch-action: manipulation !important;
        }}
    }}
    
    /* Windows Edge Mobile */
    @media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {{
        section[data-testid="stSidebar"] {{
            -ms-overflow-style: -ms-autohiding-scrollbar !important;
        }}
    }}
    
    {rtl_styles}
    
    /* Sidebar Navigation Button Styling */
    section[data-testid="stSidebar"] .stButton > button {{
        background: transparent !important;
        border: none !important;
        border-radius: 8px !important;
        color: {BRAND['navy']} !important;
        padding: 12px 16px !important;
        margin: 4px 8px !important;
        text-align: left !important;
        width: calc(100% - 16px) !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        display: block !important;
    }}
    
    /* Hover state for navigation buttons */
    section[data-testid="stSidebar"] .stButton > button:hover {{
        background: {BRAND['orange_light']} !important;
        color: {BRAND['navy']} !important;
        transform: translateX(4px) !important;
    }}
    
    /* Active/Focus state */
    section[data-testid="stSidebar"] .stButton > button:active,
    section[data-testid="stSidebar"] .stButton > button:focus {{
        background: {BRAND['orange']} !important;
        color: white !important;
        outline: none !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1) !important;
    }}
    
    /* Main content responsive margin handled by media queries above */
    
    /* Collapsed sidebar styles */
    .sidebar-collapsed .nav-text,
    .sidebar-collapsed .app-name {{
        display: none !important;
    }}
    
    .sidebar-collapsed .nav-group-header {{
        justify-content: center !important;
    }}
    
    .sidebar-collapsed .nav-item {{
        justify-content: center !important;
        padding-left: 8px !important;
        padding-right: 8px !important;
    }}
    
    /* Toggle button styling */
    .sidebar-toggle {{
        position: absolute !important;
        top: 10px !important;
        right: -15px !important;
        width: 30px !important;
        height: 30px !important;
        background: {BRAND['orange']} !important;
        color: white !important;
        border-radius: 50% !important;
        border: none !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        z-index: 1000 !important;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2) !important;
    }}
    
    .sidebar-toggle:hover {{
        background: {BRAND['orange_dark']} !important;
    }}
    
    /* Sidebar header positioning */
    .sidebar-header {{
        position: relative !important;
    }}
    </style>
    """,
        unsafe_allow_html=True,
    )

    # Logo with icon - same size as login screen
    try:
        import base64
        from pathlib import Path

        # Try to load the Fixzit logo (PNG format)
        logo_path = Path("assets/fixzit_logo.png")
        if logo_path.exists():
            with open(logo_path, "rb") as f:
                logo_data = base64.b64encode(f.read()).decode()
                logo_html = f'<img src="data:image/png;base64,{logo_data}" style="height: 120px; width: auto; margin-right: 10px; vertical-align: middle; object-fit: contain;">'
        else:
            # Fallback to JPG format
            logo_path_jpg = Path("assets/fixzit_logo.jpg")
            if logo_path_jpg.exists():
                with open(logo_path_jpg, "rb") as f:
                    logo_data = base64.b64encode(f.read()).decode()
                    logo_html = f'<img src="data:image/jpeg;base64,{logo_data}" style="height: 120px; width: auto; margin-right: 10px; vertical-align: middle; object-fit: contain;">'
            else:
                logo_html = "🔧 "
    except Exception:
        logo_html = "🔧 "

    # Simple mobile menu for small screens
    st.markdown(
        f"""
    @media (max-width: 767px) {{
        section[data-testid="stSidebar"] {{
            transform: translateX(-100%) !important;
            transition: transform 0.3s ease !important;
        }}
        
        .main .block-container {{
            margin: 0 !important;
            padding: 1rem !important;
            max-width: 100vw !important;
        }}
    }}
    
    
    <style>
    /* Enhanced Resolution & Performance Optimizations */
    
    /* Dynamic CSS Variables for Device Optimization */
    :root {{
        --device-scale: 1;
        --pixel-ratio: 1;
        --viewport-width: 100vw;
        --viewport-height: 100vh;
    }}
    
    /* High DPI / Retina Display Optimizations */
    .resolution-hidpi {{
        image-rendering: -webkit-optimize-contrast;
        image-rendering: crisp-edges;
    }}
    
    .resolution-4k {{
        /* 4K specific optimizations */
        font-size: calc(1rem * var(--device-scale));
        line-height: 1.6;
    }}
    
    .resolution-4k section[data-testid="stSidebar"] {{
        width: calc(320px * var(--device-scale)) !important;
        font-size: calc(16px * var(--device-scale));
    }}
    
    .resolution-2k {{
        font-size: calc(1rem * 1.1);
    }}
    
    /* Platform-specific optimizations */
    .platform-ios {{
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -webkit-tap-highlight-color: transparent;
    }}
    
    .platform-android {{
        touch-action: manipulation;
    }}
    
    .platform-macos section[data-testid="stSidebar"] {{
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
    }}
    
    /* Ultra-wide display optimizations */
    .aspect-ultrawide .main .block-container {{
        max-width: 85vw !important;
        margin: 0 auto !important;
    }}
    
    /* Performance optimizations for different DPR */
    .dpr-3, .dpr-4 {{
        /* High DPI devices - enable hardware acceleration */
        transform: translateZ(0);
        -webkit-transform: translateZ(0);
        will-change: transform;
    }}
    
    .reduce-motion {{
        /* Disable animations for performance */
        *, *::before, *::after {{
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }}
    }}
    
    /* Adaptive font scaling based on device capabilities */
    .res-4k {{
        font-size: 18px;
        --sidebar-width: 300px;
    }}
    
    .res-2k {{
        font-size: 16px;
        --sidebar-width: 280px;
    }}
    
    .res-fhd {{
        font-size: 14px;
        --sidebar-width: 260px;
    }}
    
    .res-hd {{
        font-size: 13px;
        --sidebar-width: 240px;
    }}
    
    .res-mobile {{
        font-size: 16px;
        --sidebar-width: min(85vw, 320px);
    }}
    
    /* Hardware Feature Optimizations */
    .has-camera .camera-controls {{
        display: block !important;
    }}
    
    .has-geolocation .location-features {{
        display: block !important;
    }}
    
    .has-vibration .haptic-feedback {{
        display: block !important;
    }}
    
    /* Input Method Optimizations */
    .input-touch {{
        /* Touch-optimized interface */
        --button-min-size: 44px;
        --touch-padding: 12px;
    }}
    
    .input-touch button, .input-touch .stButton > button {{
        min-height: var(--button-min-size) !important;
        min-width: var(--button-min-size) !important;
        padding: var(--touch-padding) !important;
        touch-action: manipulation !important;
    }}
    
    .input-stylus {{
        /* Stylus-optimized precision */
        --precision-mode: enabled;
    }}
    
    .input-stylus input, .input-stylus textarea {{
        touch-action: auto !important;
    }}
    
    .input-gamepad .gamepad-navigation {{
        display: block !important;
    }}
    
    /* Browser Capability Optimizations */
    .webgl-support .advanced-graphics {{
        display: block !important;
    }}
    
    .wasm-support .high-performance {{
        display: block !important;
    }}
    
    .webrtc-support .video-features {{
        display: block !important;
    }}
    
    /* Network Optimizations */
    .network-slow .performance-mode {{
        --animation-duration: 0.1s;
        --image-quality: 0.7;
    }}
    
    .network-2g, .network-slow-2g {{
        /* Ultra-low bandwidth mode */
        --reduce-graphics: true;
        --compress-images: true;
    }}
    
    .network-3g {{
        /* Moderate bandwidth optimizations */
        --image-quality: 0.8;
    }}
    
    .network-4g, .network-5g {{
        /* High-speed optimizations */
        --enable-animations: true;
        --high-quality-images: true;
    }}
    
    .network-save-data {{
        /* Data saving mode */
        background-image: none !important;
        --reduce-animations: true;
    }}
    
    .network-save-data img {{
        filter: blur(1px) !important;
        transition: filter 0.3s !important;
    }}
    
    .network-save-data img:hover, .network-save-data img:focus {{
        filter: none !important;
    }}
    
    /* Accessibility Optimizations */
    .reduce-motion *, .reduce-motion *::before, .reduce-motion *::after {{
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }}
    
    .high-contrast {{
        --contrast-boost: 1.5;
        filter: contrast(var(--contrast-boost));
    }}
    
    .high-contrast button, .high-contrast .stButton > button {{
        border: 2px solid currentColor !important;
        background: white !important;
        color: black !important;
    }}
    
    /* Platform-Specific Advanced Features */
    .platform-ios.has-camera .ios-camera-features {{
        display: block !important;
    }}
    
    .platform-android.has-geolocation .android-location {{
        display: block !important;
    }}
    
    .platform-macos.webgl-support .macos-graphics {{
        display: block !important;
    }}
    
    /* Feature Combinations */
    .touch-device.has-vibration button:active {{
        /* Haptic feedback simulation */
        transform: scale(0.95) !important;
        transition: transform 0.1s !important;
    }}
    
    .stylus-support.high-contrast {{
        /* High-precision, high-contrast mode */
        cursor: crosshair !important;
    }}
    
    /* iOS Mobile Optimizations */
    #mobile-menu-btn {{
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        /* Enhance for high DPI */
        border: calc(1px * var(--pixel-ratio)) solid transparent !important;
    }}
    
    @media (max-width: 767px) {{
        /* Force mobile menu button to be visible */
        #mobile-menu-btn {{
            display: block !important;
            position: fixed !important;
            visibility: visible !important;
            opacity: 1 !important;
            pointer-events: auto !important;
        }}
        
        /* Force sidebar to be hidden on mobile initially */
        section[data-testid="stSidebar"] {{
            position: fixed !important;
            {"right" if is_rtl else "left"}: -100% !important;
            width: var(--sidebar-width, min(85vw, 350px)) !important;
            height: 100vh !important;
            height: -webkit-fill-available !important;
            transition: {"right" if is_rtl else "left"} 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            box-shadow: 0 0 calc(30px * var(--pixel-ratio, 1)) rgba(0,0,0,0.5) !important;
            z-index: 998 !important;
            overflow-y: auto !important;
            -webkit-overflow-scrolling: touch !important;
            background: white !important;
            font-size: calc(16px * var(--device-scale, 1)) !important;
        }}
        
        section[data-testid="stSidebar"].mobile-open {{
            {"right" if is_rtl else "left"}: 0 !important;
        }}
        
        /* Main content full width on mobile */
        .main .block-container {{
            margin: 0 !important;
            padding: 4rem 1rem 1rem !important;
            max-width: 100vw !important;
            width: 100% !important;
        }}
        
        /* iOS specific adjustments */
        @supports (-webkit-appearance: none) {{
            section[data-testid="stSidebar"] {{
                height: 100vh !important;
                height: -webkit-fill-available !important;
            }}
            
            #mobile-menu-btn {{
                top: max(15px, env(safe-area-inset-top)) !important;
                {"right" if is_rtl else "left"}: max(15px, env(safe-area-inset-left)) !important;
            }}
        }}
    }}
    
    /* Hide mobile menu button on desktop */
    @media (min-width: 768px) {{
        .mobile-menu-btn {{
            display: none !important;
        }}
    }}
    
    /* Tablet Portrait Adjustments */
    @media (max-width: 767px) and (min-width: 481px) {{
        section[data-testid="stSidebar"] {{
            width: 320px !important;
        }}
    }}
    </style>
    
    <script>
    // Comprehensive Device & Feature Detection System
    window.deviceOptimization = {{
        init: function() {{
            this.detectDevice();
            this.detectHardwareFeatures();
            this.detectBrowserCapabilities();
            this.detectInputMethods();
            this.detectNetworkInfo();
            this.detectStorageCapabilities();
            this.detectLocationAndTime();
            this.optimizeViewport();
            this.setupDynamicScaling();
            this.optimizePerformance();
            this.enableDeviceFeatures();
        }},
        
        detectDevice: function() {{
            const screen = window.screen;
            const dpr = window.devicePixelRatio || 1;
            
            // Device capabilities detection
            this.device = {{
                width: screen.width,
                height: screen.height,
                availWidth: screen.availWidth,
                availHeight: screen.availHeight,
                pixelRatio: dpr,
                actualWidth: screen.width * dpr,
                actualHeight: screen.height * dpr,
                viewportWidth: window.innerWidth,
                viewportHeight: window.innerHeight,
                isHighDPI: dpr >= 2,
                isRetinaDisplay: dpr >= 2,
                is4K: (screen.width >= 3840 && screen.height >= 2160),
                isUltraWide: (screen.width / screen.height) > 2,
                orientation: screen.orientation ? screen.orientation.angle : 0,
                touchSupport: 'ontouchstart' in window,
                platform: this.detectPlatform()
            }};
            
            console.log('Device Detection:', this.device);
            this.applyOptimizations();
        }},
        
        detectPlatform: function() {{
            const ua = navigator.userAgent;
            if (/iPad|iPhone|iPod/.test(ua)) return 'iOS';
            if (/Android/.test(ua)) return 'Android';
            if (/Mac/.test(ua)) return 'macOS';
            if (/Win/.test(ua)) return 'Windows';
            if (/Linux/.test(ua)) return 'Linux';
            return 'Unknown';
        }},
        
        optimizeViewport: function() {{
            // Dynamic viewport meta tag optimization
            let viewport = 'width=device-width, initial-scale=1.0';
            
            // High DPI optimization
            if (this.device.isHighDPI) {{
                viewport += ', maximum-scale=1.0, user-scalable=no';
            }}
            
            // iOS specific optimizations
            if (this.device.platform === 'iOS') {{
                viewport += ', viewport-fit=cover';
            }}
            
            // Create or update viewport meta tag
            let viewportMeta = document.querySelector('meta[name="viewport"]');
            if (!viewportMeta) {{
                viewportMeta = document.createElement('meta');
                viewportMeta.name = 'viewport';
                document.head.appendChild(viewportMeta);
            }}
            viewportMeta.content = viewport;
        }},
        
        setupDynamicScaling: function() {{
            // Calculate optimal scaling factors
            const baseWidth = 1920; // Base design width
            const scaleFactor = Math.min(this.device.viewportWidth / baseWidth, 1.2);
            
            // Apply CSS custom properties for dynamic scaling
            document.documentElement.style.setProperty('--device-scale', scaleFactor);
            document.documentElement.style.setProperty('--pixel-ratio', this.device.pixelRatio);
            document.documentElement.style.setProperty('--viewport-width', this.device.viewportWidth + 'px');
            document.documentElement.style.setProperty('--viewport-height', this.device.viewportHeight + 'px');
            
            // Resolution-specific optimizations
            if (this.device.is4K) {{
                document.documentElement.classList.add('resolution-4k');
            }} else if (this.device.isHighDPI) {{
                document.documentElement.classList.add('resolution-hidpi');
            }}
            
            if (this.device.isUltraWide) {{
                document.documentElement.classList.add('aspect-ultrawide');
            }}
        }},
        
        optimizePerformance: function() {{
            // GPU acceleration for high DPI displays
            if (this.device.isHighDPI) {{
                const style = document.createElement('style');
                style.textContent = `
                    * {{
                        -webkit-transform: translateZ(0);
                        transform: translateZ(0);
                        -webkit-backface-visibility: hidden;
                        backface-visibility: hidden;
                    }}
                `;
                document.head.appendChild(style);
            }}
            
            // Disable animations on lower-end devices
            if (this.device.pixelRatio < 1.5 && this.device.viewportWidth < 1200) {{
                document.documentElement.classList.add('reduce-motion');
            }}
        }},
        
        detectHardwareFeatures: function() {{
            this.hardware = {{
                // Camera & Media Detection
                camera: navigator.mediaDevices && navigator.mediaDevices.getUserMedia,
                microphone: navigator.mediaDevices && navigator.mediaDevices.getUserMedia,
                speaker: 'AudioContext' in window || 'webkitAudioContext' in window,
                
                // Location Services
                geolocation: 'geolocation' in navigator,
                
                // Device Sensors
                accelerometer: 'DeviceMotionEvent' in window,
                gyroscope: 'DeviceOrientationEvent' in window,
                magnetometer: 'DeviceOrientationEvent' in window,
                ambientLight: 'AmbientLightSensor' in window,
                proximity: 'ProximitySensor' in window,
                
                // Device Capabilities
                vibration: 'vibrate' in navigator,
                battery: 'getBattery' in navigator,
                clipboard: 'clipboard' in navigator,
                share: 'share' in navigator,
                
                // Biometric Features
                faceID: 'faceapi' in window,
                touchID: 'TouchID' in window,
                fingerprint: 'PublicKeyCredential' in window,
                
                // NFC & Bluetooth
                nfc: 'NDEFReader' in window,
                bluetooth: 'bluetooth' in navigator,
                
                // USB & Serial
                usb: 'usb' in navigator,
                serial: 'serial' in navigator
            }};
            
            console.log('Hardware Features:', this.hardware);
        }},
        
        detectBrowserCapabilities: function() {{
            this.browser = {{
                // Graphics & Rendering
                webgl: (() => {{
                    try {{
                        const canvas = document.createElement('canvas');
                        return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
                    }} catch(e) {{ return false; }}
                }})(),
                webgl2: (() => {{
                    try {{
                        return !!document.createElement('canvas').getContext('webgl2');
                    }} catch(e) {{ return false; }}
                }})(),
                canvas: 'getContext' in document.createElement('canvas'),
                svg: 'createElementNS' in document,
                
                // Advanced Web APIs
                webrtc: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
                webassembly: 'WebAssembly' in window,
                serviceWorker: 'serviceWorker' in navigator,
                webWorker: 'Worker' in window,
                sharedWorker: 'SharedWorker' in window,
                
                // Streaming & Media
                webcodecs: 'VideoEncoder' in window,
                mediaRecorder: 'MediaRecorder' in window,
                webAudio: 'AudioContext' in window || 'webkitAudioContext' in window,
                
                // Storage & Database
                indexedDB: 'indexedDB' in window,
                webSQL: 'openDatabase' in window,
                
                // Communication
                websockets: 'WebSocket' in window,
                fetch: 'fetch' in window,
                sse: 'EventSource' in window,
                
                // Performance & Monitoring
                performanceAPI: 'performance' in window,
                intersectionObserver: 'IntersectionObserver' in window,
                mutationObserver: 'MutationObserver' in window,
                
                // Security & Privacy
                permissions: 'permissions' in navigator,
                credentials: 'credentials' in navigator,
                
                // File System
                fileSystemAccess: 'showOpenFilePicker' in window,
                
                // PWA Features
                installPrompt: 'onbeforeinstallprompt' in window,
                
                // Virtual Reality
                webxr: 'xr' in navigator,
                webvr: 'getVRDisplays' in navigator
            }};
            
            console.log('Browser Capabilities:', this.browser);
        }},
        
        detectInputMethods: function() {{
            this.input = {{
                // Basic Input Types
                touch: 'ontouchstart' in window,
                mouse: window.matchMedia('(pointer: fine)').matches,
                keyboard: true, // Always assume keyboard availability
                
                // Advanced Input
                stylus: 'PointerEvent' in window,
                gamepad: 'getGamepads' in navigator,
                
                // Pointer Capabilities
                multiTouch: navigator.maxTouchPoints > 1,
                touchPoints: navigator.maxTouchPoints || 0,
                
                // Input Events
                pointerEvents: 'PointerEvent' in window,
                touchEvents: 'TouchEvent' in window,
                
                // Hover Capability
                hover: window.matchMedia('(hover: hover)').matches,
                
                // Accessibility
                reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
                highContrast: window.matchMedia('(prefers-contrast: high)').matches,
                darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches
            }};
            
            console.log('Input Methods:', this.input);
        }},
        
        detectNetworkInfo: function() {{
            this.network = {{
                connection: navigator.connection || navigator.mozConnection || navigator.webkitConnection,
                online: navigator.onLine,
                type: (navigator.connection || {{}}).effectiveType || 'unknown',
                downlink: (navigator.connection || {{}}).downlink || 0,
                rtt: (navigator.connection || {{}}).rtt || 0,
                saveData: (navigator.connection || {{}}).saveData || false
            }};
            
            console.log('Network Info:', this.network);
        }},
        
        detectStorageCapabilities: function() {{
            this.storage = {{
                localStorage: (() => {{
                    try {{
                        localStorage.setItem('test', 'test');
                        localStorage.removeItem('test');
                        return true;
                    }} catch(e) {{ return false; }}
                }})(),
                sessionStorage: (() => {{
                    try {{
                        sessionStorage.setItem('test', 'test');
                        sessionStorage.removeItem('test');
                        return true;
                    }} catch(e) {{ return false; }}
                }})(),
                indexedDB: 'indexedDB' in window,
                webSQL: 'openDatabase' in window,
                cookiesEnabled: navigator.cookieEnabled,
                
                // Storage Quota
                quotaAPI: 'storage' in navigator && 'estimate' in navigator.storage
            }};
            
            // Get storage quota if available
            if (this.storage.quotaAPI) {{
                navigator.storage.estimate().then(estimate => {{
                    this.storage.quota = estimate.quota;
                    this.storage.usage = estimate.usage;
                    console.log('Storage Quota:', estimate);
                }});
            }}
            
            console.log('Storage Capabilities:', this.storage);
        }},
        
        detectLocationAndTime: function() {{
            // Initialize location and time detection
            this.location = {{
                supported: 'geolocation' in navigator,
                permission: null,
                latitude: null,
                longitude: null,
                accuracy: null,
                altitude: null,
                speed: null,
                heading: null,
                timestamp: null,
                address: null,
                city: null,
                country: null,
                timezone: null,
                error: null
            }};
            
            this.time = {{
                local: new Date(),
                utc: new Date().toUTCString(),
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                offset: new Date().getTimezoneOffset(),
                timestamp: Date.now(),
                iso: new Date().toISOString(),
                locale: navigator.language
            }};
            
            // Detect timezone automatically
            this.detectTimezone();
            
            // Start real-time clock
            this.startRealTimeClock();
            
            // Request location permission and get coordinates
            if (this.location.supported) {{
                this.requestLocation();
            }}
            
            console.log('Location Support:', this.location.supported);
            console.log('Current Time:', this.time);
        }},
        
        detectTimezone: function() {{
            try {{
                // Get comprehensive timezone information
                const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                const locale = navigator.language || 'en-US';
                const now = new Date();
                
                // Get timezone details
                this.time.timezone = timeZone;
                this.time.locale = locale;
                this.time.offset = now.getTimezoneOffset();
                this.time.offsetHours = Math.floor(Math.abs(this.time.offset) / 60);
                this.time.offsetMinutes = Math.abs(this.time.offset) % 60;
                this.time.offsetString = (this.time.offset <= 0 ? '+' : '-') + 
                    String(this.time.offsetHours).padStart(2, '0') + ':' + 
                    String(this.time.offsetMinutes).padStart(2, '0');
                
                // Format current time in user's timezone
                this.time.formatted = new Intl.DateTimeFormat(locale, {{
                    timeZone: timeZone,
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    timeZoneName: 'short'
                }}).format(now);
                
                console.log('Timezone detected:', timeZone);
                console.log('Formatted time:', this.time.formatted);
                
            }} catch(e) {{
                console.warn('Timezone detection failed:', e);
                this.time.timezone = 'UTC';
            }}
        }},
        
        startRealTimeClock: function() {{
            // Update time every second
            this.clockInterval = setInterval(() => {{
                const now = new Date();
                this.time.local = now;
                this.time.utc = now.toUTCString();
                this.time.timestamp = now.getTime();
                this.time.iso = now.toISOString();
                
                // Update formatted time
                try {{
                    this.time.formatted = new Intl.DateTimeFormat(this.time.locale, {{
                        timeZone: this.time.timezone,
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        timeZoneName: 'short'
                    }}).format(now);
                }} catch(e) {{
                    this.time.formatted = now.toLocaleString();
                }}
                
                // Update time display if element exists
                const timeDisplay = document.getElementById('user-time-display');
                if (timeDisplay) {{
                    timeDisplay.innerHTML = this.time.formatted;
                }}
                
                // Update location display if element exists
                const locationDisplay = document.getElementById('user-location-display');
                if (locationDisplay && this.location.city) {{
                    locationDisplay.innerHTML = `${{this.location.city}}, ${{this.location.country}}`;
                }}
                
            }}, 1000);
        }},
        
        requestLocation: function() {{
            if (!this.location.supported) {{
                console.warn('Geolocation not supported');
                return;
            }}
            
            // Request location with high accuracy
            const options = {{
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000 // 5 minutes
            }};
            
            navigator.geolocation.getCurrentPosition(
                (position) => {{
                    this.handleLocationSuccess(position);
                }},
                (error) => {{
                    this.handleLocationError(error);
                }},
                options
            );
            
            // Also watch position for continuous updates
            if (navigator.geolocation.watchPosition) {{
                this.locationWatchId = navigator.geolocation.watchPosition(
                    (position) => {{
                        this.handleLocationSuccess(position);
                    }},
                    (error) => {{
                        this.handleLocationError(error);
                    }},
                    options
                );
            }}
        }},
        
        handleLocationSuccess: function(position) {{
            const coords = position.coords;
            
            this.location.latitude = coords.latitude;
            this.location.longitude = coords.longitude;
            this.location.accuracy = coords.accuracy;
            this.location.altitude = coords.altitude;
            this.location.speed = coords.speed;
            this.location.heading = coords.heading;
            this.location.timestamp = position.timestamp;
            this.location.error = null;
            
            console.log('Location detected:', {{
                lat: this.location.latitude,
                lng: this.location.longitude,
                accuracy: this.location.accuracy + 'm'
            }});
            
            // Reverse geocoding to get address
            this.reverseGeocode(this.location.latitude, this.location.longitude);
            
            // Store in session if available
            if (this.storage.sessionStorage) {{
                try {{
                    sessionStorage.setItem('user_location', JSON.stringify({{
                        latitude: this.location.latitude,
                        longitude: this.location.longitude,
                        timestamp: this.location.timestamp,
                        accuracy: this.location.accuracy
                    }}));
                }} catch(e) {{
                    console.warn('Could not store location in session storage');
                }}
            }}
        }},
        
        handleLocationError: function(error) {{
            this.location.error = error.message;
            
            switch(error.code) {{
                case error.PERMISSION_DENIED:
                    console.warn('Location access denied by user');
                    this.location.permission = 'denied';
                    break;
                case error.POSITION_UNAVAILABLE:
                    console.warn('Location information unavailable');
                    break;
                case error.TIMEOUT:
                    console.warn('Location request timed out');
                    break;
                default:
                    console.warn('Unknown location error:', error.message);
                    break;
            }}
        }},
        
        reverseGeocode: function(lat, lng) {{
            // Try to get address information using a free geocoding service
            // Using OpenStreetMap Nominatim (free, no API key required)
            const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${{lat}}&lon=${{lng}}&zoom=10&addressdetails=1`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {{
                    if (data && data.address) {{
                        this.location.address = data.display_name;
                        this.location.city = data.address.city || data.address.town || data.address.village || data.address.county;
                        this.location.country = data.address.country;
                        this.location.countryCode = data.address.country_code;
                        this.location.state = data.address.state;
                        this.location.postalCode = data.address.postcode;
                        
                        console.log('Location geocoded:', {{
                            city: this.location.city,
                            country: this.location.country,
                            address: this.location.address
                        }});
                        
                        // Store geocoded location
                        if (this.storage.sessionStorage) {{
                            try {{
                                sessionStorage.setItem('user_geocoded_location', JSON.stringify({{
                                    city: this.location.city,
                                    country: this.location.country,
                                    address: this.location.address,
                                    timestamp: Date.now()
                                }}));
                            }} catch(e) {{
                                console.warn('Could not store geocoded location');
                            }}
                        }}
                    }}
                }})
                .catch(error => {{
                    console.warn('Reverse geocoding failed:', error);
                }});
        }},
        
        stopLocationTracking: function() {{
            if (this.locationWatchId) {{
                navigator.geolocation.clearWatch(this.locationWatchId);
                this.locationWatchId = null;
            }}
            
            if (this.clockInterval) {{
                clearInterval(this.clockInterval);
                this.clockInterval = null;
            }}
        }},
        
        enableDeviceFeatures: function() {{
            // Enable device-specific features based on capabilities
            
            // Camera & Media Features
            if (this.hardware.camera) {{
                document.documentElement.classList.add('has-camera');
                this.enableCameraFeatures();
            }}
            
            if (this.hardware.geolocation) {{
                document.documentElement.classList.add('has-geolocation');
                this.enableLocationFeatures();
            }}
            
            // Input Method Optimizations
            if (this.input.touch) {{
                document.documentElement.classList.add('touch-device');
                this.enableTouchOptimizations();
            }}
            
            if (this.input.stylus) {{
                document.documentElement.classList.add('stylus-support');
            }}
            
            // Performance Features
            if (this.browser.webgl) {{
                document.documentElement.classList.add('webgl-support');
            }}
            
            if (this.browser.webassembly) {{
                document.documentElement.classList.add('wasm-support');
            }}
            
            // Network Optimizations
            if (this.network.saveData) {{
                document.documentElement.classList.add('save-data');
                this.enableDataSavingMode();
            }}
            
            // Accessibility Features
            if (this.input.reducedMotion) {{
                document.documentElement.classList.add('reduce-motion');
            }}
            
            if (this.input.highContrast) {{
                document.documentElement.classList.add('high-contrast');
            }}
            
            console.log('Device features enabled');
        }},
        
        enableCameraFeatures: function() {{
            // Add camera functionality when available
            console.log('Camera features enabled');
        }},
        
        enableLocationFeatures: function() {{
            // Add location-based features when available
            console.log('Location features enabled');
        }},
        
        enableTouchOptimizations: function() {{
            // Optimize interface for touch devices
            const style = document.createElement('style');
            style.textContent = `
                .touch-device button, .touch-device .stButton > button {{
                    min-height: 44px !important;
                    min-width: 44px !important;
                    padding: 12px 16px !important;
                }}
                .touch-device input, .touch-device textarea {{
                    font-size: 16px !important;
                }}
            `;
            document.head.appendChild(style);
        }},
        
        enableDataSavingMode: function() {{
            // Reduce data usage when user has data saver enabled
            const style = document.createElement('style');
            style.textContent = `
                .save-data img {{
                    filter: blur(2px);
                    transition: filter 0.3s;
                }}
                .save-data img:hover {{
                    filter: none;
                }}
            `;
            document.head.appendChild(style);
        }},
        
        applyOptimizations: function() {{
            // Platform-specific CSS classes
            document.documentElement.classList.add(`platform-${{this.device.platform.toLowerCase()}}`);
            document.documentElement.classList.add(`dpr-${{Math.floor(this.device.pixelRatio)}}`);
            
            // Resolution classes
            if (this.device.viewportWidth >= 3840) document.documentElement.classList.add('res-4k');
            else if (this.device.viewportWidth >= 2560) document.documentElement.classList.add('res-2k');
            else if (this.device.viewportWidth >= 1920) document.documentElement.classList.add('res-fhd');
            else if (this.device.viewportWidth >= 1366) document.documentElement.classList.add('res-hd');
            else document.documentElement.classList.add('res-mobile');
            
            // Input method classes
            if (this.input) {{
                if (this.input.touch) document.documentElement.classList.add('input-touch');
                if (this.input.mouse) document.documentElement.classList.add('input-mouse');
                if (this.input.stylus) document.documentElement.classList.add('input-stylus');
                if (this.input.gamepad) document.documentElement.classList.add('input-gamepad');
            }}
            
            // Network classes
            if (this.network) {{
                document.documentElement.classList.add(`network-${{this.network.type}}`);
                if (this.network.saveData) document.documentElement.classList.add('network-save-data');
            }}
        }}
    }};
    
    // Initialize device optimization
    window.deviceOptimization.init();
    
    // Re-optimize on orientation change or resize
    window.addEventListener('orientationchange', function() {{
        setTimeout(() => window.deviceOptimization.init(), 100);
    }});
    
    window.addEventListener('resize', function() {{
        clearTimeout(window.resizeTimeout);
        window.resizeTimeout = setTimeout(() => window.deviceOptimization.init(), 150);
    }});
    
    console.log('Fixzit sidebar loaded');
    }});
    </script>
    """,
        unsafe_allow_html=True,
    )

    # Toggle button functionality (for desktop)
    if not is_collapsed or st.session_state.get("force_show_toggle", False):
        toggle_col1, toggle_col2 = st.sidebar.columns([1, 4])
        with toggle_col1:
            if st.button(
                "⟵" if is_collapsed else "⟶",
                key="sidebar_toggle",
                help="Collapse/Expand Sidebar",
            ):
                st.session_state.sidebar_collapsed = (
                    not st.session_state.sidebar_collapsed
                )
                st.rerun()

    # Sidebar header with conditional content
    if is_collapsed:
        # Collapsed header - only logo, no text
        st.sidebar.markdown(
            f"""
        <div class="sidebar-header" style="padding: 20px 8px; border-bottom: 1px solid {BRAND['border']}; display: flex; flex-direction: column; align-items: center; text-align: center;">
            <div style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                {logo_html.replace('height: 120px', 'height: 35px').replace('width: auto', 'width: 35px') if 'img' in logo_html else logo_html}
            </div>
        </div>
        """,
            unsafe_allow_html=True,
        )
    else:
        # Expanded header - full logo and text
        st.sidebar.markdown(
            f"""
        <div class="sidebar-header" style="padding: 30px 16px; border-bottom: 1px solid {BRAND['border']}; display: flex; flex-direction: column; align-items: center; text-align: center; position: relative;">
            {logo_html}
            <span class="app-name" style="color: {BRAND['navy']}; font-size: 18px; font-weight: 600; margin-top: 15px;">{APP_NAME}</span>
        </div>
        """,
            unsafe_allow_html=True,
        )

    current_page = st.session_state.current_page

    # Initialize translation service
    # i18n = I18nService()  # Not used, commented out
    lang = st.session_state.get("language", "en")

    # Navigation groups with translations
    # Translation mapping for group names
    group_translations = {
        "Work Management": {"en": "Work Management", "ar": "إدارة العمل"},
        "Properties": {"en": "Properties", "ar": "العقارات"},
        "Marketplace": {"en": "Marketplace", "ar": "السوق"},
        "Finance": {"en": "Finance", "ar": "المالية"},
        "Users & Access": {"en": "Users & Access", "ar": "المستخدمون والوصول"},
        "Support": {"en": "Support", "ar": "الدعم"},
        "Administration": {"en": "Administration", "ar": "الإدارة"},
        "Email & Notifications": {
            "en": "Email & Notifications",
            "ar": "البريد الإلكتروني والإشعارات",
        },
        "Sharing & Moderation": {
            "en": "Sharing & Moderation",
            "ar": "المشاركة والإشراف",
        },
        "System & Monitoring": {"en": "System & Monitoring", "ar": "النظام والمراقبة"},
        "Authentication": {"en": "Authentication", "ar": "المصادقة"},
        "Onboarding & Help": {"en": "Onboarding & Help", "ar": "البدء والمساعدة"},
    }

    # Item label translations
    item_translations = {
        "Dashboard": {"en": "Dashboard", "ar": "لوحة التحكم"},
        "Boards": {"en": "Boards", "ar": "اللوحات"},
        "Automations": {"en": "Automations", "ar": "الأتمتة"},
        "Tickets": {"en": "Tickets", "ar": "التذاكر"},
        "Properties": {"en": "Properties", "ar": "العقارات"},
        "Contracts": {"en": "Contracts", "ar": "العقود"},
        "Marketplace": {"en": "Marketplace", "ar": "السوق"},
        "Payments": {"en": "Payments", "ar": "المدفوعات"},
        "Users": {"en": "Users", "ar": "المستخدمون"},
        "Settings": {"en": "Settings", "ar": "الإعدادات"},
        "Analytics": {"en": "Analytics", "ar": "التحليلات"},
        "Support Tickets": {"en": "Support Tickets", "ar": "تذاكر الدعم"},
        "My Profile": {"en": "My Profile", "ar": "ملفي الشخصي"},
        "Onboarding": {"en": "Onboarding", "ar": "البدء"},
        "Financials": {"en": "Financials", "ar": "المالية"},
        "Login": {"en": "Login", "ar": "تسجيل الدخول"},
        "Sign Up": {"en": "Sign Up", "ar": "التسجيل"},
        "Reports": {"en": "Reports", "ar": "التقارير"},
    }

    # Simple groups - NAVIGATION is an array
    for group in NAVIGATION:
        group_name = group["group"]
        is_expanded = group_name in st.session_state.expanded_groups

        # Get translated group name
        translated_group = group_translations.get(group_name, {}).get(lang, group_name)

        # Group header with expand/collapse
        col1, col2 = st.sidebar.columns([10, 1])
        with col1:
            if st.button(
                f"{group.get('icon', '•')} {translated_group}",
                key=f"grp_{group_name}",
                use_container_width=True,
            ):
                # Toggle expand/collapse
                if is_expanded:
                    st.session_state.expanded_groups.discard(group_name)
                else:
                    st.session_state.expanded_groups.add(group_name)
                st.rerun()

        with col2:
            expand_symbol = "−" if is_expanded else "+"
            st.markdown(
                f'<div style="color: {BRAND["orange"]}; font-weight: bold; padding-top: 8px;">{expand_symbol}</div>',
                unsafe_allow_html=True,
            )

        # Show sub-items if expanded
        if is_expanded:
            for item in group["items"]:
                is_active = item["id"] == current_page

                # Get translated item label
                item_label = item_translations.get(item["label"], {}).get(
                    lang, item["label"]
                )

                if st.sidebar.button(
                    f"  {item.get('icon', '•')} {item_label}",
                    key=f"nav_{item['id']}",
                    help=f"Go to {item_label}",
                    use_container_width=True,
                ):
                    st.session_state.current_page = item["id"]
                    # Navigate to the actual page file
                    if "path" in item and item["path"]:
                        try:
                            # Add pages/ prefix if not already present
                            page_path = item["path"]
                            if not page_path.startswith("pages/"):
                                page_path = f"pages/{page_path}"

                            # Special handling for dashboard to ensure proper routing
                            if item["id"] == "dashboard":
                                page_path = "pages/01_Dashboard_WorkOS.py"

                            st.switch_page(page_path)
                        except Exception as e:
                            # If navigation fails, try direct path
                            if item["id"] == "dashboard":
                                try:
                                    st.switch_page("pages/01_Dashboard_WorkOS.py")
                                except Exception:
                                    st.error(
                                        "Could not navigate to Dashboard. Please check if the file exists."
                                    )
                            else:
                                st.error(
                                    f"Could not navigate to {item['label']}: {str(e)}"
                                )
                            st.rerun()

                # Apply active styling
                if is_active:
                    st.sidebar.markdown(
                        f'<div style="background: {BRAND["orange_light"]}; margin: 2px 0; padding: 2px 8px; border-left: 3px solid {BRAND["orange"]}; border-radius: 4px;"></div>',
                        unsafe_allow_html=True,
                    )

    # Simple footer - adapt to collapsed state
    st.sidebar.markdown("---")
    if is_collapsed:
        # Collapsed footer - minimal
        st.sidebar.markdown(
            f"""
        <div style="padding: 8px; text-align: center; font-size: 10px; color: {BRAND['orange']};">
            © 2024
        </div>
        """,
            unsafe_allow_html=True,
        )
    else:
        # Expanded footer - full text
        st.sidebar.markdown(
            f"""
        <div style="padding: 16px; text-align: center; font-size: 11px; color: {BRAND['navy_light']};">
            <div style="font-weight: 600; color: {BRAND['navy']};">شركة خدماتي الشاملة</div>
            <div style="color: {BRAND['orange']}; margin-top: 4px;">© 2024 Fixzit</div>
        </div>
        """,
            unsafe_allow_html=True,
        )

    return "main", current_page


# Compatibility
def goto(page_id: str):
    st.session_state.current_page = page_id
    st.rerun()


def hide_sidebar_on_login():
    st.markdown(
        '<style>section[data-testid="stSidebar"] {display: none !important;}</style>',
        unsafe_allow_html=True,
    )


def get_user_location_and_time():
    """
    Retrieve user's location and time data from browser session storage
    Returns a dictionary with location and time information
    """

    # Add JavaScript to read from session storage and update Streamlit session state
    st.markdown(
        """
    <script>
    // Function to read location/time data from session storage and send to Streamlit
    function updateStreamlitLocationTime() {
        try {
            const data = sessionStorage.getItem('fixzit_location_time');
            if (data) {
                const locationTimeData = JSON.parse(data);
                
                // Update Streamlit session state via window.parent
                if (window.parent && window.parent.postMessage) {
                    window.parent.postMessage({
                        type: 'updateSessionState',
                        data: {
                            user_location: locationTimeData.location,
                            user_time: locationTimeData.time,
                            location_timestamp: locationTimeData.lastUpdate
                        }
                    }, '*');
                }
                
                console.log('Location and time data retrieved:', locationTimeData);
                return locationTimeData;
            }
        } catch (e) {
            console.warn('Could not read location/time from session storage:', e);
        }
        return null;
    }
    
    // Try to update immediately
    updateStreamlitLocationTime();
    
    // Also update every 10 seconds
    setInterval(updateStreamlitLocationTime, 10000);
    </script>
    """,
        unsafe_allow_html=True,
    )

    # Return any existing data from Streamlit session state
    location_data = {
        "location": st.session_state.get("user_location", {}),
        "time": st.session_state.get("user_time", {}),
        "timestamp": st.session_state.get("location_timestamp", None),
    }

    return location_data
