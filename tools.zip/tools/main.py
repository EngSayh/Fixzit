"""
FIXZIT - Main Application Entry Point
Clean routing to login page
"""

import streamlit as st

# Page configuration MUST be first
st.set_page_config(
    page_title="Fixzit - شركة خدماتي الشاملة",
    page_icon="🔧",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# Initialize session state
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

# Always redirect to login page for now
if not st.session_state.get("authenticated", False):
    st.switch_page("pages/00_Login.py")
else:
    st.switch_page("pages/01_Dashboard_WorkOS.py")
