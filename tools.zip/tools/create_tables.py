"""
Create database tables for Fixzit application
"""

from utils.database import get_db_connection


def create_tables():
    conn = get_db_connection()
    if not conn:
        print("❌ Failed to connect to database")
        return False

    cur = conn.cursor()
    tables_created = []

    # Create tables
    try:
        # Users table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL,
                full_name VARCHAR(255),
                phone VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("users")

        # Properties table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS properties (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                address TEXT,
                type VARCHAR(100),
                status VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("properties")

        # Units table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS units (
                id SERIAL PRIMARY KEY,
                property_id INTEGER REFERENCES properties(id),
                unit_number VARCHAR(50),
                type VARCHAR(100),
                status VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("units")

        # Contracts table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS contracts (
                id SERIAL PRIMARY KEY,
                unit_id INTEGER REFERENCES units(id),
                tenant_id INTEGER REFERENCES users(id),
                start_date DATE,
                end_date DATE,
                rent_amount DECIMAL(10,2),
                status VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("contracts")

        # Tickets table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS tickets (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id),
                property_id INTEGER REFERENCES properties(id),
                subject VARCHAR(255),
                description TEXT,
                status VARCHAR(50),
                priority VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("tickets")

        # Payments table - using paid_date not payment_date
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS payments (
                id SERIAL PRIMARY KEY,
                contract_id INTEGER REFERENCES contracts(id),
                amount DECIMAL(10,2),
                paid_date DATE,
                payment_method VARCHAR(50),
                status VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("payments")

        # OTP codes table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS otp_codes (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id),
                code VARCHAR(10),
                expires_at TIMESTAMP,
                used BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """
        )
        tables_created.append("otp_codes")

        conn.commit()
        print("✅ Database tables created successfully!")
        print(f"Tables created: {', '.join(tables_created)}")
        return True

    except Exception as e:
        print(f"❌ Error creating tables: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    create_tables()
