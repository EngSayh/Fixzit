#!/usr/bin/env python3
"""
Comprehensive verification script for Fixzit system
Tests all modules, database connections, and UI components
"""

import sys
import os
from pathlib import Path
from datetime import datetime

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

print("=" * 70)
print(" FIXZIT SYSTEM VERIFICATION ")
print("=" * 70)
print(f"Started at: {datetime.now()}")
print("-" * 70)

# Track all results
errors = []
warnings = []
successes = []

# 1. DATABASE VERIFICATION
print("\n🔍 DATABASE VERIFICATION")
print("-" * 40)
try:
    from utils.database import get_db_connection
    conn = get_db_connection()
    
    if conn:
        cur = conn.cursor()
        
        # Check all tables and count records
        tables = {
            'users': 0,
            'properties': 0, 
            'tickets': 0,
            'payments': 0,
            'contracts': 0,
            'units': 0,
            'otp_codes': 0
        }
        
        for table in tables.keys():
            try:
                cur.execute(f"SELECT COUNT(*) as count FROM {table}")
                result = cur.fetchone()
                count = result.get('count', 0) if result else 0
                tables[table] = count
                
                if count > 0:
                    print(f"✅ Table '{table}': {count} records")
                    successes.append(f"Table '{table}' has {count} records")
                else:
                    print(f"⚠️  Table '{table}': empty")
                    warnings.append(f"Table '{table}' is empty")
            except Exception as e:
                print(f"❌ Table '{table}': ERROR - {str(e)}")
                errors.append(f"Table '{table}' error: {str(e)}")
        
        conn.close()
        print(f"\n✅ Database connection successful")
        print(f"   Total records across all tables: {sum(tables.values())}")
        successes.append(f"Database connected with {sum(tables.values())} total records")
    else:
        print("❌ Database connection failed")
        errors.append("Cannot connect to PostgreSQL database")
except ImportError as e:
    print(f"❌ Database module import failed: {e}")
    errors.append(f"Database module import error: {e}")
except Exception as e:
    print(f"❌ Database verification error: {e}")
    errors.append(f"Database error: {e}")

# 2. MODULE IMPORTS VERIFICATION
print("\n🔍 MODULE IMPORTS VERIFICATION")
print("-" * 40)
modules = [
    ('utils.database', 'Database utilities'),
    ('utils.auth', 'Authentication system'),
    ('utils.translations', 'Translation system'),
    ('module_loader_simple', 'Module loader'),
    ('fixzit_app', 'Main application')
]

for module_name, description in modules:
    try:
        __import__(module_name)
        print(f"✅ {description} ({module_name})")
        successes.append(f"Module '{module_name}' imports successfully")
    except ImportError as e:
        print(f"❌ {description} ({module_name}): {e}")
        errors.append(f"Module '{module_name}' import failed: {e}")

# 3. PAGE FUNCTIONS VERIFICATION
print("\n🔍 PAGE RENDERING FUNCTIONS")
print("-" * 40)
try:
    from module_loader_simple import (
        render_finance_dashboard,
        render_payments_page,
        render_properties_page,
        render_tickets_page,
        render_contracts_page,
        render_users_page
    )
    
    pages = [
        ('Financial Dashboard', render_finance_dashboard),
        ('Payments & Invoicing', render_payments_page),
        ('Properties & Units', render_properties_page),
        ('Tickets System', render_tickets_page),
        ('Contracts Management', render_contracts_page),
        ('User Management', render_users_page)
    ]
    
    for page_name, func in pages:
        if callable(func):
            print(f"✅ {page_name} function ready")
            successes.append(f"Page '{page_name}' render function exists")
        else:
            print(f"❌ {page_name} function not callable")
            errors.append(f"Page '{page_name}' function not callable")
            
except ImportError as e:
    print(f"❌ Cannot import page functions: {e}")
    errors.append(f"Page functions import failed: {e}")

# 4. CONFIGURATION VERIFICATION
print("\n🔍 CONFIGURATION VERIFICATION")
print("-" * 40)
try:
    from fixzit_app import BRAND, NAV, BADGES, APP_NAME
    
    # Check white theme
    if BRAND.get('bg') == '#ffffff':
        print("✅ White professional theme active")
        successes.append("White professional theme configured")
    else:
        print(f"❌ Theme not white: bg={BRAND.get('bg')}")
        errors.append(f"Theme background is {BRAND.get('bg')} instead of white")
    
    # Check navigation structure
    total_groups = len(NAV)
    total_modules = sum(len(group.get('items', [])) for group in NAV)
    print(f"✅ Navigation: {total_groups} groups, {total_modules} modules")
    successes.append(f"Navigation configured with {total_groups} groups and {total_modules} modules")
    
    # Check badges
    print(f"✅ Active badges: {len(BADGES)} configured")
    successes.append(f"{len(BADGES)} badge indicators configured")
    
    # Check app name
    print(f"✅ App name: {APP_NAME}")
    successes.append(f"App name set to '{APP_NAME}'")
    
except ImportError as e:
    print(f"❌ Configuration import failed: {e}")
    errors.append(f"Configuration import error: {e}")

# 5. WORKFLOW VERIFICATION
print("\n🔍 WORKFLOW VERIFICATION")
print("-" * 40)
import subprocess

try:
    # Check if Streamlit is running
    result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
    if 'streamlit' in result.stdout:
        print("✅ Streamlit server is running")
        successes.append("Streamlit server active")
    else:
        print("⚠️  Streamlit server not detected")
        warnings.append("Streamlit server not running")
        
    # Check if port 5000 is open
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('localhost', 5000))
    sock.close()
    
    if result == 0:
        print("✅ Port 5000 is accessible")
        successes.append("Web server accessible on port 5000")
    else:
        print("❌ Port 5000 is not accessible")
        errors.append("Port 5000 not accessible")
        
except Exception as e:
    print(f"⚠️  Workflow check error: {e}")
    warnings.append(f"Workflow verification error: {e}")

# 6. ENVIRONMENT VARIABLES
print("\n🔍 ENVIRONMENT VARIABLES")
print("-" * 40)
env_vars = [
    'DATABASE_URL',
    'PGDATABASE',
    'PGHOST',
    'PGPASSWORD',
    'PGPORT',
    'PGUSER'
]

for var in env_vars:
    if os.environ.get(var):
        print(f"✅ {var} is set")
        successes.append(f"Environment variable '{var}' configured")
    else:
        print(f"❌ {var} is missing")
        errors.append(f"Environment variable '{var}' not set")

# FINAL REPORT
print("\n" + "=" * 70)
print(" VERIFICATION SUMMARY ")
print("=" * 70)

print(f"\n📊 STATISTICS:")
print(f"   ✅ Successful checks: {len(successes)}")
print(f"   ❌ Errors found: {len(errors)}")
print(f"   ⚠️  Warnings: {len(warnings)}")

if errors:
    print(f"\n❌ ERRORS ({len(errors)}):")
    for i, error in enumerate(errors[:10], 1):
        print(f"   {i}. {error}")
    if len(errors) > 10:
        print(f"   ... and {len(errors) - 10} more")

if warnings:
    print(f"\n⚠️  WARNINGS ({len(warnings)}):")
    for i, warning in enumerate(warnings[:5], 1):
        print(f"   {i}. {warning}")
    if len(warnings) > 5:
        print(f"   ... and {len(warnings) - 5} more")

# Overall status
print("\n" + "=" * 70)
if not errors:
    print("🎉 SYSTEM STATUS: ✅ ALL CHECKS PASSED!")
    print("\n   ✓ Database connected with data")
    print("   ✓ All modules import correctly")
    print("   ✓ All page functions exist")
    print("   ✓ White professional theme active")
    print("   ✓ Navigation configured properly")
    print("   ✓ Environment variables set")
    print("\n   System is ready for production use!")
elif len(errors) <= 2:
    print("⚠️  SYSTEM STATUS: OPERATIONAL WITH MINOR ISSUES")
    print(f"   {len(errors)} issue(s) need attention")
else:
    print("❌ SYSTEM STATUS: CRITICAL ISSUES DETECTED")
    print(f"   {len(errors)} critical issues found")
    print("   Immediate attention required!")

print("=" * 70)
print(f"Completed at: {datetime.now()}")
print("=" * 70)

# Exit with appropriate code
sys.exit(0 if not errors else 1)