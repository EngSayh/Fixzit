#!/usr/bin/env python3
"""
Auto-patch script to add universal navigation to all Streamlit pages
Run this once to update all existing pages with the new navigation system.
Usage: python tools/patch_pages.py
"""

from pathlib import Path


def find_pages():
    """Find all Python pages in the pages directory"""
    pages_dir = Path("pages")
    if not pages_dir.exists():
        print("Pages directory not found!")
        return []

    python_files = []
    for file in pages_dir.glob("*.py"):
        if file.name == "00_Login.py":  # Skip login page
            continue
        python_files.append(file)

    return python_files


def patch_page(file_path):
    """Add navigation bootstrap to a single page"""
    print(f"Patching {file_path}...")

    try:
        # Read the existing file
        content = file_path.read_text(encoding="utf-8")

        # Check if already patched
        if "boot_nav_auto" in content:
            print(f"  ✓ Already patched: {file_path}")
            return

        # Find the imports section
        lines = content.split("\n")

        # Find where to insert the navigation import and call
        import_insert_index = -1
        config_end_index = -1
        auth_check_index = -1

        for i, line in enumerate(lines):
            if line.strip().startswith("import streamlit as st"):
                import_insert_index = i + 1
            elif "st.set_page_config" in line:
                # Find the end of the page config block
                bracket_count = line.count("(") - line.count(")")
                j = i
                while bracket_count > 0 and j < len(lines) - 1:
                    j += 1
                    bracket_count += lines[j].count("(") - lines[j].count(")")
                config_end_index = j + 1
            elif 'st.session_state.get("authenticated"' in line:
                auth_check_index = i

        # Insert the navigation import after other imports
        if import_insert_index > -1:
            lines.insert(import_insert_index, "from ui.nav import boot_nav_auto")

        # Insert the bootstrap call after authentication check or page config
        insert_index = (
            max(auth_check_index, config_end_index)
            if auth_check_index > -1
            else config_end_index
        )

        if insert_index > -1:
            # Find a good spot after authentication
            while insert_index < len(lines) and (
                lines[insert_index].strip().startswith("st.stop()")
                or lines[insert_index].strip().startswith("st.error")
                or lines[insert_index].strip() == ""
            ):
                insert_index += 1

            lines.insert(insert_index, "")
            lines.insert(insert_index + 1, "# Bootstrap universal navigation")
            lines.insert(insert_index + 2, "boot_nav_auto()")
            lines.insert(insert_index + 3, "")

        # Remove old navigation calls
        filtered_lines = []
        for line in lines:
            if any(
                old_nav in line
                for old_nav in [
                    "nav_sidebar()",
                    "set_nav_active",
                    "activate_app_chrome",
                ]
            ):
                continue
            if "from ui.nav import" in line and "boot_nav_auto" not in line:
                continue
            if "from ui.reset import" in line:
                continue
            filtered_lines.append(line)

        # Write the patched content
        new_content = "\n".join(filtered_lines)
        file_path.write_text(new_content, encoding="utf-8")
        print(f"  ✓ Successfully patched: {file_path}")

    except Exception as e:
        print(f"  ✗ Error patching {file_path}: {e}")


def main():
    """Main function to patch all pages"""
    print("🔧 Starting universal navigation patch...")

    pages = find_pages()
    if not pages:
        print("No pages found to patch.")
        return

    print(f"Found {len(pages)} pages to patch:")
    for page in pages:
        print(f"  - {page}")

    print("\nStarting patch process...")

    success_count = 0
    for page in pages:
        try:
            patch_page(page)
            success_count += 1
        except Exception as e:
            print(f"Failed to patch {page}: {e}")

    print(
        f"\n✅ Patch complete! Successfully updated {success_count}/{len(pages)} pages"
    )
    print("🚀 Your navigation system is now consistent across all pages!")


if __name__ == "__main__":
    main()
