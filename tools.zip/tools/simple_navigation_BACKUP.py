"""
Fixzit Simple Working Sidebar
"""

import streamlit as st
from typing import Optional, Tuple

def render_sidebar() -> Tuple[Optional[str], Optional[str]]:
    """Simple sidebar that actually works"""
    
    # Initialize state
    if "current_page" not in st.session_state:
        st.session_state.current_page = "dashboard"
    if "expanded_groups" not in st.session_state:
        st.session_state.expanded_groups = {"Dashboard"}
    
    # Make sure sidebar is visible - remove any CSS that might hide it
    st.markdown("""
    <style>
    /* Force sidebar to be visible */
    section[data-testid="stSidebar"] {
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        position: relative !important;
        left: 0 !important;
        background-color: white !important;
    }
    
    /* Remove any hiding styles */
    .css-1d391kg {
        display: block !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.sidebar.title("🔧 Fixzit")
    st.sidebar.markdown("---")
    
    # Dashboard Section
    if st.sidebar.button("📊 Dashboard", key="nav_dashboard", use_container_width=True):
        st.session_state.current_page = "dashboard"
    
    # Work Management Section
    st.sidebar.markdown("### 🛠️ Work Management")
    if st.sidebar.button("📋 Boards", key="nav_boards", use_container_width=True):
        st.session_state.current_page = "boards"
    if st.sidebar.button("⚡ Automations", key="nav_automations", use_container_width=True):
        st.session_state.current_page = "automations"
    if st.sidebar.button("🎫 Tickets", key="nav_tickets", use_container_width=True):
        st.session_state.current_page = "tickets"
    
    # Properties Section
    st.sidebar.markdown("### 🏢 Properties")
    if st.sidebar.button("🏘️ Properties", key="nav_properties", use_container_width=True):
        st.session_state.current_page = "properties"
    if st.sidebar.button("📄 Contracts", key="nav_contracts", use_container_width=True):
        st.session_state.current_page = "contracts"
    
    # Marketplace Section
    st.sidebar.markdown("### 🛍️ Marketplace")
    if st.sidebar.button("🏪 Marketplace", key="nav_marketplace", use_container_width=True):
        st.session_state.current_page = "marketplace"
    if st.sidebar.button("🛒 Fixzit Souq", key="nav_souq", use_container_width=True):
        st.session_state.current_page = "souq"
    
    # Finance Section
    st.sidebar.markdown("### 💰 Finance")
    if st.sidebar.button("💵 Financials", key="nav_financials", use_container_width=True):
        st.session_state.current_page = "financials"
    if st.sidebar.button("💳 Payments", key="nav_payments", use_container_width=True):
        st.session_state.current_page = "payments"
    
    # Users Section
    st.sidebar.markdown("### 👥 Users")
    if st.sidebar.button("👥 Users", key="nav_users", use_container_width=True):
        st.session_state.current_page = "users"
    if st.sidebar.button("👤 My Profile", key="nav_profile", use_container_width=True):
        st.session_state.current_page = "profile"
    
    # Admin Section
    st.sidebar.markdown("### ⚙️ Administration")
    if st.sidebar.button("🔧 Settings", key="nav_settings", use_container_width=True):
        st.session_state.current_page = "settings"
    if st.sidebar.button("🛠️ Admin Panel", key="nav_admin", use_container_width=True):
        st.session_state.current_page = "admin"
    
    # Footer
    st.sidebar.markdown("---")
    st.sidebar.markdown("""
    <div style="text-align: center; font-size: 11px; color: #666;">
        © 2024 Fixzit
    </div>
    """, unsafe_allow_html=True)
    
    return None, st.session_state.current_page

# Backward compatibility
def hide_sidebar_on_login():
    """Hide sidebar on login pages"""
    st.markdown("""
    <style>
    section[data-testid="stSidebar"] {
        display: none !important;
    }
    </style>
    """, unsafe_allow_html=True)