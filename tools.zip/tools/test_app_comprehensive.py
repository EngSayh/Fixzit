#!/usr/bin/env python3
"""Comprehensive testing script for Fixzit application"""

import psycopg2
import os
import sys
from datetime import datetime

# Set up test environment
os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"


def test_database_connection():
    """Test database connectivity"""
    print("\n1. Testing Database Connection...")
    try:
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()
        cur.execute("SELECT version()")
        version = cur.fetchone()[0]
        print(f"   ✓ Connected to PostgreSQL: {version[:50]}...")
        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"   ✗ Database connection failed: {e}")
        return False


def test_user_authentication():
    """Test user authentication for all roles"""
    print("\n2. Testing User Authentication...")

    test_accounts = [
        ("admin@fixzit.com", "admin", "Admin User"),
        ("manager@fixzit.com", "manager", "Manager User"),
        ("tenant@fixzit.com", "tenant", "Tenant User"),
    ]

    try:
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()

        for email, expected_role, name in test_accounts:
            cur.execute(
                """
                SELECT id, role, first_name, last_name, is_verified 
                FROM users 
                WHERE email = %s
            """,
                (email,),
            )

            result = cur.fetchone()
            if result:
                user_id, role, first_name, last_name, is_verified = result
                if role == expected_role and is_verified:
                    print(f"   ✓ {name} ({email}): Role={role}, Verified={is_verified}")
                else:
                    print(f"   ✗ {name} ({email}): Role mismatch or not verified")
            else:
                print(f"   ✗ {name} ({email}): User not found")

        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"   ✗ Authentication test failed: {e}")
        return False


def test_critical_tables():
    """Test presence and structure of critical tables"""
    print("\n3. Testing Critical Tables...")

    critical_tables = {
        "users": ["id", "email", "role", "first_name", "last_name"],
        "properties": ["id", "name", "type", "address"],
        "tickets": ["id", "title", "status", "priority", "submitter_id"],
        "contracts": ["id", "contract_number", "tenant_id", "property_id"],
        "payments": ["id", "amount", "status", "payment_date"],
    }

    try:
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()

        for table, required_columns in critical_tables.items():
            # Check table exists
            cur.execute(
                """
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = %s
            """,
                (table,),
            )

            columns = [row[0] for row in cur.fetchall()]

            if columns:
                missing = [col for col in required_columns if col not in columns]
                if missing:
                    print(f"   ⚠ Table '{table}' missing columns: {missing}")
                else:
                    # Check record count
                    cur.execute(f"SELECT COUNT(*) FROM {table}")
                    count = cur.fetchone()[0]
                    print(
                        f"   ✓ Table '{table}': {count} records, all required columns present"
                    )
            else:
                print(f"   ✗ Table '{table}' not found")

        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"   ✗ Table test failed: {e}")
        return False


def test_page_files():
    """Test that critical page files exist and are loadable"""
    print("\n4. Testing Page Files...")

    critical_pages = [
        "pages/2_Properties.py",
        "pages/3_Tickets.py",
        "pages/4_Reports.py",
        "pages/5_Payments.py",
        "pages/8_Contracts.py",
        "pages/119_HomeDashboard.py",
    ]

    import glob

    all_pages = glob.glob("pages/*.py")
    print(f"   Total pages found: {len(all_pages)}")

    for page in critical_pages:
        if os.path.exists(page):
            try:
                with open(page, "r") as f:
                    content = f.read()
                    if "st.set_page_config" in content:
                        print(f"   ✓ {page}: Valid Streamlit page")
                    else:
                        print(f"   ⚠ {page}: Missing page config")
            except Exception as e:
                print(f"   ✗ {page}: Error reading file - {e}")
        else:
            print(f"   ✗ {page}: File not found")

    return True


def test_sample_data():
    """Test that sample data exists for testing"""
    print("\n5. Testing Sample Data...")

    try:
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()

        # Check for sample tickets
        cur.execute(
            """
            SELECT COUNT(*), 
                   COUNT(CASE WHEN status = 'open' THEN 1 END) as open_count,
                   COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed_count
            FROM tickets
        """
        )
        total, open_count, closed_count = cur.fetchone()
        print(f"   ✓ Tickets: {total} total ({open_count} open, {closed_count} closed)")

        # Check for properties
        cur.execute("SELECT COUNT(*) FROM properties")
        prop_count = cur.fetchone()[0]
        print(f"   ✓ Properties: {prop_count} total")

        # Check for contracts
        cur.execute("SELECT COUNT(*) FROM contracts")
        contract_count = cur.fetchone()[0]
        print(f"   ✓ Contracts: {contract_count} total")

        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"   ✗ Sample data test failed: {e}")
        return False


def test_translations():
    """Test translation system"""
    print("\n6. Testing Translation System...")

    try:
        from utils.translations import get_translation, TRANSLATIONS

        # Test key translations
        test_keys = ["login", "register", "dashboard", "tickets", "properties"]

        for key in test_keys:
            en_trans = get_translation(key, "en")
            ar_trans = get_translation(key, "ar")

            if en_trans and ar_trans and en_trans != ar_trans:
                print(f"   ✓ '{key}': EN='{en_trans[:20]}...', AR='{ar_trans[:20]}...'")
            else:
                print(f"   ⚠ '{key}': Translation issue")

        print(f"   Total translation keys: {len(TRANSLATIONS.get('en', {}))}")
        return True
    except Exception as e:
        print(f"   ✗ Translation test failed: {e}")
        return False


def run_all_tests():
    """Run all tests and generate report"""
    print("=" * 60)
    print("FIXZIT APPLICATION COMPREHENSIVE TEST REPORT")
    print("=" * 60)
    print(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    results = []

    # Run each test
    results.append(("Database Connection", test_database_connection()))
    results.append(("User Authentication", test_user_authentication()))
    results.append(("Critical Tables", test_critical_tables()))
    results.append(("Page Files", test_page_files()))
    results.append(("Sample Data", test_sample_data()))
    results.append(("Translation System", test_translations()))

    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)

    passed = sum(1 for _, result in results if result)
    failed = len(results) - passed

    for test_name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{test_name:.<40} {status}")

    print("\n" + "=" * 60)
    print(f"Total Tests: {len(results)}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Success Rate: {(passed/len(results)*100):.1f}%")
    print("=" * 60)

    if failed == 0:
        print("\n✅ ALL TESTS PASSED - Application is ready for production!")
    else:
        print(f"\n⚠️ {failed} tests failed - Please fix issues before deployment")

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
