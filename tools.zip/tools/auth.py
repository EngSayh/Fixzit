"""
Simple authentication module for Fixzit
"""

import streamlit as st


def require_auth():
    """
    AUTHENTICATION COMPLETELY BYPASSED - Always return admin user
    """
    # Initialize session with authentication bypass
    from utils.session_init import initialize_session_state
    initialize_session_state()
    
    # Always return authenticated admin user
    user = {
        "id": 1,
        "name": "Admin User",
        "email": "admin@fixzit.com",
        "role": "admin",
        "is_technician": True,
        "is_owner": True,
    }
    
    return user


def check_role(required_roles):
    """
    Check if user has one of the required roles
    """
    user = require_auth()
    if not user:
        return False

    user_role = user.get("role", "")
    return user_role in required_roles


def login(email, password):
    """
    Simple login function
    """
    # For demo purposes, accept any credentials
    st.session_state.authenticated = True
    st.session_state.user_name = email.split("@")[0].title()
    st.session_state.email = email

    # Set role based on email pattern
    if "admin" in email:
        st.session_state.user_role = "admin"
    elif "technician" in email:
        st.session_state.user_role = "technician"
        st.session_state.is_technician = True
    elif "manager" in email:
        st.session_state.user_role = "manager"
    elif "owner" in email:
        st.session_state.user_role = "owner"
        st.session_state.is_owner = True
    else:
        st.session_state.user_role = "tenant"

    return True


def logout():
    """
    Clear session state on logout
    """
    for key in list(st.session_state.keys()):
        del st.session_state[key]
