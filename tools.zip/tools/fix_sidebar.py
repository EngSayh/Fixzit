"""
Fix sidebar on all pages
"""

import os


def fix_page(filepath):
    """Add render_sidebar() call to a page if missing"""
    with open(filepath, "r") as f:
        content = f.read()

    # Skip login page
    if "00_Login.py" in filepath:
        return False

    # Check if render_sidebar is already imported
    if "from navigation import render_sidebar" not in content:
        # Add the import after other imports
        if "import streamlit as st" in content:
            content = content.replace(
                "import streamlit as st",
                "import streamlit as st\nfrom navigation import render_sidebar",
            )

    # Check if render_sidebar() is called
    if "render_sidebar()" not in content:
        # Find where to add it - after page config or after authentication check
        if "st.set_page_config(" in content:
            # Find the end of page config
            lines = content.split("\n")
            for i, line in enumerate(lines):
                if "st.set_page_config(" in line:
                    # Find the closing parenthesis
                    j = i
                    while j < len(lines) and ")" not in lines[j]:
                        j += 1
                    # Insert render_sidebar after page config
                    lines.insert(
                        j + 2, "\n# Render navigation sidebar\nrender_sidebar()"
                    )
                    content = "\n".join(lines)
                    break

    with open(filepath, "w") as f:
        f.write(content)

    return True


# Fix all pages
pages_dir = "pages"
fixed_count = 0

for filename in os.listdir(pages_dir):
    if filename.endswith(".py") and filename != "00_Login.py":
        filepath = os.path.join(pages_dir, filename)
        if fix_page(filepath):
            fixed_count += 1
            print(f"Fixed: {filename}")

print(f"\nTotal pages fixed: {fixed_count}")
