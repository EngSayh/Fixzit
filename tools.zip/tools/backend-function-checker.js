#!/usr/bin/env node

/**
 * FIXZIT SOUQ Backend Function Checker
 * Scans backend codebase for missing functions based on scope requirements
 */

const fs = require('fs').promises;
const path = require('path');
const glob = require('glob');

// Configuration
const CONFIG = {
  backendPath: './', // Current directory contains routes, models, etc.
  apiPath: './api',
  controllersPath: './controllers', 
  servicesPath: './services',
  modelsPath: './models',
  routesPath: './routes',
  fileExtensions: ['js', 'ts', 'jsx', 'tsx'],
  ignorePatterns: ['node_modules', 'dist', 'build', '.git', 'test', 'tests']
};

// Required Backend Functions based on your scope
const REQUIRED_FUNCTIONS = {
  // Dashboard Module Functions
  dashboard: [
    'getDashboardMetrics',
    'getActivityFeed', 
    'getCalendarEvents',
    'getRoleBasedDashboard',
    'getMyWork',
    'getAlerts',
    'updateKPICard',
    'refreshDashboard'
  ],
  
  // Work Orders Module Functions
  workOrders: [
    'createWorkOrder',
    'updateWorkOrderStatus',
    'assignTechnician',
    'autoAssignWorkOrder',
    'trackSLA',
    'getServiceHistory',
    'dispatchWorkOrder',
    'generatePreventiveMaintenance',
    'updateWorkOrderState', // Draft → Closed workflow
    'getKanbanView',
    'getCalendarView',
    'getGanttView',
    'calculateRoute'
  ],
  
  // Properties Module Functions
  properties: [
    'getProperties',
    'createProperty',
    'updateProperty',
    'deleteProperty',
    'getUnits',
    'getTenants',
    'createLease',
    'updateLease',
    'getAssetRegister',
    'createInspection',
    'getInspectionTemplates',
    'uploadDocument',
    'getPropertyLocation',
    'generatePropertyReport'
  ],
  
  // Finance Module Functions (ZATCA Compliance)
  finance: [
    'createInvoice',
    'generateZATCAQRCode',
    'submitToZATCA',
    'processPayment',
    'recordExpense',
    'getBudgetVsActual',
    'getPriceBooks',
    'generatePropertyStatement',
    'calculateVAT',
    'generateTaxReport',
    'reconcilePayments',
    'processBulkPayments'
  ],
  
  // HR Module Functions
  hr: [
    'getEmployeeDirectory',
    'recordAttendance',
    'submitLeaveRequest',
    'approveLeaveRequest',
    'processPayroll',
    'createRecruitmentPost',
    'scheduleTraining',
    'submitPerformanceReview',
    'calculateSalary',
    'generatePayslip'
  ],
  
  // Administration Module Functions
  administration: [
    'getDelegationMatrix',
    'updateDelegation',
    'getPolicies',
    'createAsset',
    'updateInventory',
    'manageFacilities',
    'manageFleet',
    'createVendor',
    'approveVendor',
    'evaluateVendor'
  ],
  
  // CRM Module Functions
  crm: [
    'createCustomer',
    'updateCustomer',
    'createLead',
    'convertLeadToOpportunity',
    'createContract',
    'scheduleRenewal',
    'submitFeedback',
    'createComplaint',
    'calculateNPS',
    'calculateCSAT',
    'getCustomerHistory'
  ],
  
  // Marketplace Module Functions (Amazon-style)
  marketplace: [
    'searchVendors',
    'getServiceCatalog',
    'createProcurementRequest',
    'createRFQ',
    'submitBid',
    'evaluateBids',
    'createPurchaseOrder',
    'approvePurchaseOrder',
    'getVendorRatings',
    'updateServiceCatalog'
  ],
  
  // Support Module Functions
  support: [
    'createTicket',
    'updateTicketStatus',
    'assignTicket',
    'escalateTicket',
    'searchKnowledgeBase',
    'createKBArticle',
    'trackSLACompliance',
    'createSurvey',
    'processSurveyResponse'
  ],
  
  // Compliance & Legal Module Functions
  compliance: [
    'registerPermit',
    'scheduleInspection',
    'recordFine',
    'payFine',
    'createContract',
    'initiateDocuSign',
    'trackCompliance',
    'generateAuditTrail',
    'getComplianceReport'
  ],
  
  // Reports & Analytics Functions
  reports: [
    'generateOperationalReport',
    'generateFinancialReport',
    'getWorkforceAnalytics',
    'buildCustomReport',
    'exportReport',
    'scheduleReport',
    'getRealtimeDashboard',
    'calculateKPIs'
  ],
  
  // System Management Functions
  system: [
    'createUser',
    'updateUserRole',
    'configureTenant',
    'manageIntegrations',
    'importData',
    'exportData',
    'configureWebhook',
    'updateBranding',
    'getAuditLog',
    'managePermissions'
  ],
  
  // Preventive Maintenance Functions
  preventiveMaintenance: [
    'createMaintenanceSchedule',
    'generateRecurringWorkOrder',
    'predictMaintenanceNeeds',
    'trackAssetHealth',
    'getMaintenanceHistory',
    'calculateMTBF',
    'calculateMTTR'
  ],
  
  // Event System Functions (from event catalog)
  events: [
    'publishProductCreated',
    'publishOfferUpdated', 
    'publishOrderPlaced',
    'publishPaymentAuthorized',
    'publishShipmentCreated',
    'publishDelivered',
    'publishReturnInitiated',
    'publishRefundIssued',
    'publishReviewSubmitted',
    'publishPolicyViolationRaised',
    'publishIncidentRaised',
    'subscribeToEvent',
    'handleEventCallback'
  ],
  
  // Portal-specific Functions
  portals: [
    'getTenantPortalData',
    'getTechnicianPortalData',
    'getOwnerPortalData',
    'getCorporateManagerData',
    'getVendorPortalData',
    'authenticatePortalUser',
    'getPortalNotifications'
  ],
  
  // Integration Functions
  integrations: [
    'syncWithDocuSign',
    'syncWithPaymentGateway',
    'sendSMS',
    'sendEmail',
    'getMapData',
    'convertCurrency',
    'translateContent',
    'convertToHijriDate',
    'convertToGregorianDate'
  ],
  
  // Critical Workflow Functions
  workflows: [
    'processTenantMaintenanceRequest',
    'processRFQToPurchaseOrder',
    'processOwnerApproval',
    'getWorkflowStatus',
    'moveToNextStep',
    'rollbackWorkflow',
    'validateWorkflowRules'
  ],
  
  // Authentication & Security Functions
  auth: [
    'login',
    'logout',
    'refreshToken',
    'validateJWT',
    'checkPermissions',
    'enforceRBAC',
    'logSecurityEvent',
    'detectAnomalies',
    'rateLimitCheck'
  ],
  
  // Real-time Functions
  realtime: [
    'establishWebSocket',
    'broadcastUpdate',
    'sendNotification',
    'syncData',
    'handleRealtimeEvent',
    'manageSocketRooms'
  ]
};

// Function to scan files for implemented functions
async function scanForFunctions(filePath) {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const functions = new Set();
    
    // Regex patterns to find function definitions
    const patterns = [
      // Regular functions
      /function\s+(\w+)\s*\(/g,
      // Arrow functions assigned to const/let/var
      /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Methods in objects
      /(\w+)\s*:\s*(?:async\s*)?function\s*\(/g,
      /(\w+)\s*:\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Express route handlers
      /\.(get|post|put|delete|patch)\s*\(\s*['"`]\/[\w/-]*['"`]\s*,\s*(?:async\s*)?(?:function\s*)?(\w+)?/g,
      // Controller methods
      /exports\.(\w+)\s*=/g,
      // ES6 exports
      /export\s+(?:async\s+)?function\s+(\w+)/g,
      /export\s+const\s+(\w+)\s*=/g,
      // Class methods
      /(?:async\s+)?(\w+)\s*\([^)]*\)\s*{/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        if (match[1] && !match[1].startsWith('_')) {
          functions.add(match[1]);
        }
        if (match[2]) {
          functions.add(match[2]);
        }
      }
    });
    
    return functions;
  } catch (error) {
    console.error(`Error reading file ${filePath}:`, error.message);
    return new Set();
  }
}

// Function to scan entire backend directory
async function scanBackend() {
  const implementedFunctions = new Set();
  const scannedFiles = [];
  
  // Get all relevant files
  const patterns = CONFIG.fileExtensions.map(ext => 
    `${CONFIG.backendPath}/**/*.${ext}`
  );
  
  for (const pattern of patterns) {
    const files = glob.sync(pattern, {
      ignore: CONFIG.ignorePatterns.map(p => `**/${p}/**`)
    });
    
    for (const file of files) {
      const functions = await scanForFunctions(file);
      functions.forEach(fn => implementedFunctions.add(fn));
      if (functions.size > 0) {
        scannedFiles.push({ file, functions: Array.from(functions) });
      }
    }
  }
  
  return { implementedFunctions, scannedFiles };
}

// Function to find missing functions
function findMissingFunctions(implementedFunctions) {
  const missing = {};
  const found = {};
  const partial = {};
  
  for (const [module, functions] of Object.entries(REQUIRED_FUNCTIONS)) {
    missing[module] = [];
    found[module] = [];
    partial[module] = [];
    
    for (const fn of functions) {
      let isFound = false;
      
      // Check exact match
      if (implementedFunctions.has(fn)) {
        found[module].push(fn);
        isFound = true;
      } else {
        // Check partial matches (case-insensitive or similar names)
        const lowerFn = fn.toLowerCase();
        for (const implFn of implementedFunctions) {
          if (implFn.toLowerCase().includes(lowerFn.replace(/([A-Z])/g, '_$1').toLowerCase()) ||
              lowerFn.includes(implFn.toLowerCase())) {
            partial[module].push({ required: fn, found: implFn });
            isFound = true;
            break;
          }
        }
      }
      
      if (!isFound) {
        missing[module].push(fn);
      }
    }
  }
  
  return { missing, found, partial };
}

// Function to generate report
async function generateReport() {
  console.log('\n🔍 FIXZIT SOUQ Backend Function Checker\n');
  console.log('='.repeat(80));
  
  console.log('\n📁 Scanning backend directory:', CONFIG.backendPath);
  
  const { implementedFunctions, scannedFiles } = await scanBackend();
  
  console.log(`\n✅ Found ${implementedFunctions.size} implemented functions`);
  console.log(`📄 Scanned ${scannedFiles.length} files\n`);
  
  const { missing, found, partial } = findMissingFunctions(implementedFunctions);
  
  // Calculate statistics
  let totalRequired = 0;
  let totalFound = 0;
  let totalMissing = 0;
  let totalPartial = 0;
  
  for (const module of Object.keys(REQUIRED_FUNCTIONS)) {
    totalRequired += REQUIRED_FUNCTIONS[module].length;
    totalFound += found[module].length;
    totalMissing += missing[module].length;
    totalPartial += partial[module].length;
  }
  
  // Print summary
  console.log('='.repeat(80));
  console.log('📊 SUMMARY');
  console.log('='.repeat(80));
  console.log(`Total Required Functions: ${totalRequired}`);
  console.log(`✅ Implemented: ${totalFound} (${((totalFound/totalRequired)*100).toFixed(1)}%)`);
  console.log(`⚠️  Partial Matches: ${totalPartial} (${((totalPartial/totalRequired)*100).toFixed(1)}%)`);
  console.log(`❌ Missing: ${totalMissing} (${((totalMissing/totalRequired)*100).toFixed(1)}%)`);
  console.log('='.repeat(80));
  
  // Print missing functions by module
  console.log('\n❌ MISSING FUNCTIONS BY MODULE\n');
  console.log('='.repeat(80));
  
  for (const [module, functions] of Object.entries(missing)) {
    if (functions.length > 0) {
      console.log(`\n📦 ${module.toUpperCase()} MODULE (${functions.length} missing):`);
      functions.forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
    }
  }
  
  // Print partial matches
  if (totalPartial > 0) {
    console.log('\n⚠️  PARTIAL MATCHES (might be implemented with different names)\n');
    console.log('='.repeat(80));
    
    for (const [module, matches] of Object.entries(partial)) {
      if (matches.length > 0) {
        console.log(`\n📦 ${module.toUpperCase()} MODULE:`);
        matches.forEach(({ required, found }) => {
          console.log(`   ⚠️  ${required} → might be: ${found}`);
        });
      }
    }
  }
  
  // Generate JSON report
  const report = {
    timestamp: new Date().toISOString(),
    summary: {
      totalRequired,
      totalFound,
      totalPartial,
      totalMissing,
      completionPercentage: ((totalFound/totalRequired)*100).toFixed(1)
    },
    missing,
    found,
    partial,
    scannedFiles: scannedFiles.map(f => f.file)
  };
  
  // Save report to file
  const reportPath = './backend-functions-report.json';
  await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
  console.log(`\n💾 Report saved to: ${reportPath}`);
  
  // Generate markdown checklist
  const checklistPath = './backend-implementation-checklist.md';
  const markdown = generateMarkdownChecklist(missing, found, partial);
  await fs.writeFile(checklistPath, markdown);
  console.log(`📋 Checklist saved to: ${checklistPath}`);
  
  return report;
}

// Function to generate markdown checklist
function generateMarkdownChecklist(missing, found, partial) {
  let markdown = '# FIXZIT SOUQ Backend Implementation Checklist\n\n';
  markdown += `Generated: ${new Date().toISOString()}\n\n`;
  
  for (const [module, functions] of Object.entries(REQUIRED_FUNCTIONS)) {
    markdown += `## ${module.toUpperCase()} Module\n\n`;
    
    for (const fn of functions) {
      if (found[module].includes(fn)) {
        markdown += `- ✅ ${fn}\n`;
      } else if (partial[module].find(p => p.required === fn)) {
        const match = partial[module].find(p => p.required === fn);
        markdown += `- ⚠️ ${fn} → might be: ${match.found}\n`;
      } else {
        markdown += `- ❌ ${fn}\n`;
      }
    }
    markdown += '\n';
  }
  
  return markdown;
}

// Run the checker
if (require.main === module) {
  generateReport().catch(console.error);
}

module.exports = { generateReport, scanBackend, findMissingFunctions };