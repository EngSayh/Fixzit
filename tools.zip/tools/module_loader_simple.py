"""
Simplified module loader for Fixzit navigation system
Works with existing database structure
"""

import streamlit as st
import os
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Import database utilities  
from utils.database import get_db_connection

def load_module_content(module_name: str):
    """Load and display module content"""
    
    # Module-specific content based on route
    if module_name == "finance_dashboard":
        render_finance_dashboard()
    elif module_name == "payments_invoicing":
        render_payments_page()
    elif module_name == "prop_units":
        render_properties_page()
    elif module_name == "tickets":
        render_tickets_page()
    elif module_name == "contracts":
        render_contracts_page()
    elif module_name == "roles_permissions":
        render_users_page()
    else:
        st.info(f"Module '{module_name}' is being prepared. Check back soon!")

def render_finance_dashboard():
    """Render financial dashboard"""
    st.title("📊 Financial Dashboard")
    
    col1, col2, col3, col4 = st.columns(4)
    
    conn = get_db_connection()
    if conn:
        try:
            with col1:
                # Total revenue
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM payments WHERE status = 'completed'")
                count = cur.fetchone()
                cur.close()
                st.metric("Completed Payments", count.get('count', 0) if count else 0)
            
            with col2:
                # Active contracts
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM contracts WHERE status = 'active'")
                count = cur.fetchone()
                cur.close()
                st.metric("Active Contracts", count.get('count', 0) if count else 0)
            
            with col3:
                # Pending payments
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM payments WHERE status = 'pending'")
                count = cur.fetchone()
                cur.close()
                st.metric("Pending Payments", count.get('count', 0) if count else 0)
            
            with col4:
                # Total users
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM users")
                count = cur.fetchone()
                cur.close()
                st.metric("Total Users", count.get('count', 0) if count else 0)
                
        except Exception as e:
            st.error(f"Database error: {e}")
        finally:
            conn.close()
    else:
        st.error("Could not connect to database")
    
    # Quick stats
    st.subheader("System Overview")
    st.info("Financial dashboard shows real-time data from your Fixzit database")

def render_payments_page():
    """Render payments page"""
    st.title("🧾 Payments & Invoicing")
    
    tabs = st.tabs(["All Payments", "Create Invoice"])
    
    with tabs[0]:
        conn = get_db_connection()
        if conn:
            try:
                cur = conn.cursor()
                cur.execute("SELECT id, amount, status, due_date, paid_date FROM payments ORDER BY created_at DESC LIMIT 20")
                payments = cur.fetchall()
                cur.close()
                
                if payments:
                    st.dataframe(payments, use_container_width=True)
                else:
                    st.info("No payments recorded yet")
            except Exception as e:
                st.error(f"Database error: {e}")
            finally:
                conn.close()
    
    with tabs[1]:
        st.subheader("Create New Invoice")
        with st.form("new_invoice"):
            contract_id = st.number_input("Contract ID", min_value=1)
            amount = st.number_input("Amount (SAR)", min_value=0.0, step=100.0)
            due_date = st.date_input("Due Date")
            
            if st.form_submit_button("Create Invoice"):
                conn = get_db_connection()
                if conn:
                    try:
                        cur = conn.cursor()
                        cur.execute("""
                            INSERT INTO payments (contract_id, amount, due_date, status)
                            VALUES (%s, %s, %s, 'pending')
                        """, (contract_id, amount, due_date))
                        cur.close()
                        conn.commit()
                        st.success("Invoice created successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Database error: {e}")
                        conn.rollback()
                    finally:
                        conn.close()

def render_properties_page():
    """Render properties page"""
    st.title("🏘️ Properties & Units")
    
    col1, col2 = st.columns([3, 1])
    
    with col2:
        if st.button("➕ Add Property", type="primary", use_container_width=True):
            st.session_state.show_add_property = True
    
    # Show add property form if requested
    if st.session_state.get('show_add_property', False):
        with st.form("add_property"):
            st.subheader("Add New Property")
            name = st.text_input("Property Name")
            address = st.text_area("Address")
            
            if st.form_submit_button("Add Property"):
                conn = get_db_connection()
                if conn:
                    cur = conn.cursor()
                    cur.execute("""
                        INSERT INTO properties (name, address, status)
                        VALUES (%s, %s, 'active')
                    """, (name, address))
                    conn.commit()
                    conn.close()
                    st.success(f"Property '{name}' added successfully!")
                    st.session_state.show_add_property = False
                    st.rerun()
    
    # Display properties
    conn = get_db_connection()
    if conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM properties ORDER BY created_at DESC")
        properties = cur.fetchall()
        
        if properties:
            for prop in properties:
                with st.expander(f"🏢 {prop.get('name', 'Property')}"):
                    st.write(f"**Address:** {prop.get('address', 'N/A')}")
                    st.write(f"**Status:** {prop.get('status', 'N/A')}")
        else:
            st.info("No properties added yet. Click 'Add Property' to get started!")
        
        conn.close()

def render_tickets_page():
    """Render tickets page"""
    st.title("🎫 Maintenance & Tickets")
    
    # Ticket statistics
    col1, col2, col3, col4 = st.columns(4)
    
    conn = get_db_connection()
    if conn:
        cur = conn.cursor()
        
        with col1:
            cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'open'")
            count = cur.fetchone()
            st.metric("Open Tickets", count.get('count', 0) if count else 0)
        
        with col2:
            cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'in_progress'")
            count = cur.fetchone()
            st.metric("In Progress", count.get('count', 0) if count else 0)
        
        with col3:
            cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'closed'")
            count = cur.fetchone()
            st.metric("Closed", count.get('count', 0) if count else 0)
        
        with col4:
            cur.execute("SELECT COUNT(*) FROM tickets")
            count = cur.fetchone()
            st.metric("Total Tickets", count.get('count', 0) if count else 0)
        
        conn.close()
    
    # Ticket tabs
    tabs = st.tabs(["All Tickets", "Create Ticket"])
    
    with tabs[0]:
        conn = get_db_connection()
        if conn:
            cur = conn.cursor()
            cur.execute("SELECT id, title, description, priority, status FROM tickets ORDER BY created_at DESC LIMIT 20")
            tickets = cur.fetchall()
            
            if tickets:
                st.dataframe(tickets, use_container_width=True)
            else:
                st.info("No tickets yet")
            
            conn.close()
    
    with tabs[1]:
        st.subheader("Create New Ticket")
        with st.form("new_ticket"):
            title = st.text_input("Title")
            description = st.text_area("Description")
            priority = st.selectbox("Priority", ["Low", "Medium", "High", "Urgent"])
            
            if st.form_submit_button("Create Ticket"):
                conn = get_db_connection()
                if conn:
                    cur = conn.cursor()
                    cur.execute("""
                        INSERT INTO tickets (title, description, priority, status)
                        VALUES (%s, %s, %s, 'open')
                    """, (title, description, priority))
                    conn.commit()
                    conn.close()
                    st.success("Ticket created successfully!")
                    st.rerun()

def render_contracts_page():
    """Render contracts page"""
    st.title("📑 Contracts Management")
    
    conn = get_db_connection()
    if conn:
        cur = conn.cursor()
        
        # Contract statistics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            cur.execute("SELECT COUNT(*) FROM contracts WHERE status = 'active'")
            count = cur.fetchone()
            st.metric("Active Contracts", count.get('count', 0) if count else 0)
        
        with col2:
            cur.execute("SELECT COUNT(*) FROM contracts WHERE status = 'expired'")
            count = cur.fetchone()
            st.metric("Expired", count.get('count', 0) if count else 0)
        
        with col3:
            cur.execute("SELECT COUNT(*) FROM contracts")
            count = cur.fetchone()
            st.metric("Total", count.get('count', 0) if count else 0)
        
        with col4:
            cur.execute("SELECT COUNT(DISTINCT tenant_id) FROM contracts")
            count = cur.fetchone()
            st.metric("Tenants", count.get('count', 0) if count else 0)
        
        # Contracts list
        st.subheader("All Contracts")
        cur.execute("SELECT * FROM contracts ORDER BY created_at DESC LIMIT 20")
        contracts = cur.fetchall()
        
        if contracts:
            st.dataframe(contracts, use_container_width=True)
        else:
            st.info("No contracts yet")
        
        conn.close()

def render_users_page():
    """Render users page"""
    st.title("🔐 Users & Permissions")
    
    tabs = st.tabs(["All Users", "Roles", "Add User"])
    
    conn = get_db_connection()
    
    with tabs[0]:
        if conn:
            cur = conn.cursor()
            cur.execute("SELECT id, first_name, last_name, email, role FROM users ORDER BY created_at DESC LIMIT 50")
            users = cur.fetchall()
            
            if users:
                st.dataframe(users, use_container_width=True)
            else:
                st.info("No users yet")
    
    with tabs[1]:
        st.subheader("User Roles")
        if conn:
            cur = conn.cursor()
            roles = ["Admin", "Manager", "Tenant", "Technician", "Vendor"]
            for role in roles:
                cur.execute("SELECT COUNT(*) FROM users WHERE role = %s", (role,))
                count = cur.fetchone()
                st.write(f"**{role}:** {count.get('count', 0) if count else 0} users")
    
    with tabs[2]:
        st.subheader("Add New User")
        with st.form("add_user"):
            first_name = st.text_input("First Name")
            last_name = st.text_input("Last Name")
            email = st.text_input("Email")
            role = st.selectbox("Role", ["Tenant", "Manager", "Admin", "Technician", "Vendor"])
            phone = st.text_input("Phone")
            
            if st.form_submit_button("Add User"):
                if conn:
                    cur = conn.cursor()
                    # In production, you would hash the password properly
                    cur.execute("""
                        INSERT INTO users (first_name, last_name, email, password_hash, role, phone)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (first_name, last_name, email, "temp_password_hash", role, phone))
                    conn.commit()
                    st.success(f"User '{first_name} {last_name}' added successfully!")
                    st.rerun()
    
    if conn:
        conn.close()