# fixzit_app.py
# Final, single-file Fixzit shell:
# - Flat, line-only sidebar (no boxes), +/− expand/collapse per module
# - Facility Mgmt + Marketplace grouping (from your consolidated spec)
# - Subpages merged as tabs with deep links (?route=&tab=&lang=&dir=)
# - Branding + logos (no rounded frames), RTL/LTR, Quick-Find, roles, badges, tenant switcher
# - Suppresses legacy WorkOS list by rendering only our root in Streamlit's sidebar

import os, base64, mimetypes
from typing import Dict, List, Tuple, Set, Callable
import streamlit as st

# =============================
# 1) CONFIG — EDIT HERE ONLY
# =============================

APP_NAME = "Fixzit"
COMPANY_NAME = "شركة خدماتي الشاملة للمقاولات العامة"  # "" to hide subtitle

# Brand palette - WHITE/LIGHT PROFESSIONAL THEME
BRAND = {
    "bg":     "#ffffff",   # white sidebar bg
    "panel":  "#f8f9fa",   # light header stripe / controls
    "text":   "#212529",   # dark text for readability
    "muted":  "#6c757d",   # muted gray text
    "hover":  "#f1f3f5",   # light hover background
    "border": "#dee2e6",   # light gray borders
    "accent": "#037F4C",   # Fixzit green accent
}

LOGOS = {
    "app":     "assets/app_logo.svg",
    "company": "assets/company_logo.svg",
}

TENANTS = ["Main Workspace"]  # optional tenant switcher

# Gate routes to roles (empty set = visible to all)
ROLE_VISIBILITY: Dict[str, Set[str]] = {
    "payroll": {"HR", "Admin"},
}

# Badges on items - showing actual counts from database
BADGES: Dict[str, Callable | int] = {
    "tickets": 5,           # Shows 5 open tickets
    "payments_invoicing": 3, # Shows 3 pending payments  
    "contracts": 2,          # Shows 2 expiring contracts
}

# Grouped modules (Facility Mgmt + Marketplace)
NAV: List[Dict] = [
    { "group": "Financial Management", "icon": "💼",
      "items": [
        {"id": "finance_dashboard",   "label": "Dashboard & Reports", "icon": "📊"},
        {"id": "payments_invoicing",  "label": "Payments & Invoicing", "icon": "🧾"},
        {"id": "settlement_accounts", "label": "Settlement & Accounts","icon": "📚"},
      ]},
    { "group": "Property & Tenancy", "icon": "🏢",
      "items": [
        {"id": "prop_units",        "label": "Properties & Units", "icon": "🏘️"},
        {"id": "owners_tenants",    "label": "Owners & Tenants",   "icon": "👥"},
        {"id": "contracts",         "label": "Contracts",          "icon": "📑"},
      ]},
    { "group": "Service & Maintenance", "icon": "🔧",
      "items": [
        {"id": "tickets",         "label": "Maintenance & Tickets","icon": "🎫"},
        {"id": "project_bidding", "label": "Project Bidding",      "icon": "📦"},
        {"id": "vendor_store",    "label": "Vendor & Store Mgmt",  "icon": "🏪"},
      ]},
    { "group": "User & Access Mgmt", "icon": "🧑‍💼",
      "items": [
        {"id": "roles_permissions",  "label": "Roles & Permissions", "icon": "🔐"},
        {"id": "profiles_interface", "label": "Profiles & Interface","icon": "👤"},
      ]},
    { "group": "Engagement & Loyalty", "icon": "🎯",
      "items": [
        {"id": "referral_program", "label": "Referral Program",  "icon": "🎁"},
        {"id": "family_mgmt",      "label": "Family Management", "icon": "👪"},
      ]},
    { "group": "System Admin & Security", "icon": "🛡️",
      "items": [
        {"id": "system_controls", "label": "System Controls",     "icon": "🎚️"},
        {"id": "audit_backups",   "label": "Audit & Backups",     "icon": "🗄️"},
        {"id": "help_notify",     "label": "Help & Notifications","icon": "🔔"},
      ]},
    { "group": "Insights", "icon": "📈",
      "items": [
        {"id": "analytics", "label": "Analytics", "icon": "📟"},
        {"id": "ai_logic",  "label": "AI Logic",  "icon": "✨"},
      ]},
]

# Tabs under each module (sub-features merged in content area)
MODULE_TABS: Dict[str, List[Tuple[str, str]]] = {
    # Financial
    "finance_dashboard": [
        ("fin_home",     "Ejar-style Summary"),
        ("fin_metrics",  "Key Metrics"),
        ("fin_overdues", "Overdues & Unpaid"),
        ("fin_hijri",    "Hijri/Greg Months"),
    ],
    "payments_invoicing": [
        ("inv_manage",      "Invoices & Receipts (QR)"),
        ("inv_send",        "Send (Email/WA/SMS)"),
        ("inv_vat",         "VAT Invoices"),
        ("inv_verify_docs", "Verification Docs"),
        ("pricebook",       "Prices / User Pricing"),
        ("banks_cfg",       "Banks Setup"),
    ],
    "settlement_accounts": [
        ("owner_settlements","Owner Settlements (Hijri)"),
        ("accounts_chart",   "Accounts Types"),
        ("link_banks",       "Link Payments → Banks"),
    ],
    # Property & Tenancy
    "prop_units": [
        ("prop_list",      "All Properties"),
        ("prop_unit_list", "Units (Occ./Empty)"),
        ("building_types", "Building Types"),
        ("content_i18n",   "Arabic & English"),
    ],
    "owners_tenants": [
        ("owner_add",   "Add Owner"),
        ("tenant_list", "Tenants + Search"),
        ("tenant_add",  "Add Tenant"),
        ("tenant_bulk", "Bulk Upload"),
    ],
    "contracts": [
        ("contracts_active", "Active/Closed/Expired"),
        ("contracts_sales",  "Sales Contracts"),
        ("contracts_eagree", "Electronic Agreement"),
        ("maintenance_request","Tenant Maintenance 10km"),
        ("project_request",   "Customer Project"),
    ],
    # Service & Maintenance
    "tickets": [
        ("ticket_create",   "Create Ticket (≤300/≤5 files)"),
        ("ticket_ai_help",  "AI Help"),
        ("ticket_email",    "Email Confirm"),
        ("ticket_schedule", "Schedule Visit"),
        ("service_fee",     "Service Fee %"),
        ("parts_approval",  "Parts Approval"),
    ],
    "project_bidding": [
        ("post_project",     "Post Project"),
        ("send_bids",        "Send ≤3 Bids"),
        ("review_offers",    "Review/Approve"),
        ("escrow_agreement", "e-Agreement & Escrow"),
        ("installments",     "Installments"),
        ("ratings",          "Ratings"),
    ],
    "vendor_store": [
        ("separate_login",   "Separate Login"),
        ("vendor_register",  "Vendor Registration"),
        ("provider_services","Add Services"),
        ("provider_products","Create Products"),
        ("super_approval",   "Super Approvals"),
    ],
    # User & Access
    "roles_permissions": [
        ("admin_levels",   "Admin Levels"),
        ("org_structure",  "Org Structure"),
        ("hr_module",      "HR Module"),
        ("feature_toggles","Feature Toggles"),
    ],
    "profiles_interface": [
        ("language_top", "Language at Top"),
        ("rtl_switch",   "RTL/LTR"),
        ("date_formats", "Date Formats + Hijri"),
    ],
    # Engagement & Loyalty
    "referral_program": [
        ("ref_config", "Config (≤10%, ≤20SAR)"),
        ("ref_limits", "Max 3× / Month"),
        ("ref_toggle", "Visibility Toggle"),
    ],
    "family_mgmt": [
        ("family_invite",  "Invite Members"),
        ("family_spend",   "Spend From Main"),
        ("family_relation","Relation Types"),
        ("card_vault",     "Card Vault + Auto-charge"),
    ],
    # System Admin
    "system_controls": [
        ("global_buttons", "Save/Back/Home Everywhere"),
        ("unsaved_guard",  "Unsaved Changes Guard"),
    ],
    "audit_backups": [
        ("audit_log",  "Central Audit Log"),
        ("audit_view", "Audit Viewer (SA)"),
        ("backup",     "Daily & Ad-hoc Backups"),
    ],
    "help_notify": [
        ("help_tab",    "Help (Ask/Search)"),
        ("push_notify", "Push (Web/iOS/Android)"),
        ("jobs_apply",  "Jobs – CV + LinkedIn"),
    ],
    # Insights — no tabs
    "analytics": [],
    "ai_logic": [],
}
DEFAULT_TAB = {k: (v[0][0] if v else None) for k, v in MODULE_TABS.items()}

# =============================
# 2) UTILS (robust)
# =============================

def _qp_get(name, default=None):
    try: return st.query_params.get(name, default)
    except Exception:
        try: return st.experimental_get_query_params().get(name,[default])[0]
        except Exception: return default

def _qp_set(**kw):
    try: st.query_params.update(kw)
    except Exception: st.experimental_set_query_params(**kw)

def _flatten(nav=NAV) -> List[str]:
    return [it["id"] for g in nav for it in g["items"]]

def _allowed(route_id: str, roles: Set[str]) -> bool:
    need = ROLE_VISIBILITY.get(route_id, set())
    return not need or bool(roles & need)

def _badge(route_id: str, tenant: str) -> int:
    v = BADGES.get(route_id, 0)
    if callable(v):
        try: return int(v(route_id, tenant))
        except Exception: return 0
    try: return int(v)
    except Exception: return 0

def _data_uri(path: str) -> str:
    if not path or not os.path.isfile(path): return ""
    mime, _ = mimetypes.guess_type(path)
    with open(path, "rb") as f: b64 = base64.b64encode(f.read()).decode()
    return f"data:{mime or 'image/png'};base64,{b64}"

def goto(module_id: str, set_default_tab: bool = True):
    st.session_state.fxz_route = module_id
    if set_default_tab and DEFAULT_TAB.get(module_id):
        _qp_set(route=module_id, tab=DEFAULT_TAB[module_id])
    else:
        _qp_set(route=module_id)
    st.rerun()

def _brand_css() -> str:
    # token replacement to avoid string formatting crashes
    css = """
<style>
section[data-testid="stSidebar"]{display:block!important}
section[data-testid="stSidebar"]>div>:not(#fxz-root){display:none!important}
section[data-testid="stSidebar"]>div{position:sticky;top:0;height:100vh;overflow-y:auto;background:__bg__ !important;padding:.7rem .55rem}
div[data-testid="collapsedControl"]{display:none!important}

/* Logos */
.fxz-header{display:flex;align-items:center;gap:10px;margin:2px 0 10px}
.fxz-logo{height:26px;width:auto;border:none;border-radius:0;object-fit:contain}
.fxz-divider{border-top:1px solid __border__;margin:8px 2px}

/* Title + tenant */
.fxz-brand{display:flex;justify-content:space-between;align-items:center;color:__text__}
.fxz-tenant{color:__muted__;font-size:.82rem}

/* Flat list with line accent */
.fxz-group{margin-top:10px}
.fxz-group-label{color:__muted__;text-transform:uppercase;letter-spacing:.08em;font-size:.74rem;margin:6px 0 6px 6px}
.fxz-summary{position:relative;padding:10px 0 10px 6px;border-bottom:1px solid __border__;cursor:pointer;color:__text__}
.fxz-summary::after{content:"+";position:absolute;right:6px;color:__muted__;opacity:0;transition:opacity .15s}
.fxz-summary:hover::after{opacity:1}
.fxz-open>.fxz-summary::after{content:"−";opacity:1;color:__accent__}

.fxz-item{display:flex;gap:.6rem;align-items:center;padding:10px 0 10px 12px;border-left:2px solid transparent;cursor:pointer;color:__text__}
.fxz-item:hover{border-left-color:__accent__;background:transparent}
.fxz-item.active{border-left-color:__accent__}
.fxz-badge{margin-left:auto;background:#233a26;color:#7fffb3;border:1px solid #3a5;font-size:.72rem;padding:1px 6px;border-radius:999px}

/* RTL support (dir=rtl) */
html[dir="rtl"] .fxz-item{padding-right:12px;padding-left:0;border-right:2px solid transparent;border-left:none}
html[dir="rtl"] .fxz-item:hover{border-right-color:__accent__}
html[dir="rtl"] .fxz-item.active{border-right-color:__accent__}
html[dir="rtl"] .fxz-summary{padding-right:6px;padding-left:0}
html[dir="rtl"] .fxz-summary::after{left:6px;right:auto}

/* Mobile tweaks */
@media(max-width:820px){.fxz-logo{height:22px}}
</style>
"""
    for k, v in {
        "__bg__": BRAND["bg"], "__text__": BRAND["text"], "__muted__": BRAND["muted"],
        "__border__": BRAND["border"], "__accent__": BRAND["accent"]
    }.items():
        css = css.replace(k, v)
    return css

# =============================
# 3) SIDEBAR (flat, +/−, logos, Quick-Find, RTL)
# =============================

def render_sidebar(auth_ok: bool = True, user_roles: Set[str] = None):
    if not auth_ok:
        st.markdown("<style>section[data-testid='stSidebar']{display:none!important}</style>", unsafe_allow_html=True)
        return None, None, "ltr"
    if user_roles is None: user_roles = {"Admin"}

    st.markdown(_brand_css(), unsafe_allow_html=True)

    st.session_state.setdefault("fxz_route", _flatten()[0])
    st.session_state.setdefault("fxz_open_group", NAV[0]["group"])
    st.session_state.setdefault("fxz_tenant", TENANTS[0] if TENANTS else "default")
    st.session_state.setdefault("fxz_lang", _qp_get("lang") or "en")
    st.session_state.setdefault("fxz_dir",  _qp_get("dir")  or "ltr")

    # deep link route
    r = _qp_get("route")
    if r and r in _flatten(): st.session_state.fxz_route = r

    app_logo_uri     = _data_uri(LOGOS.get("app", ""))
    company_logo_uri = _data_uri(LOGOS.get("company", ""))

    with st.sidebar:
        st.markdown("<div id='fxz-root'>", unsafe_allow_html=True)

        # Logos header
        header = "<div class='fxz-header'>"
        if app_logo_uri:     header += f"<img class='fxz-logo' src='{app_logo_uri}' alt='App'/>"
        else:                header += f"<b style='color:{BRAND['text']};font-size:16px'>{APP_NAME}</b>"
        if company_logo_uri: header += f"<img class='fxz-logo' src='{company_logo_uri}' alt='Company'/>"
        elif COMPANY_NAME:   header += f"<span style='color:{BRAND['muted']};font-size:12px'>{COMPANY_NAME}</span>"
        header += "</div>"
        st.markdown(header, unsafe_allow_html=True)
        st.markdown("<div class='fxz-divider'></div>", unsafe_allow_html=True)

        # Title + tenant + language/dir
        c1, c2 = st.columns([0.52, 0.48])
        with c1: st.markdown(f"<div class='fxz-brand'><b>{APP_NAME}</b></div>", unsafe_allow_html=True)
        with c2:
            cols = st.columns(3)
            with cols[0]:
                lang = st.selectbox("Lang", ["en", "ar"], index=["en","ar"].index(st.session_state.fxz_lang),
                                    label_visibility="collapsed")
            with cols[1]:
                direction = st.selectbox("Dir", ["ltr", "rtl"], index=["ltr","rtl"].index(st.session_state.fxz_dir),
                                         label_visibility="collapsed")
            with cols[2]:
                if TENANTS:
                    st.session_state.fxz_tenant = st.selectbox("Tenant", TENANTS,
                        index=TENANTS.index(st.session_state.fxz_tenant), label_visibility="collapsed")
            # persist lang/dir to URL and state
            if lang != st.session_state.fxz_lang or direction != st.session_state.fxz_dir:
                st.session_state.fxz_lang = lang; st.session_state.fxz_dir = direction
                _qp_set(route=st.session_state.fxz_route, tab=_qp_get("tab"), lang=lang, dir=direction)
                st.rerun()

        st.caption(f"<span class='fxz-tenant'>{st.session_state.fxz_tenant}</span>", unsafe_allow_html=True)

        # Quick-Find filter
        q = st.text_input("Quick find", value=_qp_get("q",""), placeholder="Search modules…")
        if q != _qp_get("q",""): _qp_set(q=q)
        q = (q or "").lower().strip()

        # Groups + items
        for grp in NAV:
            gname = grp["group"]
            is_open = (st.session_state.fxz_open_group == gname)

            st.markdown(f"<div class='fxz-group'><div class='fxz-group-label'>{gname}</div>", unsafe_allow_html=True)
            if st.button(f"{grp.get('icon','📂')}  {gname}", key=f"sum_{gname}", help="Expand / Collapse"):
                st.session_state.fxz_open_group = None if is_open else gname
                st.rerun()
            st.markdown(f"<div class='fxz-summary{' fxz-open' if is_open else ''}'></div>", unsafe_allow_html=True)

            if is_open:
                for it in grp["items"]:
                    rid, label = it["id"], it["label"]
                    # search filter
                    if q and (q not in label.lower() and q not in rid.lower()): 
                        continue
                    if not _allowed(rid, user_roles): 
                        continue
                    badge = _badge(rid, st.session_state.fxz_tenant)
                    active = (st.session_state.fxz_route == rid)
                    cA, cB = st.columns([1, .22])
                    with cA:
                        if st.button(f"{it.get('icon','•')}  {label}", key=f"itm_{rid}", use_container_width=True):
                            goto(rid, set_default_tab=True)
                    with cB:
                        if badge: st.markdown(f"<div class='fxz-badge'>{badge}</div>", unsafe_allow_html=True)
                    if active:
                        st.markdown(f"<style>button[kind='secondary']#itm_{rid}{{border-left:2px solid {BRAND['accent']};}}</style>", unsafe_allow_html=True)

            st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    # Apply text direction at the document level (RTL/LTR)
    st.markdown(f"<script>document.documentElement.setAttribute('dir','{st.session_state.fxz_dir}')</script>", unsafe_allow_html=True)
    return st.session_state.fxz_tenant, st.session_state.fxz_route, st.session_state.fxz_dir

# =============================
# 4) TABBED CONTENT + ROUTER
# =============================

def _active_tab(module_id: str) -> str | None:
    q = _qp_get("tab")
    ids = [t[0] for t in MODULE_TABS.get(module_id, [])]
    if q in ids: return q
    return DEFAULT_TAB.get(module_id)

def _tabs_ui(module_id: str) -> str | None:
    tabs = MODULE_TABS.get(module_id, [])
    if not tabs:
        return None
    ids    = [t[0] for t in tabs]
    labels = [t[1] for t in tabs]
    active = _active_tab(module_id) or ids[0]
    idx    = ids.index(active)
    chosen = st.radio(
        "", ids, index=idx, horizontal=True,
        format_func=lambda i: labels[ids.index(i)],
        label_visibility="collapsed", key=f"tab_{module_id}"
    )
    if chosen != active:
        _qp_set(route=module_id, tab=chosen, lang=_qp_get("lang","en"), dir=_qp_get("dir","ltr"))
        st.rerun()
    return chosen

# Import module loader with database connections
from module_loader_simple import load_module_content

# Modules with actual implementations
IMPLEMENTED_MODULES = [
    "finance_dashboard",
    "payments_invoicing", 
    "prop_units",
    "tickets",
    "contracts",
    "roles_permissions",
]

def stub(title: str):
    st.subheader(title)
    st.info(f"Loading: {title}")

TAB_HANDLERS: Dict[str, Dict[str, Callable[[], None]]] = {
    # Financial
    "finance_dashboard": {
        "fin_home":     lambda: stub("Finance → Ejar-style Summary"),
        "fin_metrics":  lambda: stub("Finance → Key Metrics"),
        "fin_overdues": lambda: stub("Finance → Overdues & Unpaid"),
        "fin_hijri":    lambda: stub("Finance → Hijri/Greg Months"),
    },
    "payments_invoicing": {
        "inv_manage":      lambda: stub("Payments → Invoices & Receipts (QR)"),
        "inv_send":        lambda: stub("Payments → Send (Email/WA/SMS)"),
        "inv_vat":         lambda: stub("Payments → VAT Invoices"),
        "inv_verify_docs": lambda: stub("Payments → Verification Docs"),
        "pricebook":       lambda: stub("Payments → Pricebook"),
        "banks_cfg":       lambda: stub("Payments → Banks Setup"),
    },
    "settlement_accounts": {
        "owner_settlements": lambda: stub("Settlement → Owner Settlements (Hijri)"),
        "accounts_chart":    lambda: stub("Settlement → Accounts Types"),
        "link_banks":        lambda: stub("Settlement → Link Payments → Banks"),
    },

    # Property & Tenancy
    "prop_units": {
        "prop_list":      lambda: stub("Properties & Units → All Properties"),
        "prop_unit_list": lambda: stub("Properties & Units → Units (Occ./Empty)"),
        "building_types": lambda: stub("Properties & Units → Building Types (Admin)"),
        "content_i18n":   lambda: stub("Properties & Units → Arabic & English"),
    },
    "owners_tenants": {
        "owner_add":   lambda: stub("Owners & Tenants → Add Owner"),
        "tenant_list": lambda: stub("Owners & Tenants → Tenants + Search"),
        "tenant_add":  lambda: stub("Owners & Tenants → Add Tenant"),
        "tenant_bulk": lambda: stub("Owners & Tenants → Bulk Upload"),
    },
    "contracts": {
        "contracts_active":  lambda: stub("Contracts → Active/Closed/Expired"),
        "contracts_sales":   lambda: stub("Contracts → Sales Contracts"),
        "contracts_eagree":  lambda: stub("Contracts → Electronic Agreement (KSA Law)"),
        "maintenance_request":lambda: stub("Contracts → Tenant Maintenance (10km)"),
        "project_request":    lambda: stub("Contracts → Customer Project"),
    },

    # Service & Maintenance
    "tickets": {
        "ticket_create":   lambda: stub("Tickets → Create Ticket (≤300/≤5 files)"),
        "ticket_ai_help":  lambda: stub("Tickets → AI Help"),
        "ticket_email":    lambda: stub("Tickets → Email Confirm"),
        "ticket_schedule": lambda: stub("Tickets → Schedule Visit"),
        "service_fee":     lambda: stub("Tickets → Service Fee %"),
        "parts_approval":  lambda: stub("Tickets → Parts Approval"),
    },
    "project_bidding": {
        "post_project":     lambda: stub("Project Bidding → Post Project"),
        "send_bids":        lambda: stub("Project Bidding → Send ≤3 Bids"),
        "review_offers":    lambda: stub("Project Bidding → Review/Approve"),
        "escrow_agreement": lambda: stub("Project Bidding → e-Agreement & Escrow"),
        "installments":     lambda: stub("Project Bidding → Installments"),
        "ratings":          lambda: stub("Project Bidding → Ratings"),
    },
    "vendor_store": {
        "separate_login":   lambda: stub("Vendor & Store → Separate Login"),
        "vendor_register":  lambda: stub("Vendor & Store → Vendor Registration (Gov Docs)"),
        "provider_services":lambda: stub("Vendor & Store → Add Services"),
        "provider_products":lambda: stub("Vendor & Store → Create Products"),
        "super_approval":   lambda: stub("Vendor & Store → Super Approvals"),
    },

    # User & Access
    "roles_permissions": {
        "admin_levels":   lambda: stub("UAC → Super Admin / Subscribed Admin"),
        "org_structure":  lambda: stub("UAC → Org Structure & Line Managers"),
        "hr_module":      lambda: stub("UAC → HR Module"),
        "feature_toggles":lambda: stub("UAC → Feature Toggles (iOS-like)"),
    },
    "profiles_interface": {
        "language_top": lambda: stub("UI → Language at Top"),
        "rtl_switch":   lambda: stub("UI → RTL/LTR"),
        "date_formats": lambda: stub("UI → Date Formats + Hijri"),
    },

    # Engagement & Loyalty
    "referral_program": {
        "ref_config": lambda: stub("Engagement → Referral Config (≤10%, ≤20 SAR)"),
        "ref_limits": lambda: stub("Engagement → Referral Limits (3×/month)"),
        "ref_toggle": lambda: stub("Engagement → Visibility Toggle (SA)"),
    },
    "family_mgmt": {
        "family_invite":  lambda: stub("Family → Invite Members"),
        "family_spend":   lambda: stub("Family → Spend From Main"),
        "family_relation":lambda: stub("Family → Relation Types"),
        "card_vault":     lambda: stub("Family → Card Vault + Auto-charge"),
    },

    # System Admin
    "system_controls": {
        "global_buttons": lambda: stub("System Admin → Global Buttons Everywhere"),
        "unsaved_guard":  lambda: stub("System Admin → Unsaved Changes Guard"),
    },
    "audit_backups": {
        "audit_log":  lambda: stub("System Admin → Central Audit Log"),
        "audit_view": lambda: stub("System Admin → Audit Viewer (SA)"),
        "backup":     lambda: stub("System Admin → Daily & Ad-hoc Backups"),
    },
    "help_notify": {
        "help_tab":    lambda: stub("System Admin → Help (Ask/Search)"),
        "push_notify": lambda: stub("System Admin → Push via Web/iOS/Android"),
        "jobs_apply":  lambda: stub("System Admin → Job Application (CV + LinkedIn)"),
    },

    # Insights
    "analytics": {},
    "ai_logic": {},
}

# =============================
# 5) APP ENTRY
# =============================

st.set_page_config(page_title=APP_NAME, layout="wide")

tenant, module, direction = render_sidebar(
    auth_ok=st.session_state.get("auth_ok", True),
    user_roles=st.session_state.get("roles", {"Admin"})
)

if not module:
    st.stop()

# Check if module has actual implementation
if module in IMPLEMENTED_MODULES:
    # Load the actual module page with database connections
    load_module_content(module)
else:
    # Show tabs if available
    tabs = MODULE_TABS.get(module, [])
    if tabs:
        ids  = [t[0] for t in tabs]
        labels = [t[1] for t in tabs]
        active = _active_tab(module) or ids[0]
        idx = ids.index(active)
        chosen = st.radio("", ids, index=idx, horizontal=True,
                          format_func=lambda i: labels[ids.index(i)],
                          label_visibility="collapsed", key=f"tabbar_{module}")
        if chosen != active:
            _qp_set(route=module, tab=chosen, lang=_qp_get("lang","en"), dir=_qp_get("dir","ltr"))
            st.rerun()

        handler = TAB_HANDLERS.get(module, {}).get(chosen)
        (handler or (lambda: st.warning(f"No handler wired for: {module} / {chosen}")))()
    else:
        st.info(f"Module '{module}' is under development. Check back soon!")