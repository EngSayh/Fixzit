"""
🤖 FIXZIT SOUQ ENTERPRISE - AI AUTOMATION DEMONSTRATION
Comprehensive showcase of AI-powered automation capabilities
Including Smart Classification, Assignment, Cost Estimation & RFQ Automation
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random
import time
import json

# Configure Streamlit page
st.set_page_config(
    page_title="Fixzit AI Automation Demo",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 10px;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid #667eea;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    .automation-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 15px;
        margin: 1rem 0;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .success-alert {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 5px;
        border-left: 5px solid #28a745;
        margin: 1rem 0;
    }
    .demo-section {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🤖 Fixzit Souq Enterprise</h1>
        <h2>AI-Powered Automation System</h2>
        <p>Comprehensive demonstration of intelligent work order processing, smart technician assignment, automated cost estimation, and procurement automation</p>
    </div>
    """, unsafe_allow_html=True)

    # Sidebar navigation
    st.sidebar.title("🔧 Navigation")
    page = st.sidebar.selectbox(
        "Select Demo Module",
        [
            "📊 Overview Dashboard",
            "🧠 Work Order Classification",
            "👨‍🔧 Smart Technician Assignment", 
            "💰 Automated Cost Estimation",
            "📋 Smart RFQ & Procurement",
            "📈 Analytics & Monitoring",
            "⚙️ System Configuration"
        ]
    )

    # Load the appropriate page
    if page == "📊 Overview Dashboard":
        show_overview_dashboard()
    elif page == "🧠 Work Order Classification":
        show_classification_demo()
    elif page == "👨‍🔧 Smart Technician Assignment":
        show_assignment_demo()
    elif page == "💰 Automated Cost Estimation":
        show_cost_estimation_demo()
    elif page == "📋 Smart RFQ & Procurement":
        show_rfq_demo()
    elif page == "📈 Analytics & Monitoring":
        show_analytics_dashboard()
    elif page == "⚙️ System Configuration":
        show_configuration_demo()

def show_overview_dashboard():
    """Display comprehensive overview of AI automation system"""
    st.markdown("## 📊 AI Automation System Overview")
    
    # Key Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("⚡ Automation Rate", "87%", "+12%")
    with col2:
        st.metric("🎯 Success Rate", "94%", "+5%")
    with col3:
        st.metric("⏱️ Time Saved", "480 hrs", "+85 hrs")
    with col4:
        st.metric("💰 Cost Savings", "$125K", "+$23K")

    # System Architecture
    st.markdown("### 🏗️ System Architecture")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="demo-section">
        <h4>🤖 AI Services</h4>
        <ul>
        <li>✅ <strong>Work Order Classification</strong> - TensorFlow.js + NLP</li>
        <li>✅ <strong>Smart Dispatch Service</strong> - ML-based assignment</li>
        <li>✅ <strong>Cost Estimation Engine</strong> - Predictive analytics</li>
        <li>✅ <strong>Smart RFQ Generator</strong> - Automated procurement</li>
        <li>✅ <strong>Automation Middleware</strong> - Event processing</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="demo-section">
        <h4>🔄 Automation Workflows</h4>
        <ul>
        <li>🔍 Auto work order classification</li>
        <li>👨‍🔧 Intelligent technician assignment</li>
        <li>💰 Automated cost estimation</li>
        <li>📋 Smart RFQ generation</li>
        <li>⚖️ Automated bid evaluation</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)

    # Real-time Activity
    st.markdown("### 🔄 Real-time Automation Activity")
    
    # Simulate real-time data
    activity_data = [
        {"Time": "08:45", "Service": "Classification", "Action": "Work Order #WO-2024-089 classified as 'PLUMBING'", "Status": "✅"},
        {"Time": "08:44", "Service": "Assignment", "Action": "Technician Ahmed assigned to WO-2024-088", "Status": "✅"},
        {"Time": "08:43", "Service": "Cost Estimation", "Action": "Estimated cost $450 for electrical repair", "Status": "✅"},
        {"Time": "08:42", "Service": "RFQ", "Action": "Generated RFQ for material procurement", "Status": "⏳"},
        {"Time": "08:41", "Service": "Procurement", "Action": "3 bids received for RFQ-2024-045", "Status": "📋"},
    ]
    
    df_activity = pd.DataFrame(activity_data)
    st.dataframe(df_activity, use_container_width=True)

    # Performance Charts
    st.markdown("### 📈 Performance Metrics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Automation success rate over time
        dates = pd.date_range(start='2024-09-01', end='2024-09-12', freq='D')
        success_rates = [85 + random.uniform(-3, 5) for _ in dates]
        
        fig = px.line(x=dates, y=success_rates, title="Daily Automation Success Rate")
        fig.update_traces(line_color='#667eea', line_width=3)
        fig.update_layout(yaxis_range=[80, 100])
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Service distribution
        services = ['Classification', 'Assignment', 'Cost Estimation', 'Procurement']
        values = [156, 142, 98, 67]
        
        fig = px.pie(values=values, names=services, title="Automation Tasks by Service")
        fig.update_traces(textinfo='percent+label')
        st.plotly_chart(fig, use_container_width=True)

def show_classification_demo():
    """Demo of AI work order classification"""
    st.markdown("## 🧠 AI Work Order Classification Demo")
    
    st.markdown("""
    <div class="automation-card">
    <h3>🎯 Smart Classification Engine</h3>
    <p>Uses TensorFlow.js and Natural NLP to automatically classify work orders, extract priorities, and identify required skills</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📝 Work Order Input")
        
        # Sample work order inputs
        sample_titles = [
            "Bathroom sink leaking in apartment 301",
            "Air conditioning not cooling properly",
            "Electrical outlet sparking in kitchen",
            "Door lock mechanism broken",
            "Window glass cracked need replacement"
        ]
        
        title = st.selectbox("Select sample work order or enter custom:", ["Custom"] + sample_titles)
        if title == "Custom":
            title = st.text_input("Work Order Title:", "")
        
        description = st.text_area("Description:", 
            "Water is leaking from under the bathroom sink. The leak appears to be coming from the pipes underneath. Tenant reported this morning that water has been dripping continuously.")
        
        # Additional inputs
        property_type = st.selectbox("Property Type:", ["Residential", "Commercial", "Industrial"])
        location = st.text_input("Location:", "Apartment 301, Building A")
        
        if st.button("🔍 Classify Work Order", type="primary"):
            if title:
                # Simulate classification processing
                with st.spinner("🤖 AI Classification in progress..."):
                    progress_bar = st.progress(0)
                    for i in range(100):
                        time.sleep(0.01)
                        progress_bar.progress(i + 1)
                    
                # Mock classification results
                classification_result = {
                    "category": "PLUMBING" if "leak" in title.lower() else "ELECTRICAL" if "electrical" in title.lower() else "HVAC",
                    "subcategory": "Pipe Repair",
                    "priority": "HIGH" if "sparking" in title.lower() else "MEDIUM",
                    "confidence": 0.94,
                    "required_skills": ["Plumbing", "Pipe Repair", "Water Damage Assessment"],
                    "estimated_duration": 2.5,
                    "urgency_level": "Standard"
                }
                
                st.markdown("""
                <div class="success-alert">
                <h4>✅ Classification Completed Successfully</h4>
                </div>
                """, unsafe_allow_html=True)
                
                # Display results
                col_a, col_b = st.columns(2)
                
                with col_a:
                    st.metric("📂 Category", classification_result["category"])
                    st.metric("🏷️ Subcategory", classification_result["subcategory"])
                    st.metric("⚡ Priority", classification_result["priority"])
                
                with col_b:
                    st.metric("🎯 Confidence", f"{classification_result['confidence']:.1%}")
                    st.metric("⏱️ Est. Duration", f"{classification_result['estimated_duration']} hrs")
                    st.metric("🚨 Urgency", classification_result["urgency_level"])
                
                # Required skills
                st.markdown("### 🛠️ Required Skills")
                skills_html = " ".join([f'<span style="background:#667eea;color:white;padding:5px 10px;margin:3px;border-radius:15px;display:inline-block;">{skill}</span>' for skill in classification_result["required_skills"]])
                st.markdown(skills_html, unsafe_allow_html=True)
    
    with col2:
        st.markdown("### 📊 Classification Stats")
        
        # Classification accuracy chart
        categories = ['Plumbing', 'Electrical', 'HVAC', 'General']
        accuracy = [96, 94, 91, 88]
        
        fig = go.Figure(data=go.Bar(x=categories, y=accuracy, marker_color='#667eea'))
        fig.update_layout(title="Model Accuracy by Category", yaxis_range=[80, 100])
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("### ⚙️ Model Info")
        st.markdown("""
        - **Model Version:** v2.3.1
        - **Training Data:** 50K+ work orders
        - **Languages:** English, Arabic
        - **Accuracy:** 94.2%
        - **Last Updated:** Sept 10, 2024
        """)

def show_assignment_demo():
    """Demo of smart technician assignment"""
    st.markdown("## 👨‍🔧 Smart Technician Assignment Demo")
    
    st.markdown("""
    <div class="automation-card">
    <h3>🎯 Intelligent Dispatch System</h3>
    <p>ML-based technician scoring using skill matching, proximity, workload, performance, and availability</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("### 🔧 Assignment Parameters")
        
        work_order_id = st.text_input("Work Order ID:", "WO-2024-089")
        category = st.selectbox("Category:", ["PLUMBING", "ELECTRICAL", "HVAC", "GENERAL_MAINTENANCE"])
        priority = st.selectbox("Priority:", ["EMERGENCY", "URGENT", "HIGH", "MEDIUM", "LOW"])
        
        # Location inputs
        st.markdown("#### 📍 Location")
        latitude = st.number_input("Latitude:", value=24.7136, format="%.4f")
        longitude = st.number_input("Longitude:", value=46.6753, format="%.4f")
        address = st.text_area("Address:", "Riyadh, Saudi Arabia")
        
        required_skills = st.multiselect("Required Skills:", 
            ["Plumbing", "Pipe Repair", "Water Damage", "Electrical", "HVAC", "General Repair"],
            default=["Plumbing", "Pipe Repair"])
        
        estimated_duration = st.slider("Estimated Duration (hours):", 0.5, 8.0, 2.5, 0.5)
        
        if st.button("🎯 Find Best Technician", type="primary"):
            # Simulate assignment processing
            with st.spinner("🤖 AI Assignment in progress..."):
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)
            
            # Mock assignment results
            assigned_technician = {
                "id": "TECH-001",
                "name": "Ahmed Al-Salem",
                "phone": "+966-50-123-4567",
                "rating": 4.8,
                "experience": 8,
                "skills": ["Plumbing", "Pipe Repair", "Water Damage", "Emergency Response"],
                "location": {"lat": 24.7200, "lng": 46.6800},
                "distance": 3.2,
                "eta": 25,
                "availability": "Available",
                "current_workload": 2,
                "total_score": 92
            }
            
            st.markdown("""
            <div class="success-alert">
            <h4>✅ Optimal Technician Assigned Successfully</h4>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        if 'assigned_technician' in locals():
            st.markdown("### 👨‍🔧 Assigned Technician")
            
            # Technician card
            st.markdown(f"""
            <div class="demo-section">
            <h4>{assigned_technician['name']}</h4>
            <p><strong>📞 Phone:</strong> {assigned_technician['phone']}</p>
            <p><strong>⭐ Rating:</strong> {assigned_technician['rating']}/5.0</p>
            <p><strong>🛠️ Experience:</strong> {assigned_technician['experience']} years</p>
            <p><strong>📍 Distance:</strong> {assigned_technician['distance']} km</p>
            <p><strong>⏱️ ETA:</strong> {assigned_technician['eta']} minutes</p>
            <p><strong>📋 Workload:</strong> {assigned_technician['current_workload']} active jobs</p>
            <p><strong>🎯 Match Score:</strong> {assigned_technician['total_score']}/100</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Skills match
            st.markdown("#### 🛠️ Skills Match")
            skills_html = " ".join([f'<span style="background:#28a745;color:white;padding:5px 10px;margin:3px;border-radius:15px;display:inline-block;">✓ {skill}</span>' for skill in assigned_technician["skills"]])
            st.markdown(skills_html, unsafe_allow_html=True)
            
            # Scoring breakdown
            st.markdown("#### 📊 Scoring Breakdown")
            scoring_data = {
                "Factor": ["Skill Match", "Proximity", "Performance", "Availability", "Workload"],
                "Score": [95, 88, 92, 100, 85],
                "Weight": ["35%", "25%", "20%", "15%", "5%"]
            }
            df_scores = pd.DataFrame(scoring_data)
            st.dataframe(df_scores, use_container_width=True)
        
        else:
            st.markdown("### 📋 Available Technicians")
            
            # Sample technician data
            technicians_data = [
                {"Name": "Ahmed Al-Salem", "Rating": 4.8, "Distance": "3.2 km", "Skills": "Plumbing, Electrical", "Status": "Available"},
                {"Name": "Omar Hassan", "Rating": 4.6, "Distance": "5.1 km", "Skills": "HVAC, General", "Status": "Busy"},
                {"Name": "Khalid Al-Rashid", "Rating": 4.9, "Distance": "2.8 km", "Skills": "Plumbing, Water", "Status": "Available"},
                {"Name": "Faisal Al-Mutairi", "Rating": 4.7, "Distance": "6.3 km", "Skills": "Electrical, Emergency", "Status": "Available"},
            ]
            
            df_tech = pd.DataFrame(technicians_data)
            st.dataframe(df_tech, use_container_width=True)

def show_cost_estimation_demo():
    """Demo of automated cost estimation"""
    st.markdown("## 💰 Automated Cost Estimation Demo")
    
    st.markdown("""
    <div class="automation-card">
    <h3>💡 Predictive Cost Engine</h3>
    <p>ML-based cost estimation using historical data, material prices, and labor analytics</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("### 📋 Estimation Parameters")
        
        work_order_id = st.text_input("Work Order ID:", "WO-2024-089")
        category = st.selectbox("Work Category:", ["PLUMBING", "ELECTRICAL", "HVAC", "GENERAL_MAINTENANCE"])
        subcategory = st.selectbox("Subcategory:", ["Pipe Repair", "Leak Fix", "Installation", "Maintenance"])
        
        property_type = st.selectbox("Property Type:", ["RESIDENTIAL", "COMMERCIAL", "INDUSTRIAL"])
        region = st.selectbox("Region:", ["Riyadh", "Jeddah", "Dammam", "Mecca", "Medina"])
        accessibility = st.selectbox("Site Accessibility:", ["EASY", "MODERATE", "DIFFICULT"])
        
        # Work details
        complexity = st.slider("Work Complexity (1-5):", 1, 5, 3)
        estimated_duration = st.slider("Estimated Duration (hours):", 0.5, 12.0, 3.0, 0.5)
        required_skills = st.multiselect("Required Skills:", 
            ["Plumbing", "Pipe Repair", "Welding", "Electrical", "HVAC"],
            default=["Plumbing", "Pipe Repair"])
        
        # Materials needed
        st.markdown("#### 🔧 Materials Required")
        materials = st.text_area("Materials List:", "- PVC pipes (2 meters)\n- Pipe fittings (4 pieces)\n- Waterproof sealant\n- Tools rental")
        
        if st.button("💰 Generate Cost Estimate", type="primary"):
            # Simulate estimation processing
            with st.spinner("🤖 AI Cost Analysis in progress..."):
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)
            
            # Mock cost estimation results
            cost_estimate = {
                "total_cost": 450.00,
                "labor_cost": 180.00,
                "materials_cost": 220.00,
                "additional_costs": 50.00,
                "labor_hours": 3.0,
                "confidence": 0.91,
                "auto_approval": True
            }
            
            st.markdown("""
            <div class="success-alert">
            <h4>✅ Cost Estimation Completed</h4>
            <p>Estimate generated with 91% confidence based on 500+ similar jobs</p>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        if 'cost_estimate' in locals():
            st.markdown("### 💰 Cost Breakdown")
            
            # Total cost display
            st.metric("💰 Total Estimated Cost", f"${cost_estimate['total_cost']:.2f}", 
                     delta=f"±${cost_estimate['total_cost'] * 0.1:.2f}")
            
            # Breakdown chart
            breakdown_data = {
                "Component": ["Labor", "Materials", "Additional"],
                "Cost": [cost_estimate['labor_cost'], cost_estimate['materials_cost'], cost_estimate['additional_costs']],
                "Percentage": [40, 49, 11]
            }
            
            fig = px.pie(breakdown_data, values='Cost', names='Component', 
                        title="Cost Breakdown", color_discrete_sequence=['#667eea', '#764ba2', '#f093fb'])
            st.plotly_chart(fig, use_container_width=True)
            
            # Detailed breakdown
            st.markdown("#### 📊 Detailed Breakdown")
            breakdown_df = pd.DataFrame({
                "Item": ["Labor Cost", "Materials", "Tools Rental", "Transportation", "Overhead"],
                "Amount": ["$180.00", "$220.00", "$30.00", "$15.00", "$5.00"],
                "Description": [
                    f"{cost_estimate['labor_hours']} hours @ $60/hr",
                    "Pipes, fittings, sealant",
                    "Specialized tools",
                    "Technician travel",
                    "Administrative costs"
                ]
            })
            st.dataframe(breakdown_df, use_container_width=True)
            
            # Auto-approval status
            if cost_estimate['auto_approval']:
                st.markdown("""
                <div style="background:#d4edda;color:#155724;padding:1rem;border-radius:5px;border-left:5px solid #28a745;">
                <h5>✅ Auto-Approval Eligible</h5>
                <p>Cost is within auto-approval threshold ($500)</p>
                </div>
                """, unsafe_allow_html=True)
        
        else:
            st.markdown("### 📈 Historical Cost Data")
            
            # Sample historical data
            historical_data = [
                {"Date": "2024-09-10", "Category": "Plumbing", "Cost": "$420", "Duration": "2.5h"},
                {"Date": "2024-09-08", "Category": "Plumbing", "Cost": "$380", "Duration": "3.0h"},
                {"Date": "2024-09-05", "Category": "Electrical", "Cost": "$520", "Duration": "4.0h"},
                {"Date": "2024-09-03", "Category": "Plumbing", "Cost": "$460", "Duration": "2.8h"},
                {"Date": "2024-09-01", "Category": "HVAC", "Cost": "$680", "Duration": "5.5h"}
            ]
            
            df_historical = pd.DataFrame(historical_data)
            st.dataframe(df_historical, use_container_width=True)

def show_rfq_demo():
    """Demo of smart RFQ generation and procurement"""
    st.markdown("## 📋 Smart RFQ & Procurement Automation Demo")
    
    st.markdown("""
    <div class="automation-card">
    <h3>🎯 Intelligent Procurement Engine</h3>
    <p>Automated RFQ generation, smart vendor selection, and AI-powered bid evaluation</p>
    </div>
    """, unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["📋 RFQ Generation", "⚖️ Bid Evaluation", "📊 Procurement Analytics"])
    
    with tab1:
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.markdown("### 📝 RFQ Details")
            
            work_order_id = st.text_input("Work Order ID:", "WO-2024-089")
            category = st.selectbox("Material Category:", ["Plumbing Supplies", "Electrical Components", "HVAC Parts", "General Materials"])
            priority = st.selectbox("RFQ Priority:", ["EMERGENCY", "URGENT", "HIGH", "MEDIUM", "LOW"])
            
            # Budget range
            st.markdown("#### 💰 Budget Range")
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                budget_min = st.number_input("Minimum ($):", value=800.0, step=50.0)
            with col_b:
                budget_max = st.number_input("Maximum ($):", value=1200.0, step=50.0)
            with col_c:
                budget_preferred = st.number_input("Preferred ($):", value=1000.0, step=50.0)
            
            deadline = st.date_input("Deadline:", value=datetime.now() + timedelta(days=7))
            
            # Material requirements
            st.markdown("#### 🔧 Material Requirements")
            materials = st.text_area("Materials Required:", 
                "- PVC pipes (20mm, 10 meters)\n- Pipe fittings (10 pieces)\n- Waterproof sealant (2 tubes)\n- Installation hardware")
            
            quality_requirements = st.multiselect("Quality Requirements:", 
                ["ISO Certified", "SASO Approved", "Warranty Required", "Local Supplier Preferred"],
                default=["ISO Certified", "SASO Approved"])
            
            if st.button("📋 Generate Smart RFQ", type="primary"):
                # Simulate RFQ generation
                with st.spinner("🤖 Generating Smart RFQ..."):
                    progress_bar = st.progress(0)
                    for i in range(100):
                        time.sleep(0.01)
                        progress_bar.progress(i + 1)
                
                # Mock RFQ results
                rfq_result = {
                    "rfq_id": "RFQ-2024-045",
                    "selected_vendors": 5,
                    "estimated_responses": 4,
                    "auto_evaluation": True
                }
                
                st.success(f"✅ RFQ {rfq_result['rfq_id']} generated successfully!")
                st.info(f"📧 Sent to {rfq_result['selected_vendors']} pre-qualified vendors")
                st.info(f"📊 Expected {rfq_result['estimated_responses']} responses")
        
        with col2:
            st.markdown("### 🏢 Selected Vendors")
            
            vendors_data = [
                {"Name": "Al-Salem Trading Co.", "Rating": 4.8, "Location": "Riyadh", "Specialization": "Plumbing", "Response Rate": "95%"},
                {"Name": "Gulf Supplies Ltd.", "Rating": 4.6, "Location": "Jeddah", "Specialization": "General", "Response Rate": "88%"},
                {"Name": "Modern Materials", "Rating": 4.9, "Location": "Riyadh", "Specialization": "Plumbing", "Response Rate": "92%"},
                {"Name": "Saudi Hardware Co.", "Rating": 4.5, "Location": "Dammam", "Specialization": "Mixed", "Response Rate": "85%"},
                {"Name": "Premium Supplies", "Rating": 4.7, "Location": "Riyadh", "Specialization": "Premium", "Response Rate": "90%"}
            ]
            
            df_vendors = pd.DataFrame(vendors_data)
            st.dataframe(df_vendors, use_container_width=True)
            
            st.markdown("### 📄 RFQ Document Preview")
            st.markdown("""
            **RFQ Title:** Materials for Plumbing Work Order WO-2024-089
            
            **Requirements:**
            - PVC pipes (20mm, 10 meters)
            - Pipe fittings (10 pieces)  
            - Waterproof sealant (2 tubes)
            - Installation hardware
            
            **Budget Range:** $800 - $1,200 (Preferred: $1,000)
            
            **Quality Standards:** ISO Certified, SASO Approved
            
            **Delivery Deadline:** Within 7 days
            
            **Evaluation Criteria:**
            - Price competitiveness (35%)
            - Quality compliance (25%)
            - Delivery timeline (20%)
            - Past performance (15%)
            - Certifications (5%)
            """)
    
    with tab2:
        st.markdown("### ⚖️ Automated Bid Evaluation")
        
        # Mock bid data
        bids_data = [
            {"Vendor": "Al-Salem Trading Co.", "Total": "$950", "Score": 92, "Delivery": "5 days", "Recommendation": "✅ Accept"},
            {"Vendor": "Modern Materials", "Total": "$1,020", "Score": 88, "Delivery": "6 days", "Recommendation": "📋 Negotiate"},
            {"Vendor": "Gulf Supplies Ltd.", "Total": "$890", "Score": 85, "Delivery": "7 days", "Recommendation": "✅ Accept"},
            {"Vendor": "Saudi Hardware Co.", "Total": "$1,150", "Score": 76, "Delivery": "8 days", "Recommendation": "❌ Reject"},
        ]
        
        df_bids = pd.DataFrame(bids_data)
        st.dataframe(df_bids, use_container_width=True)
        
        # Winning bid details
        st.markdown("### 🏆 Recommended Winner")
        
        st.markdown("""
        <div class="automation-card">
        <h4>Al-Salem Trading Co.</h4>
        <p><strong>💰 Total Bid:</strong> $950.00</p>
        <p><strong>🎯 AI Score:</strong> 92/100</p>
        <p><strong>📦 Delivery:</strong> 5 days</p>
        <p><strong>⭐ Vendor Rating:</strong> 4.8/5.0</p>
        <p><strong>🤖 Recommendation:</strong> Auto-approve and generate PO</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Scoring breakdown
        st.markdown("#### 📊 Evaluation Breakdown")
        eval_data = {
            "Criteria": ["Price Competitiveness", "Quality Compliance", "Delivery Timeline", "Past Performance", "Certifications"],
            "Weight": ["35%", "25%", "20%", "15%", "5%"],
            "Score": [95, 92, 88, 90, 85],
            "Weighted": [33.3, 23.0, 17.6, 13.5, 4.3]
        }
        df_eval = pd.DataFrame(eval_data)
        st.dataframe(df_eval, use_container_width=True)
        
        if st.button("🤖 Auto-Approve and Generate PO", type="primary"):
            st.success("✅ Purchase Order PO-2024-156 generated automatically!")
            st.info("📧 Vendor and procurement team notified")
    
    with tab3:
        st.markdown("### 📊 Procurement Analytics")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("📋 Total RFQs", "45", "+8")
        with col2:
            st.metric("🤖 Auto-Approval Rate", "73%", "+5%")
        with col3:
            st.metric("💰 Cost Savings", "$125K", "+$23K")
        
        # Charts
        col1, col2 = st.columns(2)
        
        with col1:
            # RFQ volume over time
            dates = pd.date_range(start='2024-09-01', end='2024-09-12', freq='D')
            rfq_volumes = [3 + random.randint(-2, 4) for _ in dates]
            
            fig = px.bar(x=dates, y=rfq_volumes, title="Daily RFQ Volume")
            fig.update_traces(marker_color='#667eea')
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Vendor performance
            vendors = ['Al-Salem', 'Modern Materials', 'Gulf Supplies', 'Saudi Hardware']
            performance = [92, 88, 85, 76]
            
            fig = px.bar(x=vendors, y=performance, title="Vendor Performance Scores")
            fig.update_traces(marker_color='#764ba2')
            fig.update_layout(yaxis_range=[70, 100])
            st.plotly_chart(fig, use_container_width=True)

def show_analytics_dashboard():
    """Display comprehensive analytics dashboard"""
    st.markdown("## 📈 AI Automation Analytics & Monitoring")
    
    # Key Performance Indicators
    st.markdown("### 🎯 Key Performance Indicators")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("⚡ Total Events", "1,250", "+156")
    with col2:
        st.metric("✅ Success Rate", "94.2%", "+1.5%")
    with col3:
        st.metric("⏱️ Avg Processing", "2.3s", "-0.4s")
    with col4:
        st.metric("💰 Cost Savings", "$125K", "+$23K")
    with col5:
        st.metric("🤖 Automation %", "87%", "+12%")
    
    # Service Performance
    st.markdown("### 🔧 Service Performance Metrics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Processing time by service
        services = ['Classification', 'Assignment', 'Cost Estimation', 'Procurement']
        processing_times = [1.2, 2.8, 3.5, 4.1]
        
        fig = px.bar(x=services, y=processing_times, title="Average Processing Time by Service (seconds)")
        fig.update_traces(marker_color='#667eea')
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Success rates by service
        success_rates = [96.2, 94.8, 92.5, 89.3]
        
        fig = px.bar(x=services, y=success_rates, title="Success Rates by Service (%)")
        fig.update_traces(marker_color='#764ba2')
        fig.update_layout(yaxis_range=[80, 100])
        st.plotly_chart(fig, use_container_width=True)
    
    # Activity Timeline
    st.markdown("### 📊 Activity Timeline")
    
    # Generate sample timeline data
    dates = pd.date_range(start='2024-09-01', end='2024-09-12', freq='D')
    timeline_data = []
    
    for date in dates:
        timeline_data.extend([
            {"Date": date, "Service": "Classification", "Events": random.randint(15, 25)},
            {"Date": date, "Service": "Assignment", "Events": random.randint(12, 20)},
            {"Date": date, "Service": "Cost Estimation", "Events": random.randint(8, 15)},
            {"Date": date, "Service": "Procurement", "Events": random.randint(5, 10)}
        ])
    
    df_timeline = pd.DataFrame(timeline_data)
    
    fig = px.line(df_timeline, x="Date", y="Events", color="Service", 
                  title="Daily Automation Events by Service")
    st.plotly_chart(fig, use_container_width=True)
    
    # System Health
    st.markdown("### 🏥 System Health Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class="demo-section">
        <h4>🧠 Classification Service</h4>
        <p>✅ <strong>Status:</strong> Active</p>
        <p>🕒 <strong>Uptime:</strong> 99.9%</p>
        <p>📊 <strong>Load:</strong> 23%</p>
        <p>🔄 <strong>Last Update:</strong> 2 minutes ago</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="demo-section">
        <h4>👨‍🔧 Assignment Service</h4>
        <p>✅ <strong>Status:</strong> Active</p>
        <p>🕒 <strong>Uptime:</strong> 99.8%</p>
        <p>📊 <strong>Load:</strong> 31%</p>
        <p>🔄 <strong>Last Update:</strong> 1 minute ago</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="demo-section">
        <h4>💰 Cost Estimation</h4>
        <p>✅ <strong>Status:</strong> Active</p>
        <p>🕒 <strong>Uptime:</strong> 99.7%</p>
        <p>📊 <strong>Load:</strong> 18%</p>
        <p>🔄 <strong>Last Update:</strong> 3 minutes ago</p>
        </div>
        """, unsafe_allow_html=True)

def show_configuration_demo():
    """Display system configuration interface"""
    st.markdown("## ⚙️ System Configuration")
    
    st.markdown("""
    <div class="automation-card">
    <h3>🔧 AI Automation Configuration</h3>
    <p>Configure automation thresholds, enable/disable services, and manage system behavior</p>
    </div>
    """, unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["🧠 AI Services", "🔄 Workflows", "📊 Monitoring"])
    
    with tab1:
        st.markdown("### 🤖 AI Services Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🧠 Work Order Classification")
            
            classification_enabled = st.checkbox("Enable Auto-Classification", value=True)
            confidence_threshold = st.slider("Confidence Threshold:", 0.5, 1.0, 0.8, 0.05)
            auto_assignment = st.checkbox("Enable Auto-Assignment", value=True)
            
            st.markdown("#### 👨‍🔧 Smart Dispatch")
            
            dispatch_enabled = st.checkbox("Enable Smart Dispatch", value=True)
            auto_assign_threshold = st.slider("Auto-Assign Threshold:", 0.5, 1.0, 0.8, 0.05)
            max_distance = st.slider("Max Distance (km):", 5, 100, 50, 5)
            
            st.markdown("#### 💰 Cost Estimation")
            
            estimation_enabled = st.checkbox("Enable Auto-Estimation", value=True)
            auto_approval_threshold = st.number_input("Auto-Approval Threshold ($):", value=5000.0, step=100.0)
            require_multiple_quotes = st.checkbox("Require Multiple Quotes", value=True)
        
        with col2:
            st.markdown("#### 📋 Procurement Automation")
            
            procurement_enabled = st.checkbox("Enable Smart Procurement", value=True)
            rfq_threshold = st.number_input("Auto-RFQ Threshold ($):", value=10000.0, step=500.0)
            auto_bid_evaluation = st.checkbox("Enable Auto-Bid Evaluation", value=True)
            auto_approval_amount = st.number_input("Auto-Approval Amount ($):", value=25000.0, step=1000.0)
            
            st.markdown("#### 📧 Notifications")
            
            realtime_notifications = st.checkbox("Real-time Notifications", value=True)
            email_notifications = st.checkbox("Email Notifications", value=True)
            sms_notifications = st.checkbox("SMS Notifications", value=False)
            dashboard_notifications = st.checkbox("Dashboard Notifications", value=True)
            
            st.markdown("#### 🔒 Security Settings")
            
            audit_logging = st.checkbox("Enable Audit Logging", value=True)
            encryption_enabled = st.checkbox("Enable Data Encryption", value=True)
            api_rate_limiting = st.checkbox("Enable API Rate Limiting", value=True)
    
    with tab2:
        st.markdown("### 🔄 Automation Workflows")
        
        workflows_data = [
            {"Name": "Classify New Work Orders", "Status": "✅ Active", "Priority": "High", "Last Run": "2 min ago", "Success Rate": "96%"},
            {"Name": "Auto-Assign Technicians", "Status": "✅ Active", "Priority": "High", "Last Run": "1 min ago", "Success Rate": "94%"},
            {"Name": "Estimate Costs", "Status": "✅ Active", "Priority": "Medium", "Last Run": "5 min ago", "Success Rate": "92%"},
            {"Name": "Generate Smart RFQs", "Status": "✅ Active", "Priority": "Medium", "Last Run": "10 min ago", "Success Rate": "89%"},
            {"Name": "Evaluate Bids", "Status": "⏸️ Paused", "Priority": "Low", "Last Run": "1 hour ago", "Success Rate": "87%"},
        ]
        
        df_workflows = pd.DataFrame(workflows_data)
        st.dataframe(df_workflows, use_container_width=True)
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("▶️ Start All Workflows", type="primary"):
                st.success("All workflows started successfully!")
        
        with col2:
            if st.button("⏸️ Pause All Workflows"):
                st.info("All workflows paused.")
        
        with col3:
            if st.button("🔄 Restart Workflows"):
                st.success("All workflows restarted!")
    
    with tab3:
        st.markdown("### 📊 Monitoring Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🔔 Alerts & Thresholds")
            
            error_rate_threshold = st.slider("Error Rate Alert (%):", 1, 20, 5)
            response_time_threshold = st.slider("Response Time Alert (seconds):", 1, 30, 10)
            queue_size_threshold = st.slider("Queue Size Alert:", 10, 1000, 100)
            
            st.markdown("#### 📈 Metrics Collection")
            
            collect_performance_metrics = st.checkbox("Performance Metrics", value=True)
            collect_usage_statistics = st.checkbox("Usage Statistics", value=True)
            collect_error_logs = st.checkbox("Error Logs", value=True)
            
        with col2:
            st.markdown("#### 📊 Dashboard Settings")
            
            refresh_interval = st.selectbox("Refresh Interval:", ["5 seconds", "30 seconds", "1 minute", "5 minutes"])
            chart_theme = st.selectbox("Chart Theme:", ["Light", "Dark", "Auto"])
            show_advanced_metrics = st.checkbox("Show Advanced Metrics", value=False)
            
            st.markdown("#### 💾 Data Retention")
            
            metrics_retention = st.selectbox("Metrics Retention:", ["7 days", "30 days", "90 days", "1 year"])
            logs_retention = st.selectbox("Logs Retention:", ["7 days", "30 days", "90 days"])
            audit_retention = st.selectbox("Audit Logs:", ["30 days", "90 days", "1 year", "Permanent"])
    
    # Save configuration
    if st.button("💾 Save Configuration", type="primary"):
        st.success("✅ Configuration saved successfully!")
        st.info("🔄 Services will be updated with new settings")

if __name__ == "__main__":
    main()