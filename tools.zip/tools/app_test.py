"""
Simple Sidebar Test - Basic Streamlit Sidebar
"""

import streamlit as st

# Basic page config
st.set_page_config(
    page_title="Sidebar Test",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# SIMPLE SIDEBAR TEST
st.sidebar.title("🔧 FIXZIT")
st.sidebar.markdown("**This is a test sidebar**")
st.sidebar.button("Test Button 1")
st.sidebar.button("Test Button 2")
st.sidebar.button("Test Button 3")

st.sidebar.markdown("---")
st.sidebar.markdown("## Navigation Groups")

# Simple expandable sections
with st.sidebar.expander("🏠 Dashboard", expanded=True):
    st.button("Dashboard", key="dash_btn")
    st.button("Analytics", key="analytics_btn")

with st.sidebar.expander("🛠️ Work Management"):
    st.button("Boards", key="boards_btn")
    st.button("Tickets", key="tickets_btn")

with st.sidebar.expander("🏢 Properties"):
    st.button("Properties", key="prop_btn")
    st.button("Contracts", key="contracts_btn")

# Main content
st.title("🔧 Fixzit - Sidebar Test")
st.markdown("## Testing Basic Sidebar Functionality")

if st.sidebar.button("TEST: Click me"):
    st.success("✅ Sidebar button clicked! Sidebar is working!")

st.markdown("""
### What you should see on the left:
- **🔧 FIXZIT** title
- **Test buttons**
- **Expandable navigation groups**
- **Dashboard, Work Management, Properties sections**

If you can see this sidebar, then we know Streamlit sidebar works and we can build the full navigation.
""")

st.sidebar.markdown("---")
st.sidebar.markdown("**© 2024 Fixzit**")