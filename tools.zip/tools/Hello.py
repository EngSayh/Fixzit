"""
FIXZIT - Clean Entry Point (Streamlit uses Hello.py as default)
"""

import streamlit as st

# Page config MUST be first
st.set_page_config(
    page_title="Fixzit - شركة خدماتي الشاملة",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Auto-authenticate for testing
if "authenticated" not in st.session_state:
    st.session_state.authenticated = True
if "user_name" not in st.session_state:
    st.session_state.user_name = "Test User"
if "username" not in st.session_state:
    st.session_state.username = "Test User"
if "user_role" not in st.session_state:
    st.session_state.user_role = "admin"

# Direct routing to dashboard with error handling
try:
    st.switch_page("pages/01_Dashboard_WorkOS.py")
except Exception:
    # Fallback to basic dashboard
    st.title("🔧 Fixzit - شركة خدماتي الشاملة")
    st.info("Welcome to Fixzit! Please wait while the dashboard loads...")
    st.markdown(
        """
    <meta http-equiv="refresh" content="2;url=/01_Dashboard_WorkOS">
    """,
        unsafe_allow_html=True,
    )
