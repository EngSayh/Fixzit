#!/usr/bin/env node

/**
 * FIXZIT SOUQ Backend Function Checker - Simplified Version
 * Scans backend codebase for missing functions based on scope requirements
 */

const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
  scanDirs: ['./routes', './models', './middleware', './services', './utils'],
  fileExtensions: ['.js', '.ts'],
  ignorePatterns: ['node_modules', 'dist', 'build', '.git', 'test', 'tests']
};

// Required Backend Functions based on your scope
const REQUIRED_FUNCTIONS = {
  // Authentication & Security Functions (CRITICAL)
  auth: [
    'login', 'logout', 'refreshToken', 'validateJWT', 'checkPermissions',
    'enforceRBAC', 'logSecurityEvent', 'detectAnomalies', 'rateLimitCheck'
  ],
  
  // Finance Module Functions (ZATCA Compliance - CRITICAL)
  finance: [
    'createInvoice', 'generateZATCAQRCode', 'submitToZATCA', 'processPayment',
    'recordExpense', 'getBudgetVsActual', 'calculateVAT', 'generateTaxReport',
    'reconcilePayments', 'processBulkPayments'
  ],
  
  // Work Orders Module Functions
  workOrders: [
    'createWorkOrder', 'updateWorkOrderStatus', 'assignTechnician',
    'autoAssignWorkOrder', 'trackSLA', 'getServiceHistory',
    'dispatchWorkOrder', 'generatePreventiveMaintenance', 'updateWorkOrderState',
    'getKanbanView', 'getCalendarView', 'getGanttView', 'calculateRoute'
  ],
  
  // Dashboard Module Functions
  dashboard: [
    'getDashboardMetrics', 'getActivityFeed', 'getCalendarEvents',
    'getRoleBasedDashboard', 'getMyWork', 'getAlerts',
    'updateKPICard', 'refreshDashboard'
  ],
  
  // Properties Module Functions
  properties: [
    'getProperties', 'createProperty', 'updateProperty', 'deleteProperty',
    'getUnits', 'getTenants', 'createLease', 'updateLease',
    'getAssetRegister', 'createInspection', 'getInspectionTemplates',
    'uploadDocument', 'getPropertyLocation', 'generatePropertyReport'
  ],
  
  // Portal-specific Functions (CRITICAL)
  portals: [
    'getTenantPortalData', 'getTechnicianPortalData', 'getOwnerPortalData',
    'getCorporateManagerData', 'getVendorPortalData',
    'authenticatePortalUser', 'getPortalNotifications'
  ],
  
  // Critical Workflow Functions
  workflows: [
    'processTenantMaintenanceRequest', 'processRFQToPurchaseOrder',
    'processOwnerApproval', 'getWorkflowStatus', 'moveToNextStep',
    'rollbackWorkflow', 'validateWorkflowRules'
  ],
  
  // Real-time Functions (CRITICAL)
  realtime: [
    'establishWebSocket', 'broadcastUpdate', 'sendNotification',
    'syncData', 'handleRealtimeEvent', 'manageSocketRooms'
  ]
};

// Function to recursively scan directories
function scanDirectory(dirPath, results = []) {
  if (!fs.existsSync(dirPath)) return results;
  
  const items = fs.readdirSync(dirPath);
  
  for (const item of items) {
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      // Skip ignored directories
      if (!CONFIG.ignorePatterns.some(pattern => item.includes(pattern))) {
        scanDirectory(fullPath, results);
      }
    } else if (stat.isFile()) {
      // Check if file has valid extension
      if (CONFIG.fileExtensions.some(ext => fullPath.endsWith(ext))) {
        results.push(fullPath);
      }
    }
  }
  
  return results;
}

// Function to scan files for implemented functions
function scanForFunctions(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const functions = new Set();
    
    // Regex patterns to find function definitions
    const patterns = [
      // Regular functions
      /function\s+(\w+)\s*\(/g,
      // Arrow functions assigned to const/let/var
      /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Methods in objects
      /(\w+)\s*:\s*(?:async\s*)?function\s*\(/g,
      /(\w+)\s*:\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      // Express route handlers (extract route name from path)
      /router\.(get|post|put|delete|patch)\s*\(\s*['"`]\/([^'"`\/]*)/g,
      // Controller methods
      /exports\.(\w+)\s*=/g,
      // ES6 exports
      /export\s+(?:async\s+)?function\s+(\w+)/g,
      /export\s+const\s+(\w+)\s*=/g,
      // Class methods
      /(?:async\s+)?(\w+)\s*\([^)]*\)\s*{/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        if (match[1] && !match[1].startsWith('_') && match[1] !== 'use') {
          functions.add(match[1]);
        }
        if (match[2] && !match[2].startsWith('_')) {
          functions.add(match[2]);
        }
      }
    });
    
    return functions;
  } catch (error) {
    console.error(`Error reading file ${filePath}:`, error.message);
    return new Set();
  }
}

// Function to scan entire backend
function scanBackend() {
  console.log('📁 Scanning directories:', CONFIG.scanDirs.join(', '));
  
  const implementedFunctions = new Set();
  const scannedFiles = [];
  
  for (const dir of CONFIG.scanDirs) {
    const files = scanDirectory(dir);
    
    for (const file of files) {
      const functions = scanForFunctions(file);
      functions.forEach(fn => implementedFunctions.add(fn));
      if (functions.size > 0) {
        scannedFiles.push({ file, functions: Array.from(functions) });
      }
    }
  }
  
  return { implementedFunctions, scannedFiles };
}

// Function to find missing functions
function findMissingFunctions(implementedFunctions) {
  const missing = {};
  const found = {};
  const partial = {};
  
  for (const [module, functions] of Object.entries(REQUIRED_FUNCTIONS)) {
    missing[module] = [];
    found[module] = [];
    partial[module] = [];
    
    for (const fn of functions) {
      let isFound = false;
      
      // Check exact match
      if (implementedFunctions.has(fn)) {
        found[module].push(fn);
        isFound = true;
      } else {
        // Check partial matches (case-insensitive or similar names)
        const lowerFn = fn.toLowerCase();
        for (const implFn of implementedFunctions) {
          if (implFn.toLowerCase().includes(lowerFn.replace(/([A-Z])/g, '_$1').toLowerCase()) ||
              lowerFn.includes(implFn.toLowerCase())) {
            partial[module].push({ required: fn, found: implFn });
            isFound = true;
            break;
          }
        }
      }
      
      if (!isFound) {
        missing[module].push(fn);
      }
    }
  }
  
  return { missing, found, partial };
}

// Function to generate report
function generateReport() {
  console.log('\n🔍 FIXZIT SOUQ Backend Function Checker\n');
  console.log('='.repeat(80));
  
  const { implementedFunctions, scannedFiles } = scanBackend();
  
  console.log(`\n✅ Found ${implementedFunctions.size} implemented functions`);
  console.log(`📄 Scanned ${scannedFiles.length} files\n`);
  
  const { missing, found, partial } = findMissingFunctions(implementedFunctions);
  
  // Calculate statistics
  let totalRequired = 0;
  let totalFound = 0;
  let totalMissing = 0;
  let totalPartial = 0;
  
  for (const module of Object.keys(REQUIRED_FUNCTIONS)) {
    totalRequired += REQUIRED_FUNCTIONS[module].length;
    totalFound += found[module].length;
    totalMissing += missing[module].length;
    totalPartial += partial[module].length;
  }
  
  // Print summary
  console.log('='.repeat(80));
  console.log('📊 SUMMARY');
  console.log('='.repeat(80));
  console.log(`Total Required Functions: ${totalRequired}`);
  console.log(`✅ Implemented: ${totalFound} (${((totalFound/totalRequired)*100).toFixed(1)}%)`);
  console.log(`⚠️  Partial Matches: ${totalPartial} (${((totalPartial/totalRequired)*100).toFixed(1)}%)`);
  console.log(`❌ Missing: ${totalMissing} (${((totalMissing/totalRequired)*100).toFixed(1)}%)`);
  console.log('='.repeat(80));
  
  // Priority analysis
  const criticalModules = ['auth', 'finance', 'portals', 'workflows', 'realtime'];
  let criticalMissing = 0;
  let criticalTotal = 0;
  
  for (const module of criticalModules) {
    if (REQUIRED_FUNCTIONS[module]) {
      criticalTotal += REQUIRED_FUNCTIONS[module].length;
      criticalMissing += missing[module] ? missing[module].length : 0;
    }
  }
  
  console.log('\n🚨 CRITICAL MODULES ANALYSIS');
  console.log('='.repeat(80));
  console.log(`Critical Functions Missing: ${criticalMissing}/${criticalTotal} (${((criticalMissing/criticalTotal)*100).toFixed(1)}%)`);
  
  // Print missing functions by priority
  console.log('\n❌ MISSING FUNCTIONS BY MODULE (Priority Order)\n');
  console.log('='.repeat(80));
  
  // Critical modules first
  for (const module of criticalModules) {
    if (missing[module] && missing[module].length > 0) {
      console.log(`\n🚨 ${module.toUpperCase()} MODULE - CRITICAL (${missing[module].length} missing):`);
      missing[module].forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
    }
  }
  
  // Other modules
  for (const [module, functions] of Object.entries(missing)) {
    if (!criticalModules.includes(module) && functions.length > 0) {
      console.log(`\n📦 ${module.toUpperCase()} MODULE (${functions.length} missing):`);
      functions.forEach(fn => {
        console.log(`   ❌ ${fn}`);
      });
    }
  }
  
  // Print partial matches
  if (totalPartial > 0) {
    console.log('\n⚠️  PARTIAL MATCHES (might be implemented with different names)\n');
    console.log('='.repeat(80));
    
    for (const [module, matches] of Object.entries(partial)) {
      if (matches.length > 0) {
        console.log(`\n📦 ${module.toUpperCase()} MODULE:`);
        matches.forEach(({ required, found }) => {
          console.log(`   ⚠️  ${required} → might be: ${found}`);
        });
      }
    }
  }
  
  // Generate JSON report
  const report = {
    timestamp: new Date().toISOString(),
    summary: {
      totalRequired,
      totalFound,
      totalPartial,
      totalMissing,
      completionPercentage: ((totalFound/totalRequired)*100).toFixed(1),
      criticalMissing,
      criticalTotal,
      criticalCompletionPercentage: (((criticalTotal-criticalMissing)/criticalTotal)*100).toFixed(1)
    },
    missing,
    found,
    partial,
    scannedFiles: scannedFiles.map(f => f.file),
    implementedFunctions: Array.from(implementedFunctions)
  };
  
  // Save report to file
  try {
    fs.writeFileSync('./backend-functions-report.json', JSON.stringify(report, null, 2));
    console.log('\n💾 Report saved to: backend-functions-report.json');
  } catch (error) {
    console.error('Error saving report:', error.message);
  }
  
  return report;
}

// Run the checker
if (require.main === module) {
  generateReport();
}

module.exports = { generateReport, scanBackend, findMissingFunctions };